# FV-01 final release-gate evidence

Status: RELEASE-GATE-PASS for the exact source identified in FINAL_FV01_RELEASE_GATE.md. No deployment/submission authorization is implied. Reports, logs, genuine screenshots and synthetic QA data are included; Chromium profiles are excluded.

To reproduce, install/build the exact candidate and serve dist on 127.0.0.1:5290 using tools/serve.mjs makeServer. Set SS_CANDIDATE_ROOT to the extracted SemesterSpace root, SS_ORIGIN to that HTTP origin, SS_EVIDENCE_DIR to a fresh QA working directory containing the included qa-seed.json and synthetic-*.pdf, and SS_CHROMIUM to the installed Chromium path if needed. Keep scripts together. Run:

```sh
node fv01-gate-browser.mjs
node initial-browser.mjs
node connected-browser.mjs
node native-and-negative.mjs
node calendar-write-failure.mjs
```

All exited 0 on this candidate. Run connected-browser before native-and-negative/calendar-write-failure because it creates their native persistent profile/expected accepted envelope. Use a fresh profile directory per full run; do not run on personal student data. Runtime latency and Storage fault injection are documented; UI, extraction, engine/controller/storage modules are the actual candidate. No inline mock app is substituted.

The final handoff also contains the unchanged candidate ZIP, verified static build ZIP, build integrity manifest and ready-to-paste PROMPT_FOR_CHAT_A.md. The source manifest in the candidate covers its original payload; evidence is separately checksummed. Deployment remains an explicitly approved A action.
