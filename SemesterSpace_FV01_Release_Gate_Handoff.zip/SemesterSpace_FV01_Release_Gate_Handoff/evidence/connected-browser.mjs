import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {openProfile,shot,fail,state,evidence} from './browser-common.mjs';
const seed=JSON.parse(await readFile(evidence+'/qa-seed.json'));
const {context,page,errors,consoleErrors,external}=await openProfile('connected-release-r3','2026-10-26T14:30:00Z',seed);
const report={scenario:'Production dist, native persistent Chromium profile, synthetic QA model and actual generated PDF notice',clock:'2026-10-26 20:00 Asia/Kolkata',steps:[]};
const log=async(name,extra={})=>{const x={name,revision:(await state(page)).model.revision,...extra};report.steps.push(x);console.log(JSON.stringify(x));await writeFile(evidence+'/connected-browser-progress.json',JSON.stringify(report,null,2));};
const check=async(label)=>page.getByLabel(label,{exact:true}).check();
const nav=async(name)=>page.getByRole('button',{name,exact:true}).click();
async function closeDay(date,disposition=null){
 await page.getByLabel('Attendance day to review',{exact:true}).fill(date);await page.getByLabel('Attendance day to review',{exact:true}).dispatchEvent('change');
 if(disposition)for(const x of await page.getByLabel('What happened?',{exact:true}).all())await x.selectOption(disposition);
 await check('Every listed session has ended, and these marks reflect what happened');await check('No additional attendance meetings took place on this date');
 const rev=(await state(page)).model.revision;await page.getByRole('button',{name:'Confirm completed attendance day',exact:true}).click();
 await page.waitForFunction(rev=>window.__QA_APP__.getState().model.revision>rev,rev);await log('day-confirmed',{date,disposition});
}
async function prepareReview(){
 await page.locator('[data-revision-intake] details').evaluateAll(nodes=>nodes.forEach(n=>n.open=true));
 await page.getByLabel('Academic term',{exact:true}).selectOption('ODD');await page.getByLabel('Degree group',{exact:true}).selectOption('UG');
 await page.getByLabel('Practical subgroup',{exact:true}).fill('Q3');await page.getByLabel('Programming group',{exact:true}).fill('Q23');
 await check('I checked this notice against my actual course, cohort, and confirmed teaching dates');
 await check('I manually checked the original calendar and acknowledge that old source links cannot be reconstructed');
 await page.getByLabel('Which prior documents and rows did you review?',{exact:true}).fill('SYNTHETIC QA: reviewed QA-prior-calendar.pdf and this generated notice. Old links cannot be invented.');
 await page.getByLabel('I compared original page 1 with extracted entries, captions and footnotes',{exact:true}).check();
 for(const card of await page.locator('[data-revision-effect]').all()){
  const json=card.getByLabel('Proposed calendar entry (editable JSON)',{exact:false});const after=JSON.parse(await json.inputValue());
  if('start' in after){after.start='10:00';after.end='11:00';await json.fill(JSON.stringify(after,null,2));}
  await card.getByLabel('I verified this entry is applicable to my section/cohort',{exact:true}).check();await card.getByLabel('I checked the meaning and effective date against the source',{exact:true}).check();await card.getByLabel('Include this interpreted effect in the comparison',{exact:true}).check();
 }
 await page.getByLabel('What did you manually verify on EVERY page (including legend, cohort, exams, notes, cancellations, rescheduling, end dates)?',{exact:true}).fill('SYNTHETIC QA only: compared every printed row, date and source page; no institutional or personal confirmations. No missing row was treated as deletion.');
 await check('I checked the source and manually resolved any relevant omissions (PARTIAL still means extraction was partial)');await check('I explicitly reviewed all interpretations, source evidence and exclusions before comparing');
 await page.getByRole('button',{name:'Prepare comparison (no schedule change)',exact:true}).click();await page.getByRole('heading',{name:'Comparison — not yet staged',exact:true}).waitFor();
}
try{
 assert.equal((await state(page)).persistence.status,'SAVED');await log('legacy-native-seed-loaded');
 // Unresolved outcomes must not write a completed day.
 const original=await page.evaluate(()=>localStorage.getItem('semesterspace.v1'));
 await page.getByRole('button',{name:'Confirm completed attendance day',exact:true}).click();assert.equal(await page.evaluate(()=>localStorage.getItem('semesterspace.v1')),original);await log('unknown-day-blocked');
 await closeDay('2026-10-24');await closeDay('2026-10-25');await closeDay('2026-10-26','MISSED');
 let s=await state(page);assert.deepEqual(s.model.snapshots.at(-1).counts.r,{attended:90,held:101});
 await check('I want to correct this previously closed day');await page.getByLabel('What happened?',{exact:true}).selectOption('ATTENDED');
 await check('Every listed session has ended, and these marks reflect what happened');await check('No additional attendance meetings took place on this date');await check('Keep the original record and save this as a correction');
 let rev=(await state(page)).model.revision;await page.getByRole('button',{name:'Submit attendance correction',exact:true}).click();await page.waitForFunction(rev=>window.__QA_APP__.getState().model.revision>rev,rev);
 s=await state(page);assert.deepEqual(s.model.snapshots.at(-1).counts.r,{attended:91,held:101});assert.equal(s.release.attendance.records.length,2);assert.equal(s.release.attendance.records[1].supersedesRecordId,s.release.attendance.records[0].recordId);await log('attendance-correction-preserves-history');
 await page.locator('[data-release-attendance]').scrollIntoViewIfNeeded();await shot(page,'03-attendance-desktop');await shot(page,'04-attendance-mobile',true);await page.setViewportSize({width:1440,height:1000});
 await nav('Setup & history');await page.locator('[data-ui-panel="existing-setup-controls"], [data-ui-panel="existing-snapshot"]').evaluateAll(n=>n.forEach(x=>x.open=true));
 const form=page.locator('form[data-form-group="snapshot"]');await form.locator('[data-ui-key="snapshot::date"]').fill('2026-10-26');await form.locator('[data-ui-key="snapshot::r:attended"]').fill('79');await form.locator('[data-ui-key="snapshot::r:held"]').fill('100');await form.locator('[data-ui-key="snapshot::confirm"]').check();await form.locator('[data-ui-key="snapshot::today"]').check();
 rev=(await state(page)).model.revision;await form.getByRole('button',{name:'Confirm new snapshot',exact:true}).click();await page.waitForFunction(rev=>window.__QA_APP__.getState().model.revision>rev,rev);
 s=await state(page);assert.deepEqual(s.model.snapshots.at(-1).counts.r,{attended:79,held:100});assert.ok(s.release.attendance.officialSnapshotIds.includes(s.model.snapshots.at(-1).id));assert.ok(s.release.attendance.reconciliationIssues.some(x=>JSON.stringify(x).includes('OFFICIAL_COUNT_DISCREPANCY')));assert.equal(s.release.attendance.records.length,2);await log('official-baseline-reconciled-with-discrepancy');
 // Real Storage.setItem failure, not a stub controller. Preserve stored bytes and state.
 const beforeFail=await state(page),bytes=await page.evaluate(()=>localStorage.getItem('semesterspace.v1'));
 await page.evaluate(()=>{window.__qaSetItem=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='semesterspace.v1')throw new DOMException('Synthetic QA quota fault','QuotaExceededError');return window.__qaSetItem.call(this,k,v);};});
 await form.locator('[data-ui-key="snapshot::r:attended"]').fill('80');await form.locator('[data-ui-key="snapshot::confirm"]').check();await form.locator('[data-ui-key="snapshot::today"]').check();await form.getByRole('button',{name:'Confirm new snapshot',exact:true}).click();
 await page.waitForFunction(()=>window.__QA_APP__.getState().persistence.status==='FAILED');const afterFail=await state(page);assert.deepEqual(afterFail.model,beforeFail.model);assert.deepEqual(afterFail.release,beforeFail.release);assert.equal(await page.evaluate(()=>localStorage.getItem('semesterspace.v1')),bytes);await log('storage-fault-atomic-rollback');await shot(page,'05-storage-failure-desktop');
 await page.evaluate(()=>{Storage.prototype.setItem=window.__qaSetItem;delete window.__qaSetItem;});
 await nav('Calendar updates');await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-revision.pdf');await page.getByRole('button',{name:'Read selected calendar',exact:true}).click();await page.getByText(/Reader result: PARTIAL/).waitFor({timeout:180000});
 assert.equal(await page.locator('[data-revision-effect]').count(),3);await page.locator('[data-revision-intake] details').evaluateAll(n=>n.forEach(x=>x.open=true));
 await page.getByRole('button',{name:'Prepare comparison (no schedule change)',exact:true}).click();assert.equal(await page.locator('.revision-compare').count(),0);assert.equal(await page.evaluate(()=>localStorage.getItem('semesterspace.v1')),bytes);await log('unreviewed-source-blocked');
 await prepareReview();assert.match(await page.locator('.revision-compare').innerText(),/0 unresolved/);await log('actual-pdf-comparison-ready');await page.locator('.revision-compare').scrollIntoViewIfNeeded();await shot(page,'06-comparison-desktop');
 // Delay the *real* A staging callback result after A has staged the real proposal.
 await page.evaluate(()=>{const callbacks=window.__QA_APP__.callbacks;window.__qaOriginalStage=callbacks.onProposeCalendarRevision;callbacks.onProposeCalendarRevision=async req=>{const result=window.__qaOriginalStage(req);await new Promise(resolve=>window.__qaReleaseStage=resolve);return result;};});
 await check('I have read this comparison and understand that staged items are not yet applied');await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).click();await page.waitForFunction(()=>typeof window.__qaReleaseStage==='function');
 await page.getByLabel('Which prior documents and rows did you review?',{exact:true}).fill('SYNTHETIC QA: edited review while actual A staging result was delayed.');await page.evaluate(()=>window.__qaReleaseStage());await page.waitForFunction(()=>window.__QA_APP__.getState().stagedCalendarRevision!==null);
 await page.getByRole('button',{name:'Calendar updates',exact:true}).click();assert.ok(await page.getByRole('button',{name:'Apply selected calendar changes',exact:true}).isDisabled());assert.equal((await state(page)).model.revision,rev+1);await log('delayed-stage-after-review-edit-blocked');
 await page.evaluate(()=>{window.__QA_APP__.callbacks.onProposeCalendarRevision=window.__qaOriginalStage;delete window.__qaOriginalStage;delete window.__qaReleaseStage;});
 // Re-prepare reviewed source, then delay and replace its document before result delivery.
 await page.locator('[data-revision-intake] details').evaluateAll(n=>n.forEach(x=>x.open=true));
 await page.getByLabel('I explicitly reviewed all interpretations, source evidence and exclusions before comparing',{exact:true}).check();await page.getByRole('button',{name:'Prepare comparison (no schedule change)',exact:true}).click();
 assert.equal(await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).isDisabled(),false,'FV-01 recovery must work without rereading');
 await log('corrected-comparison-stage-enabled-without-reread');
 await page.evaluate(()=>{const callbacks=window.__QA_APP__.callbacks;window.__qaOriginalStage=callbacks.onProposeCalendarRevision;callbacks.onProposeCalendarRevision=async req=>{const result=window.__qaOriginalStage(req);await new Promise(resolve=>window.__qaReleaseStage=resolve);return result;};});
 await check('I have read this comparison and understand that staged items are not yet applied');await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).click();await page.waitForFunction(()=>typeof window.__qaReleaseStage==='function');
 await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-replacement.pdf');await page.evaluate(()=>window.__qaReleaseStage());await nav('Calendar updates');assert.ok(await page.getByRole('button',{name:'Apply selected calendar changes',exact:true}).isDisabled());assert.match(await page.locator('[data-revision-intake]').innerText(),/synthetic-replacement/);await log('delayed-stage-after-replacement-blocked');
 await page.evaluate(()=>{window.__QA_APP__.callbacks.onProposeCalendarRevision=window.__qaOriginalStage;delete window.__qaOriginalStage;delete window.__qaReleaseStage;});
 await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-revision.pdf');await page.getByRole('button',{name:'Read selected calendar',exact:true}).click();await page.getByText(/Reader result: PARTIAL/).waitFor({timeout:180000});await prepareReview();await check('I have read this comparison and understand that staged items are not yet applied');await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).click();
 await page.waitForFunction(()=>window.__QA_APP__.getState().stagedCalendarRevision!==null);await page.getByRole('button',{name:'Apply selected calendar changes',exact:true}).waitFor();
 const applyRows=page.locator('[data-release-revision] > .revision-change');assert.equal(await applyRows.count(),3);
 for(const row of await applyRows.all())if(!(await row.innerText()).includes('2026-11-06'))await row.getByLabel('Include this change in the application',{exact:true}).check();
 await check('I have reviewed source coverage, my cohort and every relevant calendar page, including omissions');await check('Apply the checked changes only; retain past attendance and existing commitments for re-evaluation');
 const beforeApply=await state(page);await page.getByRole('button',{name:'Apply selected calendar changes',exact:true}).click();await page.waitForFunction(rev=>window.__QA_APP__.getState().model.revision>rev,beforeApply.model.revision);
 s=await state(page);assert.ok(s.model.schedule.holidays.some(x=>x.date==='2026-11-04'));assert.ok(!s.model.schedule.holidays.some(x=>x.date==='2026-11-06'));assert.ok(s.model.events.some(x=>x.date==='2026-11-02'));assert.deepEqual(s.model.commitments,beforeApply.model.commitments);assert.deepEqual(s.model.snapshots,beforeApply.model.snapshots);assert.deepEqual(s.release.calendar.sourceRevision.sourceHistory,[seed.release.calendar.sourceRevision]);assert.equal(s.release.calendar.sourceRevision.links.length,2);
 assert.equal(await page.evaluate(()=>window.__QA_APP__.getResults().evaluation.status),'PLAN_BLOCKED');await log('selective-apply-retains-history-and-invalid-commitment',{links:2});
 await nav('Calendar & breaks');await shot(page,'07-recalculated-calendar-desktop');await shot(page,'08-recalculated-calendar-mobile',true);report.mobileWidth=await page.evaluate(()=>({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth}));assert.ok(report.mobileWidth.scroll<=report.mobileWidth.client);
 report.savedEnvelope=JSON.parse(await page.evaluate(()=>localStorage.getItem('semesterspace.v1')));await writeFile(evidence+'/expected-native-envelope.json',JSON.stringify(report.savedEnvelope,null,2));
 report.pageErrors=errors;report.consoleErrors=consoleErrors;report.externalRequests=external;assert.deepEqual(errors,[]);assert.deepEqual(external,[]);await writeFile(evidence+'/connected-browser-report.json',JSON.stringify(report,null,2));
}catch(e){await fail(page,'connected',e);await writeFile(evidence+'/connected-browser-failure.json',JSON.stringify({message:e.message,errors,consoleErrors,external,steps:report.steps},null,2));throw e;}finally{await context.close();}
