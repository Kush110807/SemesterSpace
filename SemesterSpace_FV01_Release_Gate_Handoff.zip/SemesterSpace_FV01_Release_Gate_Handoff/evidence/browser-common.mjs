import {mkdir,writeFile} from 'node:fs/promises';
export const root=process.env.SS_CANDIDATE_ROOT??'/workspace/ss-fv01-candidate/SemesterSpace',evidence=process.env.SS_EVIDENCE_DIR??'/workspace/ss-fv01-gate-evidence',origin=process.env.SS_ORIGIN??'http://127.0.0.1:5290';
const {chromium}=await import(root+'/semester-space/node_modules/playwright/index.mjs');
export async function openProfile(name,time,seed=null){
 const context=await chromium.launchPersistentContext(evidence+'/profiles/'+name,{executablePath:process.env.SS_CHROMIUM??'/usr/bin/chromium',headless:true,viewport:{width:1440,height:1000},args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=context.pages()[0]??await context.newPage(),errors=[],consoleErrors=[],external=[],consoleDetails=[],resourceFailures=[];
 page.on('response',r=>{if(r.status()>=400)resourceFailures.push({url:r.url(),status:r.status()});});page.on('console',m=>{if(m.type()==='error')consoleDetails.push({text:m.text(),location:m.location()});});
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});page.on('request',r=>{if(!r.url().startsWith(origin)&&!r.url().startsWith('blob:')&&!r.url().startsWith('data:'))external.push(r.url());});
 await page.clock.install({time:new Date(time)});
 if(seed)await context.addInitScript(({seed,origin})=>{if(location.origin===origin&&!localStorage.getItem('semesterspace.v1'))localStorage.setItem('semesterspace.v1',JSON.stringify(seed));},{seed,origin});
 // Read the actual main.js module's controller through DevTools; no source replacement or mock.
 const cdp=await context.newCDPSession(page);await cdp.send('Debugger.enable');
 const {breakpointId}=await cdp.send('Debugger.setBreakpointByUrl',{url:origin+'/src/main.js',lineNumber:12});
 cdp.on('Debugger.paused',async({callFrames})=>{try{await cdp.send('Debugger.evaluateOnCallFrame',{callFrameId:callFrames[0].callFrameId,expression:'window.__QA_APP__=app'});await cdp.send('Debugger.removeBreakpoint',{breakpointId});}finally{await cdp.send('Debugger.resume');}});
 await page.goto(origin);await page.waitForFunction(()=>window.__QA_APP__);
 return {context,page,errors,consoleErrors,external,consoleDetails,resourceFailures};
}
export async function shot(page,name,mobile=false){await page.setViewportSize(mobile?{width:390,height:844}:{width:1440,height:1000});await page.screenshot({path:evidence+'/'+name+'.png',fullPage:false});}
export async function fail(page,name,error){await writeFile(evidence+'/'+name+'-failure.txt',String(error.stack??error)+'\n'+await page.locator('body').innerText());await writeFile(evidence+'/'+name+'-failure.html',await page.content());await shot(page,name+'-failure');}
export const state=page=>page.evaluate(()=>window.__QA_APP__.getState());
