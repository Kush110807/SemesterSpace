import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {openProfile,shot,fail,state,evidence} from './browser-common.mjs';
import {prepareReview} from './review-helper.mjs';
const seed=JSON.parse(await readFile(evidence+'/qa-seed.json'));
const {context,page,errors,external}=await openProfile('fv01-final-gate','2026-10-26T14:30:00Z',seed);
const report={scenario:'Genuine production-dist Chromium, actual PDF reader, C UI and A staging; result delivery latency only',readSelectedCalendarClicks:0};
async function compare(note){
 await page.locator('[data-revision-intake] details').evaluateAll(n=>n.forEach(d=>d.open=true));
 await page.getByLabel('Which prior documents and rows did you review?',{exact:true}).fill(note);
 await page.getByLabel('I explicitly reviewed all interpretations, source evidence and exclusions before comparing',{exact:true}).check();
 await page.getByRole('button',{name:'Prepare comparison (no schedule change)',exact:true}).click();assert.match(await page.locator('.revision-compare').innerText(),/0 unresolved/);
 await page.getByLabel('I have read this comparison and understand that staged items are not yet applied',{exact:true}).check();assert.ok(await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).isEnabled());
}
async function start(count){await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).click();await page.waitForFunction(n=>window.__fvPending.length===n,count);}
async function deliver(index){await page.evaluate(i=>window.__fvPending[i].resolve(),index);await page.waitForFunction(i=>window.__fvPending[i].delivered,index);}
async function applyEnabled(){return page.getByRole('button',{name:'Apply selected calendar changes',exact:true}).isEnabled();}
try{
 await page.getByRole('button',{name:'Calendar updates',exact:true}).click();await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-revision.pdf');await page.getByRole('button',{name:'Read selected calendar',exact:true}).click();report.readSelectedCalendarClicks++;
 await page.getByText(/Reader result: PARTIAL/).waitFor({timeout:180000});await prepareReview(page);
 const bytes=await page.evaluate(()=>localStorage.getItem('semesterspace.v1'));
 await page.evaluate(()=>{window.__fvPending=[];const c=window.__QA_APP__.callbacks;window.__fvOriginal=c.onProposeCalendarRevision;c.onProposeCalendarRevision=async request=>{const result=window.__fvOriginal(request),entry={request:structuredClone(request),result,delivered:false};await new Promise(resolve=>{entry.resolve=resolve;window.__fvPending.push(entry);});entry.delivered=true;return result;};});
 await page.getByLabel('I have read this comparison and understand that staged items are not yet applied',{exact:true}).check();await start(1);
 await page.getByLabel('Which prior documents and rows did you review?',{exact:true}).fill('SYNTHETIC QA: edit review while real staging response is delayed.');await deliver(0);assert.equal(await applyEnabled(),false);report.staleApplyBlockedAfterReviewEdit=true;
 await compare('SYNTHETIC QA: explicitly renewed corrected review, no reread.');await start(2);await deliver(1);assert.equal(await applyEnabled(),true);
 const accepted=(await state(page)).stagedCalendarRevision,requests=await page.evaluate(()=>window.__fvPending.map(x=>x.request));assert.equal(accepted.proposalId,requests[1].proposal.proposalId);assert.notEqual(accepted.proposalId,requests[0].proposal.proposalId);assert.deepEqual(accepted.changes.map(c=>c.changeId),requests[0].proposal.changes.map(c=>c.changeId));
 report.correctedProposalSuccessfullyStagedWithoutReread=true;report.sameDraftEffectIds=true;
 await page.locator('.revision-compare').scrollIntoViewIfNeeded();await shot(page,'FV01-corrected-stage-desktop');await shot(page,'FV01-corrected-stage-mobile',true);await page.setViewportSize({width:1440,height:1000});
 // A newer request must remain busy when an obsolete request completes.
 await compare('SYNTHETIC QA: begin overlap request A.');await start(3);await compare('SYNTHETIC QA: begin newer overlap request B.');await start(4);await deliver(2);
 assert.equal(await applyEnabled(),false);const pending=await page.evaluate(()=>window.__fvPending.length);const stage=page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true});if(await stage.isEnabled())await stage.click();assert.equal(await page.evaluate(()=>window.__fvPending.length),pending);
 report.oldCompletionDidNotReleaseNewerStage=true;await deliver(3);assert.equal(await applyEnabled(),true);report.newerResponseAuthorizedOnlyCurrentProposal=true;
 // Replacing the document while a genuine result is pending must revoke apply authority.
 await compare('SYNTHETIC QA: pending response before document replacement.');await start(5);await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-replacement.pdf');await deliver(4);assert.equal(await applyEnabled(),false);assert.match(await page.locator('[data-revision-intake]').innerText(),/synthetic-replacement.pdf/);report.staleApplyBlockedAfterReplacement=true;
 assert.equal(await page.evaluate(()=>localStorage.getItem('semesterspace.v1')),bytes);assert.equal((await state(page)).model.revision,7);report.noPersistedChangesFromStaging=true;report.realControllerCalls=await page.evaluate(()=>window.__fvPending.length);report.actualAResponses=await page.evaluate(()=>window.__fvPending.map(x=>x.result));
 report.pageErrors=errors;report.externalRequests=external;assert.deepEqual(errors,[]);assert.deepEqual(external,[]);await writeFile(evidence+'/fv01-gate-browser-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}catch(e){await fail(page,'fv01-gate',e);throw e;}finally{await context.close();}
