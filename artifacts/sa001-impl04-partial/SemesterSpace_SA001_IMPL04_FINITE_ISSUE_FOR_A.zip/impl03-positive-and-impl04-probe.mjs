// Exact finite overlay checks; standalone writer observations do not invent controller memory.
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {saveModel,loadModel} from '../../../src/storage.js';
import * as engine from '../../../src/engine/index.js';
const out=process.argv[2];if(!out?.startsWith('/'))throw Error('Absolute new output directory required');await mkdir(out);
const amendment='/workspace/sa001-impl03-amendment',root='/workspace/sa001-contract/contract/F_AMENDED_0_1_4',sha=x=>createHash('sha256').update(x).digest('hex'),oracle=JSON.parse(await readFile(amendment+'/active/F011_EXACT_TEST_VARIANTS_A_IMPL03_CORRECTED.json','utf8'));
const cases=[];
const positiveRaw=await readFile(amendment+'/active/fixtures/E2_B2_RELEASE1_OPAQUE_HISTORY_A_IMPL03.json','utf8'),originalRaw=await readFile(root+'/fixtures/E2_B2_OPAQUE_HISTORY.json','utf8');
for(const [id,raw,positive]of [['F-SA-02a',positiveRaw,true],['A-IMPL03-NEG',originalRaw,false]]){
 const input=JSON.parse(raw),releaseBefore=JSON.stringify(input.release),modelBefore=JSON.stringify(input.model);let disk=raw,reads=0,writes=0,getters=0;
 const candidate=structuredClone(input);if(!positive)Object.defineProperty(candidate.model,'id',{get(){getters++;throw Error('Hostile model getter');},enumerable:true});
 const storage={getItem(){reads++;return disk;},setItem(k,v){writes++;disk=v;}};
 const result=saveModel(storage,candidate.model,candidate.release,{});assert.equal(reads,1);assert.equal(writes,positive?1:0);assert.equal(getters,0);
 if(positive){assert.deepEqual([result.status,result.code],['SAVED','SAVE_OK']);assert.notEqual(disk,raw);assert.deepEqual(JSON.parse(disk),input);assert.equal(JSON.stringify(input.release),releaseBefore);assert.equal(JSON.stringify(input.model),modelBefore);}
 else {assert.deepEqual([result.status,result.code,result.reason,result.path],['FAILED','UNSUPPORTED_PERSISTED_VERSION','VERSION','/release/version']);assert.equal(disk,raw);}
 const attemptReads=reads;let reload=null;if(positive){const beforeReload=reads;reload=loadModel(storage,engine.validateModel,{date:'9999-12-31',time:'23:59',timeZone:'Asia/Kolkata'});assert.equal(reads-beforeReload,1);assert.equal(reload.persistence.status,'SAVED');assert.deepEqual(reload.model,input.model);assert.deepEqual(reload.release,input.release);}
 cases.push({id,classification:'CODEX_EXECUTED_STANDALONE_WRITER_FINITE_CONTROL',inputSHA256:sha(raw),result,attempt:{reads:attemptReads,writes,candidateGetterInvocations:getters},diagnosticReloadReads:positive?1:0,acceptedMemoryDisposition:'NOT_OBSERVED_STANDALONE_WRITER_HAS_NO_CONTROLLER',fullModelAndReleasePreserved:positive?true:null,before:raw,after:disk,reload});
}
const vector=oracle.variants.find(v=>v.variantId==='F-SA-40-optional-old-link'),raw=await readFile(root+'/fixtures/E2_WITH_REAL_LEDGER_HISTORY.json','utf8'),fixture=JSON.parse(raw);assert.equal(fixture.schemaVersion,2);assert.equal(fixture.release.version,2);
for(const m of vector.fixture.mutations){assert.equal(m.target,'both');assert.equal(m.op,'delete');assert.ok(['/release/calendar/sourceRevision/links/0/value','/release/calendar/sourceRevision/links/0/changeId'].includes(m.path));delete fixture.release.calendar.sourceRevision.links[0][m.path.split('/').at(-1)];}
const before=JSON.stringify(fixture,null,2)+'\n',observations=[];
const accepted=await import('/workspace/SemesterSpace-diamond-001/semester-space/src/storage.js');
for(const [writer,save]of [['unchanged-accepted-T1',accepted.saveModel],['SA-partial-legacy-writer',saveModel]]){
 let disk=before,reads=0,writes=0,getters=0;const candidate=structuredClone(fixture),releaseBefore=JSON.stringify(candidate.release);Object.defineProperty(candidate.model,'id',{get(){getters++;throw Error('Hostile candidate access');},enumerable:true});
 const result=save({getItem(){reads++;return disk;},setItem(k,v){writes++;disk=v;}},candidate.model,candidate.release,{});
 assert.deepEqual([result.status,result.code,result.reason,result.path],['FAILED','UNSUPPORTED_PERSISTED_VERSION','VERSION','/release/version']);assert.equal(reads,1);assert.equal(writes,0);assert.equal(getters,0);assert.equal(disk,before);assert.equal(JSON.stringify(candidate.release),releaseBefore);
 observations.push({writer,result,reads,writes,getters,beforeSha256:sha(before),afterSha256:sha(disk),releaseUnchanged:true});
}
const report={issue:'SA-C1-IMPL-04',classification:'CONFIRMED_ADJACENT_FROZEN_B2_INPUT_CONTRADICTION',node:process.version,positiveAndSupplemental:cases,activeFSA40:vector,originalFixture:{path:'fixtures/E2_WITH_REAL_LEDGER_HISTORY.json',sha256:sha(raw),schemaVersion:2,releaseVersion:2},exactMutatedStoredText:before,observations,SA001:'OPEN P1'};
await writeFile(out+'/report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({positiveAndSupplemental:cases.map(({before,after,reload,...c})=>c),originalFixture:report.originalFixture,observations},null,2));
