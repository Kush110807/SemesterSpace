# SA-001 Codex Phase 2 — Original-run omitted evidence (read-only)

This is a SUPPLEMENT to `SA001_Readonly_Forensic_Reports_2026-11-05.zip`, **not** a replacement for the full original 488 MB artifact. It contains original archive members byte-for-byte under `original/` with their original internal paths and SHA-256 in `SOURCE_MEMBER_MANIFEST.json`.

Chat A HQ has independently compared all 170 members used in the first Codex audit against the full original archive; all 170 were identical. The original archive SHA-256 is included in the manifest.

## Your mandate

1. Review original-run `ack-physical`, `lifetime`, `capacity`, `adversarial`, old/new reopen, build and overlay-identity records. Read `SOURCE_MEMBER_MANIFEST.json` and independently hash every included member.
2. Reconcile these records against the **existing** `SA001_152_CASE_ACCEPTANCE_MATRIX.csv` and full F152 contract; identify which variant-specific controller/ACK/lifecycle/load obligations gain corroboration and which remain NOT_OBSERVED. A shared-invariant observation can cover a case only with a justified evidence binding.
3. Investigate the two persisted-byte cases and the 18 getter cases with this extra source data, without inventing zero getter calls.
4. Reconcile build/source overlay identity and existing physical ACK/native-reopen evidence; retain separate labels for historical before/after original forgery proof, original replay, same-run provenance and new tests.
5. Update the existing outputs, preserving the original report and delta evidence. Return a source-addressed `PHASE2_DELTA.md`, updated case matrix, outstanding missing observation list and minimum further evidence actions.

Restrictions: static parsing and hashing only; no application execution, no CI, browser, repo edits, commits, pushes, deployment or activation. A pass in a producer report is not direct proof of full security acceptance. Full original artifact attestation remains a separate independent-review requirement. SA-001 OPEN P1.
