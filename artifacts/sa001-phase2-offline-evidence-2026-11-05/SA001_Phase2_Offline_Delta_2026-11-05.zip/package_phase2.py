#!/usr/bin/env python3
"""Read-only preservation checks and local report/evidence packaging. No Git mutations/network."""
import pathlib,hashlib,json,csv,subprocess,os,shutil,zipfile,sys
W=pathlib.Path('/workspace/sa001-phase2-investigation-2026-11-05');P=pathlib.Path('/workspace/sa001-phase2-input-2026-11-05');S=P/'original';O=W/'outputs';A=W/'audit';W1=pathlib.Path('/workspace/sa001-readonly-investigation-2026-11-05');repo=pathlib.Path('/workspace/SemesterSpace-sa-001')
def load(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
state={}
for k,args in {'identity':['rev-parse','HEAD','HEAD^','HEAD^{tree}'],'status':['status','--porcelain=v1','--untracked-files=all'],'refs':['show-ref'],'worktrees':['worktree','list','--porcelain']}.items():
 z=subprocess.run(['git','-C',str(repo),*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},capture_output=True,text=True);state[k]={'exit':z.returncode,'stdout':z.stdout,'stderr':z.stderr}
dump(W/'after-repository-state.json',state);before=load(W/'before-repository-state.json');checks={k:state[k]==before[k] for k in before}
checks['source269_unchanged_from_prior_static_snapshot']=all(sha(repo/x['path'])==x['local_sha256'] for x in load(W1/'analysis/source-identity-checks.json')['effective'])
checks['41_original_inputs_preserved']=all(sha(S/m['original_archive_member'])==m['sha256'] and (S/m['original_archive_member']).stat().st_size==m['size_bytes'] for m in load(P/'SOURCE_MEMBER_MANIFEST.json')['members'])
oldpacket=pathlib.Path('/workspace/SA001_Readonly_Forensic_Reports_2026-11-05.zip');checks['phase1_packet_unchanged']=sha(oldpacket)=='bfde8f1dd375405e79a6fb4d5092e40d4fcfb720647a67140a949bbf67549670'
refs=W/'phase1-reference';refs.mkdir(exist_ok=True);phase1files=['SA001_152_CASE_ACCEPTANCE_MATRIX.csv','SA001_MISSING_EVIDENCE_RESOLUTION.csv','SOURCE_INDEX.csv','SA001_FORENSIC_VERIFICATION_REPORT.md']
with zipfile.ZipFile(oldpacket) as z:
 for name in phase1files:
  src=W1/'outputs'/name;checks['phase1_'+name+'_unchanged']=z.read('outputs/'+name)==src.read_bytes();shutil.copyfile(src,refs/name)
old=list(csv.DictReader((refs/'SA001_152_CASE_ACCEPTANCE_MATRIX.csv').open()));new=list(csv.DictReader((O/'SA001_152_CASE_ACCEPTANCE_MATRIX_PHASE2.csv').open()));gaps=list(csv.DictReader((O/'SA001_REMAINING_MISSING_EVIDENCE_PHASE2.csv').open()))
checks['all152_original_matrix_values_preserved']=len(new)==152 and all(all(n[k]==o[k] for k in o) for o,n in zip(old,new));checks['full_case_promotions_zero']=all(x['phase2_case_promotion']=='NONE' and x['full_case_accepted']=='False' for x in new);checks['20_measurement_gaps_and149_binding_rows']=sum(x['kind']=='MANDATORY_MISSING_OBSERVATION' for x in gaps)==20 and sum(x['kind']=='INDEPENDENT_REQUIREMENT_BINDING_NOT_DISTINCT_TEST' for x in gaps)==149
checks['final_analysis_zero_failures']=load(A/'summary.json')['failed_checks']==[]
# Keep selected static source snapshots for review; no candidate file is written.
staticref=W/'static-reference';files=[]
for file in ['acknowledgment.mjs','lifetime.mjs','capacity.mjs','adversarial.mjs','browser.mjs']:
 src=repo/'semester-space/tests/sa-001'/file;dest=staticref/'semester-space/tests/sa-001'/file;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);files.append({'original_local_path':str(src),'packet_path':dest.relative_to(W).as_posix(),'sha256':sha(dest),'scope':'Copied static reference only; never executed'})
dump(staticref/'SOURCE_IDENTITIES.json',files)
receipts={'authority':'HQ-SA001-CODEX-PHASE2-OFFLINE/2026-11-05-r1','commands':[{'argv':['python3',str(W/'verify_inputs.py')],'script_sha256':sha(W/'verify_inputs.py'),'exit':int((W/'verify_inputs.exit').read_text()),'stdout':'verify_inputs.stdout','stderr':'verify_inputs.stderr'},{'argv':['python3',str(W/'attempt1-analyze_phase2.py')],'script_sha256':sha(W/'attempt1-analyze_phase2.py'),'exit':int((W/'attempt1-analyze_phase2.exit').read_text()),'stdout':'attempt1-analyze_phase2.stdout','stderr':'attempt1-analyze_phase2.stderr','qualification':'Initially named analyze_phase2.py. Own mistaken raw-file interpretation of historicalIdentitySha256; preserved and corrected using admitted configuration identities. Not a source/security/integrity finding.'},{'argv':['python3',str(W/'analyze_phase2.py')],'script_sha256':sha(W/'analyze_phase2.py'),'exit':int((W/'analyze_phase2.exit').read_text()),'stdout':'analyze_phase2.stdout','stderr':'analyze_phase2.stderr'},{'argv':['python3',str(W/'write_phase2_reports.py')],'script_sha256':sha(W/'write_phase2_reports.py'),'exit':int((W/'write_phase2_reports.exit').read_text()),'stdout':'write_phase2_reports.stdout','stderr':'write_phase2_reports.stderr'},{'argv':['python3',str(W/'package_phase2.py')],'script_sha256':sha(pathlib.Path(__file__)),'qualification':'Read-only Git preservation, matrix consistency and local packaging; final process stdout/exit saved alongside ZIP'}],'git_environment':'GIT_OPTIONAL_LOCKS=0','git_commands':['git -C /workspace/SemesterSpace-sa-001 rev-parse HEAD HEAD^ HEAD^{tree}','git -C /workspace/SemesterSpace-sa-001 status --porcelain=v1 --untracked-files=all','git -C /workspace/SemesterSpace-sa-001 show-ref','git -C /workspace/SemesterSpace-sa-001 worktree list --porcelain'],'no_application_execution':True,'no_network_or_github_write':True,'investigator_attempt_retained':True}
dump(W/'COMMAND_RECEIPTS.json',receipts);dump(W/'PRESERVATION_AND_OUTPUT_CHECKS.json',checks)
if not all(checks.values()):print(json.dumps(checks,indent=2));sys.exit(1)
readme='''# SA-001 Phase2 offline evidence delta — 2026-11-05

SA-001 OPEN P1. Authority HQ-SA001-CODEX-PHASE2-OFFLINE/2026-11-05-r1. No acceptance/waiver or application execution.

Four requested deliverables are in outputs/: PHASE2_DELTA.md; SA001_152_CASE_ACCEPTANCE_MATRIX_PHASE2.csv; SA001_REMAINING_MISSING_EVIDENCE_PHASE2.csv; PHASE2_MINIMUM_VERIFICATION_PLAN.md. PHASE2_SOURCE_INDEX.csv binds exact original paths/SHA. audit/ contains per-control, trace, history, shared-binding and source/build checks.

input/ preserves the supplied Phase2 supplement unchanged. phase1-reference/ preserves the original matrix,20-gap list, index and forensic report; the full Phase1 packet remains a dependency, SHA bfde8f1dd375405e79a6fb4d5092e40d4fcfb720647a67140a949bbf67549670. static-reference/ contains selected byte-matched driver text for static inspection only. Scripts contain recorded absolute paths and require the original Phase1 input tree and approved repository for some cross-checks; do not execute the packaged app/drivers under this authority.

All41 new input members match manifest/original ledger;361 final static consistency checks match. The prior152 matrix values are preserved and new evidence is explicitly scoped shared support. Full-case acceptance stays0/152;18 getter and two immediate byte observations remain absent. The169-row remaining register separates20 observation gaps from149 binding-review rows; it is not169 new tests. All limitations and unavailable/pending gates remain explicit.

COMMAND_RECEIPTS.json includes final static command identities/results and the preserved investigator-only failed interpretation. PRESERVATION_AND_OUTPUT_CHECKS.json verifies unchanged repository state and prior artifacts. MANIFEST.json/SHA256SUMS.txt cover all packet files except those two manifests. The ZIP's own hash/identity and final packaging stdout/exit are sidecars outside the ZIP to avoid self-reference.

No source changes, installs, app/helper tests, browser, CI, commits, pushes, deployment, activation or waiver occurred. No GitHub publication is included under this Phase2 read-only authority. This is a supplement, not the original full488MB archive or independent E/F/D security acceptance.
'''
(W/'README.md').write_text(readme)
items=[]
for root,arcroot in [(W,''),(P,'input')]:
 for f in sorted(root.rglob('*')):
  if not f.is_file():continue
  if root==W and (f.name in ['MANIFEST.json','SHA256SUMS.txt'] or f.name.startswith('ZIP_')):continue
  name=(pathlib.PurePosixPath(arcroot)/f.relative_to(root).as_posix()).as_posix();items.append((f,name))
manifest=[{'path':n,'size_bytes':f.stat().st_size,'sha256':sha(f)} for f,n in items];dump(W/'MANIFEST.json',manifest);(W/'SHA256SUMS.txt').write_text(''.join(x['sha256']+'  '+x['path']+'\n' for x in manifest))
archive=W.parent/'SA001_Phase2_Offline_Delta_2026-11-05.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f,n in items:z.write(f,n)
 z.write(W/'MANIFEST.json','MANIFEST.json');z.write(W/'SHA256SUMS.txt','SHA256SUMS.txt')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for m in manifest:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
info={'archive':str(archive),'size_bytes':archive.stat().st_size,'sha256':sha(archive),'manifested_files':len(manifest),'all_preservation_checks_passed':True,'required_deliverables':4,'full_case_accepted':0,'SA001':'OPEN P1','github_publication':'NOT_PERFORMED_PROHIBITED'};dump(W/'ZIP_IDENTITY.json',info);(W/'ZIP_SHA256.txt').write_text(info['sha256']+'  '+archive.name+'\n');print(json.dumps(info,indent=2))
