import pathlib,hashlib,json,subprocess,os,sys
P=pathlib.Path('/workspace/sa001-phase2-input-2026-11-05');O=pathlib.Path('/workspace/sa001-phase2-investigation-2026-11-05');old=pathlib.Path('/workspace/sa001-readonly-investigation-input-2026-11-05');m=json.loads((P/'SOURCE_MEMBER_MANIFEST.json').read_bytes());ledger=json.loads((old/'FINAL_SHA256.json').read_bytes());checks=[]
for x in m['members']:
 p=P/'original'/x['original_archive_member'];b=p.read_bytes();h=hashlib.sha256(b).hexdigest();checks.append({**x,'actual_sha256':h,'actual_size':len(b),'manifest_match':h==x['sha256'] and len(b)==x['size_bytes'],'phase1_root_ledger_match':ledger.get(x['original_archive_member'])==h,'root_ledger_entry_present':x['original_archive_member'] in ledger})
assert len(checks)==41 and len({x['original_archive_member'] for x in checks})==41
assert all(x['manifest_match'] for x in checks)
repo='/workspace/SemesterSpace-sa-001';state={}
for key,args in {'identity':['rev-parse','HEAD','HEAD^','HEAD^{tree}'],'status':['status','--porcelain=v1','--untracked-files=all'],'refs':['show-ref'],'worktrees':['worktree','list','--porcelain']}.items():
 z=subprocess.run(['git','-C',repo,*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},capture_output=True,text=True);state[key]={'exit':z.returncode,'stdout':z.stdout,'stderr':z.stderr}
(O/'before-repository-state.json').write_text(json.dumps(state,indent=2)+'\n');(O/'member-verification.json').write_text(json.dumps(checks,indent=2)+'\n');summary={'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((P/'SOURCE_MEMBER_MANIFEST.json').read_bytes()).hexdigest(),'members_verified':len(checks),'root_ledger_links_verified':sum(x['phase1_root_ledger_match'] for x in checks),'root_ledger_entries_absent':[x['original_archive_member'] for x in checks if not x['root_ledger_entry_present']]};print(json.dumps(summary,indent=2));(O/'input-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
