#!/usr/bin/env python3
"""Phase2 static-only reconciliation. Reads evidence/source text; executes no application/helper."""
import pathlib,json,csv,hashlib,collections,zipfile,re,sys
W=pathlib.Path('/workspace/sa001-phase2-investigation-2026-11-05');P=pathlib.Path('/workspace/sa001-phase2-input-2026-11-05');O=W/'outputs';A=W/'audit';O.mkdir(exist_ok=True);A.mkdir(exist_ok=True);S=P/'original';R=next((S/'RECOVERED_APPLICATION_EVIDENCE').iterdir());P1=pathlib.Path('/workspace/sa001-readonly-investigation-input-2026-11-05');R1=next((P1/'RECOVERED_APPLICATION_EVIDENCE').iterdir());W1=pathlib.Path('/workspace/sa001-readonly-investigation-2026-11-05');repo=pathlib.Path('/workspace/SemesterSpace-sa-001')
def load(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def compact(d):return json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def dump(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def cite(p,pointer=''):
 root=S if p.is_relative_to(S) else P1
 return dict(original_source_path=p.relative_to(root).as_posix(),sha256=sha(p.read_bytes()),json_pointer=pointer,phase=2 if root==S else 1)
checks=[]
def check(ok,what,kind='EVIDENCE_CONSISTENCY'):
 checks.append(dict(assertion=what,kind=kind,ok=bool(ok)))
 return bool(ok)
def csvout(path,rows):
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
ackp=R/'ack-physical-outputs/report.json';lifep=R/'lifetime-outputs/report.json';capp=R/'capacity-outputs/report.json';advp=R/'adversarial-outputs/report.json';runp=R/'RUN_STATE.json';pre=load(R/'START_PREFLIGHT.json');run=load(runp);L=load(R1/'loaded-assets-binding.json');J=load(R1/'loaded-asset-verification-outputs/binding-result.json');ack=load(ackp);life=load(lifep);cap=load(capp);adv=load(advp);C=load(R1/'oracle-comparator-outputs/reconciliation.json');Cmap={x['id']:x for x in C['cases']}
# Same-run process/build/source identity chain, using independent byte checks only.
histp=S/'container/HISTORICAL_SOURCE_BEFORE_OVERLAY.json';ovp=S/'container/SOURCE_OVERLAY_APPLIED.json';hist=load(histp);ov=load(ovp);plat=load(S/'APPLICATION_PLATFORM_IDENTITY.json')
check(plat['GITHUB_RUN_ID']=='41387922793' and plat['GITHUB_RUN_ATTEMPT']=='1' and plat['GITHUB_SHA']=='1e4413f6791fd76d5676494ff007f35712813d60','platform run identity')
check(plat['GITHUB_REPOSITORY']=='Kush110807/SemesterSpace-SA001-verify','workflow and candidate repositories distinguished')
check(ov['historicalHead']=='acfb6799f699b7868612db346958c9e3d710680f' and ov['historicalTree']=='6b2e0336582a6f205c48374c058b1ac2798fff15','overlay frozen candidate identity')
changed=[p for p,h in ov['historicalSourceFileSha256'].items() if ov['effectiveSourceFileSha256'].get(p)!=h];check(changed==ov['allowedWorktreeDelta']==['semester-space/tests/sa-001/e-finite.mjs'],'exact one-file historical-to-effective overlay')
for p,d,mode in [(histp,hist,'historical'),(ovp,ov,'effective')]:
 key='historicalSourceFileSha256' if mode=='historical' else 'effectiveSourceFileSha256';expected='historicalInventoryCanonicalSha256' if mode=='historical' else 'effectiveInventoryCanonicalSha256';check(sha(compact(d[key]).encode())==d[expected],mode+' inventory canonical hash')
check(hist['effectiveSourceFileSha256']==hist['historicalSourceFileSha256'],'before-overlay clean inventory equality')
for d,label in [(ov,'overlay'),(pre['identity'],'preflight'),(run['source'],'run state')]:
 check(d['effectiveSourceFileSha256']==L['sourceFileSha256'],label+' effective 269-file inventory matches Job28 binding')
 check(d['historicalSourceFileSha256']==L['historicalSourceFileSha256'],label+' historical 269-file inventory matches Job28 binding')
check(ov['historicalIdentitySha256']==pre['runtimeCandidateIdentitySha256']==load(P1/'APPLICATION_APPROVAL_IDENTITY.json')['bindings']['identitySha256'],'overlay historicalIdentitySha256 matches admitted candidate config identity, not raw before-overlay record')
check(pre['identity']['gitPorcelain']==' M semester-space/tests/sa-001/e-finite.mjs','preflight records exact permitted dirty overlay')
check(pre['identity']['indexUnchanged'] is True and ov['indexUnchanged'] is True,'reported source index unchanged')
static=[]
for file,h in pre['reviewedExecutables']['approvedExactHashes'].items():
 p=repo/'semester-space/tests/sa-001'/file
 static.append(dict(path=str(p),sha256=sha(p.read_bytes()) if p.exists() else None,approved_sha256=h,match=p.exists() and sha(p.read_bytes())==h,qualification='Static text comparison only; e-finite effective overlay is not available locally' if file=='e-finite.mjs' else 'Static text comparison only'))
check(sum(not x['match'] for x in static)==1 and next(x for x in static if not x['match'])['path'].endswith('/e-finite.mjs'),'18 reviewed executable hashes: only declared e-finite overlay unavailable')
# Job receipt stdout/stderr and post-build hash inventories. No historical command is run.
metas=[];runmap={x['tag']:x for x in run['results']};build=load(R/'build.meta.json');bd=build['postCheck']['distSha256'];check(bd=={k:v['sha256'] for k,v in L['buildFiles'].items()},'all73 build post-check hashes equal Job28 inventory')
for p in sorted(R.glob('*.meta.json')):
 m=load(p);tag=m['tag'];check(m==runmap[tag],tag+' metadata exactly equals RUN_STATE result')
 row=dict(tag=tag,source=cite(p),argv=m['argv'],status=m['status'],exitCode=m['exitCode'],started=m['startedAtUTC'],finished=m['finishedAtUTC'],stdout=None,stderr=None,build_inventory_match=m['postCheck'].get('distSha256')==bd)
 for stream in ['stdout','stderr']:
  f=R/(tag+'.'+stream)
  if f.exists():
   ok=sha(f.read_bytes())==m[stream+'Sha256'];check(ok,tag+' '+stream+' SHA');row[stream]=cite(f)
 check(m['exitCode']==0 and m['status']=='EXITED',tag+' recorded producer exit0')
 if tag in ['ack-physical','lifetime','capacity','adversarial']:check(row['build_inventory_match'],tag+' same build inventory as Job28')
 metas.append(row)
check(len(run['results'])==28 and all(x['exitCode']==0 for x in run['results']),'RUN_STATE 28 recorded successful process exits; not28 accepted security gates')
check(run['technicalComplete'] is False and run['pendingHumanAndD'] is True,'producer explicitly not technical complete and human/D pending')
check(build['finishedAtUTC']<runmap['browser-native-connected']['startedAtUTC'],'build finished before browser job')
source_build=dict(platform=cite(S/'APPLICATION_PLATFORM_IDENTITY.json'),historical=cite(histp),overlay=cite(ovp),overlay_decision_reference=ov['decisionReference'],overlay_record_reference_sha256=ov['overlayRecordSha256'],overlay_record_reference_bytes_available=False,effective_overlay_source_bytes_available=False,changed_paths=changed,preflight=cite(R/'START_PREFLIGHT.json'),run=cite(runp),build=cite(R/'build.meta.json'),build_stdout=cite(R/'build.stdout'),build_dist_hash_count=len(bd),source_executable_comparisons=static,metas=metas,technical_complete=run['technicalComplete'])
dump(A/'source-build-provenance.json',source_build)
# Decode captured Playwright values inertly, retaining locations and selected summaries.
def decode(x,refs=None):
 refs={} if refs is None else refs
 if not isinstance(x,dict):return x
 if 'ref' in x:return refs.get(x['ref'],{'unresolved_reference':x['ref']})
 if 'o' in x:
  d={};refs[x.get('id')]=d
  for pair in x['o']:d[pair['k']]=decode(pair['v'],refs)
  return d
 if 'a' in x:
  a=[];refs[x.get('id')]=a;a.extend(decode(v,refs) for v in x['a']);return a
 for k in ['s','n','b']:
  if k in x:return x[k]
 if 'v' in x:return None if x['v']=='null' else {'playwright_special':x['v']}
 return x

def getters(value,path=''):
 out=[]
 if isinstance(value,dict):
  for k,v in value.items():
   if 'getter' in k.lower():out.append(dict(pointer=path+'/'+k,value=v))
   out.extend(getters(v,path+'/'+k))
 elif isinstance(value,list):
  for i,v in enumerate(value):out.extend(getters(v,path+'/'+str(i)))
 return out
tracefull={};traces=[]
for p in sorted(R.rglob('*.zip')):
 with zipfile.ZipFile(p) as z:
  check(z.testzip() is None,str(p.relative_to(S))+' ZIP CRC')
  b=z.read('trace.trace');es=[json.loads(line) for line in b.splitlines()];be={x['callId']:(i,x) for i,x in enumerate(es) if x['type']=='before'};calls=[];found=[]
  for i,e in enumerate(es):
   if e['type']!='after' or e.get('callId') not in be:continue
   bi,v=be[e['callId']];result=decode(e.get('result',{}).get('value',{}));found.extend(getters(result,f'/ndjson/{i+1}/result/value'))
   calls.append(dict(call_id=e['callId'],before_line=bi+1,after_line=i+1,expression=v.get('params',{}).get('expression',''),result=result,params=v.get('params',{})))
  tracefull[p.relative_to(R).as_posix()]=calls
  summaries=[]
  for x in calls:
   result=x['result'];summaries.append(dict(call_id=x['call_id'],before_line=x['before_line'],after_line=x['after_line'],expression_excerpt=x['expression'][:180],result_keys=list(result) if isinstance(result,dict) else None,result_sha256=sha(compact(result).encode()),operation_result=result.get('result') if isinstance(result,dict) else None,raw_byte_fields={k:None if result[k] is None else sha(result[k].encode()) for k in ['raw','before','after','attempted'] if isinstance(result,dict) and k in result and (result[k] is None or isinstance(result[k],str))}))
  traces.append(dict(source=cite(p),trace_member='trace.trace',trace_member_sha256=sha(b),events=len(es),calls=summaries,getter_observation_keys=found))
# Newly recovered e-finite ZIPs match exact hashes advertised in Job28.
for phase,name in [('forgery-before','forgery-before-reopen.zip'),('forgery-after','finite-after-reopen.zip')]:check(sha((R/'e-finite-outputs'/name).read_bytes())==J['jobs']['e-finite']['phases'][phase]['traceSha256'],phase+' recovered trace matches Job28 advertised hash')
# ACK: exact byte/state checks and case-associated replay/reload trace records.
ackrows=[];acalls={x['call_id']:x for x in tracefull['ack-physical-outputs/trace.zip']}
for i,c in enumerate(ack['cases']):
 a=c['actual'];after=a.get('memoryAfter',a.get('state'));mb=a['memoryBefore'];ok=a['before']!=a['after'] and a['after']==a['attempted'] and all(mb[k]==after[k] for k in ['model','release']) and a['reads']==1 and a['writes']==1
 check(ok,'ACK physical bytes/memory '+c['id']);check(c['pass'] is True and c['memoryPreserved'] is True,'ACK flag consistent '+c['id'])
 row=dict(id=c['id'],source=cite(ackp,f'/cases/{i}'),result=a.get('result'),persistence=after['persistence'],before_sha256=sha(a['before'].encode()),after_sha256=sha(a['after'].encode()),attempted_sha256=sha(a['attempted'].encode()),changed_bytes=True,after_equals_attempted=True,accepted_model_unchanged=mb['model']==after['model'],accepted_release_unchanged=mb['release']==after['release'],reads=a['reads'],writes=a['writes'],reload=None,replay=None,trace_calls=None)
 if i<2:
  check(a['result']==c['expected']=={'status':'UNCERTAIN','code':'SA_COMMIT_UNCERTAIN','reason':'POST_WRITE_ACK_FAILED','path':None},'ACK result tuple '+c['id'])
  attempt,replay,reload=(['call@17','call@19','call@21'] if i==0 else ['call@25','call@27','call@29']);rp=acalls[replay]['result'];rl=c['reload'];check(acalls[attempt]['result']==a,'ACK report equals trace actual '+c['id']);check(acalls[reload]['result']==rl,'ACK report equals trace reload '+c['id']);check(rp['writes']==0 and rp['reads']==0 and rp['result']['status']=='REJECTED','ACK stage replay denied '+c['id']);check(rl['reads']==1 and rl['writes']==0 and rl['state']['model']==json.loads(a['after'])['model'] and rl['state']['release']==json.loads(a['after'])['release'],'ACK explicit reload complete state '+c['id']);row['reload']=dict(call_id=reload,reads=rl['reads'],writes=rl['writes'],state_matches_physical_bytes=True);row['replay']=rp;row['trace_calls']=[attempt,replay,reload]
 else:
  attempt,reload=(['call@31','call@33'] if i==2 else ['call@35','call@37']);check(acalls[attempt]['result']==a,'ordinary ACK trace match '+c['id']);rl=acalls[reload]['result'];check(rl['state']['model']==json.loads(a['after'])['model'] and rl['state']['release']==json.loads(a['after'])['release'],'ordinary ACK explicit reload full state '+c['id']);row['reload']=dict(call_id=reload,reads=rl['reads'],writes=rl['writes'],state_matches_physical_bytes=True);row['trace_calls']=[attempt,reload]
 ackrows.append(row)
dump(A/'physical-ack-observations.json',ackrows)
# Lifetime: complete bytes/state verification and recorded private stage non-reuse/restage.
liferows=[];lcalls={x['call_id']:x for x in tracefull['lifetime-outputs/trace.zip']}
for i,c in enumerate(life['cases']):
 a=c['actual'];check(a['before']==a['after'],'lifetime unchanged bytes '+c['id']);check(a['memoryBefore']['model']==a['memoryAfter']['model'] and a['memoryBefore']['release']==a['memoryAfter']['release'],'lifetime unchanged accepted model/release '+c['id']);check(a['writes']==0 and a['reads']==(1 if i>=5 else 0),'lifetime counts '+c['id'])
 row=dict(id=c['id'],source=cite(lifep,f'/cases/{i}'),result=a['result'],reads=a['reads'],writes=a['writes'],before_sha256=sha(a['before'].encode()),after_sha256=sha(a['after'].encode()),model_unchanged=True,release_unchanged=True,replay=None,restage=None,base_specificity=None)
 if i<4:
  rp=lcalls[f'call@{19+8*i}']['result'];rest=lcalls[f'call@{21+8*i}']['result'];row['replay']=rp;row['restage']=dict(prepared_ok=rest.get('prepared',{}).get('ok'),call_id=f'call@{21+8*i}');check(rp['result']['status']=='REJECTED' and rest['prepared']['ok'] is True,'lifetime replay rejected/restage permitted '+c['id']);check(a['result']=={'status':'REJECTED','code':'SA_AUTH_INVALID','reason':'INVALID_INTENT','path':None},'lifetime intent tuple '+c['id'])
 elif i==4:check(a['result']=={'status':'REJECTED','code':'SA_CLOCK_CONFLICT','reason':'REVIEW_CLOCK','path':None},'clock tuple')
 else:
  disk=json.loads(a['before'])['model'];mem=a['memoryBefore']['model'];row['base_specificity']=dict(same_id=mem['id']==disk['id'],same_revision=mem['revision']==disk['revision'],stored_vs_memory_model_equal=mem==disk)
  check(mem['revision']==disk['revision'] and (mem['id']==disk['id'])==(i==5),'lifetime equal revision and dataset identity distinction')
  check(a['result']=={'status':'REJECTED','code':'SA_UPGRADE_CONSENT_STALE','reason':'BASE_BYTES_CHANGED','path':None},'lifetime byte drift tuple '+c['id'])
 liferows.append(row)
dump(A/'lifetime-observations.json',liferows)
# Capacity: native quota, isolated storage cap controls, near-cap memory, read-only mutation flags.
caprows=[]
for i,c in enumerate(cap['cases']):
 a=c.get('actual');row=dict(id=c['id'],source=cite(capp,f'/cases/{i}'),classification=c.get('classification',''),direct_observations={},limitations=[])
 if i==0:
  ok=a['before']==a['after'] and a['reads']==a['writes']==1 and all(a['memoryBefore'][k]==a['state'][k] for k in ['model','release']) and a['state']['persistence']['status']=='UNCERTAIN';check(ok,'native quota refusal bytes and accepted state');row['direct_observations']=dict(before_sha256=sha(a['before'].encode()),after_sha256=sha(a['after'].encode()),attempted_sha256=sha(a['attempted'].encode()),unchanged_accepted_model_release=True,reads=1,writes=1,persistence=a['state']['persistence'])
 elif i==1:
  check(a['reads']==1 and a['writes']==0 and a['state']['model']==cap['cases'][0]['actual']['memoryBefore']['model'] and a['state']['release']==cap['cases'][0]['actual']['memoryBefore']['release'],'quota explicit reload preserved full accepted state');row['direct_observations']=dict(reads=1,writes=0,loaded_full_prequota_state=True)
 elif i==2:
  f=R/'capacity-outputs/capacity-final-storage.json';before=R/'capacity-outputs/capacity-before-quota.json';check(f.read_bytes()==before.read_bytes(),'quota before/final storage bytes equality');check(sha(f.read_bytes())==c['rawSha256'],'capacity native-reopen raw hash');check(c['beforePid']!=c['afterPid'] and c['sameProfile'] and c['unchanged'],'capacity distinct browser PID and same profile reported');row['direct_observations']={k:v for k,v in c.items() if k!='id'};row['limitations']=['PIDs are CDP SystemInfo browser-process observations per hash-bound capacity.mjs; capacity trace/raw protocol transcript not supplied. This is a distinct session, not Job28 browser/e-finite PID recovery. No post-reopen capability probe is recorded here.']
 elif 3<=i<=14:
  category,size,textmode=re.match(r'CAP_(RECEIPT|ENVELOPE)_(\d+)_(.*)',c['id']).groups();size=int(size);limit=524288 if category=='RECEIPT' else 2097152;admitted=size<=limit;result=a['attempt']['result'];check(a['attemptReads']==1 and a['diagnosticReloadReads']==1 and a['attemptWrites']==(1 if admitted else 0),'capacity boundary counts '+c['id']);check(a['measuredBytes']==size,'capacity boundary reported size '+c['id']);check(result['code']==('SAVE_OK' if admitted else 'PROVENANCE_LIMIT_EXCEEDED'),'capacity boundary tuple '+c['id'])
  obs=dict(category=category,reported_size=size,textmode=textmode,result=result,attempt_reads=a['attemptReads'],attempt_writes=a['attemptWrites'],diagnostic_reload_reads=a['diagnosticReloadReads'],before_sha256=sha(a['before'].encode()) if isinstance(a['before'],str) else None,after_sha256=sha(a['after'].encode()) if isinstance(a['after'],str) else None,admitted=admitted)
  if admitted:
   e=json.loads(a['after']);check(e['model']==a['loaded']['model'] and e['release']==a['loaded']['release'],'capacity diagnostic reload full state '+c['id'])
   if category=='ENVELOPE':measured=len(a['after'].encode())
   else:
    offset=a['after'].index('"receipts":[')+len('"receipts":[');_,end=json.JSONDecoder().raw_decode(a['after'],offset);measured=len(a['after'][offset:end].encode())
   obs['independently_measured_utf8_bytes']=measured;check(measured==size,'capacity admitted raw UTF8 size '+c['id']);obs['utf8_vs_codepoint_difference']=len(a['after'].encode())-len(a['after'])
  else:
   check(a['before']==a['after'],'capacity refused bytes unchanged '+c['id']);obs['refused_candidate_raw_bytes_available']=False;row['limitations'].append('Refused candidate size is a reported measurement plus hash-bound recipe, not independently reconstructible from stored bytes; before/after retention is directly observable.')
  row['direct_observations']=obs;row['limitations'].append('Isolated context native-storage boundary; trusted test authorizer, not a document source-authority positive or controller-memory observation.')
 elif i in [15,16]:
  bef=c['before']['state'] if i==15 else c['before'];af=a['state'];check(all(bef[k]==af[k] for k in ['model','release']) and a['reads']==1 and a['writes']==0,'near-cap attendance accepted memory '+c['id']);obs=dict(reads=1,writes=0,model_unchanged=True,release_unchanged=True,result=a['result'],persistence=af['persistence'],raw_pair_available=i==15)
  if i==15:check(c['before']['raw']==c['after']['raw'],'near-cap dayclose raw bytes unchanged');obs['before_sha256']=sha(c['before']['raw'].encode());obs['after_sha256']=sha(c['after']['raw'].encode())
  else:row['limitations'].append('Correction report lacks literal post raw bytes; source asserts equality before exit0, which is not a saved raw pair.')
  row['direct_observations']=obs
 else:
  check(c['loaded']['status']=='SAVED_READ_ONLY','readonly fixture status '+c['id']);mut=[]
  for n,x in enumerate(a):
   check(x['reads']==0 and x['writes']==0 and all(x[k] is True for k in ['unchangedBytes','unchangedModel','unchangedRelease']),'readonly mapped mutation observations '+c['id']+'/'+x['id']);mut.append(dict(index=n,**x))
  row['direct_observations']=dict(loaded_persistence=c['loaded'],mapped_mutations=mut,count=len(mut));row['limitations']=['Per-mutation immutability booleans are observed report fields, not independently reconstructed raw model/release/byte pairs. Exactly11 mapped callbacks, not every possible controller entrypoint; no actual correction or typed event callback is listed. Receipt-only over-limit fixture is not exercised by this control.']
 caprows.append(row)
dump(A/'capacity-observations.json',caprows)
# Independent history prefix and UTF8 checkpoints; distinguish measurements from authority/ACK proof.
h12p=R/'capacity-outputs/history-after-12.json';h24p=R/'capacity-outputs/history-after-24.json';finalp=R/'capacity-outputs/capacity-final-storage.json';h12=load(h12p);h24=load(h24p);fin=load(finalp)
def prefix(a,b):return len(b)>=len(a) and b[:len(a)]==a
histchecks=[]
for name,x,y in [('12-to24',h12,h24),('24-tofinal',h24,fin)]:
 vals={}
 for key in ['records','closedDays','officialSnapshotIds','reconciliationIssues']:vals['attendance/'+key]=prefix(x['release']['attendance'][key],y['release']['attendance'][key])
 vals['provenance/receipts']=prefix(x['release']['provenance']['receipts'],y['release']['provenance']['receipts']);vals['calendar/appliedRevisions']=prefix(x['release']['calendar']['appliedRevisions'],y['release']['calendar']['appliedRevisions']);vals['model/snapshots']=prefix(x['model']['snapshots'],y['model']['snapshots'])
 for k,v in vals.items():check(v,'capacity history exact prefix '+name+'/'+k)
 histchecks.append(dict(transition=name,comparisons=vals))
measurements=[]
for i,x in enumerate(cap['measurements']):
 row={k:v for k,v in x.items() if k not in ['prepared','samples','metrics']};row['source']=cite(capp,f'/measurements/{i}')
 if x['phase']=='REVISION':check(x['reads']==1 and x['writes']==1 and x['result']['status']=='ACCEPTED','capacity genuine revision record '+str(x['n']))
 if x['phase']=='TWENTY_PAGE_TRANSIENT_NATIVE_MEMORY':
  check(max(v.get('summedRSSBytes',0) for v in x['samples'])==x['observedMaxSummedRSSBytes'],'native sampled RSS maximum') if any('summedRSSBytes' in v for v in x['samples']) else None
  row['samples_count']=len(x['samples']);row['sample_keys']=list(x['samples'][0]) if x['samples'] else []
 measurements.append(row)
for n,p in [(12,h12p),(24,h24p)]:check(len(p.read_bytes())==next(x['envelopeBytes'] for x in cap['measurements'] if x['phase']=='REVISION' and x['n']==n),'capacity checkpoint native raw byte length '+str(n))
check(len(finalp.read_bytes())==720960 and len(fin['release']['provenance']['receipts'])==26,'capacity final state bytes/receipt population')
cap_history=dict(checkpoints=[dict(source=cite(p),utf8_bytes=len(p.read_bytes()),revision=load(p)['model']['revision'],receipts=len(load(p)['release']['provenance']['receipts'])) for p in [h12p,h24p,finalp]],prefix_checks=histchecks,measurements=measurements)
dump(A/'capacity-history-and-measurements.json',cap_history)
# Adversarial population and scope. Preserve repeated IDs as separate indexed observations.
advcases=adv['result']['cases'];advrows=[]
for i,c in enumerate(advcases):
 if 'pass' in c:check(c['pass'] is True,'adversarial reported expectation '+str(i))
 advrows.append(dict(index=i,id=c['id'],source=cite(advp,f'/result/cases/{i}'),reported_pass=c.get('pass'),reported_status=c.get('status'),actual=c.get('actual')))
dump(A/'adversarial-observations.json',dict(classification=adv['classification'],observations=len(advcases),unique_id_labels=len({c['id'] for c in advcases}),reported_passes=sum(c.get('pass') is True for c in advcases),unavailable=[dict(index=i,**c) for i,c in enumerate(advcases) if 'status' in c],command_types=adv['result']['commandTypes'],live_handles_serialized=adv['result']['liveHandlesSerialized'],cases=advrows))
# Search all new reports/results for getter observations. Strings/code do not count as counters.
getterkeys=[]
for p in [ackp,lifep,capp,advp]:getterkeys.extend(dict(source=cite(p),**x) for x in getters(load(p)))
check(not getterkeys and all(not t['getter_observation_keys'] for t in traces),'no candidate getter observation recovered in new reports/trace results')
dump(A/'recovered-trace-analysis.json',traces);dump(A/'new-getter-search.json',dict(report_measurement_keys=getterkeys,trace_sources=[dict(source=x['source'],measurement_keys=x['getter_observation_keys']) for x in traces],limitation='Absence is NOT proof of zero invocation; no new original F-SA28/F-SA29 operation-bound byte snapshots identified. Different sessions cannot replace those operations.'))
# Evidence bindings: useful shared controls, never relabelled original case executions.
def link(p,pointer,scope,limitation):return dict(**cite(p,pointer),scope=scope,limitation=limitation)
ACK=[link(ackp,'/cases','SHARED_CONTROLLER_ACK_NEGATIVES','Four missing/unknown-ACK faults on genuine source/ordinary routes; not positive ACK order or exact F152 variant')]
NATIVE=[link(capp,'/cases/2','SHARED_NATIVE_PROCESS_REOPEN','Capacity session, distinct CDP browser PIDs and raw equality; not original per-variant session/capability count')]
AUTH=[link(advp,'/result/cases','SHARED_AUTHORITY_BOUNDARY','Isolated AuthorityHost/real reader, not saved-source positive; repeated IDs and one unavailable SAB control')]
LIFE=[link(lifep,'/cases','SHARED_SOURCE_LIFETIME_CLOCK_DRIFT','Different exact fixtures/IDs; controller SA tuples do not replace B2 storage tuples')]
BIND=[];matrix=list(csv.DictReader((W1/'outputs/SA001_152_CASE_ACCEPTANCE_MATRIX.csv').open()));newbindingcount=0;storagebindingcount=0
for row in matrix:
 c=Cmap[row['case_id']];e=c['oracleExpectedUnchanged'];bindings=[];tail=[];id=c['id'];cl=c['classification'];expectedmem=e['acceptedMemoryDisposition']
 if cl in ['PARTIAL_STORAGE_OBSERVABLE_MATCH','PARTIAL_MISSING_OBSERVABLE']:
  # Public projection/clone denial supports reload nonauthority invariant but does not count handles per case.
  bindings+=AUTH+NATIVE;tail.append('No direct new execution of this original oracle variant; native reopen and authority controls are shared, not per-case NONE/0 measurements.')
  if expectedmem=='ADVANCE_AFTER_ACK':bindings+=ACK;tail.append('Invalid ACK withholding is directly observed in shared controls; valid ACK-before-promotion order for this exact successful candidate remains unobserved.')
  if e.get('phase')=='P10' or id in ['F-SA-26-commit-throw','F-SA-27a']:
   bindings+=ACK+[link(capp,'/cases/0','SHARED_NATIVE_QUOTA_RETENTION','Real native quota refusal: one attempted write, unchanged physical bytes and memory; different fixture/fault from original variant')]
  if e.get('phase')=='P7' or 'stale-base' in id or id.startswith('F-SA-24') or id.startswith('F011-X-15'):
   bindings+=LIFE;tail.append('Byte/dataset drift shared tuples are SA_UPGRADE_CONSENT_STALE; retain this row\'s actual original expected result.')
  if '19-' in id or '20-' in id or id=='F-SA-21-unicode-count':
   kind='RECEIPT' if '19-' in id else 'ENVELOPE' if '20-' in id else None
   matching=[(i,x) for i,x in enumerate(cap['cases']) if (kind and x['id'].startswith('CAP_'+kind+'_')) or (kind is None and 'MULTIBYTE_ESCAPED' in x['id'])]
   for i,x in matching:
    if ('below' in id and ('524287' not in x['id'] and '2097151' not in x['id'])) or ('equal' in id and ('524288' not in x['id'] and '2097152' not in x['id'])) or ('above' in id and ('524289' not in x['id'] and '2097153' not in x['id'])):continue
    bindings.append(link(capp,f'/cases/{i}','RELATED_NATIVE_STORAGE_BOUNDARY','Exact category/size relation; trusted isolated context, no original candidate/stage/controller promotion identity'))
  if e['acceptedMemoryDisposition']=='READ_ONLY_INSPECTION_ONLY' or e['phase']=='P6b' or e['phase']=='P6a':
   for i in [17,18]:bindings.append(link(capp,f'/cases/{i}','SHARED_READ_ONLY_11_CALLBACK_FENCE','Related unknown/whole-envelope read-only fixtures; not receipt-only limit, exact field path, all possible callbacks or this row\'s raw loaded payload'))
  if id=='F-SA-31-explicit-attendance':
   bindings+=[link(capp,f'/cases/{i}','SHARED_ATTENDANCE_CAP_REFUSAL','Actual day-close/correction controller retains memory on refusal; not this successful ledger candidate') for i in [15,16]]
  if id in ['F-SA-28-reload-reuse','F-SA-29-manual-revision']:tail.append('New sessions neither supply this original case\'s immediate before/after byte pair nor getter count.')
 else:tail.append('Original external/excluded ruling unchanged; run summary exit0 does not convert it to a single-call PASS.')
 if bindings:newbindingcount+=1;storagebindingcount+=cl=='PARTIAL_STORAGE_OBSERVABLE_MATCH'
 row.update(phase2_full_case_disposition=row['full_case_disposition'],phase2_case_promotion='NONE',phase2_direct_new_case_observation='NOT_OBSERVED',phase2_shared_support=compact(bindings),phase2_remaining_binding= ' '.join(tail),phase2_provenance_disposition='VERIFIED_SOURCE_AND_BUILD_RECORD_CORRESPONDENCE; effective overlay source/approval-document bytes still NOT_OBSERVED',phase2_getter_observation='NOT_OBSERVED' if cl=='PARTIAL_MISSING_OBSERVABLE' else 'UNCHANGED_PHASE1',phase2_byte_gap='NOT_OBSERVED' if id in ['F-SA-28-reload-reuse','F-SA-29-manual-revision'] else 'UNCHANGED_PHASE1')
 BIND.append(dict(case_id=id,shared_bindings=bindings,remaining=' '.join(tail)))
csvout(O/'SA001_152_CASE_ACCEPTANCE_MATRIX_PHASE2.csv',matrix);dump(A/'152-shared-binding-crosswalk.json',BIND)
# Maintain the precise20 originally missing observations, and disclose remaining binding obligations separately.
oldgaps=list(csv.DictReader((W1/'outputs/SA001_MISSING_EVIDENCE_RESOLUTION.csv').open()));gaps=[]
for i,g in enumerate(oldgaps):
 gaps.append(dict(gap_id=f'OBS-{i+1:02}',kind='MANDATORY_MISSING_OBSERVATION',case_id=g['case_id'],requirement=g['missing_requirement'],expected=g['expected'],disposition='NOT_OBSERVED',source_path=g['source_path'],source_sha256=g['source_sha256'],json_pointer=g['json_pointer'],phase2_support='New reports/traces contain no bound counter or original-case byte pair; search audit records exact sources',next_action='A/F/D adjudicate acceptable evidence method; only then authorize exact missing capture if needed'))
for row in matrix:
 c=Cmap[row['case_id']];cl=c['classification'];e=c['oracleExpectedUnchanged']
 if cl not in ['PARTIAL_STORAGE_OBSERVABLE_MATCH','PARTIAL_MISSING_OBSERVABLE']:continue
 # Bundled binding obligations preserve full oracle expectation tuples without inflating observations/tests.
 pending=['phase','reloadAuthority','stageCapabilitiesAfterReload'];fieldstates=json.loads(row['observed_field_states'])
 if cl=='PARTIAL_STORAGE_OBSERVABLE_MATCH' or fieldstates.get('acceptedMemoryDisposition')!='MATCH':pending.append('acceptedMemoryDisposition')
 gaps.append(dict(gap_id='BIND-'+c['id'],kind='INDEPENDENT_REQUIREMENT_BINDING_NOT_DISTINCT_TEST',case_id=c['id'],requirement=compact(pending),expected=compact({k:e[k] for k in pending}),disposition='PENDING_REVIEW',source_path=row['comparator_path'],source_sha256=row['comparator_sha256'],json_pointer=row['comparator_pointer'],phase2_support=row['phase2_shared_support'],next_action='Review exact per-case shared/source binding; execute only genuinely uncovered requirements after separate authorization'))
csvout(O/'SA001_REMAINING_MISSING_EVIDENCE_PHASE2.csv',gaps)
summary=dict(authority='HQ-SA001-CODEX-PHASE2-OFFLINE/2026-11-05-r1',script_sha256=sha(pathlib.Path(__file__).read_bytes()),new_original_members=41,combined_original_members=211,source_identity='Verified original record correspondence; authentic effective overlay bytes not present',build_inventory_hashes_matched=73,ack_controls=len(ackrows),lifetime_controls=len(liferows),capacity_cases=len(caprows),adversarial_observations=len(advcases),adversarial_unique_id_labels=len({x['id'] for x in advcases}),adversarial_reported_passes=sum(x.get('pass') is True for x in advcases),adversarial_unavailable=sum('status' in x for x in advcases),new_traces=len(traces),case_matrix_rows=len(matrix),rows_with_shared_support=newbindingcount,storage_rows_with_shared_support=storagebindingcount,mandatory_missing_observations=len(oldgaps),unresolved_requirement_binding_rows=len(gaps)-len(oldgaps),full_case_accepted=0,new_direct_original_variant_executions=0,application_executions=0,source_edits=0,github_writes=0,consistency_checks=len(checks),failed_checks=[x for x in checks if not x['ok']])
dump(A/'checks.json',checks);dump(A/'summary.json',summary);print(json.dumps(summary,indent=2));sys.exit(1 if summary['failed_checks'] else 0)
