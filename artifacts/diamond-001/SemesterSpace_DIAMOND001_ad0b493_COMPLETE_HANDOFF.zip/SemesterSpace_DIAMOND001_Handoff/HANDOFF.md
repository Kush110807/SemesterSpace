# DIAMOND-001 candidate for A and independent D review

**HOLD — engineering candidate, not integration/release acceptance.**

Branch: `engineering/diamond-001-t1`  
Candidate commit: `ad0b4934466c6d29f54282b192024ccf83e5dc96`  
Tree: `dfdd05e08b21da0638c51dde97ec71f7c4eb195f`  
Base: `4233158b6225bb5b1c11a11e53182a38b6f02942`  
FV-01 executable parent: `a2b963407b967d6729037719fef5b92ff1e77ea0`

Main and deployed code were untouched. No remote push, PR, merge, deployment, migration or native/public release. Only the four authorized production files plus four bounded test/driver files and one implementation document changed. The three later baseline documentation files and package/lockfile remain byte-identical. The worktree is clean.

## Results and finite issue for A

- Clean npm ci, 70-module syntax check, 26 engine tests, 342 independent arithmetic cases and production build: exit 0.
- Complete npm test: **494 run, 493 PASS, 1 FAIL, 0 skipped**.
- New DIAMOND unit tests: **220/220 PASS**; 71 additional actual-module controller variants passed.
- Served production-build Chromium: strict UI create/title/cancel/convert/relink; no-op; dirty-base rejection; source/history/ambiguous/unproved-origin restrictions; read/quota/lossy serializer faults; explicit clock-hold recovery; 320px/keyboard/focus; demo isolation; native profile process close/reopen without reseeding: passed.
- Recovered original FV-01 archive matched its pinned SHA256 and manifest. All five original browser drivers passed on this exact final build: actual PDF/OCR/manual review, selective calendar application, original/corrected attendance, official reconciliation, storage failures, retained invalidated commitments, same-profile native reopen, stale-generation/busy recovery and restage without rereading. Additional real manual-wizard fallback and genuine reviewed-stage retention/revocation controls passed.
- Missing/unrecognized save-code injection: DevTools changed the helper acknowledgment **after a real successful write**. Accepted memory rejected both codes, newer actual stored bytes remained, and no compensating write occurred. These are post-write invalid-ack controls, not zero-write storage fences or durable receipt claims.

**A-01: full-suite acceptance blocker.** The unchanged `D B4: matching roster initializes without replacing actual counts or roster` test at `semester-space/tests/integration/controller.test.mjs:64` loads `schedule.initialized=false` with an always-success mock validator. Real frozen validation rejects those stored bytes as UNINITIALIZED_SCHEDULE. Required B2 P5 now rejects the save, so line 69's old success assertion fails. Baseline's mocked test passed. Production's frozen loader already refuses that invalid setup. No assertion was removed/skipped/weakened and P5 was not relaxed. A must resolve this precise fixture/acceptance conflict before claiming a green suite; D should independently reproduce and assess it.

The extra navigation-adapted `tests/diamond-001/import-browser.mjs` also retains a diagnosed failing legacy raw-string assertion: it rejects the legitimate envelope key `reconciliationIssues`. Its earlier failure log is supplied as diagnostic evidence, not a passing gate. The unmodified recovered FV-01 initial browser driver passed independently. No legacy test was weakened to conceal this.

## Known failures and UNRUN limits

DIAMOND-SA-001 is **OPEN P1**. The exact supplied forged-stage reproduction accepts the forgery on both baseline and candidate. Its exit 0 observes the defect: **KNOWN_BASELINE_FAILURE**, never a source-safety PASS. T2-LINK's future linked `date:null` EFFECT_OUT_OF_SCOPE is reproduced and remains a separate P2 limitation. D001-H4-03d's complete indirect source-authority proof is separate/unrun; routes are inventoried, no repair or broad protection is claimed.

D review, A integration decision, deployment/release, physical devices, assistive technology, other browsers and concurrency/ABA/power-loss guarantees are not established. The case matrix records case-level evidence and these limits. Do not equate producer runs with D acceptance.

## Artifacts and replay

- `DIAMOND001-ad0b493-source.zip`: complete tracked source, tests and supporting doc; excludes .git/dependencies/vendor/dist/profiles.
- `DIAMOND001-ad0b493.patch`: binary/full-index patch against the exact pinned base; `git apply --check` passed on the untouched base.
- `DIAMOND001-ad0b493-branch.bundle`: local branch commits with the pinned base as prerequisite; `git bundle verify` passed. No remote push is needed.
- `DIAMOND001-ad0b493-dist.zip`: exact tested static build with local PDF/OCR assets/licenses.
- `DIAMOND001-ad0b493-evidence.zip`: raw logs, command exit codes, versions, full per-case state/bytes/read/write evidence, traces/screenshots, contract packet, original and additional drivers, fixture inputs, source/build/lockfile hashes, complete diff and case mapping; excludes profiles and credentials.
- `SHA256SUMS.txt` and `ARTIFACTS.json`: artifact checksums. Internal `EVIDENCE_SHA256.txt` hashes every evidence member.

After applying the patch to the pinned base or checking out the branch bundle, run commands from `semester-space/`: npm ci; npm run check; npm test; node --test tests/engine/*.test.mjs; python3 tests/checker.py; npm run build. Expect the precisely documented full-suite failure until A resolves it.

Serve dist using `makeServer` exported by the unchanged tools/serve.mjs with the dist absolute path, e.g. port 5174; then run `SS_ORIGIN=http://127.0.0.1:5174 DIAMOND_EVIDENCE_DIR=/tmp/diamond-browser node tests/diamond-001/browser.mjs --run`. Exact final commands/exit codes are in evidence `final/commands.tsv`. Additional driver scripts and original FV-01 scripts are included; set SS_CANDIDATE_ROOT, SS_ORIGIN and SS_EVIDENCE_DIR as recorded, and use fresh synthetic profiles. Run connected-browser, native-and-negative and calendar-write-failure sequentially on their shared profile. Reopen does not reseed.

For rollback, hold this isolated branch/build; main requires no rollback. Never restore stale browser bytes over newer accepted state. Forward this exact commit/source/build/evidence to A and D with the supplied independent-review instructions. No approval is implied by this handoff.

## Source and build digests

- `DIAMOND001-ad0b493.patch`: `c6eeb0e68a228f11f3bcc816247d2810fba342ca37dc596b9a6181c119b14d52` (117671 bytes)
- `DIAMOND001-ad0b493-source.zip`: `dc39b90fe3797ea8280da2581bf69a9eafe5aa1ec2d32eac6b21995826ecbe4c` (9365594 bytes)
- `DIAMOND001-ad0b493-branch.bundle`: `67b2f2002f80d54c1d1e2f1c8323d81286de4c0b9dd39da04706be0eeaff4ed9` (36502 bytes)
- `DIAMOND001-ad0b493-dist.zip`: `e5d76c3d743ce09a658904fcc9956b48f22b220723acd4a34bc8500ce66f17c5` (20916037 bytes)
