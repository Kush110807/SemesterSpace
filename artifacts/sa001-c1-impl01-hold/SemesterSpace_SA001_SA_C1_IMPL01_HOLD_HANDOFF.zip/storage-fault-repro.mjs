// Negative native-Web-Storage primitive probe only. Not an SA candidate,
// authority-positive, receipt, oracle-stage execution or T1 functional suite.
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {writeFile} from 'node:fs/promises';
import {chromium} from '/workspace/SemesterSpace-diamond-001/semester-space/node_modules/playwright/index.mjs';
const out='/workspace/sa001-evidence/preflight-oracle-conflict';
const server=createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html'});res.end('<!doctype html><title>Synthetic storage fault probe</title>');});
await new Promise(r=>server.listen(5197,'127.0.0.1',r));
let browser;
try{
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const context=await browser.newContext();await context.tracing.start({snapshots:true,screenshots:true});const page=await context.newPage();await page.goto('http://127.0.0.1:5197');
 const results=await page.evaluate(()=>['setItemCommitsThenThrows','afterSaveAckThrows'].map(fault=>{
  const key='semesterspace.v1',before='synthetic pre-write bytes',candidate='synthetic post-write bytes';
  const nativeGet=Storage.prototype.getItem,nativeSet=Storage.prototype.setItem;
  nativeSet.call(localStorage,key,before); // Explicit setup, outside the one-attempt counters.
  let reads=0,writes=0,acceptedMemory=before,caught=false;
  const disk={getItem(){reads++;return nativeGet.call(localStorage,key)},setItem(value){writes++;nativeSet.call(localStorage,key,value);if(fault==='setItemCommitsThenThrows')throw Error('explicit negative fault after physical commit')}};
  const old=disk.getItem();
  try{disk.setItem(candidate);if(fault==='afterSaveAckThrows')throw Error('explicit negative host fault after normal setItem return');acceptedMemory=candidate;}catch{caught=true;}
  // This is a separate diagnostic inspection, not a hidden reread in the attempt.
  const actual=nativeGet.call(localStorage,key);
  return {fault,attemptReads:reads,attemptWrites:writes,postAttemptDiagnosticReads:1,before:old,after:actual,bytesUnchanged:actual===old,physicalByteDisposition:actual===old?'UNCHANGED':'CHANGED',acceptedMemoryUnchanged:acceptedMemory===old,caught,compensatingWrites:0};
 }));
 for(const r of results){assert.equal(r.attemptReads,1);assert.equal(r.attemptWrites,1);assert.equal(r.physicalByteDisposition,'CHANGED');assert.equal(r.acceptedMemoryUnchanged,true);assert.equal(r.compensatingWrites,0);assert.equal(r.caught,true);}
 const report={classification:'NATIVE_STORAGE_NEGATIVE_PRIMITIVE_DIAGNOSTIC_NOT_SA_CANDIDATE_TEST',origin:'http://127.0.0.1:5197',browser:browser.version(),executable:'/usr/bin/chromium',profile:'Fresh disposable Playwright context; synthetic strings only; no real personal store',results,candidateAuthorityCasesExecuted:0};
 await writeFile(out+'/native-storage-fault-observations.json',JSON.stringify(report,null,2)+'\n');await context.tracing.stop({path:out+'/native-storage-negative-trace.zip'});console.log(JSON.stringify(report,null,2));await context.close();
}finally{await browser?.close();await new Promise(r=>server.close(r));}
