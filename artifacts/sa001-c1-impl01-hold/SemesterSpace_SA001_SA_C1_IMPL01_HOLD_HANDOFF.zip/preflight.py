from pathlib import Path
import subprocess,json,hashlib,datetime,zoneinfo
R=Path('/workspace/SemesterSpace');O=Path(__file__).parent;P=Path('/workspace/sa001-input');C=Path('/workspace/sa001-contract');commands=[]
def run(name,args,cwd=R,allowed=(0,)):
 p=subprocess.run(args,cwd=cwd,capture_output=True);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);commands.append({'name':name,'argv':args,'cwd':str(cwd),'exit':p.returncode,'stdout':name+'.stdout','stderr':name+'.stderr'});assert p.returncode in allowed,(name,p.returncode);return p.stdout.decode().strip()
def snapshot(label):
 refs=run(label+'-refs',['git','show-ref']);wt=run(label+'-worktrees',['git','worktree','list','--porcelain']);items=[]
 for block in wt.split('\n\n'):
  if not block:continue
  fields=dict(s.split(' ',1) for s in block.splitlines() if ' ' in s);path=Path(fields['worktree']);status=run(label+'-status-'+str(len(items)),['git','status','--porcelain=v1','--untracked-files=all'],path)
  names=run(label+'-tracked-'+str(len(items)),['git','ls-files','-z'],path).split('\0');files={}
  for name in names:
   if name:
    f=path/name;files[name]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'mode':f.stat().st_mode&0o777}
  items.append({'worktree':str(path),'head':fields.get('HEAD'),'branch':fields.get('branch'),'status':status,'files':files})
 value={'refs':refs,'worktrees':items};(O/(label+'-inventory.json')).write_text(json.dumps(value,indent=2)+'\n');return value
if __name__=='__main__':
 before=snapshot('before')
 run('config',['git','config','--show-origin','--list']);run('remotes',['git','remote','-v']);run('hookspath',['git','config','--path','--get','core.hooksPath'],allowed=(0,1))
 hookfiles=[{'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((R/'.git/hooks').iterdir()) if p.is_file()];assert all(h['name'].endswith('.sample') for h in hookfiles);(O/'hooks.json').write_text(json.dumps(hookfiles,indent=2)+'\n')
 run('target-ref-absent',['git','show-ref','--verify','--quiet','refs/heads/engineering/diamond-sa-001'],allowed=(1,));assert not Path('/workspace/SemesterSpace-sa-001').exists()
 base='88d606ea940be945fa55124671c1a8deb57c7b04';tree='1efa8ec205d125ac3fac9d934e99cfdccceff872';assert run('baseline-commit',['git','rev-parse',base+'^{commit}'])==base;assert run('baseline-tree',['git','rev-parse',base+'^{tree}'])==tree
 baseline=json.loads((P/'evidence/BASELINE_AND_SCOPE.json').read_text());hashes={}
 for name,digest in baseline['sourceSha256'].items():
  raw=subprocess.check_output(['git','show',base+':semester-space/'+name],cwd=R);hashes[name]=hashlib.sha256(raw).hexdigest();assert hashes[name]==digest
 (O/'baseline-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
 assert hashlib.sha256((P/'accepted/D_INDEPENDENT_CONTRACT_ACCEPTANCE.md').read_bytes()).hexdigest()==baseline['DReportSha256']
 bundle=C/'reference/AUTHENTIC_88d606e_WITH_BASE.bundle';assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='0a728be696094d4a395834aa3da143f2d8d4d6cec81ef53e7c91db22c1e8673d';run('bundle-verify',['git','bundle','verify',str(bundle)]);run('git-integrity',['git','fsck','--full'])
 manifests=[('outer',P),('contract',C),('E',C/'contract/E_AUTHORITY_0_1_1'),('F-base',C/'contract/F_PERSISTENCE_0_1_1'),('F-amended',C/'contract/F_AMENDED_0_1_4'),('E-R2',C/'reviews/E_C3_CONCURRENCE_R2')];counts={}
 for name,path in manifests:run('manifest-'+name,['sha256sum','-c','SHA256SUMS.txt'],path);counts[name]=len((path/'SHA256SUMS.txt').read_text().splitlines())
 assert counts['contract']==191
 index=json.loads((C/'CONTRACT_INDEX.json').read_text());originals={}
 for name,digest in index['specialistOriginalArchivesSHA256'].items():
  originals[name]=hashlib.sha256((C/'reference'/name).read_bytes()).hexdigest();assert originals[name]==digest
 E=json.loads((C/'contract/E_AUTHORITY_0_1_1/AUTHORITY_EVIDENCE_0_1_1.schema.json').read_text())['$defs'];F=json.loads((C/'contract/F_AMENDED_0_1_4/reference/SA001_PROFILE3_EMBEDDED_0.1.1_PROPOSED.schema.json').read_text())['$defs'];L=json.loads((C/'contract/F_AMENDED_0_1_4/F011_TYPED_LOAD_RESULT_0_1_2_PROPOSED.schema.json').read_text())['$defs'];assert len(E)==81 and len(F)==116 and len(L)==119;assert all(F[k]==v for k,v in E.items()) and all(L[k]==v for k,v in F.items())
 oraclePath=C/'contract/F_AMENDED_0_1_4/F011_EXACT_TEST_VARIANTS_0_1_3_PROPOSED.json';oracle=json.loads(oraclePath.read_text());assert len(oracle['variants'])==152;rows=[v for v in oracle['variants'] if v['variantId'] in ['F-SA-26-commit-throw','F-SA-27a']];assert len(rows)==2 and all(v['expected']['persistedByteDisposition']=='UNCHANGED' for v in rows)
 (O/'exact-conflicting-rows.json').write_text(json.dumps({'oracleSha256':hashlib.sha256(oraclePath.read_bytes()).hexdigest(),'counter_scope':oracle['counter_scope'],'variants':rows},indent=2)+'\n')
 summary={'explicitAuthorization':'APPROVED A-SA-C1/2026-10-27-r1 by user; historical NOT_GRANTED package metadata does not override it','packageSha256':'3c249e8acaf4d888f7c121b25baafef89196ed5616b48b95f579b10f8e86ff46','acceptedAssemblySha256':hashlib.sha256((P/'accepted/A-SA-CLOSURE_2026-10-27-r2.zip').read_bytes()).hexdigest(),'manifests':counts,'DReportSha256':baseline['DReportSha256'],'baselineCommit':base,'baselineTree':tree,'baselineSourceHashesVerified':len(hashes),'schemaDefinitions':{'E':len(E),'F':len(F),'load':len(L),'embeddedEquality':True},'originalSpecialistArchives':originals,'SAWorktreeCreated':False,'SAProductionEdits':False,'candidateRuntimeCasesExecuted':0,'blockingRows':[v['variantId'] for v in rows],'reason':'Both exact post-write controller rows require unchanged physical bytes despite specified successful physical write, no compensating write and explicit changed-byte counter_scope. No expected outcome altered.','timestampAsiaKolkata':datetime.datetime.now(zoneinfo.ZoneInfo('Asia/Kolkata')).isoformat()};(O/'preflight-result.json').write_text(json.dumps(summary,indent=2)+'\n')
 after=snapshot('after');assert before==after;(O/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(summary,indent=2))
