from pathlib import Path
import json,hashlib,subprocess,importlib.util,shutil,zipfile,datetime,zoneinfo
r=Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest()
spec=importlib.util.spec_from_file_location('snapshot_receipt',r/'preflight.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);after=mod.snapshot('final');assert after==json.loads((r/'before-inventory.json').read_text());(r/'final-preservation-commands.json').write_text(json.dumps(mod.commands,indent=2)+'\n')
assert not Path('/workspace/SemesterSpace-sa-001').exists();p=subprocess.run(['git','show-ref','--verify','--quiet','refs/heads/engineering/diamond-sa-001'],cwd='/workspace/SemesterSpace');assert p.returncode==1
oraclePath=Path('/workspace/sa001-contract/contract/F_AMENDED_0_1_4/F011_EXACT_TEST_VARIANTS_0_1_3_PROPOSED.json');x=json.loads(oraclePath.read_text());rows=[]
for i,v in enumerate(x['variants']):
 if v['variantId'] in ['F-SA-26-commit-throw','F-SA-27a']:rows.append({'id':v['variantId'],'pointer':f'/variants/{i}/expected/persistedByteDisposition','expected':'UNCHANGED','fault':v['fixture']['mutations'][0],'tuple':{k:v['expected'][k] for k in ['status','code','reason','path']},'attemptCounts':{'reads':v['expected']['getItemCount'],'writes':v['expected']['setItemCount']}})
result={'result':'HOLD — EXACT GATE','finding':'SA-C1-IMPL-01: conflicting physical-byte post-write expectations','explicitOwnerAuthorizationAccepted':True,'frozenOracleSha256':sha(oraclePath.read_bytes()),'conflictingRows':rows,'normativeCounterScope':x['counter_scope'],'interpretationNotSilentlyChanged':True,'productionEdits':False,'SAWorktreeCreated':False,'SABranchCreated':False,'candidateCommit':None,'candidateTree':None,'baselineCommit':'88d606ea940be945fa55124671c1a8deb57c7b04','baselineTree':'1efa8ec205d125ac3fac9d934e99cfdccceff872','allExistingWorktreeBytesModesHeadsBranchesStatusesAndRefsUnchanged':True,'requiredRuntimeCandidateGates':'UNRUN, blocked before candidate creation; no runtime acceptance or case PASS claimed','diagnosticOnly':'Two native-storage fault observations, not materialized authority stage/oracle executions','noPushCIUploadMergeDeploymentMigrationRelease':True,'SA001':'OPEN P1','T2LINK':'OPEN P2 separate','requiredFiniteADisposition':'Reconcile only the two post-write physical-byte expectations against counter_scope and normative uncertainty/no-compensation rules; preserve all result tuples/read-write counts/memory invariants unless A explicitly dispositions otherwise. No protocol/schema/wire or expected outcome was modified.','timestampAsiaKolkata':datetime.datetime.now(zoneinfo.ZoneInfo('Asia/Kolkata')).isoformat()}
(r/'HOLD.json').write_text(json.dumps(result,indent=2)+'\n')
text='''# HOLD — EXACT GATE

## SA-C1-IMPL-01: two contradictory post-write physical-byte expectations

Owner authorization A-SA-C1/2026-10-27-r1 is explicitly granted and accepted. This is not an authorization refusal or a reopening of C1/C2/C3 research. It is the assignment's explicit stop for contradictory required acceptance outcomes discovered before production edits.

Active oracle: contract/F_AMENDED_0_1_4/F011_EXACT_TEST_VARIANTS_0_1_3_PROPOSED.json in accepted A-SA-CLOSURE/2026-10-27-r2 (original archive SHA 564dd204ebb26b6a0463a52c10019037f3fb8faf14e2a82472fcdd861229605b).

| Exact case | Mutation | Frozen physical-byte expectation |
|---|---|---|
| F-SA-26-commit-throw, /variants/55/expected/persistedByteDisposition | setItemCommitsThenThrows | UNCHANGED |
| F-SA-27a, /variants/56/expected/persistedByteDisposition | afterSaveAckThrows | UNCHANGED |

The same oracle's counter_scope explicitly says: “Conforming setItem throw: 1 invocation/unchanged bytes; commit-then-throw: 1 invocation/changed bytes/uncertain ACK.” The normative F011 machine-oracle document defines UNCHANGED as exact before/after raw-string equality; its first-match check6 explicitly allows changed physical bytes after synthetic commit-then-throw and forbids a compensating write or second save/replay. Integrated persistence contract and D's accepted report preserve that distinction. The rows' UNCERTAIN result tuples, unchanged accepted memory and one-read/one-write counts are coherent; the two physical-byte fields conflict with those requirements.

For a genuine changed source acceptance, the required new model revision and appended receipt produce different bytes. The “valid source/result could be identical” exception cannot avoid that difference in these controller cases. Once a fault performs the real write before throwing, returning UNKNOWN/UNCERTAIN cannot roll storage back. Satisfying raw-byte UNCHANGED would require avoiding the prescribed fault/write, restoring stale bytes with a prohibited second write, silently weakening the expected outcome, or misreporting evidence. None was done.

## Concrete diagnostic and limits

storage-fault-repro.mjs ran with pinned installed Playwright and genuine /usr/bin/chromium 154.0.8037.57 at fresh localhost origin http://127.0.0.1:5197 using a disposable context and synthetic strings only. Both faults actually invoke native localStorage.setItem. Each attempt records one getItem and one setItem; a separate explicitly counted diagnostic read inspects the result. Both show CHANGED physical bytes, UNCHANGED accepted-memory value, and zero compensating writes. Raw stdout/stderr/exit, observation JSON and native trace are included.

This is a native-storage negative primitive reproduction, NOT an implemented SA controller/source-authority positive or execution of the two oracle stage cases. No mock receipt, decoder or authority was used. All152 SA vectors and other candidate producer/independent gates remain UNRUN; no old PASS or primitive observation is transferred as a candidate result.

## Verified preflight and preservation

Outer16, accepted191, E23, F-base10, F-amended78 and E-R2 38 manifest entries verify. Original accepted archive, D report and accepted original specialist E/F archive hashes match. E81 definitions exactly embed in F116, which exactly embed in load119. Authentic bundle SHA/verify, actual baseline commit/tree, git fsck and all33 baseline source/lockfile Git-object hashes pass. Baseline is authentic88d606ea940be945fa55124671c1a8deb57c7b04/tree1efa8ec205d125ac3fac9d934e99cfdccceff872, never an artifact delivery branch or reconstructed source identity.

Existing refs and all six pre-existing worktrees' HEAD/branch/status/tracked file bytes/modes match before/after/final inventories. No applicable AGENTS.md was found. Hooks are inactive sample hooks; no hook disabled. SA target branch/path were absent and remain absent. No baseline functional suite was rerun. No source, tests, contracts, main/T1/integration or lockfile changes, candidate commit, push, CI dispatch, public upload, merge, migration, deployment or release occurred.

## Exact finite issue for A

Please disposition these two persistedByteDisposition expectations against the already specified post-write uncertainty semantics. If CHANGED physical bytes is intended for the two forced-commit fault recipes, supply that bounded oracle clarification/correction while retaining unchanged accepted memory, UNCERTAIN tuples, one read/one attempted write, revoked capabilities, explicit reload and no compensation. If another interpretation is intended, state the required observable behavior explicitly. The input oracle was not edited. No new schema/status/production path is proposed and no broad contract research restart is requested.

The owner's approval remains recorded. After A resolves this finite acceptance conflict, the isolated implementation can begin from the same authentic unchanged baseline under the existing nine-path authorization. No passing SA candidate is delivered here. SA-001 remains OPEN P1, T2-LINK separate OPEN P2; Open Interval and mathematical objectives remain separate.
'''
(r/'A_FINITE_HANDOFF.md').write_text(text)
# Preserve original frozen inputs once; the accepted bundle/source prerequisites are inside this exact package.
original=Path('/workspace/attachments/8266e1ba-1b90-4f22-a6b0-b34e3a929f5c/SemesterSpace_SA001_SA_C1_Implementation_Authorization_Package_2026-10-27.zip');assert sha(original.read_bytes())=='3c249e8acaf4d888f7c121b25baafef89196ed5616b48b95f579b10f8e86ff46';shutil.copyfile(original,r/'FROZEN_INPUT_PACKAGE.zip')
(r/'AUTHORIZATION.txt').write_text('Explicit user approval A-SA-C1/2026-10-27-r1 received 27 October2026, for isolated local SA-001 implementation/producer verification on unchanged88d606e/tree1efa8ec, PO-SA1–7, nine-file scope and bounded tests/docs. The user expressly directed stopping for scope/interface/contract conflict or unresolvable acceptance failure. No GitHub write/push/CI/merge/public upload/real-store migration/activation/deployment/release is authorized. This HOLD exercises that stop condition; approval itself is not questioned.\n')
(r/'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.relative_to(r)}\n' for p in sorted(r.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts))
archive=Path('/workspace/SemesterSpace_SA001_SA_C1_IMPL01_HOLD_HANDOFF.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(r.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(p.relative_to(r)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  digest,name=line.split('  ',1);assert sha(z.read(name))==digest
archive.with_suffix('.zip.sha256').write_text(sha(archive.read_bytes())+'  '+archive.name+'\n');print(json.dumps({'result':result['result'],'handoff':str(r/'A_FINITE_HANDOFF.md'),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'existingWorktreesAndRefsPreserved':True},indent=2))
