# Reconstruct the paused source without pretending it is a final commit

Use a new scratch repository; do not overwrite an existing worktree. Verify SHA256SUMS.txt first.

```
git clone committed-history.bundle scratch-sa001
cd scratch-sa001
git checkout 18a190c57eac63ce45c465cac74c21e2d89300e2
git apply --index ../18a190c-to-progress.patch
git write-tree
```

Expected tree: `b2aaee98e12a450dd725b618849aa550f2560ec7`. The patch includes the new supporting files. The expected working tree is modified; there is no new candidate commit. Alternatively extract source-progress.zip to a new directory; archive extraction alone does not establish Git identity.

Frozen original inputs can be expanded from IMPL02's nested accepted IMPL01 archive. Apply IMPL03 and IMPL04 as separate active overlays, never overwrite accepted originals. Some supporting producer scripts use the prescribed `/workspace/...` input locations; reproduce those locations or adapt only the supporting path configuration, recording the adaptation. Do not execute commands while this assignment remains paused without an instruction to continue. Commands listed in evidence are historical recipes, not a new authorization or claim that final gates passed.
