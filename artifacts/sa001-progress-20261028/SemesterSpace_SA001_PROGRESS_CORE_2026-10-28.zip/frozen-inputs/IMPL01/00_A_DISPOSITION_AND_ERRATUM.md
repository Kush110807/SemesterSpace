# A — SA-C1-IMPL-01 finite disposition

**SA-C1-IMPL-01 RESOLVED — CONTINUE EXISTING AUTHORIZED ISOLATED IMPLEMENTATION**

27 October2026 · Erratum **A-SA-C1-IMPL-01/2026-10-27-r1**.

Codex's HOLD was justified. A's prior freeze retained two machine expectations inconsistent with the accepted post-write uncertainty semantics. This is a bounded oracle error, not an application implementation failure or renewed authorization refusal. A accepts responsibility for missing the two fields. Original C1/C2/C3 closures remain intact.

## Exactly corrected expectations

| Case | Original pointer | Old value | Controlling value |
|---|---|---|---|
| F-SA-26-commit-throw | /variants/55/expected/persistedByteDisposition | UNCHANGED | **CHANGED** |
| F-SA-27a | /variants/56/expected/persistedByteDisposition | UNCHANGED | **CHANGED** |

The same two values are corrected under `/oracle/variants/...` in SA-C1's embedded acceptance register. This is two authoritative expectation corrections, mirrored in two files; no other parsed value or original formatting is changed. All152 variant IDs/readiness/execution labels, all schemas, all other expectations, policies, interfaces, production paths and source identities remain unchanged. Original archives and D report are immutable and included inside the preserved original SA-C1 package.

## Required observable behavior

1. Materialize a genuine, fully validated source operation against the stored base using a live stage and matching consent where needed. Its accepted model revision and new receipt make the proposed full-envelope bytes different from the prior bytes. The symbolic same-named stored/candidate fixture does not license an identical/no-op write or a cloned fake stage. These cases were already private-stage-dependent and remain so.
2. F-SA-26-commit-throw: the instrumented setItem invokes the real physical write successfully, then throws before the controller receives a successful acknowledgment. Return unchanged `UNCERTAIN / SA_COMMIT_UNCERTAIN / STORAGE_ACK_UNCERTAIN`.
3. F-SA-27a: the real setItem returns normally, then the host acknowledgment fault throws **before accepted-model/release promotion**. Return unchanged `UNCERTAIN / SA_COMMIT_UNCERTAIN / POST_WRITE_ACK_FAILED`. A later arbitrary rendering exception after true accepted-memory promotion is not this fault recipe and cannot be substituted for it.
4. For each exact attempt: one getItem, one attempted setItem, zero candidate getter invocations as specified, zero compensating writes, different physical stored bytes, unchanged controller accepted model/release/revision until explicit authoritative reload. Never assert SAVED/source acceptance from the uncertain response. Internal context caches cannot be used to bypass the uncertainty guard.
5. Revoke the old stage/lease/consent and block persistence/source acceptance until explicit authoritative reload. Reload validates actual stored bytes and may load the newly written valid state, but restores **zero** capabilities/consent; `reloadAuthority=NONE`, `stageCapabilitiesAfterReload=0`. Do not auto retry, restore old bytes, replay the consumed stage or manufacture ALREADY_APPLIED authority.
6. A separate counted diagnostic read or explicit reload may inspect durable state; it is not hidden in the one-attempt getItemCount. Preserve the actual committed candidate byte string/hash and prove post-fault raw equality to that string, not merely “different.” Preserve raw original bytes/hash for comparison.

## Physical-byte terminology clarification

For these two post-write cases, `CHANGED` describes the physical before/after raw-string relation. It does **not** assert controller acceptance, acknowledged success, successful overall P11 command completion or a durability guarantee. The earlier machine-oracle wording describing CHANGED as a replacement “after P11” describes the ordinary acknowledged case; it must not be read as excluding changed physical bytes on these explicitly forced-commit uncertain branches. The counter_scope and postwrite check6 already distinguish those branches.

Conforming Web Storage write failure remains different: a native throwing write that does not commit preserves original bytes. Its existing UNCHANGED expectations remain untouched. A known prewrite refusal still performs zero writes. This erratum does not change those cases, error precedence or the B2/OMR guarantees.

## Scope, authority and independent verification

Existing owner approval A-SA-C1/2026-10-27-r1 continues. This correction aligns two fields with already accepted post-write behavior and adds no source capability, status/schema, production path or permission. **No renewed owner authorization or broad E/F/D contract round is required to resume the existing isolated implementation.** Codex must not weaken other outcomes or infer a scope expansion.

D's original contract acceptance applies to the immutable original assembly; it is not relabeled as independent review of this later erratum. Supply this correction with the eventual exact candidate to F and D. They must verify the two corrected outcomes and preserved conforming-failure/uncertainty controls as part of mandatory independent candidate review. E's authority/evidence schemas and semantic concurrence are unchanged. If a specialist establishes another concrete contradiction, return that finite finding to A.

SA-001 remains OPEN P1. All152 implemented-candidate cases remain UNRUN. T2-LINK remains separate OPEN P2. No production source/test edit, candidate branch/commit, CI, merge, push, migration, deployment or release was performed by A for this correction.
