# SA-C1 IMPL-01 correction and continuation

**RESOLVED — CONTINUE EXISTING AUTHORIZED ISOLATED IMPLEMENTATION**

Read `00_A_DISPOSITION_AND_ERRATUM.md`, then send this entire ZIP to the same Codex conversation with `01_EXACT_CODEX_CONTINUATION.md` pasted as the prompt. The owner has already authorized SA-C1. No further approval is needed for this correction within the same scope.

Only F-SA-26-commit-throw and F-SA-27a change persistedByteDisposition from UNCHANGED to CHANGED; the embedded register mirrors those two values. All other expected outcomes stay identical. The source must still return UNCERTAIN with unchanged accepted memory, one write, no compensation and explicit reload. This is not acceptance of an implemented SA candidate.

`accepted/` preserves the complete original authorized SA-C1 ZIP, containing the accepted contract, D report, source bundle and original instructions. `active/` supplies only the corrected acceptance inputs and exact guarded JSON Patch. `ERRATUM_INDEX.json` pins their identity and precedence. `evidence/` contains inspected Codex diagnostics and inventories; the full original Codex input manifest133 entries verified in A's review, with its verification log included. Only selected relevant input evidence is reproduced here; this is not a claim that all original133 files are included in this correction.

From this packet root, run `sha256sum -c SHA256SUMS.txt` and `python3 research/verify_erratum.py`. The verifier reads/checks inputs; it does not patch a source tree or initiate implementation. It proves the exact two-field overlay (four mirrored leaves across the two files), preserved byte formatting and unchanged original package. Use active overlay instead of mutating original immutable archives.

Supply this erratum to F/D with the later implemented candidate using file02. The independent review is still mandatory and pending. All152 SA runtime cases remain UNRUN; the native diagnostic is producer-executed primitive evidence only. SA-001 OPEN P1; T2-LINK separate OPEN P2. No new implementation scope, CI, merge, push, migration, deployment or release permission.
