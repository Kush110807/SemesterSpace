# F/D — carry-forward check for IMPL-01, with the implemented candidate

No new full contract audit is requested and no new independent acceptance is claimed by A. C1/C2/C3 and E's unchanged semantic concurrence remain closed.

When the implemented candidate arrives, verify the exact original SA-C1/accepted contract plus erratum A-SA-C1-IMPL-01/2026-10-27-r1 and corrected oracle/register hashes. Establish only the two physical-disposition leaves changed, mirrored in the register. All other152-case inventory fields, source/evidence schemas, prior source/history bindings and interfaces remain intact.

Independently execute:

- F-SA-26-commit-throw: actual validated changed envelope physically written once, fault before storage acknowledgment, SA_COMMIT_UNCERTAIN/STORAGE_ACK_UNCERTAIN, physical CHANGED, accepted memory unchanged before reload.
- F-SA-27a: actual validated changed envelope written and storage acknowledgment returned once, host fault before accepted-memory promotion, SA_COMMIT_UNCERTAIN/POST_WRITE_ACK_FAILED, physical CHANGED, accepted memory unchanged before reload.
- Conforming native throw and known prewrite refusal controls retain their original unchanged-byte/zero-write or one-attempt semantics; no compensating writes.
- In both uncertain cases the active capability/consent is revoked; explicit reload validates the exact committed envelope and restores no stage authority. Separate diagnostic/reload reads from command counters. No stale automatic replay, receipt-derived credential or false SAVED claim.

A inspected Codex's supplied native primitive source/log/report/trace and preflight receipts; A did not rerun the browser primitive or an SA candidate. Native strings are not a genuine source/controller/profile3 test. All152 runtime rows remain UNRUN until implemented-candidate execution. Do not relabel the original D contract review as D verification of this erratum.

Any failure is a finite source/verification finding on the exact new candidate, not grounds to reopen unrelated T1/B2 or E research. All original independent acceptance requirements remain. No CI dispatch, production edits, merge, push, deployment or release is authorized by this note.
