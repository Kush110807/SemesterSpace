# SA-C1 — isolated implementation authorization package

**READY FOR PRODUCT OWNER'S BOUNDED IMPLEMENTATION AUTHORIZATION**

Version: **A-SA-C1/2026-10-27-r1**. Prepared27 October2026. Preparation only; authorization state is **NOT_GRANTED**. DIAMOND-SA-001 remains **OPEN P1**.

D accepted contract assembly A-SA-CLOSURE/2026-10-27-r2, original ZIP SHA-256 `564dd204ebb26b6a0463a52c10019037f3fb8faf14e2a82472fcdd861229605b`. C1/C2/C3 are closed; no specialist research restart is required. This package freezes application adapters and owner-policy recommendations needed to implement that accepted contract. It does not change the wire schemas, reopen those findings, or claim D has reviewed new implementation code.

## Contents and use

1. Read `01_OWNER_POLICIES_AND_AUTHORIZATION.md`; approve the exact statement there only if you accept its policies and limits.
2. `02_FROZEN_INTERFACES.md` and `design/INTERFACE_FREEZE.json` define the proposed new API. All new exports are **to implement**, not existing source claims. Existing source mapping is in `03_SOURCE_MAPPING_AND_SCOPE.md` and `evidence/BASELINE_AND_SCOPE.json`.
3. After explicit owner approval, attach this complete ZIP to Codex and paste `04_EXACT_CODEX_PROMPT.md`. Approval permits only the isolated candidate, local tests/build and evidence work specified. It grants no production activation, CI dispatch, merge, push or deployment.
4. `05_TICKETS_AND_ACCEPTANCE_GATES.md` and `design/ACCEPTANCE_REGISTER.json` define completion. All future runtime gates remain unexecuted now.
5. Send the frozen completed candidate to E/F/D using the exact assignments in `assignments/`. Each verifies the same candidate and attributes execution honestly. Return their reports and candidate to A for closure review.

`accepted/A-SA-CLOSURE_2026-10-27-r2.zip` is the unchanged complete accepted contract, including schemas, E/F material, historical research, oracle and authentic T1 Git bundle. `accepted/D_INDEPENDENT_CONTRACT_ACCEPTANCE.md` is the exact supplied D report. D's separate raw contract evidence ZIP was not attached to this task and is not represented as inspected or included; D's report contains its execution attribution. The complete contract evidence already delivered by A remains in the accepted archive.

## Fixed baseline and workspace boundaries

Start from authentic commit `88d606ea940be945fa55124671c1a8deb57c7b04`, tree `1efa8ec205d125ac3fac9d934e99cfdccceff872`. Use new branch `engineering/diamond-sa-001` and new worktree `/workspace/SemesterSpace-sa-001` when the existing repository is `/workspace/SemesterSpace`; if a different genuine root is necessary, record it and preserve the same identities. Branch/path must be absent; do not overwrite existing work. Preserve accepted T1 integration branch/worktree and every unrelated ref. Local/remote main are outside this authorization. Authentic bundle import is allowed only into an absent local review-input ref, without moving unrelated refs or modifying history.

A matched33 relevant baseline files directly to authentic Git objects, inspected real declarations/call sites and confirmed the review checkout clean. No application implementation, candidate test suite, install, build, browser run or CI execution was performed for SA-C1.

The source-authorization vulnerability is still present in T1. An accepted architecture and a permitted isolated candidate do not establish security or public readiness. T2-LINK stays separate OPEN P2; Open Interval UI-01–UI-07 and B's mathematical objectives remain separate.
