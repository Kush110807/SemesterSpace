# Dependency-ordered engineering and complete future gates

No implementation under preparation. After owner approval, local checkpoints can proceed without repeated permission within the exact scope. A scope contradiction is a finite stop, not a new full audit.

| Ticket | Dependency | Work and permitted files | Local exit / independent owner |
|---|---|---|---|
| SA-00 | Owner authorization | Authentic absent branch/worktree from88d606e, manifests/ref/byte inventories, lockfile and scope bind. No application mutation in preflight. | Exact genuine source and isolation receipts; Codex producer. |
| SA-01 | SA-00 | storage codecs + new import/authority.js, main composition, shared types. Actual private extractors, manifests, typed review, groups, copied editor projection. | E vector parity/owned-byte and real decode smoke; no partial route enabled outside isolated candidate. |
| SA-02 | SA-01 | controller/types; main private host/context binding. Permit/lease/consent, clocks/domain/history, raw route rejection, raw patch vs retained assembly. | Original forgery denied and genuine initial/revision succeeds; local tests. D/E later independently replay. |
| SA-03 | SA-02 agreed transaction | storage/controller/types; context, exact load/read-only and one-envelope receipt transition. | Applicable152 vector mapping, legacy B2/OMR, uncertainty/history/cap boundaries; F independent later. |
| SA-04 | SA-02/03 | Four allowed UI modules; closed editor controls, trusted closure handles, explicit source/reload/refusal/history. | Genuine importer workflow and useful manual route; keyboard/focus/status/reload and no lost history. No CP-VR3 redesign. |
| SA-05 | SA-01–04 | Supporting tests/research/docs only; local full/build/browser/capacity evidence, source freeze. | Producer package complete or exact environment/functional HOLD. All independent gates remain pending. |
| SA-06 | Frozen SA-05 candidate | E source/semantics + F persistence in parallel if same candidate; D final independent boundary/lifecycle review. | E/F/D independent acceptance or finite findings. Implementation changes create new commit/hash and require affected reviewers to rebind/rerun. |
| SA-07 | E/F/D acceptance | A exact candidate/evidence reconciliation; no implementation assumed. | A may close bounded SA-001 only after all required gates and limitations are dispositioned. Owner separately considers integration/activation/release. |

SA-01/02/03 can use incremental local harnesses; no user-facing production route may be activated between them. No request to D to approve partially passing code as final.

## Frozen acceptance sources

The complete machine register is `design/ACCEPTANCE_REGISTER.json`. It embeds all152 original oracle rows unchanged,17 AUTH families, nine positive recipes (normative reference), four SEM families,14 adapter/codec controls, six capacity scenarios and four accessibility/usability controls. New rows are specifications only. Nothing here has run against an SA implementation.

- F152:116 PROFILE3,18 CONTROLLER_SA,10 LOADER_E3,6 B2_FROZEN,2 OUT_OF_SCOPE. Preserve every ID, expected phase/tuple/path/count and readiness. The last two are not unique call passes; materialize specified suite coverage or retain an explicit exclusion. No claim of “152 passed” by counting two N/A rows as tests.
- Readiness:127 base+mutation,4 emitted digest-valid unknowns,17 stage-dependent,1 actual-ledger candidate/save-unrun,1 future F-SA-40 builder,2 non-single-call. F-SA-40 requires genuine operation bound to the altered legacy base's optional absent links; never copy incompatible old receipt commitments.
- AUTH01–17 cover exact original forgery, anchors, source substitution, late jobs, cloned/foreign/leaked capability, review/subset/base drift, replay/concurrent apply, origin laundering/manual route, history, clocks/coverage/omissions/groups, storage/reopen and recovery. Positive success prevents a trivial “disable all imports” fix.
- P1–P9 use actual installed extractors/readers, source-specific corrections and trusted acceptance. P2 manual intentionally has no importer. At least one genuine image OCR worker path and separate PDF text path. SEM01–04 retain machine output versus reviewed meaning, unresolved/abstention and known limits; no broad accuracy claim.
- All codec/interpreter paths must preserve explicit null/absence, opaque legacy values, escaped text, exact UTF-16 key order/ID-set rules and all framed commitments. Initial clock exception applies solely to the newly created snapshot0 slot. No receipt-cycle hash or main.js self-hash.

## Evidence required for each applicable case

Record case ID and fixture/generator/font/source hashes; exact candidate commit/tree/build/lockfile; runtime/tool/browser/asset versions; entrypoint/request/fault recipe; expected and actual phase/status/code/reason/path; one-attempt read/write/getter/serializer counters; before/after raw storage strings and SHA; model/release/revision/receipt count; accepted memory; live-stage/consent lifecycle; actual source/run/page/anchor/qualifier/group/subset identity; full output and exit code. Existing history comparisons use the same scenario's ancestor, never unrelated FRESH_DOCUMENT and multi-receipt fixture histories.

Browser cases additionally retain origin, process/profile continuity, trace/screenshots, network/console diagnostics, actual post-reopen storage/receipts and zero revived handles. Failed attempts remain in separate immutable directories. Physical successful write with lost ACK is not a zero-write refusal. Profile contents may contain local browsing data, so share synthetic evidence exports and continuity receipts, not the browser profile directory.

## Local commands after implementation authorization

From candidate semester-space/ (these were NOT run for SA-C1):

```sh
npm ci --no-audit --no-fund
npm run check
npm test
node --test tests/engine/*.test.mjs tests/attendance/ledger.test.mjs
node --test tests/diamond-001/storage.test.mjs tests/diamond-001/omitted-release-acceptance.test.mjs tests/diamond-001/omitted-release-precedence.test.mjs
python3 tests/checker.py
npm run build
node tests/sa-001/browser.mjs --run --out /ABS/NEW_BROWSER_EVIDENCE
node tests/sa-001/capacity.mjs --run --out /ABS/NEW_CAPACITY_EVIDENCE
```

The last two paths are proposed supporting runners to create, not existing baseline exports. Use frozen npm dependency versions from actual lockfile (Playwright1.58.2, pdfjs-dist5.4.624, tesseract.js7.0.0, English data1.0.0). Record actual Node/npm/Chromium, genuine /usr/bin/chromium path and assets. No browser download substitution or unpinned package. If genuine Chromium is unavailable, report the gate rather than fake it. Installation/network restrictions may block execution; keep the original pin, no spending/CI without separate authorization.

The previously accepted540 count and12 browser workflows belong to T1. Do not label them SA results or promise an unmeasured new count. New full suite must execute all retained required tests and additions, with exact mapping for intentional source-route expectation changes, no unexplained omission, skips/todo or silent removal. Pure engine/arithmetic populations overlap full suite; report separately without summing unique totals. Full new candidate independent lifecycle execution must satisfy D's independence requirement; owner/Codex producer evidence alone cannot satisfy it.

## Capacity and minimum UI gates

Measure real20-page/hybrid decode/receipt and transient memory;12/24 successive genuine revisions plus growing ledger; each cap at-1/equality/+1 including multibyte and escaped text; near-full-origin localStorage quota; ordinary day-close/correction near limits; genuine reload inspection/refusal. Keep all previous receipts; no capacity repair by pruning, cap change or fake excerpt. Report device/RAM/latency/memory without invented budget compliance; production semester/headroom choice remains deferred. An isolated candidate may honestly exhibit a cap refusal; E/F/D must verify it preserves data. Such evidence is not production-usability approval.

Modified review forms must work with keyboard only (including file selection, typed decisions, whole-group selection, consent, final apply and reload), visible focus, no traps and intentional focus recovery. Test actual200% zoom/reflow at320/390px and primary-action visibility; source images have meaningful alternatives and retained text is text. Independently exercise a real screen reader on the declared browser/OS, status/error announcements, disabled/read-only/uncertain semantics and consent vs saved result. At least one observed non-author student walkthrough of manual plus document setup/revision/recovery must distinguish reviewed/source-bound from institution-verified and saved from staged/uncertain. Record critical misunderstandings as blockers, not a numeric usability success percentage. These are minimum changed-flow gates; broader CP-VR3 device/student study remains separate.

## Completion boundaries

Producer pass → E/F/D candidate review; independent environment failures remain HOLD, not application defects by inference. D must agree on any alternate independent runner before evidence collection; this package does not dispatch CI. No SA closure from research assertions or a producer-only full suite. If semantic support needs a parser change, return to A with exact unsupported case; do not silently enlarge scope or relax gold.

A controller/domain unit may use a clearly labeled trusted-host/fault double in its own isolated instance to reach a specific history/serialization guard. Such a unit is not a genuine source-authority positive. Do not rewrite a historical test from HISTORY_PROTECTED to an earlier SOURCE_REVIEW_REQUIRED refusal and claim the original history behavior was still exercised. Preserve that guard's meaningful coverage via valid configured unit boundary plus actual genuine-source lifecycle evidence. No mock/fault facility is exposed in production UI or used to mint authority for the real composition.
