# SemesterSpace Diamond — Codex: isolated SA-001 implementation

Execute this assignment ONLY when the Product Owner's explicit A-SA-C1/2026-10-27-r1 authorization statement accompanies it. The attached package alone is not authorization. If absent, return AUTHORIZATION_NOT_GRANTED without editing code.

Implement the accepted SA-001 contract under the frozen application interfaces in this package. Do not restart C1/C2/C3 research. Contract acceptance is D's exact assembly A-SA-CLOSURE/2026-10-27-r2; original archive SHA564dd204ebb26b6a0463a52c10019037f3fb8faf14e2a82472fcdd861229605b. Read README, owner policies, interface freeze, actual-source mapping, tickets, machine acceptance register and accepted D report before changes.

## Preflight and isolation

1. Verify the outer handoff manifest and nested accepted contract191 entries. Verify D report identity and accepted E/F versions; preserve these inputs outside the candidate checkout.
2. Inspect applicable AGENTS.md instructions and current Git/worktree/ref inventory. Preserve every existing worktree/branch/status/byte and record before/after inventories. No stash/reset/rebase/cherry-pick/main creation or movement.
3. Establish authentic baseline88d606ea940be945fa55124671c1a8deb57c7b04, tree1efa8ec205d125ac3fac9d934e99cfdccceff872. Verify expected production/lockfile hashes against evidence/BASELINE_AND_SCOPE.json. If needed, use the authentic bundle included in the accepted archive (SHA0a728be696094d4a395834aa3da143f2d8d4d6cec81ef53e7c91db22c1e8673d); verify real Git objects/prerequisites. Do not reconstruct identity from files or use an artifact-handoff branch as the source.
4. Create only absent branch engineering/diamond-sa-001 in absent worktree /workspace/SemesterSpace-sa-001 from that exact commit. If genuine repository root differs, record it. If target exists, stop and report rather than overwrite or reset it. Import a missing baseline ref only into absent review-input/sa001-base-88d606e; do not change accepted T1 refs.
5. Record preflight receipts outside source; no functional T1 suite rerun on the baseline. Then implement on the new isolated candidate only.

## Implementation

Follow SA-01 through SA-05 in order, completing local checks at each dependency. New source APIs and editor projection are exactly frozen in 02_FROZEN_INTERFACES.md and design/INTERFACE_FREEZE.json. All proposed exports must be implemented, not assumed present. Keep existing extractors/compiler/preparer/builder/engine/ledger implementations and signatures unchanged.

Only nine production paths under semester-space/:
src/import/authority.js (new), src/main.js, src/controller.js, src/storage.js, src/shared/types.d.ts, src/ui/import.js, src/ui/revision-review.js, src/ui/release.js, src/ui/index.js.

Supporting tests/fixtures/research: tests/sa-001/. Documentation: docs/sa-001/. Minimal existing-test adaptations are limited to legitimate source positives now using authority and original unsafe routes now correctly rejecting. Preserve original attack inputs; publish per-test-ID changes/reasons. No deleting failures, skipped/todo acceptance cases, weaker gold or broad harness rewrite.

Implement private copied-byte/run lineage, closed review/typed effect editors, complete groups/subset, controller lease/replay/base/clock/history guards, immutable full evidence receipts, exact profile3 persistence/typed recovery, full-release omission guards, one-use upgrade, two-pass core/unknown classification, single write/acknowledged state swap and explicit uncertainty/reload. Preserve useful manual, demo isolation, ordinary legacy and historical T1 behaviors. Original public raw proposal/apply routes must fail closed even when no authority instance is configured. No serialized/digest/foreign-factory capability fallback.

New application-only EditorSnapshot is a copied read-only projection, not E.Preview or a raw importer draft. Do not add keys to accepted E/F wire definitions. Use actual compiler option map and actual evaluateDayClose correction; there is no evaluateDayCorrection. Hash actual raw sourceRevisionPatch separately from assembled retained crosswalk. No source-authenticated badge or claim of institutional/parser truth.

Use synchronous browser-compatible codecs inside allowed storage.js and verify against independent native implementations. Do not change legacy load/save call/return ABI or introduce Promise returns there. No new dependency/production helper file. Manifest must be real pinned available-artifact configuration embedded privately in main, with honest unknown self-referential/new-module identities and NOT_OBSERVED actually-used assets. No copied authored manifest values or remote loader fallback.

Apply PO-SA1–7 in the isolated candidate. Use disposable browser profile and candidate-only localhost origin with synthetic/rights-cleared fixtures; no real personal dataset or credentials. New candidate setups e3, existing legacy ordinary operations retain accepted dispatch, document upgrade explicit only. Cap refusal never truncates evidence/history or raises budgets silently. No production activation/coexistence promise.

## Authorized local producer verification

After implementation, from semester-space/ run pinned npm ci, npm run check, npm test, the unchanged engine/ledger/B2/OMR focused regressions, python3 tests/checker.py and npm run build. Use the unchanged lockfile; no npm install/update, dependency substitution, paid service or API. Record exact commands, versions, complete stdout/stderr/exits and source identities. These are NEW SA candidate producer executions, not new D runs or reruns of baseline acceptance.

Implement tests/sa-001/browser.mjs with --run --out /ABS/NEW_EVIDENCE and tests/sa-001/capacity.mjs with the same CLI. Both must use pinned installed Playwright and genuine /usr/bin/chromium, served candidate origin, fail nonzero on genuine failure and preserve output even on failure. Execute original forgery denial AND actual installed PDF/OCR positives. Keep source setup→document revision→connected persistence→browser-process close/reopen same persistent profile→failed-write/uncertainty recovery in one continuous local evidence session without reseeding accepted data. No mock text/worker/receipt may satisfy importer positives. Fault injections belong to explicitly labeled negative tests; ordinary reader/source paths remain real.

Retain applicable existing12 T1 browser workflows with narrowly adapted legitimate source routes and per-workflow result mapping; known T2/parser characterizations remain distinctly labeled. Do not reuse or modify frozen T1 02_run_recovery.py against the new candidate: it pins the old source and is historical evidence, not the SA runner. Preserve all failed attempts and report environment-unavailable gates honestly. Do not trigger GitHub Actions or another CI job.

Materialize the applicable152 oracle vectors, including F-SA-40 through an actual base-bound reviewed operation. The two non-single-call/out-of-scope entries require explicit applicable suite evidence/exclusion treatment, never false PASS. Execute AUTH01–17, all nine useful positive recipes, SEM01–04 dispositions, adapter/codec controls and capacity matrix. No unique-count inflation from overlapping suites. Capacity may fail; record measurements and refusal behavior without changing caps/parser/gold to pass. No unverified headroom claim.

## Stop conditions

Stop affected implementation and report a finite A handoff if a tenth production path, changed parser/compiler/engine/ledger signature, new wire/schema/status requirement, dependency/lockfile/build/CSS change, additional storage key, contradictory expected outcome or unsupported real positive requires scope expansion. Do not silently downgrade an acceptance case or repair T2-LINK. Ordinary implementation defects within approved paths should be fixed and tested without repeated permission requests.

A missing install/browser capability, blocked localhost or unexecuted independent gate is an honest evidence blocker, not permission for synthetic substitutes. No provider/API purchase or CI run. Do not delete failed evidence or declare completion while required local gates are unrun/failing. Package partial work/evidence and exact blocker if the environment prevents completion.

## Final output

Local candidate commits on the isolated branch may freeze source; no merge/push. Provide exact commit/tree, full parent/base ancestry, clean worktree status, exact production/supporting diff, all source/lockfile hashes and genuine complete Git bundle containing baseline prerequisites. Package source, tests/generators/gold, frozen contract/interface/policies, raw command evidence, complete applicable-case register, browser traces/screenshots, actual reopened storage/history and capacity report with SHA256SUMS. Exclude node_modules/cache/profiles/real academic data/credentials from shareable source; retain replayable synthetic workflow evidence and necessary local native-reopen receipts.

Separate producer executions, inherited contract research and UNRUN independent E/F/D gates. Report LOCAL ISOLATED SA-001 CANDIDATE — NOT INDEPENDENTLY ACCEPTED — NOT RELEASED only if required producer gates pass. Otherwise report HOLD — EXACT GATE. SA-001 remains OPEN P1 pending independent E/F/D verification and A disposition. Preserve T2-LINK OPEN P2, Open Interval and mathematical objectives as separate.

No GitHub write, main/integration merge, push, CI execution, live migration, deployment or release.
