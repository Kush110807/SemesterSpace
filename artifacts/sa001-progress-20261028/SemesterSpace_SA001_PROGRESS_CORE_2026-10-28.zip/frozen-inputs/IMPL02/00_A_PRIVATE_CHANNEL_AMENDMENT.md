# A — SA-C1-IMPL-02 private epoch/bootstrap disposition

**SA-C1-IMPL-02 RESOLVED — CONTINUE FROM THE PRESERVED PARTIAL CHECKPOINT**

Amendment **A-SA-C1-IMPL-02/2026-10-27-r1**,27 October2026. Existing owner authorization continues. No new owner approval or full specialist research round is required for this bounded private adapter clarification within the same nine paths. Mandatory independent candidate verification remains.

Codex correctly identified an omitted channel in A's proposed interface freeze. A did not specify how the composition-owned epoch reaches createController. The amendment makes that input explicit and also freezes the bootstrap needed to deliver the controller-owned write authorizer to the persistence context. There is no already-existing epoch accessor to pretend was implemented. Original C1/C2/C3 closures and IMPL01 physical-byte correction remain unchanged.

## 1. Exact private constructor input

Extended proposed signature:

```ts
createController({engine, render, storage, clock=currentClock,
                  attendance=null, revision=null,
                  sourceAuthority=null, persistenceContext=null,
                  controllerEpoch=null})
  -> {callbacks,getState,getResults};
```

controllerEpoch is a **trusted composition-only** input, a string with1..256 UTF-16 code units and nonempty trimmed content. Production composition generates it once with crypto.randomUUID() before constructing that controller. Use the same exact value for controller and persistence context; no independent controller mint, receipt-derived epoch, time/Math.random fallback, UI input, global or function-property backchannel. If the required platform primitive is unavailable, fail initialization honestly; do not weaken the source-authority model.

Legacy construction with both SA facets absent/null and epoch omitted/null keeps existing synchronous behavior and return shape. In active SA construction, sourceAuthority, the context factory below and a valid controllerEpoch are required together. Missing/invalid epoch, a partial facet set, or the wrong factory value type throws TypeError before context invocation/load/render; no silent partial setup or fallback writer. This is constructor admission, not a new persisted status or public source-result enum.

The new scalar reaches controller-owned AuthorityHost.captureBase, which writes it only into the already defined AcceptedBase.binding.controllerEpoch. Existing StorageBase and legacy/profile3 load-result keys remain exact and unchanged. Existing E.Prepared.base and E.AcceptedPayload.base already have this field. No new protocol property, profile version, storage key, endpoint, exported getter or controller return method is introduced.

An epoch is a lifetime identifier, not a credential. Its appearance inside the existing historical E binding is permitted. Knowing it cannot mint a stage, permit or consent; private instance membership remains mandatory.

## 2. Context bootstrap — remove the construction-order ambiguity

The trusted createController argument named **persistenceContext** is now explicitly a **one-use synchronous factory**, not a preconstructed context instance:

```ts
type PersistenceContextFactory =
  (bootstrap:{controllerEpoch:string,authorizeTransition:AuthorizeTransition})
    => PersistenceContext;
```

The bootstrap object has exactly those two required keys. AuthorizeTransition retains the already frozen `(permit,header,current)` signature and private controller-owned registry/clock/binding checks. The factory result retains exactly the existing `load`, `captureBase`, `commit` methods. The storage export itself is unchanged:

```ts
createPersistenceContext({storage,controllerEpoch,authorizeTransition})
  -> PersistenceContext;
```

Why this is necessary: composition owns storage/configuration, while only the controller owns the per-attempt write-permit registry. Main cannot obtain the private authorizer from an undocumented returned property. The controller therefore creates its authorizer closure first, then calls the composition-supplied factory once. The factory constructs the one private context using the exact supplied epoch/closure. It is not an extractor/validator injection surface in UI, and cannot be swapped later. Accepting a preconstructed context instance as a fallback would leave the registry binding ambiguous and is not part of this amended ABI.

This is an explicit narrow value-type/bootstrap clarification to the existing trusted constructor key, in addition to the new epoch key. Do not describe it as an unchanged pre-existing signature or invent a second return channel. No profile3 context implementation existed at the supplied checkpoint, so continuing this adapter does not require discarding implemented context code.

## 3. Initialization order and UI delivery

Main's schematic wiring, **an interface illustration, not production code supplied by A**:

```js
const epoch = crypto.randomUUID();
const authority = createSourceAuthority({approvedManifest,engine});
const persistenceContext = bootstrap => createPersistenceContext({
  storage,
  controllerEpoch: bootstrap.controllerEpoch,
  authorizeTransition: bootstrap.authorizeTransition
});
let uiCallbacks;
const renderWithSource = (state,results,callbacks) => {
  uiCallbacks ??= Object.freeze({...callbacks,source:authority.ui});
  render(state,results,uiCallbacks);
};
const app = createController({
  engine,render:renderWithSource,storage,attendance,revision,
  sourceAuthority:authority.controller,persistenceContext,
  controllerEpoch:epoch
});
```

All variables above are composition-local. No controller resolver, permit, authorizer or context is sent to UI. The existing render argument provides the existing UI-only source facet to real render; no new constructor key for UI or authority facet getter is required. The returned app keeps the original callbacks/getState/getResults shape. Focus/visibility/minute refresh continues through app.callbacks.onRefresh. The UI callback wrapper keeps the same stable method references/facet; it is not a mutable authority registry.

Controller construction order:

1. Validate the trusted complete facet set and epoch before side effects.
2. Create the private transaction/permit registry and controller-owned authorizer closure. It may close over later accepted-state variables, but must not be invoked before their initialization.
3. Invoke persistenceContext({controllerEpoch,authorizeTransition}) exactly once; validate the returned method surface. The factory/context constructor must not write, decode, render or invoke the authorizer.
4. Load/classify persisted state once through the returned context and initialize accepted controller state. Context load does not invoke write authorization. Existing legacy and new profile3 load semantics remain unchanged.
5. Bind the existing exact four-key authority host once, after accepted state exists and before exposing source UI. Its captureBase supplies the private constructor epoch alongside the context-derived base data, not a caller epoch.
6. Initialize callbacks/evaluation and emit through renderWithSource only after host binding. No initial UI callback can reach a half-bound host or uninitialized authorizer/state.
7. Subsequent commits use the same controller registry-bound authorizer and same private context. No second context creation, property patch, global handoff or bypass function is allowed.

## 4. Lifetime, reload and historical compatibility

The constructor epoch is fixed for that createController instance. Mode changes, source replacement, accepted mutation, cancellation, dataset invalidation and explicit reload revoke applicable handles/consent and advance/reset the already specified private generation/lifecycle state. Do not try to rotate this scalar in place behind an immutable context. A newly composed controller has a fresh epoch, new context and empty authority registries. This clarifies the previous phrase “changed/revoked” on lifecycle changes; revocation/generation is sufficient within the same instance. It does not permit stale capability resurrection.

On reload, valid historical receipts keep their original epochs. Never require every historical receipt's epoch to equal the current instance's epoch or rewrite it to fit. Only the active/newly accepted source operation must bind the current controller/context epoch; its Prepared.base and AcceptedPayload.base must agree. The context can check the newly appended receipt against its own constructor epoch before writing. A deliberately miswired context/new-operation epoch must refuse before setItem, without new error vocabulary or changing other classifier precedence. Ordinary writes and loads do not rebind old receipts to the current epoch.

A copied epoch in a JSON object, source request, old receipt or foreign factory remains non-authorizing. No epoch field is added to public accept/prepare intents, StorageBase or load results. The frozen closed source inputs still reject extras.

## 5. Authorization, checkpoint and review

Continue engineering/diamond-sa-001 at checkpoint **d664c6e608990883d5da1dbb9223a7a1a8c81f92**, tree **c5863a16240022597c42de3faf52b685998eb1d2**, direct parent88d606ea940be945fa55124671c1a8deb57c7b04. Preserve that work and failed-attempt evidence. Do not reset, recreate an existing worktree or edit accepted T1.

A verified outer manifest15 entries and evidence manifest164 entries;238 source files match genuine supplied Git objects; exact tree/parent/bundle integrity and permitted partial two-production-path diff hold. The old storage implementation remains an exact prefix. This is identity/scope inspection, **not A approval of the partial authority implementation**. The281 tests and owned-PDF/browser-crypto checkpoints are Codex-executed evidence inspected by A, not independent E/F/D or complete source acceptance. A did not rerun application tests, OCR, browser, build or T1 suites.

All152 SA runtime cases remain UNRUN; lifecycle/capacity/full candidate/independent gates remain pending. Add EP01–08 checks in this package without changing existing oracle outcomes. F/D must inspect this private wiring and lifecycle behavior with the implemented candidate; E must verify actual source lineage. Original D contract acceptance is not relabeled as review of this later adapter amendment.

No production path outside the original nine, no accepted wire schema/status/profile, oracle gold, parser/engine/ledger signature, dependency/lockfile/build/CSS, storage key, implementation objective or release permission is added. Existing owner implementation authorization continues. No production code was modified by A. SA-001 remains OPEN P1; T2-LINK remains separate OPEN P2.
