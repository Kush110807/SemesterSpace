# IMPL02 private epoch/bootstrap amendment

**RESOLVED — CONTINUE THE EXISTING AUTHORIZED ISOLATED IMPLEMENTATION**

Send this whole ZIP to the same Codex conversation and paste `01_EXACT_CODEX_CONTINUATION.md`. Existing owner authorization remains granted. No extra approval round is needed within this bounded private wiring correction.

`00_A_PRIVATE_CHANNEL_AMENDMENT.md` defines the one new trusted controllerEpoch constructor key and the explicit one-use context factory/bootstrap value type. This closes both epoch delivery and controller-owned-authorizer initialization without hidden channels. Original wire schemas,152 oracle rows, nine production paths and independent gates are unchanged. The machine interface key-list overlay and controlling bootstrap spec are in active/; original interface files are retained in accepted/.

`accepted/IMPL01_ERRATUM_WITH_ORIGINAL_SA_C1.zip` preserves the prior complete erratum, original authorized package, accepted contract and D report. `checkpoint/` preserves the genuine partial Git bundle, complete tracked source ZIP, exact base diff, producer report and full producer evidence ZIP. This is a partial implementation checkpoint, not accepted SA code or a tested SA build. Read BUILD_UNRUN.txt. Original artifact indexes describe original delivery files; this package's SHA256SUMS controls its own contents.

A verified identity/scope and inspected producer evidence; no application tests or browser workflow was independently rerun by A. All152 implemented SA cases remain UNRUN. New EP01–08 checks are also UNRUN. UX03/04 pending tester availability is recorded, not waived. Existing gates still govern final acceptance.

Verify `sha256sum -c SHA256SUMS.txt`, then run `python3 research/verify_amendment.py`. It checks artifacts/ABI deltas only, creates no source tree and runs no application. To inspect source, use the authentic checkpoint bundle in a disposable review directory; never fabricate Git identity from source.zip or patch an accepted T1 checkout. Continue the existing candidate from checkpoint d664c6e… without resetting it.

SA-001 OPEN P1; T2-LINK separate OPEN P2. No new CI/merge/push/migration/deployment/release authority.
