# F/D targeted carry-forward: private epoch/bootstrap amendment

Review this with the eventual implemented candidate. No advance full contract restart or new owner authorization is requested. Original D acceptance/C1–C3 and IMPL01 remain intact; do not label them independent approval of this later adapter amendment.

Verify the original accepted SA-C1+IMPL01 identities, active interface list addition controllerEpoch, and controlling PRIVATE_EPOCH_BOOTSTRAP specification. The narrow application ABI clarification also makes the existing persistenceContext constructor value a one-use factory receiving exactly controllerEpoch and the controller-owned authorizeTransition closure. It creates the same already specified context surface. No wire/storage schema or oracle expectation changes.

Independently inspect/test EP-01–EP-08: identical private epoch passed through both paths; failure of incomplete/malformed initialization before side effects; legacy constructor compatibility; no epoch-as-credential; lifecycle revocation/generation; fresh epoch on newly composed instance with historical epoch preservation; one factory invocation before state load/host bind/first render; no preconstructed-instance bypass or privileged UI/global/property channel.

Main's existing render argument supplies only the UI facet to the existing rendering API. Controller receives only resolver; storage context and authorizer remain private. Prepared/AcceptedPayload already bind epoch; no extra StorageBase/load keys. Miswired new source epoch rejects before write, while old historical receipts remain readable and immutable. Mode/reload revokes rather than silently rotating the fixed per-instance scalar behind context.

A verified partial commit d664c6e608990883d5da1dbb9223a7a1a8c81f92/treec5863a16240022597c42de3faf52b685998eb1d2 against authentic Git and supplied source, not its complete behavior. The281 tests/real PDF checkpoint are producer evidence only, not authority acceptance or independent E/F/D execution. All152 full cases and EP controls remain UNRUN now. Preserve all original genuine importer/adversarial/storage/native/capacity/UX/independent-runner gates. Missing human tester does not become a false UX pass.

Return exact finite implemented-candidate findings to A. No implementation, source changes, CI dispatch, merge, push, activation or release is authorized by this note. SA-001 remains OPEN P1.
