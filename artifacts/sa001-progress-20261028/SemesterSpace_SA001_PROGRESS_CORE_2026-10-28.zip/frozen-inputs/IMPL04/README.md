# SA-C1-IMPL-04 finite input amendment

Send this ZIP and01_EXACT_CODEX_CONTINUATION.md to the same Codex conversation. Existing authorization persists. Read00_A_FINITE_DISPOSITION.md for the exact finite scope and dependent controller materialization rules.

```
sha256sum -c SHA256SUMS.txt
python3 research/verify_amendment.py
```

This small package overlays the already available IMPL03 oracle/register, while retaining IMPL01 and IMPL02. Embedded historical version metadata stays unchanged; this overlay is identified by A-SA-C1-IMPL04/2026-10-27-r1 and INPUT_IDENTITIES.json. Original accepted archives remain immutable. No production source, new schema or migration is supplied here.

Optional bounded pure-writer probe, using the authentic checkout and pinned Node:

```
node research/probe_fixture.mjs /ABS/CHECKOUT/semester-space /ABS/THIS_PACKAGE
```

The probe is not a full controller acceptance harness. Complete SA implementation, genuine authority positives, independent E/F/D verification and mandatory human gates remain unfinished. SA-001 OPEN P1. No release authorization.
