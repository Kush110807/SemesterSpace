# A-SA-C1-IMPL04/2026-10-27-r1

SA-C1-IMPL-04 RESOLVED FOR ISOLATED CONTINUATION. DIAMOND-SA-001 remains OPEN P1; complete implementation and acceptance remain unfinished.

Codex's stop was correct. F-SA-40-optional-old-link describes an admitted legacy B2 save, but its original input is envelope2/model1/release2. Deleting two optional source-link members does not make release2 supported. The original input must fail at P4: FAILED / UNSUPPORTED_PERSISTED_VERSION / VERSION /release/version, one read, zero writes, zero hostile candidate getter calls, unchanged bytes. B2/OMR stays unchanged.

## Exact correction and dependency accounting

Preserve the original fixture and all accepted archives. The separately named `active/fixtures/E2_RELEASE1_REAL_LEDGER_HISTORY_A_IMPL04.json` differs in parsed JSON only at `/release/version`: 2 becomes 1. Model revision stays8. No records, closed days, official snapshot references, applied revision, source history, spelling, crosswalk or linked value change. This is a synthetic acceptance-input derivative, never an authorized repair/downgrade of an actual store.

Actual inventory: 16 variants reference the original fixture, not14. This package explicitly dispositions all16 in REFERENCE_DISPOSITIONS.json. Only14 reference leaves change in each active oracle/register: both stored/candidate in F-SA-40-optional-old-link, and the stored base in12 CONTROLLER_SA rows. Thirteen variants change references; their expected tuples, mutations, counts and readiness remain exactly unchanged. All152 IDs and IMPL01/03 corrections survive. IMPL02 bootstrap remains controlling.

The12 controller stored-base changes are finite dependencies of this same wrong version tag: the ten consent scenarios F011-X-15-{required,declined,stage,base}, F-SA-23-decline, F-SA-24-{subset,base-bytes,epoch,stage,profile}; F-SA-40-profile3-upgrade-pending; and F011-X-16a-stale-base-negative. They require a valid legacy base before the intended authority/consent condition can be meaningfully exercised. None is newly declared passed or executed.

Three variants remain byte-for-byte unchanged: F-SA-03a keeps its explicit unsupported-version negative; F-SA-34-current-old-client keeps its unsupported outer3 fence; F-SA-34-pre-B2 stays out of scope. The original release2 fixture is retained for these recipes and supplementary refusal controls. Do not globally replace its filename or change the shared original file.

## Materialization rules — no receipt forgery

For F-SA-40-optional-old-link: start from the new release1 derivative for both sides, apply exactly the existing two deletions, retain indented stored JSON plus newline, pass the complete explicit model/release to the real legacy writer. Expect SAVE_OK/one attempt read/one attempted write, preserved JSON and exact absence of value/changeId. Physical bytes CHANGED follows pretty-to-compact serialization, not a required semantic/history change. Count the explicit verification reload separately. A pure helper has no accepted controller memory; do not invent that observation.

For F-SA-40-profile3-upgrade-pending: use the new derivative as the stored base, then the two existing stored-link deletions. Start a genuine new review/stage for this exact base. Obtain source bytes through the unchanged real importer, review and build a new accepted payload through the actual authorized path. Compute base raw hash, prior-release hash, stage binding, consent, prepared/payload/receipt commitments from their actual values. No copying/relabeling an old immutable receipt, no test-only capability or trusted decoder, no assumption that another E2_REVISION_BASE is interchangeable. Verify optional absence in the preserved historical link/crosswalk; do not demand that a genuinely new source's separate new link omit fields. Assert the required retention mapping explicitly. This remains a future authority-builder/E-verification gate, not solved by the pure writer probe.

For the ten consent scenarios: construct genuine stages/consent against the corrected admitted base before the named fault. Static LEGACY_UNATTESTED_UPGRADE.json is a semantic fixture/reference, not an authentic stage/capability for revision8. Recompute legitimate live bindings through real code, never retrofit persisted receipt hashes into authority. Counts apply only to the acceptance attempt, not preceding reads/review work. Preserve the distinction: named SA-PRE cached/private consent invalidation rows have zero attempt reads; actual external persisted-byte drift is the distinct one-read check. Do not reinterpret all BASE_BYTES_CHANGED cases as the same fault recipe.

For F011-X-16a-stale-base-negative: preserve the intentional revision8 stored base versus revision6 consent/receipt and revision7 candidate mismatch. The derivative only makes the stored profile admissible. Do NOT refresh that deliberately stale consent, substitute revision6 data, or recompute its frozen mismatch away. It must refuse for its specified stale-base reason after the prescribed one read, without writes or candidate inspection. Record cached base, presented stale token and actual persisted base separately. If genuine protocol execution cannot produce the specified scenario, report that precise reachability/interface conflict; never fabricate a stage to force the tuple.

Preserve all stated expected tuples. Any newly reproducible conflict beyond this source-version correction still requires a finite A disposition. This amendment is not approval to edit adjacent gold or bypass actual authority construction.

## Actual evidence and limits

A verified15 outer and310 nested manifest entries, genuine bundle clone/fsck/commit/tree/parent, all249 tracked archive files against Git blobs, and only three supporting doc/test changes since c6410cbc. No production or lockfile change this pass. Checkpoint18a190c57eac63ce45c465cac74c21e2d89300e2/tree1141db0c8cf4916c6989f2b4624cc1db6b262ae9, parentc6410cbc7f42b3c2f24c289a8bffc3143d11a09b. T1 storage equals its authentic accepted Git bytes.

A's included finite probe ran four storage inputs on each authentic T1 and partial module: original/derived version, with/without the specified optional deletions. Both originals refused with reads1/writes0/getters0/unchanged bytes. Both derivatives saved and reloaded exact parsed history; missing optional members remained absent. Nodev24.22.1, raw stdout/stderr/exits retained. These eight observations are pure in-memory fixture checks, not eight complete SA cases or independent F/D acceptance. No T1 suite, build, browser or CI rerun by A. Codex's prior289 checks and partial129 storage matches remain producer-attributed, incomplete and not transferred as final candidate passes.

F-SA-46-unpaired is a reported implementation defect, not an oracle erratum: fix within scope after resumption, retain its expected result and raw failing attempt. Complete producer/browser/capacity/authority/UX gates remain mandatory. UX03/04 stay UNRUN without actual human testers.

## Authorization and independent review

Existing Product Owner isolated-implementation authorization persists. No new approval is required for this finite synthetic-input correction. Resume the existing branch/worktree, not a new/reset checkpoint. No new production path, signature, schema version or storage migration is authorized. F/D must inspect the exact correction and eventually execute/review candidate evidence independently; original D acceptance is not relabeled as approving these new bytes. E must verify genuine upgrade semantics and preserved optional-history absence. No broad C1/C2/C3 research restart.

No A production changes. No merge, push, GitHub write, CI dispatch, real-profile migration/activation, deployment or release. T1/main/integration preserved. T2-LINK remains separate OPEN P2.
