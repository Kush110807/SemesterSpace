# Targeted review at eventual candidate verification

F: check the one-leaf fixture derivative,14 reference changes and unchanged152 tuples/IDs. Independently run optional-link legacy save, exact absence/history reload, original unsupported-release negatives with hostile getters, and the genuine profile3 upgrade. Confirm no runtime release2→1 normalization and no weakened version fence. Inspect the12 controller recipe bindings and distinguish cached consent invalidation from persisted-byte drift. Review F-SA-46 as implementation behavior, not amended gold. Independently recheck storage/provenance/uncertainty/capacity gates against final bytes.

E: verify the genuine new operation on the exact optional-absence legacy base. New private input/run/review lineage and all accepted commitments must be actual; preserve the historical absence and existing facts without reattestation. Existing example receipts are not bearer capabilities. The future upgrade case remains pending your independent candidate-level verification.

D: inspect this finite reference overlay alongside IMPL01–03 and the exact eventual candidate. Confirm authentic ancestry, authorized scope, complete execution bindings, failed attempts retained and no fabricated positive/stale capability. Check that the intentional revision8-versus6 stale scenario remains intact and meaningful. Do not transfer original contract acceptance to the new overlay or partial implementation; retain HOLD for missing mandatory gates, including real human gates where required.

No request to reopen closed mathematical/semantic research or accepted T1 verification. SA-001 stays OPEN P1 until independently accepted, implemented and verified as required. No activation/release authority is created by this review note.
