# Targeted review with the eventual implementation candidate

F: independently verify the derivative differs from the original only at /release/version (2→1); both active references and embedded register agree; all 152 IDs/expectations and previous amendments remain unchanged. Execute the genuine positive/history reload and original future-version/hostile-getter negative. Verify zero implicit downgrade/migration of stored release2 and preserved P0–P11/OMR behavior. Review remaining storage, provenance, capacity and uncertainty cases against candidate bytes. A's finite probes are not your execution results.

D: inspect this bounded oracle-input overlay and F's independent results alongside IMPL01/02 and the exact final candidate. Confirm scope, authentic lineage, complete raw execution bindings, existing failed attempts, genuinely unrun human gates, and no transferred or synthetic PASS. Original D contract acceptance does not itself approve the new overlay or unfinished implementation. Retain HOLD if mandatory evidence remains missing.

E: no semantic evidence-graph, authority or canonicalization contract changes occur here. Retain the assigned real-importer, source-substitution, stage/replay and evidence-integrity candidate verification; no reopening closed C1/C2/C3 research is requested.
