# A-SA-C1-IMPL03/2026-10-27-r1 — acceptance-input correction

Disposition: SA-C1-IMPL-03 RESOLVED FOR CONTINUATION. Isolated implementation remains incomplete. DIAMOND-SA-001 remains OPEN P1.

Codex correctly stopped. F-SA-02a describes an admitted e2/model1/release1 positive but points to an e2/model1/release2 fixture. Its unchanged T1 B2 writer must reject that original input at P4 with FAILED / UNSUPPORTED_PERSISTED_VERSION / VERSION /release/version, one read, zero writes, unchanged bytes. No production change may admit release2 to the frozen B2 path.

## Controlling finite correction

Preserve the original fixture and accepted archives immutably. Introduce `active/fixtures/E2_B2_RELEASE1_OPAQUE_HISTORY_A_IMPL03.json`: the original parsed JSON with ONLY `/release/version` changed from 2 to 1. No historical record, model revision, crosswalk, source spelling, opaque linked value, or attendance fact changes. Formatting remains indented JSON plus newline. This is an acceptance-input derivative, never a migration or a repair of real stored data.

In F-SA-02a only, replace both fixture.stored and fixture.candidate references with `fixtures/E2_B2_RELEASE1_OPAQUE_HISTORY_A_IMPL03.json`. Preserve all expected fields and every other variant exactly. Preserve the 152 IDs and IMPL01's two CHANGED physical-byte corrections. Apply the identical two-reference change to the embedded register oracle. This package supplies both complete active files, originals, derivative, and a verifier.

The positive attempt uses the fixture text as stored bytes and explicit full fixture.model and fixture.release as candidate values, options `{}`. P11 SAVE_OK, one read/one write, exact parsed model/release preservation, no re-stamping, remain required. Physical bytes CHANGED is coherent because this pretty stored JSON is rewritten compactly by the real serializer. Do not minify the stored input before the attempt. A standalone writer has no controller memory: ADVANCE_AFTER_ACK is a rule for the consuming controller harness, not permission to invent controller observations from the pure probe. Track any separate explicit reload read outside attempt counts.

Retain the original release2 fixture as supplemental control A-IMPL03-NEG: P4 refusal above. Exercise a hostile candidate getter and confirm zero invocation before refusal. This control supplements the unchanged 152-case register; it neither replaces the positive nor counts as a new passing registered case. Do not change adjacent cases by inference.

## What A actually inspected and ran

13/13 outer and 203/203 nested manifest entries passed. Authentic bundle clone/fsck and commit/tree/parent inspection passed. All 247 tracked source-archive files matched genuine Git blobs for c6410cbc7f42b3c2f24c289a8bffc3143d11a09b, tree b5469efe84c4e484c98dea8f08a3eaa1a3498df4, parent d664c6e608990883d5da1dbb9223a7a1a8c81f92. T1 storage matched its authentic Git blob and accepted SHA c9e3afacef8341dbb15d8efeb56fd76be007b32d04ca42d985ad3d24abd5fce8.

A ran only the included two-input Node probe, separately against authentic unchanged T1 and the partial checkpoint. Both refused the original with zero writes; both saved the derived release1 with one write, preserved parsed history exactly, and reloaded it with SAVED. Node v24.22.1, raw outputs/exits included. This new concrete finding warranted these finite probes, not a T1 verification-suite rerun. No accepted T1 source changed. These are pure storage fixture checks, not full F-SA-02a controller/authority acceptance, independent F/D candidate acceptance, or a complete SA test result. Codex's 289 bounded checks remain Codex-attributed. Remaining oracle failures require honest implementation/harness diagnosis, not gold adjustment.

## Authority, review and limits

This correction supplies the intended supported positive without weakening B2/OMR, adding a wire version, changing a production signature or expanding the nine-file scope. It overlays the existing IMPL01 oracle/register; IMPL02 private bootstrap remains controlling. Original D contract acceptance stays historically attributed to its original bytes; F and D must explicitly inspect this finite correction and its eventual candidate results. No new broad C1/C2/C3 research review is requested. Existing Product Owner isolated-implementation authorization remains valid; no renewed approval is needed.

Continue from the existing clean checkpoint; do not recreate/reset worktrees. Finish in-scope implementation and real acceptance gates. If another concrete contradiction arises, stop with exact inputs/outputs and a finite request. Keep genuine failed attempts. Do not weaken tests, transfer previous PASS claims, simulate importer authority or conflate static verification with runtime acceptance. UX03/04 remain UNRUN until actual human evidence exists. No merge, push, CI dispatch, production activation, real-store migration, deployment or release. T2-LINK remains separate OPEN P2.
