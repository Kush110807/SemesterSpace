# SA-C1-IMPL-03 finite correction

Read 00_A_FINITE_DISPOSITION.md, then give 01_EXACT_CODEX_CONTINUATION.md and this complete ZIP to the same Codex implementation conversation. Existing authorization remains granted. The package intentionally excludes the large, already available source and earlier archives; no download exceeds 32 MiB.

From this directory:

```
sha256sum -c SHA256SUMS.txt
python3 research/verify_amendment.py
```

The package is an overlay to the existing IMPL01 oracle/register and IMPL02 private-bootstrap amendment. Preserve those original archives. The active files retain their original embedded version metadata; A-SA-C1-IMPL03/2026-10-27-r1 and INPUT_IDENTITIES.json identify this overlay explicitly. No claim of byte identity with the original accepted oracle is made.

For the optional finite storage probe only, using the existing authentic checkout:

```
node research/probe_fixture.mjs /ABS/CHECKOUT/semester-space /ABS/THIS_PACKAGE
```

This is not the complete controller/stage acceptance harness. No application source is supplied or modified here. DIAMOND-SA-001 remains OPEN P1.
