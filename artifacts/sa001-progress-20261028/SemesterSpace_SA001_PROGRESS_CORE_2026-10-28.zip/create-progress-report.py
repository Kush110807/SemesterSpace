from pathlib import Path
import json,hashlib,subprocess,datetime
out=Path('/workspace/sa001-progress-20261028');ev=Path('/workspace/sa001-impl04-continuation-evidence');identity=json.loads((out/'SOURCE_IDENTITY.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
def add(label,kind,scope):
 p=ev/label/'report.json';d=json.loads(p.read_text());exitFile=ev/(label+'.exit');entry={'label':label,'classification':kind,'scope':scope,'report':'raw-evidence/impl04-continuation/'+label+'/report.json','reportSha256':sha(p),'reportedStatus':d.get('status'),'recordedExit':exitFile.read_text().strip() if exitFile.exists() else None,'caseCount':len(d.get('cases',[])),'binding':'Existing producer execution; not a final all-gates execution on a new candidate commit.'};rows.append(entry);return d
browser=add('browser-attempt10','REAL_READER_AND_NATIVE_BROWSER_POPULATION','43 assertions covering actual PDF/OCR, P1-P9-related flows, 18 F controller cases, retained history, native same-profile process reopen, physical changed-write/ACK faults, source binding/witness and history guards. Some negative cases use explicitly labeled trusted-resolver fault wrappers.')
add('effects-attempt6','REAL_READER_TYPED_EFFECTS','Eight closed effect kinds plus manual missing rows; 9 population entries.')
a=add('adversarial-attempt3','REAL_READER_AND_ADMISSION_CONTROLS','100 recorded controls, including one unavailable SharedArrayBuffer browser exposure control; not the complete AUTH register.');rows[-1]['controlCount']=len(a['result']['cases']);rows[-1]['unavailable']=[v for v in a['result']['cases'] if not v.get('pass')]
add('acknowledgment-after2','TRUSTED_CONTEXT_ACK_FAULT_CONTROLS','4 source/ordinary SAVE_OK acknowledgment-shape guards; physical write preserves memory until explicit reload.')
add('retained-attempt1','RETAINED_T1_BROWSER_POPULATION','19 recorded cases for manual event create/update/no-op/dirty base/source/reopen/faults/clock and history. Full 12-workflow equivalence mapping remains to reconcile.')
add('semantics-attempt2','REAL_READER_SEMANTIC_CHARACTERIZATION','Ambiguous dates, disjoint date sets and negation retained with reviewed meanings; SEM population reconciliation remains.')
add('ui-attempt16','MAIN_COMPOSITION_INITIAL_UI','Actual built main composition initial source-review form and keyboard interactions; native file delivery uses automation, not a claimed human/native-file-picker session.')
add('ui-revision-attempt5','MAIN_COMPOSITION_REVISION_UI','5 document-continuity/group/consent/uncertainty/reload controls with keyboard interactions.')
add('manual-ui-attempt1','MAIN_COMPOSITION_MANUAL_UI','One complete manual fallback population; separate from documentary source positives.')
add('zoom-attempt3','MAIN_COMPOSITION_NATIVE_ZOOM','6 200-percent browser-zoom/reflow observations at required mobile widths and forms.')
add('lifetime-attempt2','REAL_STAGE_LIFETIME_CLOCK_DRIFT','7 typed-intent/review-clock/external-byte/dataset drift controls. Earlier failed expectation preserved; updated ad hoc test follows existing source-consent tuple, no oracle changed.')
capacity=add('capacity-resume-20261028-a','NATIVE_CAPACITY_AND_REFUSAL','24 genuine successive revisions with growing actual ledger, 20-page PDF, memory/time samples, real origin quota, cap boundaries including escaped/multibyte strings, safe near-cap day-close/correction refusal, readonly guards and native process reopen.')
latestStorage=json.loads((ev/'storage-attempt3/register.json').read_text());oracle=json.loads(Path('/workspace/sa001-impl04-amendment/active/F011_EXACT_TEST_VARIANTS_A_IMPL04_CORRECTED.json').read_text());byStorage={r['id']:r for r in latestStorage['results']};byBrowser={r['id']:r for r in browser['cases']};bindings=[]
for v in oracle['variants']:
 ident=v['variantId'];s=byStorage.get(ident);b=byBrowser.get(ident)
 if s and s['status']=='PASS_STORAGE_ASSERTIONS_ONLY':status='EXECUTED_STORAGE_ASSERTIONS_FULL_CASE_RECONCILIATION_PENDING';path='storage-attempt3/'+ident+'.json'
 elif b:status='EXECUTED_BROWSER_POPULATION_FINAL_BINDING_RECONCILIATION_PENDING';path='browser-attempt10/report.json#/cases/'+str(browser['cases'].index(b))
 elif v['operation']=='TEST_SUITE':status='EXTERNAL_B2_OMR_SUITE_EVIDENCE_AVAILABLE_NOT_SINGLE_CALL_PASS';path='full-tests-attempt2.stdout'
 elif v['component']=='OUT_OF_SCOPE' or v['expected']['phase']=='NOT_APPLICABLE':status='EXCLUDED_FROM_SINGLE_CALL_PASS_COUNT';path=None
 else:status='UNRUN_OR_UNMAPPED';path=None
 bindings.append({'id':ident,'operation':v['operation'],'component':v['component'],'expected':v['expected'],'progressStatus':status,'evidence':path})
counts={}
for b in bindings:counts[b['progressStatus']]=counts.get(b['progressStatus'],0)+1
(out/'CASE_TO_EVIDENCE_PROGRESS.json').write_text(json.dumps({'classification':'PROGRESS_ONLY_NOT_ACCEPTANCE_REGISTER_REWRITE','activeOracleSha256':'5628adc49a277b4b283fb9cdfbc082924048dc24e018db415b2e9c768f3497a1','countsNotPassingCaseTotals':counts,'bindings':bindings,'producerPopulations':rows},indent=2)+'\n')
(out/'TEST_RESULTS_PROGRESS.json').write_text(json.dumps({'classification':'PAUSED_PROGRESS_EXISTING_PRODUCER_RESULTS','fullSuite':{'command':'npm test','report':'raw-evidence/impl04-continuation/full-tests-attempt2.stdout','recordedExit':0,'tests':638,'pass':638,'fail':0,'skipped':0,'todo':0,'limitation':'Historical dirty-worktree execution before later implementation changes; final full-suite execution on frozen candidate is pending.'},'epochAndCodecs':{'tests':98,'exit':0,'report':'raw-evidence/impl04-continuation/epoch-codecs-current.stdout'},'storage':{'matchedPartialStorageAssertions':131,'stageDependentOrSuiteRowsNotRunByThisRunner':21,'notCompleteSACasePassCount':True},'populations':rows,'independentReviews':'E/F/D UNRUN_PENDING','UX03UX04':'UNRUN_NO_TESTER_AVAILABLE','allFinalProducerGates':'NOT_YET_RECONCILED_OR_RERUN_ON_FROZEN_FINAL_CANDIDATE','evidenceLimitation':'One resume capacity-attempt1 log-label collision overwrote earlier top-level stream files; the prior report directory remains preserved. Exact event in raw evidence resume-evidence-label-collision.json. No claim that overwritten prior stream bytes were recovered.'},indent=2)+'\n')
inputs=[]
for path in [Path('/workspace/sa001-input/SHA256SUMS.txt'),Path('/workspace/sa001-erratum/ERRATUM_INDEX.json'),Path('/workspace/sa001-impl02-amendment/AMENDMENT_INDEX.json'),Path('/workspace/sa001-impl03-amendment/INPUT_IDENTITIES.json'),Path('/workspace/sa001-impl04-amendment/INPUT_IDENTITIES.json')]:inputs.append({'path':str(path),'sha256':sha(path)})
(out/'ACTIVE_INPUT_IDENTITIES.json').write_text(json.dumps({'originalSA_C1ArchiveSHA256':'3c249e8acaf4d888f7c121b25baafef89196ed5616b48b95f579b10f8e86ff46','acceptedContractSHA256':'564dd204ebb26b6a0463a52c10019037f3fb8faf14e2a82472fcdd861229605b','IMPL01ArchiveSHA256':'4da5accf4ecff588fa7981b2b12ad64fc76224a888df3a4f18bb32c7095ef10a','IMPL02ArchiveSHA256':'d787e2eed73dabec84d07217718e1cb0089fa225d2c247dd59b0a5d80f503585','IMPL03ArchiveSHA256':'5c42652d6cc37d074665d3d5dbd2eebf474b770b1f068e385c96ba94a06127d1','IMPL04ArchiveSHA256':'2d2cdde6cccb40487166b7ab10f6292ca54b3f05c0bb4322d47b51cc2cd255f4','precedence':['Original D assembly and SA-C1 immutable historical inputs','IMPL01 exact two physical-byte expectation leaves and register mirrors','IMPL02 trusted epoch/factory bootstrap, no oracle change','IMPL03 separately named release1 derivative and F-SA-02a references only','IMPL04 separately named ledger release1 derivative and explicit 14 reference leaves in 13 variants; all152 outcomes preserved'],'activeOracleSHA256':'5628adc49a277b4b283fb9cdfbc082924048dc24e018db415b2e9c768f3497a1','activeRegisterSHA256':'7fcc171afec1763325d5899f2604915019e698a89b2d7a71faa920b337042f6d','indexes':inputs},indent=2)+'\n')
text=f'''# SemesterSpace SA-001 — paused progress handoff

28 October 2026. **PAUSED PROGRESS SNAPSHOT — NOT A FINAL CANDIDATE — NOT INDEPENDENTLY ACCEPTED — NOT RELEASED.** Implementation remains paused at the owner's request. This handoff captures existing work and results; no installation, tests, rebuild, source edits or new candidate commit were performed to produce it.

## Exact source state

- Repository worktree: `/workspace/SemesterSpace-sa-001`; branch `engineering/diamond-sa-001`.
- Last committed checkpoint: `{identity['lastCommit']}`; committed tree `{identity['lastCommittedTree']}`.
- Current uncommitted source/support snapshot tree: `{identity['uncommittedSnapshotTree']}`. This is a genuine Git tree captured with a temporary index; it is **not a new commit**. The real index, working bytes and refs remain unchanged.
- Authorized accepted T1 base: `88d606ea940be945fa55124671c1a8deb57c7b04`, tree `1efa8ec205d125ac3fac9d934e99cfdccceff872`.
- Exactly the authorized nine production paths differ from T1. No dependency/lockfile/build-source/CSS/engine/ledger/importer implementation or additional storage-key change is included. `SOURCE_IDENTITY.json` has every source SHA-256 and exact dirty status.

## Work implemented so far

Private copied-source intake and run lineage, closed review commands/editor projections, source-wide review and dependency-group selection, typed eight-effect adapters, source receipt construction, trusted epoch/context factory bootstrap, identity-bound controller stages/leases/consent/permits, raw source-route denial, historical and clock guards, profile3 context classification/limits/one-write persistence, acknowledged-state promotion and explicit uncertainty/reload handling. Main composition and the four allowed UI modules now use the UI authority facet, typed review forms, explicit consent/apply/reload and retained-history presentation. These are implementation descriptions, not a claim that every required gate has passed.

Original B2/OMR writer fence is retained. IMPL01 through IMPL04 active overlays were verified and preserved. IMPL03/04 synthetic release1 derivatives apply only to the named acceptance inputs; real stored release2 is never normalized to release1. Pending unpaired-string admission was corrected in scope. Supporting tests, genuine synthetic document generators and narrow old-test adaptations are included. Per-test adaptation reasons and replacement meaningful coverage are recorded in `tests/sa-001/LEGACY_TEST_ADAPTATIONS.json`; an early raw-route rejection is not relabeled as execution of a history guard.

## Existing executed results

Counts are overlapping populations, **not totals to add**. They are historical producer executions on evolving local source, not an all-gates run bound to a final frozen candidate.

| Population | Recorded result | Scope/limit |
|---|---:|---|
| Full `npm test` |638/638 pass,0 fail/skip/todo,exit0|Later implementation changes still need final complete execution. Earlier18 failures and their corrections remain in evidence.|
| Epoch + codec tests |98 pass,exit0|Includes native Node/browser SHA comparisons and targeted bootstrap controls; full EP register reconciliation remains.|
| Storage oracle probe |131 partial storage matches,21 not executed by runner|Not131 complete SA passes. Browser execution covers18 additional controller rows; three suite/out-of-scope rows are not single-call passes. Full per-case bindings still need reconciliation.|
| Genuine source/browser population |43 cases,exit0|Actual PDF and installed OCR, initial/revision/selective effects, P2–P9-related flows,18 controller oracle rows, saved history and real same-profile new-process reopen. Some negative guards use labeled trusted fault wrappers.|
| Typed effects/manual missing rows |9 entries,exit0|Eight effect kinds plus real-reader layout-abstention/manual completion.|
| Adversarial source/admission |100 recorded controls|99 recorded pass; SharedArrayBuffer browser exposure control UNAVAILABLE on the non-isolated origin. No unavailable control is counted as pass.|
| Acknowledgment controls |4 entries,exit0|Source/ordinary malformed or missing SAVE_OK acknowledgment boundaries.|
| Retained T1 browser population |19 entries,exit0|Event/UI/dirty-base/fault/reopen/history/clock; exact retained12-workflow mapping remains to reconcile.|
| Semantic characterization |3 entries,exit0|Ambiguous dates, disjoint set and negation; no parser-truth/accuracy claim or complete SEM register claim.|
| Main initial/manual/revision UI |Passing recorded runs|Typed forms, saved-vs-staged/consent/recovery, keyboard interactions; file inputs supplied via browser automation. Not a human walkthrough.|
| Native200% zoom/reflow |6 observations,exit0|Executed mobile forms and primary actions; not a full UX acceptance claim.|
| Latest live-stage/clock/drift |7 entries,exit0|Invalid intents, rollback and external-byte/dataset drift; failed prior attempt preserved.|
| Latest capacity/refusal run |31 measurements,19 cases,exit0|24 successive genuine revisions with growing ledger;20-page PDF; quota/boundary/refusal/reopen controls. No headroom approval.|

`TEST_RESULTS_PROGRESS.json` and `CASE_TO_EVIDENCE_PROGRESS.json` bind every active F ID to available evidence or an explicit pending/exclusion status. Original acceptance metadata/gold is unchanged.

The continuous browser session records source setup → revision → connected persistence → browser-process close/reopen with the same persistent profile and no reseeding → changed physical-write/ACK faults → explicit reload. F-SA-26-commit-throw and F-SA-27a observe genuinely changed validated bytes, one read/one attempted write, accepted model/release unchanged before explicit reload, revoked stage and no compensating write. Native profiles themselves are excluded; synthetic before/after exports and traces are included.

Capacity evidence observed24 successful new reviewed revisions, then a20-page notice accepted. That final envelope was720,960 UTF-8 bytes; the20-page receipt108,609 bytes. Both fixed caps at-1/equality/+1 include ASCII and escaped/multibyte tests. Origin quota was genuinely filled and growth refused; near-cap day-close/correction preserves history on refusal. Timing/process/heap samples are observations on this producer machine, not an absolute peak or a student-device/semester budget guarantee.

## Remaining work before a final engineering candidate

1. Finish the explicit152-case, AUTH01–17, ADP01–14, EP01–08, SEM01–04, nine-positive and retained12-workflow reconciliation; complete any missing assertions/controls. Do not turn population matches into full acceptance passes.
2. Resolve the unavailable browser SharedArrayBuffer control or record it with an explicit legitimate execution/exclusion treatment; no synthetic pass.
3. Finish any implementation defects exposed by those checks; then execute pinned clean npm ci, syntax, full suite, unchanged engine/ledger/B2/OMR regressions, independent arithmetic checker, production build and required browser/capacity gates against the final exact source. Do not transfer earlier PASS results across changed source.
4. Freeze a clean local candidate commit, bind final source/build/lockfile bytes and commands/exits, and prepare E/F/D review handoff. No final complete candidate exists yet.
5. UX03 real screen-reader session and UX04 non-author student walkthrough remain **UNRUN: owner reports no tester available**. Automation is not a substitute. They prevent all-acceptance/closure/readiness claims, but do not prevent completing other authorized work once the owner resumes it.
6. E/F/D independent candidate verification and A disposition/closure remain **UNRUN/PENDING**. Producer results do not replace them.

## Evidence and archive contents

`source-progress.zip` contains the exact current tracked/untracked approved source/support snapshot. The three full-index binary patches reproduce that tree from authentic18a190c,c6410cb or88d606e. `committed-history.bundle` contains genuine committed history through18a190c; it does not pretend the uncommitted snapshot is a committed candidate. `build-progress.zip` archives the existing served production-build bytes without rebuilding; all nine production files match current source bytes, with independent build hash inventory. This is not final release/build acceptance.

Raw continuation evidence includes failed attempts, JSON requests/results, storage exports, source fixtures, native reopen receipts, screenshots/traces and available command stdout/stderr/exits. Earlier immutable checkpoint evidence is included separately. Some earlier build attempts lack a separately saved exit file; that is reported as missing, never inferred from a success string. One resume label collision overwrote prior capacity-attempt1 top-level stream files before an EEXIST refusal; its prior report directory is preserved and the loss is explicitly recorded in `resume-evidence-label-collision.json`. There is no claim that missing earlier stream bytes were recovered. Native browser profiles, node_modules/caches and credentials are excluded.

`frozen-inputs/` preserves the nested original SA-C1/accepted contract/IMPL01/IMPL02 archives plus IMPL03/04 amendments and active oracle/register. `SHA256SUMS.txt` covers this handoff. Tool versions are recorded. Restoration instructions are in `REPRODUCE_SNAPSHOT.md`.

## Authority and status

Implementation remains paused. Main, accepted T1 and local integration are unchanged. No GitHub write/push/PR/CI/merge/migration/activation/deployment/release was performed for this handoff. DIAMOND-SA-001 remains **OPEN P1**; T2-LINK remains separate **OPEN P2**. Open Interval and B's objectives remain separate.
'''
(out/'PROGRESS_HANDOFF.md').write_text(text)
(out/'REPRODUCE_SNAPSHOT.md').write_text(f'''# Reconstruct the paused source without pretending it is a final commit

Use a new scratch repository; do not overwrite an existing worktree. Verify SHA256SUMS.txt first.

```
git clone committed-history.bundle scratch-sa001
cd scratch-sa001
git checkout {identity['lastCommit']}
git apply --index ../18a190c-to-progress.patch
git write-tree
```

Expected tree: `{identity['uncommittedSnapshotTree']}`. The patch includes the new supporting files. The expected working tree is modified; there is no new candidate commit. Alternatively extract source-progress.zip to a new directory; archive extraction alone does not establish Git identity.

Frozen original inputs can be expanded from IMPL02's nested accepted IMPL01 archive. Apply IMPL03 and IMPL04 as separate active overlays, never overwrite accepted originals. Some supporting producer scripts use the prescribed `/workspace/...` input locations; reproduce those locations or adapt only the supporting path configuration, recording the adaptation. Do not execute commands while this assignment remains paused without an instruction to continue. Commands listed in evidence are historical recipes, not a new authorization or claim that final gates passed.
''')
print(json.dumps({'snapshotTree':identity['uncommittedSnapshotTree'],'bindingPopulations':counts,'reports':len(rows)},indent=2))
