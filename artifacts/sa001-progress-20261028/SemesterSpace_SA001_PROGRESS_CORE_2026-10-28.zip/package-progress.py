from pathlib import Path
import json,zipfile,subprocess,hashlib,shutil,os,tempfile,datetime
out=Path('/workspace/sa001-progress-20261028');repo=Path('/workspace/SemesterSpace-sa-001');identity=json.loads((out/'SOURCE_IDENTITY.json').read_text())
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
def git(*args,env=None):return subprocess.check_output(['git','-C',str(repo),*args],env=env)
# Verify both reconstruction and complete committed ancestry without altering any checkout/ref.
checks={}
for base,name in [('18a190c57eac63ce45c465cac74c21e2d89300e2','18a190c-to-progress.patch'),('c6410cbc7f42b3c2f24c289a8bffc3143d11a09b','c6410cb-to-progress.patch'),('88d606ea940be945fa55124671c1a8deb57c7b04','88d606e-to-progress.patch')]:
 with tempfile.TemporaryDirectory(prefix='sa001-progress-verify-',dir='/tmp') as tmp:
  env={**os.environ,'GIT_INDEX_FILE':tmp+'/index'}
  for args in [('read-tree',base),('apply','--cached',str(out/name))]:git(*args,env=env)
  actual=git('write-tree',env=env).decode().strip();assert actual==identity['uncommittedSnapshotTree'];checks[name]=actual
with tempfile.TemporaryDirectory(prefix='sa001-progress-bundle-',dir='/tmp') as tmp:
 subprocess.run(['git','init','--bare',tmp],capture_output=True,check=True);r=subprocess.run(['git','-C',tmp,'bundle','verify',str(out/'committed-history.bundle')],capture_output=True);assert r.returncode==0;checks['bundle']=r.stdout.decode()+r.stderr.decode()
# Frozen original archives; original SA-C1/contract/IMPL01 remain inside IMPL02's immutable nested archive.
frozen=out/'frozen-inputs';frozen.mkdir()
paths=[Path('/workspace/sa001-impl02-transport/reassembled/SemesterSpace_SA001_IMPL02_Private_Epoch_Amendment_and_Continuation.zip'),Path('/workspace/attachments/2e35dbbd-2104-4d56-b2f5-5b0683301644/SemesterSpace_SA001_IMPL03_Finite_Amendment_and_Continuation.zip'),Path('/workspace/attachments/a5af4e67-98ec-4cd1-b67a-b653c1202091/SemesterSpace_SA001_IMPL04_Finite_Amendment_and_Continuation.zip')]
for p in paths:shutil.copy2(p,frozen/p.name)
for root,label in [(Path('/workspace/sa001-input'),'original-SA-C1'),(Path('/workspace/sa001-erratum'),'IMPL01'),(Path('/workspace/sa001-impl02-amendment'),'IMPL02'),(Path('/workspace/sa001-impl03-amendment'),'IMPL03'),(Path('/workspace/sa001-impl04-amendment'),'IMPL04')]:
 dest=frozen/label;dest.mkdir()
 for p in root.iterdir():
  if p.is_file() and p.suffix in ['.md','.json','.txt']:shutil.copy2(p,dest/p.name)
 if (root/'active').exists():shutil.copytree(root/'active',dest/'active')
# Preserve both prior immutable evidence and every current continuation attempt. No browser profiles.
evidenceRoots=[(Path('/workspace/sa001-impl02-evidence-sealed'),'prior-IMPL02'),(Path('/workspace/sa001-impl03-evidence-sealed'),'prior-IMPL03'),(Path('/workspace/sa001-impl04-evidence-sealed'),'prior-IMPL04'),(Path('/workspace/sa001-impl04-continuation-evidence'),'impl04-continuation')]
records=[]
for root,label in evidenceRoots:
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  parts=p.relative_to(root).parts;assert not any(x in ['node_modules','.cache','profiles','.git'] or x.startswith('sa001-native-profile-') for x in parts),p
  records.append((p,Path(label)/p.relative_to(root)))
print('Archiving raw evidence files:',len(records),flush=True)
checksums=[]
with zipfile.ZipFile(out/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
 for p,name in records:
  digest=sha(p);checksums.append(digest+'  '+str(name));z.write(p,name,compress_type=zipfile.ZIP_STORED if p.suffix in ['.zip','.png','.jpg','.jpeg'] else zipfile.ZIP_DEFLATED)
(out/'RAW_EVIDENCE_SHA256SUMS.txt').write_text('\n'.join(checksums)+'\n')
with zipfile.ZipFile(out/'build-progress.zip','w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
 for p in sorted((repo/'semester-space/dist').rglob('*')):
  if p.is_file():z.write(p,Path('dist')/p.relative_to(repo/'semester-space/dist'))
# Exact commands/exit files as observed, including missing build exit receipts.
commandInventory=[]
for root,label in evidenceRoots:
 for p in sorted(root.glob('*.stdout')):
  prefix=p.with_suffix('');exitFile=Path(str(prefix)+'.exit');errorFile=Path(str(prefix)+'.stderr');commandInventory.append({'label':str(Path(label)/prefix.name),'stdout':str(Path('raw-evidence')/label/p.name),'stderr':str(Path('raw-evidence')/label/errorFile.name) if errorFile.exists() else None,'recordedExit':exitFile.read_text().strip() if exitFile.exists() else None,'missingExitNotInferred':not exitFile.exists()})
(out/'COMMAND_LOG_INVENTORY.json').write_text(json.dumps(commandInventory,indent=2)+'\n')
versions=[]
for cmd in [['node','--version'],['npm','--version'],['python3','--version'],['git','--version'],['/usr/bin/chromium','--version']]:
 r=subprocess.run(cmd,capture_output=True);versions.append({'command':cmd,'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
(out/'TOOL_VERSIONS.json').write_text(json.dumps(versions,indent=2)+'\n')
# Isolation proof: source/status/index/refs remain byte-identical to the snapshot operation's start.
assert git('status','--porcelain=v1','--untracked-files=all')==(out/'snapshot-status-before.txt').read_bytes();assert git('show-ref')==(out/'refs-before.txt').read_bytes();assert git('worktree','list','--porcelain')==(out/'worktrees-before.txt').read_bytes()
assert git('rev-parse','refs/heads/main').decode().strip()=='4233158b6225bb5b1c11a11e53182a38b6f02942'
protected=[]
for root,head in [('/workspace/SemesterSpace','4233158b6225bb5b1c11a11e53182a38b6f02942'),('/workspace/SemesterSpace-diamond-001','88d606ea940be945fa55124671c1a8deb57c7b04'),('/workspace/SemesterSpace-integration-diamond-001','88d606ea940be945fa55124671c1a8deb57c7b04')]:
 assert subprocess.check_output(['git','-C',root,'rev-parse','HEAD'],text=True).strip()==head
 status=subprocess.check_output(['git','-C',root,'status','--porcelain=v1'],text=True);assert not status;protected.append({'path':root,'head':head,'clean':True})
remote=subprocess.check_output(['git','-C',str(repo),'ls-remote','origin','refs/heads/main'],text=True).split()[0];assert remote=='4233158b6225bb5b1c11a11e53182a38b6f02942'
checks['preservation']={'realIndexStatusRefsWorktreesUnchanged':True,'protected':protected,'liveRemoteMain':remote,'noNewCommitOrBranch':True,'noPushGitHubWriteCIRelease':True,'noImplementationOrTestExecutionWhilePaused':True}
(out/'VERIFICATION_AND_PRESERVATION.json').write_text(json.dumps(checks,indent=2)+'\n')
artifactFiles={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.rglob('*')) if p.is_file()};(out/'ARTIFACTS.json').write_text(json.dumps({'classification':'PAUSED_PROGRESS_NOT_FINAL_CANDIDATE','lastCommit':identity['lastCommit'],'snapshotTree':identity['uncommittedSnapshotTree'],'files':artifactFiles},indent=2)+'\n');(out/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(out))+'\n' for p in sorted(out.rglob('*')) if p.is_file()))
archive=Path('/workspace/SemesterSpace_SA001_PROGRESS_2026-10-28.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(out),compress_type=zipfile.ZIP_STORED if p.suffix in ['.zip','.bundle'] else zipfile.ZIP_DEFLATED)
compact=Path('/workspace/SemesterSpace_SA001_PROGRESS_SUMMARY_2026-10-28.zip')
with zipfile.ZipFile(compact,'w',zipfile.ZIP_DEFLATED) as z:
 for name in ['PROGRESS_HANDOFF.md','SOURCE_IDENTITY.json','BUILD_IDENTITY.json','TEST_RESULTS_PROGRESS.json','CASE_TO_EVIDENCE_PROGRESS.json','ACTIVE_INPUT_IDENTITIES.json','COMMAND_LOG_INVENTORY.json','VERIFICATION_AND_PRESERVATION.json','TOOL_VERSIONS.json','ARTIFACTS.json','REPRODUCE_SNAPSHOT.md']:
  z.write(out/name,name)
for p in [archive,compact,out/'source-progress.zip',out/'build-progress.zip',out/'raw-evidence.zip']:
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
result={'lastCommit':identity['lastCommit'],'snapshotTree':identity['uncommittedSnapshotTree'],'fullHandoff':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)},'summaryHandoff':{'path':str(compact),'bytes':compact.stat().st_size,'sha256':sha(compact)},'readableReport':str(out/'PROGRESS_HANDOFF.md'),'implementationStillPaused':True};Path('/workspace/sa001-progress-20261028-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
