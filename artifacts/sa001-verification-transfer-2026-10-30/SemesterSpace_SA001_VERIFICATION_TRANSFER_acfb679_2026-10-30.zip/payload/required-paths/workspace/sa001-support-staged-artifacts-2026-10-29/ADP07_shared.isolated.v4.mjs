/* D-F-SAB-01 — SUPPORTING PROPOSAL ONLY; UNRUN.
 * Exact bytes require D advance approval before an isolated-origin execution.
 * No production headers, no disabled Chromium sandbox, no source/gold changes.
 * Invoke only in reviewed disposable checkout: node /ABS/THIS.mjs --run --out /ABS/NEW
 * A negative admission test, NOT proof of full stage lifecycle or loaded-asset graph.
 */
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {join,resolve,sep} from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';

if(!process.argv.includes('--run')) throw Error('Explicit --run required');
const oi=process.argv.indexOf('--out'),out=oi>=0?process.argv[oi+1]:null;
if(!out?.startsWith('/'))throw Error('Use --out /ABS/NEW');
await mkdir(out,{recursive:false});
const root=resolve(process.cwd()), sha=b=>createHash('sha256').update(b).digest('hex');
// Resolve pinned Playwright from the disposable application checkout, not the helper location.
const {chromium}=createRequire(join(root,'package.json'))('playwright');
const requests=[],served={}, forbidden=['--no'+'-sandbox','--disable-setuid-sandbox','--disable-namespace-sandbox'];
let phase='BOOTSTRAP',browser,browserServer;
const mime=p=>p.endsWith('.js')||p.endsWith('.mjs')?'text/javascript; charset=utf-8':p.endsWith('.json')?'application/json; charset=utf-8':'text/plain; charset=utf-8';
const server=createServer(async(req,res)=>{
  res.setHeader('Cross-Origin-Opener-Policy','same-origin');
  res.setHeader('Cross-Origin-Embedder-Policy','require-corp');
  res.setHeader('Cross-Origin-Resource-Policy','same-origin');
  res.setHeader('X-Content-Type-Options','nosniff');
  let u;
  try{u=new URL(req.url,'http://127.0.0.1/')}catch{res.writeHead(400).end();return;}
  requests.push({phase,method:req.method,path:u.pathname});
  if(u.pathname==='/'){
    res.setHeader('Content-Type','text/html; charset=utf-8');res.end('<!doctype html><meta charset="utf-8"><title>SA SAB isolated test-only</title>');return;
  }
  let path;
  try{path=resolve(root,'.'+decodeURIComponent(u.pathname))}catch{res.writeHead(400).end();return;}
  if(!path.startsWith(root+sep)||!/^\/src\/[^?]+\.(?:js|mjs)$/.test(u.pathname)){
    res.statusCode=404;res.end('Not served');return;
  }
  try{const body=await readFile(path);served[u.pathname]=sha(body);res.setHeader('Content-Type',mime(path));res.end(body)}
  catch{res.statusCode=404;res.end('Missing');}
});
const report={classification:'PROPOSED_ADP07_SHARED_ATTEMPT_SCOPED_SANDBOXED_TEST',pass:false,status:'NOT_EXECUTED',
  boundaries:{isolation:'test-only localhost with COOP/COEP/CORP',scope:'ui.selectSource synchronous admission only; no stage lifecycle claim'},
  identities:{helperSha256:sha(await readFile(fileURLToPath(import.meta.url))),
    authoritySha256:sha(await readFile(join(root,'src/import/authority.js'))),
    engineIndexSha256:sha(await readFile(join(root,'src/engine/index.js'))),
    chromiumExecutableSha256:sha(await readFile('/usr/bin/chromium'))}};
async function save(){await writeFile(join(out,'report.json'),JSON.stringify(report,null,2)+'\n');}
try {
  await new Promise((ok,bad)=>{server.once('error',bad);server.listen(0,'127.0.0.1',ok)});
  const port=server.address().port;
  // chromiumSandbox:true is mandatory. A browser that cannot launch with sandboxing fails closed.
  browserServer=await chromium.launchServer({
    executablePath:'/usr/bin/chromium',headless:true,chromiumSandbox:true,host:'127.0.0.1'
  });
  const proc=browserServer.process();
  if(!proc?.pid)throw Error('SANDBOX_PREFLIGHT_NO_BROWSER_PROCESS_ID');
  const argv=(await readFile(`/proc/${proc.pid}/cmdline`)).toString('utf8').split('\0').filter(Boolean);
  report.sandbox={requestedChromiumSandbox:true,observedBrowserPid:proc.pid,
    commandLineSha256:sha(Buffer.from(argv.join('\0'))),disabledFlagsPresent:argv.filter(a=>forbidden.some(f=>a===f||a.startsWith(f+'=')))};
  assert.deepEqual(report.sandbox.disabledFlagsPresent,[],'Unsafe Chromium launch flag — fail closed');
  const wsEndpoint=browserServer.wsEndpoint(),wsURL=new URL(wsEndpoint);
  if(wsURL.protocol!=='ws:'||wsURL.hostname!=='127.0.0.1')
    throw Error('BROWSER_SERVER_NOT_LOOPBACK');
  report.sandbox.browserServerLoopbackHost=wsURL.hostname;
  browser=await chromium.connect(wsEndpoint,{timeout:30000});
  report.identities.chromiumVersion=browser.version();
  const context=await browser.newContext(),page=await context.newPage();
  report.origin=`http://127.0.0.1:${port}/`;
  await page.goto(report.origin,{waitUntil:'load'});
  const manifest=JSON.parse(await readFile(join(root,'tests/sa-001/gold/AVAILABLE_CONFIG_MEASURED.json'),'utf8'));
  // Bootstrap imports and source authority BEFORE measuring the attempted decoder boundary.
  const bootstrap=await page.evaluate(async approvedManifest=>{
    const isolation={isSecureContext,crossOriginIsolated,hasSharedArrayBuffer:typeof SharedArrayBuffer==='function'};
    if(!isolation.isSecureContext||!isolation.crossOriginIsolated||!isolation.hasSharedArrayBuffer)
      return {status:'UNAVAILABLE_ENVIRONMENT_PRECONDITION',isolation};
    const {createSourceAuthority}=await import('/src/import/authority.js');
    const engine=await import('/src/engine/index.js');
    window.__adp07Factory=createSourceAuthority({approvedManifest,engine});
    return {status:'READY',isolation};
  },manifest);
  report.bootstrap=bootstrap;
  if(bootstrap.status!=='READY')throw Error('ISOLATED_SAB_PRECONDITION_UNAVAILABLE');
  const beforeRequests=requests.slice();phase='ADMISSION_ATTEMPT';
  // Both storage areas, all three write methods, and fetch/Worker attempts are scoped
  // to this one selectSource call. Bootstrap module/asset requests are not counted as decode.
  const actual=await page.evaluate(()=>{
    const snap=s=>{
      const v=[];for(let i=0;i<s.length;i++){const k=s.key(i);v.push([k,s.getItem(k)]);}
      return v.sort((a,b)=>a[0].localeCompare(b[0]));
    };
    const before={localStorage:snap(localStorage),sessionStorage:snap(sessionStorage)};
    const orig={setItem:Storage.prototype.setItem,removeItem:Storage.prototype.removeItem,
      clear:Storage.prototype.clear,fetch:window.fetch,Worker:window.Worker};
    const operations={setItem:0,removeItem:0,clear:0,local:{setItem:0,removeItem:0,clear:0},session:{setItem:0,removeItem:0,clear:0},other:{setItem:0,removeItem:0,clear:0}};
    const bucket=s=>s===localStorage?operations.local:s===sessionStorage?operations.session:operations.other;
    let fetchAttempts=0,workerAttempts=0,result,after,attemptMs=0;
    const sab=new SharedArrayBuffer(64),bytes=new Uint8Array(sab);bytes.set([0x25,0x50,0x44,0x46]);
    try{
      for(const name of ['setItem','removeItem','clear'])Storage.prototype[name]=function(...args){
        operations[name]++;bucket(this)[name]++;return orig[name].apply(this,args);
      };
      window.fetch=(...args)=>{fetchAttempts++;return orig.fetch(...args)};
      window.Worker=function(...args){workerAttempts++;return new orig.Worker(...args)};
      const t=performance.now();result=window.__adp07Factory.ui.selectSource('TIMETABLE',bytes,'sab.pdf');attemptMs=performance.now()-t;
      after={localStorage:snap(localStorage),sessionStorage:snap(sessionStorage)};
    }finally{
      for(const name of ['setItem','removeItem','clear'])Storage.prototype[name]=orig[name];
      window.fetch=orig.fetch;window.Worker=orig.Worker;
    }
    return {status:'EXECUTED',actualBoundary:'createSourceAuthority(...).ui.selectSource',
      sharedBacking:bytes.buffer===sab,attemptMs,result,before,after,operations,fetchAttempts,workerAttempts,
      noSlotInReturnedValue:!result?.ok&&!Object.hasOwn(result??{},'value')};
  });
  phase='POST_ATTEMPT';report.actual=actual;report.requestEvidence={bootstrap:beforeRequests,attempt:requests.slice(beforeRequests.length)};
  report.identities.testModuleBodiesServedSha256_NotBrowserResponseProof=served;
  assert.equal(actual.status,'EXECUTED');assert.equal(actual.sharedBacking,true);
  assert.deepEqual(bootstrap.isolation,{isSecureContext:true,crossOriginIsolated:true,hasSharedArrayBuffer:true});
  assert.deepEqual({ok:actual.result.ok,code:actual.result.error?.code,reason:actual.result.error?.reason},
    {ok:false,code:'SA_INPUT_INVALID',reason:'UNSUPPORTED_INPUT'});
  assert.deepEqual(actual.operations,{setItem:0,removeItem:0,clear:0,
    local:{setItem:0,removeItem:0,clear:0},session:{setItem:0,removeItem:0,clear:0},other:{setItem:0,removeItem:0,clear:0}});
  assert.deepEqual(actual.after,actual.before,'Complete localStorage/sessionStorage changed');
  assert.equal(actual.fetchAttempts,0);assert.equal(actual.workerAttempts,0);
  assert.deepEqual(report.requestEvidence.attempt,[],'Attempt triggered unexpected network requests');
  assert.equal(actual.noSlotInReturnedValue,true);
  report.pass=true;report.status='PASSED_ATTEMPT_SCOPED_NEGATIVE_ONLY';
}catch(error){report.status='FAIL_CLOSED_OR_UNAVAILABLE';report.failure=error.stack??String(error);throw error;}
finally{
  report.identities.testModuleBodiesServedSha256_NotBrowserResponseProof=served;
  report.requestEvidence??={bootstrap:requests.filter(r=>r.phase==='BOOTSTRAP'),attempt:requests.filter(r=>r.phase==='ADMISSION_ATTEMPT')};
  // Teardown is independent: a connection-close fault must never skip either server.
  const cleanupFailures=[];
  const cleanup=async(name,action)=>{try{await action()}catch(error){cleanupFailures.push({name,error:String(error?.stack??error)})}};
  await cleanup('browserConnection',async()=>{if(browser)await browser.close()});
  await cleanup('browserServer',async()=>{if(browserServer)await browserServer.close()});
  await cleanup('httpServer',async()=>{
    if(server.listening)await new Promise((ok,bad)=>server.close(error=>error?bad(error):ok()));
  });
  if(cleanupFailures.length){report.pass=false;report.status='FAIL_CLOSED_OR_UNAVAILABLE';report.cleanupFailures=cleanupFailures;}
  await save();
  if(cleanupFailures.length)throw Error('SAB_HELPER_CLEANUP_FAILURE');
}
