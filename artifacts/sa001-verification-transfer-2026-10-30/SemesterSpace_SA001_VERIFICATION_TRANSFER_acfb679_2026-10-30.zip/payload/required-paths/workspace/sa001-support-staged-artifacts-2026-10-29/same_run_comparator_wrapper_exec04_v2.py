#!/usr/bin/env python3
"""SA-001 supporting-only proposal: fail-closed, same-run comparator v2 invocation.

Invocation by separately reviewed operator_runner_exec04_v4.py, after separately approved job integration:
  python3 /workspace/sa001-support-staged-artifacts-2026-10-29/same_run_comparator_wrapper_exec04_v2.py {new_output}

NO historical producer report fallback; NO acceptance promotion or source/gold edits.
Not executable without A/D exact-byte approval. This source does not launch a browser.
"""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

CHECKPOINT = 'aec0abb117939b2819ebcd7b0b426e8243705e65'
TREE = '40ffc07eb2e4552e742e9c5fa3a931ccea92e5b3' # base checkpoint ONLY; not the amended runtime tree
BASE_IDENTITY_SHA = 'd84f8041623b9c882c2c0a80aee459964dd770547d1e191a975c3bf7dd1cba5c'
COMPARATOR = Path('/workspace/sa001-support-staged-artifacts-2026-10-29/reconcile_assertions_v2.py')
COMPARATOR_SHA = '73e0f2456523aa62734d6b7a1beb5bf90d9681e6338d1296f00a435e8e71f963'
ORACLE = Path('/workspace/sa001-impl04-amendment/active/F011_EXACT_TEST_VARIANTS_A_IMPL04_CORRECTED.json')
ORACLE_SHA = '5628adc49a277b4b283fb9cdfbc082924048dc24e018db415b2e9c768f3497a1'
BINDINGS = Path('/workspace/sa001-support-staged-artifacts-2026-10-29/F152_FINAL_SAME_RUN_BINDINGS_PROPOSED.json')
BINDINGS_SHA = '2d07a96fce9a6c5f4c1b61580af32562fbdbdc825be3bd9d1801cf4295f8cecb'
PRODUCERS = {
  'oracle-storage': {'output':'oracle-storage-outputs/register.json', 'array':'results', 'index': 'oracle-storage-outputs', 'expectedStatus': 'PASS_STORAGE_ASSERTIONS_ONLY'},
  'browser-native-connected': {'output':'browser-native-connected-outputs/report.json', 'array':'cases', 'index':'browser-native-connected-outputs','expectedStatus':'PASS'},
}
STORAGE = 'EXECUTED_STORAGE_ASSERTIONS_FULL_CASE_RECONCILIATION_PENDING'
BROWSER = 'EXECUTED_BROWSER_POPULATION_FINAL_BINDING_RECONCILIATION_PENDING'
EXTERNAL = 'EXTERNAL_B2_OMR_SUITE_EVIDENCE_AVAILABLE_NOT_SINGLE_CALL_PASS'
EXCLUDED = 'EXCLUDED_FROM_SINGLE_CALL_PASS_COUNT'

class Refusal(Exception): pass

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load_exact(path, expected_sha):
    if not path.is_file() or path.is_symlink() or sha(path) != expected_sha:
        raise Refusal('MISSING_OR_CHANGED_REVIEWED_INPUT ' + str(path))
    return json.loads(path.read_bytes())

def require(flag, message):
    if not flag: raise Refusal(message)

def parse_utc(s):
    return dt.datetime.fromisoformat(s.replace('Z', '+00:00')).astimezone(dt.timezone.utc)

def require_job(run, label, report_dir):
    meta_path=run / (label+'.meta.json')
    require(meta_path.is_file() and not meta_path.is_symlink(), 'MISSING_SAME_RUN_PRODUCER_METADATA '+str(meta_path))
    m=json.loads(meta_path.read_bytes())
    require(m.get('tag')==label and m.get('status')=='EXITED' and type(m.get('exitCode')) is int and m['exitCode']==0,
            'PRODUCER_NOT_SUCCESSFULLY_EXITED '+label)
    require((m.get('postCheck') or {}).get('sourceStable') is True and 'postCheckError' not in m,
            'MISSING_OR_FAILED_POSTCHECK '+label)
    argv=m.get('argv')
    require(isinstance(argv,list) and all(isinstance(v,str) for v in argv), 'BAD_PRODUCER_ARGV '+label)
    if label=='oracle-storage':
        require(any(v.endswith('/research/oracle-storage.mjs') or v=='tests/sa-001/research/oracle-storage.mjs' for v in argv),
                'WRONG_ORACLE_PRODUCER '+label)
    else:
        require('tests/sa-001/browser.mjs' in argv, 'WRONG_BROWSER_PRODUCER')
    require(str(report_dir)==argv[-1], 'WRONG_SAME_RUN_OUTPUT_ARGV '+label)
    cwd=m.get('cwd','')
    require(isinstance(cwd,str) and cwd.startswith('/') and cwd.endswith('/semester-space'), 'BAD_SOURCE_CWD '+label)
    start=parse_utc(m['startedAtUTC']);end=parse_utc(m['finishedAtUTC'])
    require(start<=end, 'INVALID_PRODUCER_INTERVAL '+label)
    for ext in ('stdout','stderr'):
        p=run/(label+'.'+ext)
        require(p.is_file() and not p.is_symlink() and m.get(ext+'Sha256')==sha(p), 'CORRUPTED_RAW_PRODUCER_STREAM '+label+'.'+ext)
    return {'startedAtUTC':m['startedAtUTC'],'finishedAtUTC':m['finishedAtUTC'],
            'argv':argv, 'cwd':cwd, 'metaSha256':sha(meta_path)}

def ensure_report(run, label, spec, expected_ids):
    p=run/spec['output']
    require(p.is_file() and not p.is_symlink() and p.resolve()==p, 'MISSING_SAME_RUN_REPORT '+label)
    origin=require_job(run,label,p.parent)
    raw=p.read_bytes()
    report=json.loads(raw)
    cases=report.get(spec['array'])
    require(isinstance(cases,list), 'MISSING_REPORT_CASE_ARRAY '+label)
    ids=[r.get('id') for r in cases if isinstance(r,dict)]
    require(len(ids)==len(cases) and len(set(ids))==len(ids), 'DUPLICATE_OR_BAD_REPORT_IDS '+label)
    found={r['id']:r for r in cases}
    missing=sorted(set(expected_ids)-set(found))
    require(not missing, 'MISSING_CURRENT_CASE_ROWS '+label+' '+','.join(missing))
    bad=sorted(x for x in expected_ids if found[x].get('status')!=spec['expectedStatus'])
    require(not bad, 'CURRENT_CASE_NOT_PASSING_PRODUCER_ASSERTIONS '+label+' '+','.join(bad))
    if label=='oracle-storage':
        require(report.get('oracleFile')==ORACLE.name, 'ORACLE_REPORT_IDENTIFIES_DIFFERENT_GOLD')
        # The pure runner must include all 152 rows; controller rows there are UNRUN, not a PASS.
        require(len(cases)==152 and set(ids)==set(ALL_IDS), 'STORAGE_REPORT_DOES_NOT_COVER_EXACT_152')
    else:
        require(report.get('status')=='EXECUTED_BROWSER_POPULATION_PASS_OTHER_GATES_SEPARATELY_REPORTED',
                'BROWSER_TOP_LEVEL_NOT_SUCCESSFUL')
    return {'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'rows':len(cases),
            'requiredRows':len(expected_ids),'producer':origin}, report

ALL_IDS=()

def main(argv):
    global ALL_IDS
    require(len(argv)==2, 'USAGE: same_run_comparator_wrapper_exec04_v2.py {new_output}')
    dest=Path(argv[1]);require(dest.is_absolute() and dest.name=='oracle-comparator-outputs',
           'BAD_NEW_OUTPUT_PARENT_OR_NOT_ABSOLUTE')
    require(not dest.exists() and not dest.is_symlink(), 'OUTPUT_EXISTS_NO_OVERWRITE')
    run=dest.parent
    require(run.is_dir() and not run.is_symlink() and run.name.startswith('SA001-') and
            run.parent.as_posix()=='/workspace/sa001-evidence-final', 'UNTRUSTED_OR_NONUNIQUE_RUN_ROOT')
    require((run/'START_PREFLIGHT.json').is_file(), 'MISSING_SAME_RUN_PREFLIGHT')
    pre=json.loads((run/'START_PREFLIGHT.json').read_bytes())
    identity=pre.get('identity') or {}
    # The E HAR supporting patch changes the tracked tree; aec0abb is provenance,
    # never the expected final runtime HEAD. Bind the separately A/D reviewed
    # runtime identity JSON named in this run's preflight, not historical reports.
    candidate_path=Path(pre.get('runtimeCandidateIdentityPath',''))
    require(candidate_path.is_absolute() and candidate_path.suffix=='.json' and candidate_path.is_file(),
            'MISSING_A_D_REVIEWED_RUNTIME_CANDIDATE_JSON')
    candidate=load_exact(candidate_path,pre.get('runtimeCandidateIdentitySha256',''))
    require(candidate.get('classification')=='A_D_REVIEWED_FINAL_CLEAN_CANDIDATE' and
            pre.get('mode')=='final_clean' and identity.get('head')==candidate.get('commitSha') and
            identity.get('headTree')==candidate.get('treeSha') and
            (candidate.get('commitSha'),candidate.get('treeSha'))!=(CHECKPOINT,TREE) and
            pre.get('baseCheckpointIdentitySha256')==BASE_IDENTITY_SHA and
            pre.get('approvedBaseCheckpointSha256')==BASE_IDENTITY_SHA and
            (pre.get('eIntegrationBinding') or {}).get('sourceFiles')==269,
            'RUNTIME_CANDIDATE_NOT_A_D_BOUND')
    require(pre.get('technicalCompleteAllowed') is False, 'PREFLIGHT_UNEXPECTED_ACCEPTANCE_FLAG')
    oracle=load_exact(ORACLE,ORACLE_SHA)
    bindings=load_exact(BINDINGS,BINDINGS_SHA)
    require(COMPARATOR.is_file() and not COMPARATOR.is_symlink() and sha(COMPARATOR)==COMPARATOR_SHA,
            "COMPARATOR_EXECUTABLE_BYTES_CHANGED") # Python source is not JSON (EXEC-01)
    variants=oracle.get('variants') or []; br=bindings.get('bindings') or []
    all_ids=[v['variantId'] for v in variants];ALL_IDS=tuple(all_ids)
    require(len(all_ids)==152 and len(set(all_ids))==152 and len(br)==152, 'ORACLE_OR_BINDING_BAD_CARDINALITY')
    binding_by_id={x['id']:x for x in br}
    require(len(binding_by_id)==152 and set(binding_by_id)==set(all_ids), 'BINDING_IDS_NOT_EXACT_ORACLE')
    assert_count={STORAGE:131,BROWSER:18,EXTERNAL:1,EXCLUDED:2}
    for status,n in assert_count.items():
        require(sum(x['progressStatus']==status for x in br)==n, 'BINDING_POPULATION_CHANGED '+status)
    for v in variants:
        b=binding_by_id[v['variantId']]
        require(b['expected']==v['expected'] and b['component']==v['component'] and b['operation']==v['operation'],
                'ORACLE_EXPECTATION_OR_OPERATION_CHANGED '+v['variantId'])
        require(b.get('currentRunState')=='UNRUN' and b.get('fullCaseAccepted') is False,
                'PREEXECUTION_BINDING_CLAIMS_EXECUTION')
    storage_ids=[x['id'] for x in br if x['progressStatus']==STORAGE]
    browser_ids=[x['id'] for x in br if x['progressStatus']==BROWSER]
    storage,storage_data=ensure_report(run,'oracle-storage',PRODUCERS['oracle-storage'],storage_ids)
    browser,browser_data=ensure_report(run,'browser-native-connected',PRODUCERS['browser-native-connected'],browser_ids)
    # Each actual row must be from the current report; no historical classification is loaded.
    dest.mkdir(mode=0o700,exist_ok=False)
    out=dest/'reconciliation.json'
    child=['python3',str(COMPARATOR),'--oracle',str(ORACLE),'--storage-report',storage['path'],
           '--browser-report',browser['path'],'--bindings',str(BINDINGS),'--out',str(out)]
    invocation={'classification':'EXECUTED_BY_THIS_WRAPPER_ONLY_IF_PREAPPROVED',
                'baseCheckpointCommit':CHECKPOINT,'baseCheckpointTree':TREE,'runtimeCommit':candidate['commitSha'],'runtimeTree':candidate['treeSha'], 'runtimeCandidateIdentitySha256':pre['runtimeCandidateIdentitySha256'],'sourceRun':str(run),
                'comparatorSha256':COMPARATOR_SHA,'oracleSha256':ORACLE_SHA,'bindingSha256':BINDINGS_SHA,
                'inputs':{'storage':storage,'browser':browser},'exactArgv':child,
                'beganAtUTC':dt.datetime.now(dt.timezone.utc).isoformat(),
                'acceptanceGranted':False}
    (dest/'COMPARATOR_INPUTS.json').write_text(json.dumps(invocation,indent=2)+'\n')
    # Never overwrite; retain all streams even if comparator exits nonzero.
    p=subprocess.run(child,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    (dest/'comparator.stdout').write_bytes(p.stdout)
    (dest/'comparator.stderr').write_bytes(p.stderr)
    invocation['exitCode']=p.returncode
    invocation['endedAtUTC']=dt.datetime.now(dt.timezone.utc).isoformat()
    invocation['stdoutSha256']=sha(dest/'comparator.stdout')
    invocation['stderrSha256']=sha(dest/'comparator.stderr')
    invocation['classification']='CHILD_EXITED_NOT_YET_CLASSIFIED'
    (dest/'COMPARATOR_INPUTS.json').write_text(json.dumps(invocation,indent=2)+'\n')
    require(out.is_file() and out.parent==dest, 'COMPARATOR_DID_NOT_EMIT_RESULT')
    result=json.loads(out.read_bytes())
    counts=result.get('counts') or {}
    require(counts.get('uniqueOracleIds')==152 and counts.get('standaloneStorage')==131 and
            counts.get('controllerBrowser')==18 and counts.get('externalSuite')==1 and
            counts.get('excludedNonSingleCall')==2 and counts.get('fullCaseAccepted')==0,
            'COMPARATOR_INVALID_CASE_ACCOUNTING')
    require(p.returncode==0, 'COMPARATOR_EXIT_NONZERO '+str(p.returncode))
    bad={'MISMATCH_REQUIRES_REVIEW','MISSING_EVIDENCE','REPORT_NOT_PASSING'}
    require(not any((x.get('classification') in bad) for x in result.get('cases',[])),
            'COMPARATOR_HAS_DIRECT_MISMATCH_OR_MISSING_CASE')
    require(len(result.get('cases',[]))==152 and
            set(x['id'] for x in result['cases'])==set(all_ids), 'COMPARATOR_EMITTED_WRONG_IDS')
    invocation['resultSha256']=sha(out)
    invocation['classification']='PARTIAL_DIRECT_COMPARISON_ONLY_NO_FULL_ACCEPTANCE'
    (dest/'COMPARATOR_INPUTS.json').write_text(json.dumps(invocation,indent=2)+'\n')
    print(json.dumps({'status':'PARTIAL_DIRECT_COMPARISON_ONLY','fullCaseAccepted':0,
                      'result':str(out),'storageReportSha256':storage['sha256'],
                      'browserReportSha256':browser['sha256']},sort_keys=True))
    return 0

if __name__=='__main__':
    try: sys.exit(main(sys.argv))
    except BaseException as error:
        # Operator v3 retains raw stdout/stderr and failure metadata; no fallback or retry.
        sys.stderr.write('F152_FAIL_CLOSED '+type(error).__name__+' '+str(error)+'\n')
        if not isinstance(error,Refusal): traceback.print_exc(file=sys.stderr)
        sys.exit(3)
