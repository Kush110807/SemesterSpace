#!/usr/bin/env python3
"""SUPPORTING PROPOSAL ONLY. Report-grounded tri-state comparator for F's 152 active IDs.
Does NOT change gold, infer ACK ordering, invent a public phase field or certify SA-001.
"""
import argparse, collections, hashlib, json, pathlib, sys

ABSENT = object()
STORAGE='EXECUTED_STORAGE_ASSERTIONS_FULL_CASE_RECONCILIATION_PENDING'
BROWSER='EXECUTED_BROWSER_POPULATION_FINAL_BINDING_RECONCILIATION_PENDING'
EXTERNAL='EXTERNAL_B2_OMR_SUITE_EVIDENCE_AVAILABLE_NOT_SINGLE_CALL_PASS'
EXCLUDED='EXCLUDED_FROM_SINGLE_CALL_PASS_COUNT'

def ptr(path): return ''.join('/'+str(x).replace('~','~0').replace('/','~1') for x in path)
def compare(key, expected, actual, actual_present, component, outcome):
    """Return MATCH/ABI_OPTIONAL_ABSENT/MISSING/MISMATCH and preserve presence."""
    if not actual_present:
        # SaveResult reason/path are optional on successful B2 SAVE_OK; absence != null mismatch.
        if key in ('reason','path') and expected is None and outcome.get('status')=='SAVED' and outcome.get('code')=='SAVE_OK':
            return 'ABI_OPTIONAL_ABSENT'
        # No blanket optionality for SA accepted/rejected, or expected nonnull B2 failure.
        if component=='B2_FROZEN' and key=='path' and expected is None and outcome.get('status')=='FAILED':
            return 'ABI_OPTIONAL_ABSENT'
        return 'MISSING'
    return 'MATCH' if actual==expected else 'MISMATCH'

def evaluate_variant(v, report, population):
    e=v['expected'];component=v['component']; id=v['variantId']
    rec={'id':id,'component':component,'operation':v['operation'],'population':population,
         'oracleExpectedUnchanged':e,'checks':[],'evidencePointers':[],
         'integrationNeeded':[],'unasserted':[], 'phase':{'expected':e['phase'], 'classification':'NOT_A_PUBLIC_TELEMETRY_FIELD'},
         'classification':'UNASSESSED','sourceReportStatus':None}
    if population==EXCLUDED:
        rec['classification']='EXCLUDED_NOT_SINGLE_CALL';rec['scope']='No single-call assertion';return rec
    if population==EXTERNAL:
        rec['classification']='EXTERNAL_SUITE_DEPENDENCY';rec['scope']='Requires exact matching B2/OMR suite evidence';return rec
    if report is None:
        rec['classification']='MISSING_EVIDENCE';rec['unasserted'].append('caseReport');return rec
    a=report.get('actual') or {};result=a.get('result') or {};rec['sourceReportStatus']=report.get('status')
    if report.get('status') not in ('PASS_STORAGE_ASSERTIONS_ONLY','PASS'):
        rec['classification']='REPORT_NOT_PASSING';rec['unasserted'].append('producerReportPassStatus');return rec
    report_base='/results' if population==STORAGE else '/cases'
    def add(field,expected,actual=ABSENT,actual_pointer=None,description=None):
        status=compare(field,expected,None if actual is ABSENT else actual,actual is not ABSENT,component,result)
        item={'field':field,'expectation':expected,'state':status,'actualPresent':actual is not ABSENT}
        if actual is not ABSENT:item['actual']=actual
        if actual_pointer:item['sourcePointer']=actual_pointer
        if description:item['detail']=description
        rec['checks'].append(item)
    for k in ('status','code','reason','path'):
        add(k,e[k],result.get(k,ABSENT),'/actual/result/'+k)
    for key,alternate in (('getItemCount','reads'),('setItemCount','writes')):
        add(key,e[key],a.get(key,a.get(alternate,ABSENT)),'/actual/'+(key if key in a else alternate))
    add('candidateGetterInvocations',e['candidateGetterInvocations'],a.get('candidateGetterInvocations',ABSENT),'/actual/candidateGetterInvocations')
    direct=a.get('persistedByteDisposition',ABSENT)
    before=a.get('before',ABSENT);after=a.get('after',ABSENT)
    if direct is ABSENT and before is not ABSENT and after is not ABSENT:
        direct='CHANGED' if before!=after else 'UNCHANGED'
    add('persistedByteDisposition',e['persistedByteDisposition'],direct,'/actual/persistedByteDisposition' if 'persistedByteDisposition' in a else '/actual/before,/actual/after')
    # Existing source-report facts are used rather than labeled missing.
    if population==STORAGE:
        rec['scope']='Standalone pure storage context: memory/authority are not available here'
        ig=a.get('inputGraphUnchanged',ABSENT)
        if ig is not ABSENT:add('inputGraphUnchanged',True,ig,'/actual/inputGraphUnchanged')
        else:rec['unasserted'].append('inputGraphUnchanged')
        for k in ('beforeSha256','afterSha256'):
            if k in a:rec['evidencePointers'].append('/actual/'+k)
        if a.get('beforeSha256',ABSENT) is not ABSENT and a.get('afterSha256',ABSENT) is not ABSENT:
            h0,h1=a.get('beforeSha256'),a.get('afterSha256')
            # null hash = no stored bytes, not itself absent evidence.
            observed='CHANGED' if h0!=h1 else 'UNCHANGED'
            add('hashDispositionConsistency',a.get('persistedByteDisposition',observed),observed,'/actual/beforeSha256,/actual/afterSha256')
        dg=a.get('diagnosticReload')
        if isinstance(dg,dict) and all(k in dg for k in ('before','after','attemptReadCountsExcludeTheseReads')):
            rec['evidencePointers'].append('/actual/diagnosticReload')
            b,af=dg['before'],dg['after']
            if 'loaded' in b and 'loaded' in af:
                if e['persistedByteDisposition']=='UNCHANGED':
                    add('unchangedDiagnosticReload',True,b['loaded']==af['loaded'],'/actual/diagnosticReload')
                rec['diagnosticReload']={'beforeStatus':(b['loaded'].get('persistence') or {}).get('status'),
                    'afterStatus':(af['loaded'].get('persistence') or {}).get('status'),
                    'beforeModelPresent':b['loaded'].get('model') is not None,
                    'afterModelPresent':af['loaded'].get('model') is not None,
                    'containsCompleteModelAndRelease':all('model' in t['loaded'] and 'release' in t['loaded'] for t in (b,af)),
                    'readCountsExcludedFromAttempt':bool(dg['attemptReadCountsExcludeTheseReads'])}
            else:rec['unasserted'].append('diagnosticReload.loaded')
        else:rec['unasserted'].append('diagnosticReload')
        # NOT a failure and NOT five mandatory extra tests: explicit context distinction.
        rec['notApplicableHere']=['acceptedMemoryDisposition','reloadAuthority','stageCapabilitiesAfterReload']
        rec['integrationNeeded'].append({'expectations':['acceptedMemoryDisposition','reloadAuthority','stageCapabilitiesAfterReload'],
          'reason':'Pure storage helper has no controller memory, transient stages, or ACK-order observation. Bind separate real integration controls; do not invent telemetry.'})
    else:
        rec['scope']='Actual controller/browser integration; compare memory only where present, not ACK order inferred'
        if isinstance(a.get('memoryBefore'),dict) and isinstance(a.get('memoryAfter'),dict):
            rec['evidencePointers'].extend(['/actual/memoryBefore','/actual/memoryAfter'])
            before=(a['memoryBefore'].get('model'),a['memoryBefore'].get('release'))
            after=(a['memoryAfter'].get('model'),a['memoryAfter'].get('release'))
            mem='UNCHANGED' if before==after else 'CHANGED_ORDER_UNKNOWN'
            if e['acceptedMemoryDisposition']=='UNCHANGED':add('acceptedMemoryDisposition','UNCHANGED',mem,'/actual/memoryBefore,/actual/memoryAfter')
            elif e['acceptedMemoryDisposition']=='ADVANCE_AFTER_ACK':
                if mem=='UNCHANGED':add('acceptedMemoryChange','CHANGED_ORDER_UNKNOWN','UNCHANGED','/actual/memoryBefore,/actual/memoryAfter')
                else:rec['integrationNeeded'].append({'expectation':'ADVANCE_AFTER_ACK','reason':'State changed but physical write-before-memory promotion not shown by snapshots alone; needs failure/ACK trace.'})
            else:rec['unasserted'].append('acceptedMemoryDisposition comparison not supported')
        else:rec['unasserted'].append('memoryBefore/memoryAfter')
        rec['integrationNeeded'].append({'expectations':['reloadAuthority','stageCapabilitiesAfterReload'],
            'reason':'Require a bound native reopen/capability inspection, not a pure diagnostic load or assumed NONE/0.'})
        if isinstance(a.get('diagnostics'),dict):rec['evidencePointers'].append('/actual/diagnostics')
    # Phase may be consistent with tuple, but is NOT independently measured by a fabricated field.
    keys=('status','code','reason','path','getItemCount','setItemCount','candidateGetterInvocations')
    checkmap={x['field']:x['state'] for x in rec['checks']}
    rec['phase']['classification']='TUPLE_COMPATIBLE_NOT_PROVEN' if all(checkmap.get(k) in ('MATCH','ABI_OPTIONAL_ABSENT') for k in keys if k in checkmap) else 'UNRESOLVED_TUPLE'
    rec['phase']['proofRequired']='first-match source branch map + competing-invalidity/zero-access controls; no phase instrumentation' 
    mismatches=[x for x in rec['checks'] if x['state']=='MISMATCH']
    missing=[x for x in rec['checks'] if x['state']=='MISSING']
    if mismatches:rec['classification']='MISMATCH_REQUIRES_REVIEW'
    elif missing or rec['unasserted']:rec['classification']='PARTIAL_MISSING_OBSERVABLE'
    elif population==STORAGE:rec['classification']='PARTIAL_STORAGE_OBSERVABLE_MATCH' # pure context, not 131 independent integration tests
    elif rec['integrationNeeded']:rec['classification']='PARTIAL_INTEGRATION_NEEDED'
    else:rec['classification']='PARTIAL_DIRECT_ONLY_NOT_ACCEPTANCE' # never count report-only as full acceptance
    return rec

def reconcile(oracle,store,browser,bindings):
    variants=oracle['variants'];bound={b['id']:b for b in bindings['bindings']}
    sr={r['id']:r for r in store['results']};br={r['id']:r for r in browser['cases']}
    if len(variants)!=152 or len(set(x['variantId'] for x in variants))!=152:raise ValueError('active oracle is not exactly 152 unique cases')
    if set(bound)!=set(x['variantId'] for x in variants):raise ValueError('binding IDs differ from oracle')
    result=[]
    for v in variants:
        id=v['variantId'];p=bound[id]['progressStatus']
        report=sr.get(id) if p==STORAGE else br.get(id) if p==BROWSER else None
        rec=evaluate_variant(v,report,p)
        if p==STORAGE:rec['sourceReportPointer']=f'/results/{next((i for i,x in enumerate(store["results"]) if x["id"]==id),-1)}'
        elif p==BROWSER:rec['sourceReportPointer']=f'/cases/{next((i for i,x in enumerate(browser["cases"]) if x["id"]==id),-1)}'
        result.append(rec)
    status=collections.Counter(x['classification'] for x in result)
    return {'schemaVersion':'F_RECONCILIATION_CORRECTED/2','decision':'PRODUCER_REPORT_PARTIAL_EVIDENCE_NO_ACCEPTANCE',
            'historicalInventory':{'priorFConservativeMissingFieldTally':675,'interpretation':'Historical scanner inventory only; NOT failures nor 675 mandatory new tests',
              'source':'F_RECONCILIATION.json previous version'},
            'counts':{'uniqueOracleIds':len(result),'standaloneStorage':sum(x['population']==STORAGE for x in result),
              'controllerBrowser':sum(x['population']==BROWSER for x in result),'externalSuite':sum(x['population']==EXTERNAL for x in result),
              'excludedNonSingleCall':sum(x['population']==EXCLUDED for x in result),
              'classifications':dict(status),'fullCaseAccepted':0},
            'constraints':{'noOracleGoldChanges':True,'noPhaseTelemetry':True,'noACKInference':True,'optionalSuccessFieldsPreserved':True,'notIndependentExecutorEvidence':True},'cases':result}

def load(p):return json.loads(pathlib.Path(p).read_text())
def cli():
 p=argparse.ArgumentParser();p.add_argument('--oracle',required=True);p.add_argument('--storage-report',required=True);p.add_argument('--browser-report',required=True);p.add_argument('--bindings',required=True);p.add_argument('--out',required=True)
 a=p.parse_args();out=reconcile(load(a.oracle),load(a.storage_report),load(a.browser_report),load(a.bindings));path=pathlib.Path(a.out)
 if path.exists():raise SystemExit('Refuse overwrite of existing classification file')
 if not path.parent.is_dir():raise SystemExit('Output parent must exist')
 path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps(out['counts'],sort_keys=True))
 if out['counts']['classifications'].get('MISMATCH_REQUIRES_REVIEW'):sys.exit(2)
if __name__=='__main__':cli()
