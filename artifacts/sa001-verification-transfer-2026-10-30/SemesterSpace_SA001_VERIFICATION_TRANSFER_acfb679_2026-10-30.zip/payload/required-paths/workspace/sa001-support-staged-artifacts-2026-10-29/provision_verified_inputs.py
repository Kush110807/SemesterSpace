#!/usr/bin/env python3
"""PROPOSED external fixture copier; no source/gold edit. Never overwrites a destination.
Use ONLY with separately reviewed archive identity and a NEW disposable fixture root.
Default --plan does not create directories or write files.
"""
import argparse,hashlib,json,pathlib,shutil,sys,zipfile
P=argparse.ArgumentParser();P.add_argument('--archive',required=True);P.add_argument('--inventory',required=True)
P.add_argument('--new-root',required=True);P.add_argument('--create',action='store_true')
a=P.parse_args();archive=pathlib.Path(a.archive).resolve();root=pathlib.Path(a.new_root).resolve();inv=json.loads(pathlib.Path(a.inventory).read_text());
def sha(b):return hashlib.sha256(b).hexdigest()
if not root.is_absolute() or root.exists():raise SystemExit('Destination must be an absolute NEW directory; never replace')
if sha(archive.read_bytes())!=inv['archiveSha256']:raise SystemExit('Source archive hash mismatch')
mapping={
 'review-inputs/accepted-specialist-contracts/F_AMENDED_0_1_4/':'contract/F_AMENDED_0_1_4/',
 'review-inputs/accepted-specialist-contracts/E_AUTHORITY_0_1_1/':'contract/E_AUTHORITY_0_1_1/',
 'review-inputs/frozen-inputs/IMPL04/active/':'impl04/active/'}
plan=[]
with zipfile.ZipFile(archive) as z:
 for entry in inv['availableFiles']:
  src=entry['archivePath'];b=z.read(src)
  if sha(b)!=entry['sha256'] or len(b)!=entry['bytes']:raise SystemExit('Entry hash/size mismatch: '+src)
  pre=next((x for x in mapping if src.startswith(x)),None)
  if pre is None:raise SystemExit('Unapproved archive path: '+src)
  rel=pathlib.PurePosixPath(mapping[pre]+src[len(pre):]);
  if '..' in rel.parts or rel.is_absolute():raise SystemExit('Unsafe path: '+src)
  target=root.joinpath(*rel.parts)
  plan.append({'source':src,'target':str(target),'sha256':sha(b),'bytes':len(b)})
 if a.create:
  root.mkdir(mode=0o700,exist_ok=False)
  for row in plan:
   t=pathlib.Path(row['target']);t.parent.mkdir(parents=True,exist_ok=True)
   with t.open('xb') as f:f.write(z.read(row['source']))
   if hashlib.sha256(t.read_bytes()).hexdigest()!=row['sha256']:raise SystemExit('Copy hash mismatch '+str(t))
  (root/'PROVISIONED_INPUTS.json').write_text(json.dumps({'sourceArchiveSha256':inv['archiveSha256'],'files':plan},indent=2)+'\n')
print(json.dumps({'mode':'CREATED_NEW_VERIFIED_STAGING' if a.create else 'PLAN_ONLY_UNRUN',
  'files':len(plan),'newRoot':str(root),'oracleEnvRoots':{
  'SA_CONTRACT_ROOT':str(root/'contract/F_AMENDED_0_1_4')+'/',
  'SA_IMPL04_ROOT':str(root/'impl04/active')+'/'},
  'hardcodedWorkspaceConsumersStillRequireSeparateQualifiedProvisioning':True},indent=2))
