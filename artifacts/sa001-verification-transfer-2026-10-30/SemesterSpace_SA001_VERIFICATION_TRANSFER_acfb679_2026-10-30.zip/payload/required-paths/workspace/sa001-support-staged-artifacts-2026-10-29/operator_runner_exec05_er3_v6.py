#!/usr/bin/env python3
"""EXEC-05 E-r3 V6 PROPOSAL, NOT AUTHORIZED EXECUTION. Fail-closed qualified-operator evidence runner.
Can preflight exact paused baseline OR separately reviewed final CLEAN commit.
Never installs/executes absent explicit --execute, --approval and complete prerequisites.
Never changes gold, production files, Git HEAD, index, or original worktree deliberately.
"""
import argparse, datetime as dt, hashlib, json, os, pathlib, re, shutil, signal, subprocess, sys, time, traceback, uuid

UTC=lambda:dt.datetime.now(dt.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def cmd(argv,cwd=None,timeout=15):
 x=subprocess.run(argv,cwd=cwd,capture_output=True,text=True,timeout=timeout,check=False)
 if x.returncode:raise RuntimeError(f'{argv} exit={x.returncode} stdout={x.stdout[-600:]} stderr={x.stderr[-600:]}')
 return x.stdout.strip()
def read(path):return json.loads(pathlib.Path(path).read_text())
def file_sha_map(base,exclude_generated=True):
 out={}
 for root,dirs,files in os.walk(base):
  rel=pathlib.Path(root).relative_to(base).as_posix()
  dirs[:]=[d for d in dirs if d not in ('.git','node_modules','dist') and not (d=='vendor' and rel=='semester-space/src/import')]
  for f in files:
   p=pathlib.Path(root)/f;out[p.relative_to(base).as_posix()]=sha(p)
 return out

def verify_source(repo,app,identity,mode):
 # .git must be a genuine checkout; no fabricated Git identity from archive text.
 actual_head=cmd(['git','rev-parse','HEAD'],repo)
 head_tree=cmd(['git','rev-parse','HEAD^{tree}'],repo)
 active_tree=cmd(['git','write-tree'],repo)
 porcelain=cmd(['git','status','--porcelain=v1','--untracked-files=all'],repo)
 if mode=='final_clean':
  if identity.get('classification')!='A_D_REVIEWED_FINAL_CLEAN_CANDIDATE':raise ValueError('Final manifest lacks separate A/D approval label')
  if actual_head!=identity.get('commitSha') or head_tree!=identity.get('treeSha') or active_tree!=head_tree:
   raise ValueError('Final authentic HEAD/tree mismatch')
  if porcelain:raise ValueError('Final candidate must be initially clean; do not execute on a dirty/supplemented checkout')
 else:
  if actual_head!=identity.get('lastCommit') or active_tree!=identity.get('uncommittedSnapshotTree'):
   raise ValueError('Exact baseline authentic HEAD/staged tree mismatch')
  if actual_head!='18a190c57eac63ce45c465cac74c21e2d89300e2':raise ValueError('Baseline HEAD changed')
 expected=identity.get('sourceFileSha256')
 if not isinstance(expected,dict) or not expected:raise ValueError('Reviewed full source inventory missing')
 present=file_sha_map(repo)
 absent=sorted(set(expected)-set(present));extra=sorted(set(present)-set(expected))
 changed=[k for k in expected if k in present and expected[k]!=present[k]]
 if absent or extra or changed:
  raise ValueError('Full source inventory differs: '+json.dumps({'missing':absent[:8],'extra':extra[:8],'changed':changed[:8],'counts':[len(absent),len(extra),len(changed)]}))
 tracked=set(cmd(['git','ls-files','--cached'],repo).splitlines())
 # A detached archive may contain untracked files but a final clean checkout cannot.
 if mode=='final_clean' and tracked!=set(expected):
  raise ValueError('Reviewed final tracked-file inventory differs: '+str({'extraTracked':sorted(tracked-set(expected))[:7],'missingTracked':sorted(set(expected)-tracked)[:7]}))
 return {'head':actual_head,'headTree':head_tree,'activeIndexTree':active_tree,'gitPorcelain':porcelain,'trackedCount':len(tracked),'sourceFiles':len(present),'sourceHashMatches':len(expected), 'lockSha256':sha(app/'package-lock.json'), 'goldSha256':{k:v for k,v in present.items() if '/gold/' in k}}

def verify_generated(repo,app,initial_source):
 # Check tracked/read-only source and lock/gold remained byte-for-byte identical.
 actual=file_sha_map(repo)
 differences={'new':sorted(set(actual)-set(initial_source)), 'missing':sorted(set(initial_source)-set(actual)),
   'changed':sorted(k for k in initial_source if k in actual and initial_source[k]!=actual[k])}
 if any(differences.values()):raise ValueError('Install/build changed non-generated source/lock/gold: '+json.dumps(differences)[:1300])
 vendor=app/'src/import/vendor';vm=vendor/'SHA256.json';vendor_hashes={}
 if vendor.exists():
  if not vm.exists():raise ValueError('Generated vendor lacks SHA256.json')
  manifest=read(vm)
  vendor_hashes={p.relative_to(vendor).as_posix():sha(p) for p in vendor.rglob('*') if p.is_file() and p!=vm}
  if manifest!=vendor_hashes:raise ValueError('Vendor generated manifest mismatch/unlisted bytes')
 dist=app/'dist';dist_hashes={}
 if dist.exists():
  dist_hashes={p.relative_to(dist).as_posix():sha(p) for p in dist.rglob('*') if p.is_file()}
  expected={'index.html':sha(app/'index.html')}
  expected.update({'src/'+p.relative_to(app/'src').as_posix():sha(p) for p in (app/'src').rglob('*') if p.is_file()})
  if dist_hashes!=expected:raise ValueError('dist not exact expected build copy or has extra files')
 return {'sourceStable':True,'lockSha256':sha(app/'package-lock.json'),
         'goldSha256':{k:v for k,v in actual.items() if '/gold/' in k},
         'vendorSha256':vendor_hashes,'vendorManifestSha256':sha(vm) if vm.exists() else None,
         'distSha256':dist_hashes}

def check_prereqs(prereq,run_dir=None):
 """No auto provisioning. Each path must be verified and safe before execution."""
 failures=[];verified=[]
 for row in prereq.get('files',[]):
  p=pathlib.Path(row['path'])
  if not p.is_absolute() or not p.is_file() or p.is_symlink() or sha(p)!=row['sha256']:failures.append({'path':str(p),'reason':'missing/not absolute/hash mismatch'})
  else:verified.append({'path':str(p),'sha256':row['sha256']})
 for row in prereq.get('directories',[]):
  s=row['path'];p=pathlib.Path(s)
  if not s.endswith('/') or not p.is_absolute() or not p.is_dir():failures.append({'path':s,'reason':'absolute directory ending / required'});continue
  for f in row.get('files',[]):
   q=p/f['relativePath']
   if not q.is_file() or sha(q)!=f['sha256']:failures.append({'path':str(q),'reason':'fixture missing or hash mismatch'})
   else:verified.append({'path':str(q),'sha256':f['sha256']})
 if prereq.get('goldMutationPermitted'):failures.append({'reason':'gold mutation prohibited'})
 required=['oracle','comparator','sab','loadedAssets','semantic','effects','ep06','capacity','ui','browser','eFinite','eCommandMatrix','sandboxLauncherReview','humanPlans','independentExecutorPlan','phaseApplicability','directStaleStageRace','eR3ExactByteApproval']
 for k in required:
  item=prereq.get('gates',{}).get(k)
  if not isinstance(item,dict) or item.get('state')!='APPROVED_PREREQUISITES_ONLY':failures.append({'gate':k,'reason':'supporting prerequisite not approved (NOT a runtime PASS)'})
 return {'verified':verified,'failures':failures,'technicalComplete':False}

# Exact D-F-RUN-SEC-02 proposed source identities, against E's combined patch.
# Every change requires NEW D review and new runner hash; no source auto-fix.
REVIEWED_LAUNCHER_AND_E_HASHES = {'acknowledgment.mjs': '80c859c8038758f1e99bc78e265599ed5fadd8a1eba85e92ceb57c6db7e3a191', 'adversarial.mjs': '63b7c43a812fe29bf1449ca1a73f4fffec51e67d198275aa13ec9554d6d70a34', 'browser.mjs': '7a122770af52967a5b7b8c92e74983010bd04581dbf257c731a814390df7f6d6', 'capacity.mjs': 'e3e2220c35428f474c71bdb13dd6cc908033ae14d6c1067a53330cb7a3ecccf0', 'e-assertions.mjs': '9a26c999709815c9ced495f4cf6ad7b23612913ed64d6f043375c4ad334c097d', 'e-command-matrix.mjs': '581f8ceb47ff825c92a36640d773644d3a1ea8c7ec58492eb62bde96b1be19b2', 'e-finite.mjs': '588f3a11b97b35f8478b1116fa912c7d742c3229bad2e207e6fd145a22e19479', 'effects.mjs': 'ecf85cc1fa55f3e0fd16a4cba11dfb19fd072febf86fb56e1330bcdf1a731074', 'lifetime.mjs': '49d11adcd7619438c5024cb780100ce489bd9336f6c24ab5029969c0c4b576e5', 'manual-ui.mjs': 'dc20b3f5adfe230dd0ce5ffd8ad26b02780a0eb3ca4567b99442291b68fae853', 'owned-reader-smoke.mjs': 'cdc1324cc189c118d80bb3f5fcc519ea022c1c966b5fffcc59d68a1841d2e653', 'review-recipes.mjs': 'cfa96525e3fb4ef644704a73bca17b951935b69f7456de4cf54f49ab341fafb9', 'semantics.mjs': 'd61c110cffe5be6a6e651913fc000166d618542f77625559c91b4845ea37c556', 't1-events.mjs': '9474fca78a0b323ab19173d7459cb903dfb91b32a66090667f6241e21d8fc5d2', 'ui-revision.mjs': 'fd885f24aa41ce8dc1d821c9570370cdb8c7ef12050c5840e8454a468122459e', 'ui.mjs': '1bba2f35265f49f1072aa2d0d36b511b67a7497af7ca838221a1234db2cce198', 'zoom.mjs': '0c9928db32aef491083418e79dae8f3fd88757dc3388039c412f2a302d0bdd85', 'loaded-assets.mjs': 'c7a3d09c3c08fe424d2b548d4fd112f6f4fcb4013cc9a6b692e7d83cdf8d265e'}

def verify_reviewed_executables(app):
    base=app/'tests'/'sa-001'
    for name,expected in REVIEWED_LAUNCHER_AND_E_HASHES.items():
        path=base/name
        if not path.is_file() or sha(path)!=expected:
            raise ValueError('UNAPPROVED_EXECUTABLE_BYTES '+str(path))
        body=path.read_text()
        if name in {'acknowledgment.mjs','capacity.mjs','lifetime.mjs','manual-ui.mjs','owned-reader-smoke.mjs','t1-events.mjs','ui.mjs','ui-revision.mjs','zoom.mjs','browser.mjs','adversarial.mjs','effects.mjs','semantics.mjs','e-finite.mjs'}:
            if '--no'+'-sandbox' in body or 'chromiumSandbox:true' not in body:
                raise ValueError('SANDBOX_LAUNCHER_POLICY_FAILED '+str(path))
    # retained imports t1-events; no second launcher is scheduled.
    text=(base/'retained.mjs').read_text()
    if "from './t1-events.mjs'" not in text:
        raise ValueError('Retained imported launcher changed; new path audit required')
    return {'approvedExactHashes':REVIEWED_LAUNCHER_AND_E_HASHES,'importedRunner':'retained.mjs -> t1-events.mjs'}

E_VERIFIER_SHA='ef8b9501443df71e55e83443c02124488863be9a4f7d675436ab8f31a6c137b8'
E_ASSET_HELPER_SHA='c7a3d09c3c08fe424d2b548d4fd112f6f4fcb4013cc9a6b692e7d83cdf8d265e'
E_PHASE_POLICY_CANONICAL_SHA='ae9f393a2b741e75d79ae8a78171dfc99a25a63834392e6200bd59f892c141a6'
COMPARATOR_V2_SHA='73e0f2456523aa62734d6b7a1beb5bf90d9681e6338d1296f00a435e8e71f963'
ORACLE_SHA='5628adc49a277b4b283fb9cdfbc082924048dc24e018db415b2e9c768f3497a1'
F152_SHA='2d07a96fce9a6c5f4c1b61580af32562fbdbdc825be3bd9d1801cf4295f8cecb'
# The only three changed/added runtime files are E's complete r2 replacement against aec0abb.
E_R3_REPLACEMENT_PATCH_SHA='65ba1213bbaa8bdc1206a397d525a17a470167d796bc1b41145ce20e2b784380'
E_PROPOSED={'browser.mjs':'7a122770af52967a5b7b8c92e74983010bd04581dbf257c731a814390df7f6d6',
            'e-finite.mjs':'588f3a11b97b35f8478b1116fa912c7d742c3229bad2e207e6fd145a22e19479',
            'loaded-assets.mjs':E_ASSET_HELPER_SHA}

def validate_runtime_candidate(base,candidate):
    if (base.get('commitSha'),base.get('treeSha'))!=('aec0abb117939b2819ebcd7b0b426e8243705e65','40ffc07eb2e4552e742e9c5fa3a931ccea92e5b3'):
        raise ValueError('BASE_CHECKPOINT_IDENTITY_CHANGED')
    a,b=base['sourceFileSha256'],candidate['sourceFileSha256']
    allowed={'semester-space/tests/sa-001/'+k:v for k,v in E_PROPOSED.items()}
    if set(b)-set(a)!={'semester-space/tests/sa-001/loaded-assets.mjs'} or set(a)-set(b):
        raise ValueError('RUNTIME_CANDIDATE_ALLOWED_FILE_SET_MISMATCH')
    if {p for p in a if a[p]!=b[p]}==set():
        raise ValueError('E_CHANGE_NOT_INTEGRATED')
    if {p for p in a if a[p]!=b[p]}!=set(allowed)-{'semester-space/tests/sa-001/loaded-assets.mjs'}:
        raise ValueError('RUNTIME_CANDIDATE_OTHER_SOURCE_CHANGED')
    for p,h in allowed.items():
        if b.get(p)!=h:raise ValueError('RUNTIME_CANDIDATE_E_BYTES_MISMATCH '+p)
    if candidate.get('commitSha')==base.get('commitSha') or candidate.get('treeSha')==base.get('treeSha'):
        raise ValueError('AMENDED_CANDIDATE_MUST_GET_NEW_A_ISSUED_COMMIT_TREE')
    if candidate.get('classification')!='A_D_REVIEWED_FINAL_CLEAN_CANDIDATE':
        raise ValueError('NO_A_D_REVIEWED_FINAL_CANDIDATE')
    return {'changed':sorted(allowed),'sourceFiles':len(b),'sourceScope':'E_R3_2_CHANGED_1_ADDED_ONLY','replacementPatchSha256':E_R3_REPLACEMENT_PATCH_SHA}

def step_list(app,extra,prereq):
 cmds=[('install',['npm','ci']),('check',['npm','run','check']),('full-tests',['npm','test']),
 ('engine-ledger',['node','--test',*map(lambda p:p.relative_to(app).as_posix(), sorted((app/'tests/engine').glob('*.test.mjs'))),
                                 *map(lambda p:p.relative_to(app).as_posix(), sorted((app/'tests/attendance').glob('*.test.mjs')))]),
 ('b2-omr',['node','--test','tests/diamond-001/storage.test.mjs','tests/diamond-001/omitted-release-acceptance.test.mjs','tests/diamond-001/omitted-release-precedence.test.mjs']),
 ('adp-epoch',['node','--test','tests/sa-001/codecs.test.mjs','tests/sa-001/epoch.test.mjs']),
 ('math-checker',['python3','tests/checker.py']),('build',['npm','run','build']),
 ('loaded-asset-freeze',['python3',prereq['assetVerifier'],'freeze','--checkout','{repo}',
   '--checkpoint',prereq['baseCheckpointIdentity'],'--candidate','{runtime_candidate_identity}',
   '--evidence-root','{run}', '--run-uuid','{run_uuid}','--out','{asset_binding}'])]
 scripts=[('owned-reader','owned-reader-smoke.mjs'),('browser-native-connected','browser.mjs'),('ack-physical','acknowledgment.mjs'),
 ('lifetime','lifetime.mjs'),('effects','effects.mjs'),('e-finite','e-finite.mjs'),('adversarial','adversarial.mjs'),('semantics','semantics.mjs'),
 ('retained','retained.mjs'),('main-ui','ui.mjs'),('revision-ui','ui-revision.mjs'),('manual-ui','manual-ui.mjs'),
 ('zoom','zoom.mjs'),('capacity','capacity.mjs')]
 cmds.extend((label,['node','tests/sa-001/'+name,'--run','--out','{new_output}']) for label,name in scripts)
 # E command matrix consumes genuinely completed browser and effects report.jsons.
 # Insert immediately AFTER effects, preserving connected browser native/reopen within its one job.
 idx=next(i for i,(label,_) in enumerate(cmds) if label=='effects')+1
 cmds.insert(idx,('e-command-matrix',['node','tests/sa-001/e-command-matrix.mjs','{browser_report}','{effects_report}']))
 # Optional reviewed supporting jobs supplied as exact argv, never injected into app source.
 required=['oracle-storage','adp07-shared','oracle-comparator','loaded-asset-verification']
 if [job.get('label') for job in extra]!=required:
  raise ValueError('Supplemental order must be exact: '+repr(required))
 for job in extra:
  if not isinstance(job,dict) or job.get('label') in {k for k,_ in cmds} or not isinstance(job.get('argv'),list):raise ValueError('Invalid supplemental job')
  script=pathlib.Path(job.get('scriptPath',''));declared=job.get('sha256')
  if not script.is_absolute() or not script.is_file() or script.is_symlink() or sha(script)!=declared:
   raise ValueError('Supplemental script identity missing or changed: '+str(script))
  if str(script) not in job['argv']:
   raise ValueError('Supplemental job argv must name its reviewed exact script: '+str(script))
  if any('manifest.mjs' in z for z in job['argv']):raise ValueError('gold-writing manifest.mjs forbidden')
  cmds.append((job['label'],job['argv']))
 return cmds

def write_json(path,data):
 path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

def run_command(argv,cwd,run,tag,timeout,env):
 now=UTC();wall=time.monotonic();stdout=run/(tag+'.stdout');stderr=run/(tag+'.stderr');meta=run/(tag+'.meta.json')
 rec={'tag':tag,'argv':argv,'cwd':str(cwd),'startedAtUTC':now,'stdout':str(stdout),'stderr':str(stderr),
      'timeoutSeconds':timeout,'status':'STARTED_NOT_YET_COMPLETED'}
 write_json(meta,rec)  # metadata exists before launch
 proc=None
 try:
  with stdout.open('xb') as fo,stderr.open('xb') as fe:
   proc=subprocess.Popen(argv,cwd=cwd,stdout=fo,stderr=fe,env=env,start_new_session=True)
   try:code=proc.wait(timeout=timeout);rec.update(exitCode=code,status='EXITED')
   except subprocess.TimeoutExpired:
    os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    rec.update(exitCode=proc.returncode,status='TIMEOUT_STOP_NO_RETRY')
 except KeyboardInterrupt:
  if proc and proc.poll() is None:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=6)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  rec.update(exitCode=proc.returncode if proc else None,status='INTERRUPTED_NO_RETRY')
 except BaseException as err:rec.update(exitCode=proc.returncode if proc else None,status='LAUNCH_EXCEPTION',exception=repr(err))
 finally:
  rec.update(finishedAtUTC=UTC(),durationSeconds=round(time.monotonic()-wall,4))
  for p,label in ((stdout,'stdoutSha256'),(stderr,'stderrSha256')):
   if p.is_file():rec[label]=sha(p)
  write_json(meta,rec)
 return rec

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',required=True,help='Disposable semester-space application root')
 p.add_argument('--identity',required=True,help='Reviewed full manifest; for FINAL new A/D-approved clean commit manifest')
 p.add_argument('--mode',required=True,choices=['exact_baseline','final_clean'])
 p.add_argument('--prerequisites',required=True,help='External, separately approved fixture and gates inventory')
 p.add_argument('--evidence-root',required=True,help='Existing evidence parent; unique child created')
 p.add_argument('--approval',help='Execution-specific A/D approval JSON document with runner SHA-256')
 p.add_argument('--execute',action='store_true');p.add_argument('--timeout-seconds',type=int,default=1800)
 args=p.parse_args();app=pathlib.Path(args.source).resolve();repo=app.parent;parent=pathlib.Path(args.evidence_root).resolve()
 if args.timeout_seconds<60 or not app.joinpath('package.json').is_file() or not parent.is_dir() or not (repo/'.git').exists():raise SystemExit('Invalid source, git checkout, timeout, or evidence parent')
 if app.as_posix()!='/workspace/sa001-final-operator-disposable/semester-space' or parent.as_posix()!='/workspace/sa001-evidence-final':
  raise SystemExit('EXEC04_STAGED_SOURCE_OR_EVIDENCE_ROOT_MISMATCH')
 if any((str(repo)==v or str(repo).startswith(v.rstrip('/')+'/')) for v in ['/workspace/SemesterSpace-sa-001','/workspace/SemesterSpace-diamond-001']):
  raise SystemExit('Original worktrees explicitly forbidden')
 if (app/'node_modules').exists() or (app/'dist').exists() or (app/'src/import/vendor').exists():
  raise SystemExit('Disposable checkout must have no pre-existing node_modules, dist or generated vendor assets')
 # Do not treat an executable Python file as the JSON prerequisites document.
 for key,pth in [('identity',args.identity),('prerequisites',args.prerequisites)]:
  if pathlib.Path(pth).suffix.lower()!='.json' or not pathlib.Path(pth).is_file():
   raise SystemExit('EXEC01_EXPECTED_REVIEWED_JSON_DOCUMENT '+key+' '+str(pth))
 identity=read(args.identity);prereq=read(args.prerequisites)
 if not isinstance(identity,dict) or not isinstance(prereq,dict):
  raise SystemExit('EXEC01_REVIEWED_DOCUMENT_OBJECT_REQUIRED')
 base_identity=prereq.get('baseCheckpointIdentity')
 if not base_identity or pathlib.Path(base_identity).suffix.lower()!='.json' or not pathlib.Path(base_identity).is_file() or sha(base_identity)!=prereq.get('baseCheckpointIdentitySha256'):
  raise SystemExit('EXEC02_MISSING_VERIFIED_BASE_CHECKPOINT_IDENTITY')
 if args.mode!='final_clean':raise SystemExit('EXEC02_NEW_E_SUPPORT_REQUIRES_NEW_FINAL_CLEAN_CANDIDATE')
 if not isinstance(prereq.get('assetVerifier'),str) or not pathlib.Path(prereq['assetVerifier']).is_file() or sha(prereq['assetVerifier'])!=E_VERIFIER_SHA:
  raise SystemExit('EXEC03_E_VERIFIER_MISSING_OR_CHANGED')
 candidate_binding=validate_runtime_candidate(read(base_identity),identity)

 who={'node':shutil.which('node'),'npm':shutil.which('npm'),'python3':shutil.which('python3'),
      'git':shutil.which('git'),'chromium':'/usr/bin/chromium'}
 if any(not x for x in who.values()) or not pathlib.Path('/usr/bin/chromium').is_file():raise SystemExit('Required binaries not available')
 source_identity=verify_source(repo,app,identity,args.mode);reviewed_executables=verify_reviewed_executables(app);deps=check_prereqs(prereq)
 extra=prereq.get('approvedSupportingJobs',[])
 cmds=step_list(app,extra,prereq)
 versions={k:cmd([binary,'--version'],cwd=app).split('\n')[0] for k,binary in who.items()}
 check={'mode':args.mode,'identity':source_identity,'binaries':who,'versions':versions,'prerequisites':deps,
        'commands':[{'label':label,'argv':argv} for label,argv in cmds], 'reviewedExecutables':reviewed_executables, 'technicalCompleteAllowed':False,'runtimeCandidateIdentitySha256':sha(args.identity),'runtimeCandidateIdentityPath':str(pathlib.Path(args.identity).resolve()),'approvedBaseCheckpointSha256':sha(base_identity),'baseCheckpointIdentitySha256':sha(base_identity), 'eIntegrationBinding':candidate_binding, 'phasePolicyEnforcement':'E_R3_PHASE_APPLICABILITY_FROZEN_RECIPE_PROPOSED_UNRUN_PENDING_D_REVIEW', 'racePolicy':'E_RACE01_DELAYED_PREPARE_AND_MUTATION_REVOCATION_PROPOSED_UNRUN_PENDING_D_REVIEW'}
 if not args.execute:print(json.dumps({'status':'DRY_PREFLIGHT_NO_APP_EXECUTION',**check},indent=2));return
 if deps['failures']:raise SystemExit('Unresolved prerequisites; no execute: '+json.dumps(deps['failures'][:10]))
 if not args.approval or pathlib.Path(args.approval).suffix.lower()!='.json':raise SystemExit('Explicit A/D execution approval JSON required')
 approval=read(args.approval)
 if approval.get('authorized') is not True or approval.get('mode')!=args.mode or approval.get('identitySha256')!=sha(args.identity) or approval.get('runnerSha256')!=sha(__file__) or approval.get('prerequisitesSha256')!=sha(args.prerequisites):
  raise SystemExit('Runner/identity not bound by A/D approval')
 required_jobs={'oracle-storage','adp07-shared','oracle-comparator','loaded-asset-verification','e-finite','e-command-matrix','loaded-asset-freeze'}
 if not required_jobs.issubset({label for label,_ in cmds}):raise SystemExit('Mandatory reviewed oracle/SAB/comparator/loaded-asset jobs missing from plan')
 run=parent/('SA001-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:12]);run.mkdir(mode=0o700,exist_ok=False)
 write_json(run/'START_PREFLIGHT.json',check)
 # Original source inventory snapshot protects ALL supplied files including tests/gold/lock.
 source_snapshot=file_sha_map(repo);records=[];env=os.environ.copy();measured_asset_sha=None
 # external environment is checked in prereq; tool does not create paths or replace inputs.
 for k,v in prereq.get('approvedEnvironment',{}).items():
  if k not in ('SA_CONTRACT_ROOT','SA_IMPL04_ROOT'):raise ValueError('Only exact bounded env-only oracle paths allowed')
  if not isinstance(v,str) or not v.startswith('/') or not v.endswith('/'):raise ValueError('Expected an absolute root ending with /')
  env[k]=v
 try:
  for label,argv in cmds:
   out=run/(label+'-outputs')
   input_reports={'{browser_report}':run/'browser-native-connected-outputs'/'report.json',
                  '{effects_report}':run/'effects-outputs'/'report.json'}
   if label=='e-command-matrix':
    for p in input_reports.values():
     if not p.is_file():raise RuntimeError('Missing E command-matrix prerequisite report: '+str(p))
   # Freeze is an in-graph job immediately after build; the hash is generated NOW,
   # not part of the pre-existing source identity or predicted from the source.
   binding=run/'loaded-assets-binding.json'
   subs={'{new_output}':str(out),'{repo}':str(repo),'{run}':str(run),
         '{run_uuid}':run.name,'{asset_binding}':str(binding),
         '{runtime_candidate_identity}':str(pathlib.Path(args.identity).resolve()),
         '{browser_output}':str(run/'browser-native-connected-outputs'),
         '{finite_output}':str(run/'e-finite-outputs')}
   if measured_asset_sha is not None:subs['{asset_binding_sha256}']=measured_asset_sha
   def expand_token(value):
    if value in input_reports:return str(input_reports[value])
    found=re.findall(r'\{[a-z_]+\}',value)
    if any(k not in subs for k in found):raise RuntimeError('UNRESOLVED_RUNTIME_ARGV_TOKEN '+label+': '+value)
    for k in found:value=value.replace(k,subs[k])
    if re.search(r'\{[a-z_]+\}',value):raise RuntimeError('UNRESOLVED_RUNTIME_ARGV_TOKEN '+label)
    return value
   argv=[expand_token(x) for x in argv]
   if label in ('browser-native-connected','e-finite'):
    if measured_asset_sha is None or not binding.is_file() or sha(binding)!=measured_asset_sha:
     raise RuntimeError('NO_MATCHING_SAME_RUN_PRE_BROWSER_BINDING')
    env=dict(env,SA_LOADED_ASSET_BINDING=str(binding),SA_LOADED_ASSET_BINDING_SHA256=measured_asset_sha)
   run_env=env if label in ('browser-native-connected','e-finite') else {k:v for k,v in env.items() if k not in ('SA_LOADED_ASSET_BINDING','SA_LOADED_ASSET_BINDING_SHA256')}
   rec=run_command(argv,app,run,label,args.timeout_seconds,run_env);records.append(rec)
   if label in ('browser-native-connected','e-finite'):
    cleanup_failure=out/'cleanup-failure.json'
    if cleanup_failure.exists():
     rec['cleanupFailureSha256']=sha(cleanup_failure) if cleanup_failure.is_file() else None
     rec['status']='CLEANUP_FAILURE_PRESERVED_HOLD'
    source_report=out/'report.json'
    if not source_report.is_file():
     rec['producerReportMissing']=True
     rec['status']='MISSING_PRODUCER_REPORT_HOLD'
    else:
     rec['producerReportSha256']=sha(source_report)
     try:
      report=read(source_report)
      positive=(report.get('status')=='EXECUTED_BROWSER_POPULATION_PASS_OTHER_GATES_SEPARATELY_REPORTED') if label=='browser-native-connected' else (report.get('runtime') in ('PARTIAL_ORIGINAL_FORGERY_ARTIFACT_BLOCKED','FOCUSED_CONTROLS_PASS_OTHER_GATES_OPEN'))
      if not positive:
       rec['producerReportedState']=report.get('status',report.get('runtime'))
       rec['status']='PRODUCER_REPORT_NOT_PASS_HOLD'
     except BaseException as err:
      rec['producerReportParseError']=repr(err)
      rec['status']='UNREADABLE_PRODUCER_REPORT_HOLD'
   if label=='e-finite' and rec.get('status')=='EXITED' and rec.get('exitCode')==0:
    report=read(out/'report.json')
    race_rows=[row for row in report.get('cases',[]) if isinstance(row,dict) and row.get('id')=='E_RACE01_DELAYED_PREPARE_AND_MUTATION_REVOCATION']
    required_events=['OLD_REAL_PREPARE_SETTLED','NEW_GENUINE_STAGE_READY','OLD_RESULT_DELIVERED','ACCEPTED_MODEL_MUTATION','FRESH_POST_MUTATION_STAGE_READY','FRESH_POST_MUTATION_ACCEPT_RETURNED']
    if len(race_rows)!=1 or race_rows[0].get('status')!='PASS' or not isinstance(race_rows[0].get('actual'),dict):
     rec['status']='E_RACE01_REQUIRED_ROW_MISSING_OR_NOT_PASS_HOLD'
    else:
     events=race_rows[0]['actual'].get('events',[])
     ordinal={e.get('tag'):e.get('ordinal') for e in events if isinstance(e,dict)}
     if not all(isinstance(ordinal.get(x),int) for x in required_events) or not all(ordinal[a]<ordinal[b] for a,b in zip(required_events,required_events[1:])):
      rec['status']='E_RACE01_EVENT_ORDER_UNPROVEN_HOLD'
     else:
      rec['raceAssertionRow']='E_RACE01_DELAYED_PREPARE_AND_MUTATION_REVOCATION'
      rec['raceRowSourceSha256']=E_PROPOSED['e-finite.mjs']
      rec['raceResultMeaning']='E_REAL_STAGE_TEST_ROW_ONLY_NOT_PRODUCTION_OR_INDEPENDENT_ACCEPTANCE'
   if label=='e-command-matrix':
    rec['exactInputReportSha256']={str(p):sha(p) for p in input_reports.values()}
   # Verify immediately after install, build, and each step; no new source/lock/gold allowed.
   try:rec['postCheck']=verify_generated(repo,app,source_snapshot)
   except BaseException as e:rec['postCheckError']=str(e);rec['status']='POSTCHECK_FAILED'
   if label=='loaded-asset-freeze' and rec.get('status')=='EXITED' and rec.get('exitCode')==0 and not rec.get('postCheckError'):
    if not binding.is_file() or binding.is_symlink():raise RuntimeError('FREEZE_DID_NOT_EMIT_NEW_BINDING')
    measured_asset_sha=sha(binding)
    f=read(binding)
    if f.get('status')!='PRE_BROWSER_BUILD_FREEZE' or f.get('runUuid')!=run.name or f.get('runtimeIdentitySha256')!=sha(args.identity) or f.get('verifierSha256')!=E_VERIFIER_SHA or f.get('phasePolicySha256')!=E_PHASE_POLICY_CANONICAL_SHA:
     raise RuntimeError('FREEZE_BINDING_WRONG_CANDIDATE_OR_RUN')
    rec['assetBindingSha256']=measured_asset_sha
    rec['buildInventorySha256']=f.get('buildInventorySha256')
   if label=='loaded-asset-verification' and rec.get('status')=='EXITED' and rec.get('exitCode')==0 and not rec.get('postCheckError'):
    result=out/'binding-result.json'
    if not result.is_file() or read(result).get('version')!='E-LOADED-ASSETS/1' or read(result).get('status')!='LOADED_BYTE_BINDING_COMPLETE_FOR_TWO_SCOPED_JOBS_ONLY' or read(result).get('bindingSha256')!=measured_asset_sha or set((read(result).get('jobs') or {}).keys())!={'browser','e-finite'}:
     raise RuntimeError('ASSET_VERIFIER_OUTPUT_NOT_COMPLETE_FOR_SCOPED_JOBS')
    rec['loadedAssetResultSha256']=sha(result)
    rec['loadedByteMeaning']='SCOPE_LIMITED_RESPONSES_ONLY_NOT_WASM_INSTANTIATION_OR_MODULE_EVALUATION_NOT_SA_ACCEPTANCE'
   write_json(run/(label+'.meta.json'),rec)
   write_json(run/'RUN_STATE.json',{'classification':'PRODUCER_UNLESS_INDEPENDENCE_SEPARATELY_APPROVED', 'source':source_identity,
        'results':records,'technicalComplete':False,'pendingHumanAndD':True})
   if rec.get('status')!='EXITED' or rec.get('exitCode')!=0 or rec.get('postCheckError'):
    raise RuntimeError('Stop on '+label+'; raw evidence retained, no automatic retry')
 except BaseException as exc:
  write_json(run/'RUN_FAILURE.json',{'status':'STOPPED_NO_RETRY','exceptionType':type(exc).__name__,
     'message':str(exc),'traceback':traceback.format_exc(),'atUTC':UTC(),
     'completedJobCount':len(records),'technicalComplete':False})
  raise
 finally:
  artifacts={p.relative_to(run).as_posix():sha(p) for p in run.rglob('*') if p.is_file() and p.name!='FINAL_ARTIFACT_HASHES.json'}
  write_json(run/'FINAL_ARTIFACT_HASHES.json',{'hashes':artifacts,'endedAtUTC':UTC()})
 print('Producer technical steps finished; NO SA-001 acceptance without reviewed gate assertions, loaded asset binding, UX03/UX04 and D independent execution:',run)
if __name__=='__main__':main()
