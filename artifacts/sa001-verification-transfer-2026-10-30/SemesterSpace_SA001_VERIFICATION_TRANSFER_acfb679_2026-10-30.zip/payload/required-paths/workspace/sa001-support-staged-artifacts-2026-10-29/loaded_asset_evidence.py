#!/usr/bin/env python3
"""Proposed offline freeze/verifier; no browser launch, build, install or application import."""
import argparse, base64, collections, hashlib, json, pathlib, re, subprocess, urllib.parse, zipfile
BASE_COMMIT='aec0abb117939b2819ebcd7b0b426e8243705e65'
BASE_TREE='40ffc07eb2e4552e742e9c5fa3a931ccea92e5b3'
CHANGED={'semester-space/tests/sa-001/browser.mjs','semester-space/tests/sa-001/e-finite.mjs'}
ADDED={'semester-space/tests/sa-001/loaded-assets.mjs'}
def sha(b): return hashlib.sha256(b).hexdigest()
def readjson(p): return json.loads(pathlib.Path(p).read_bytes())
def require(ok, msg):
    if not ok: raise ValueError(msg)
def file_bytes(p):
    p=pathlib.Path(p)
    require(p.is_file() and not p.is_symlink(),'Missing/symlink file: '+str(p))
    require(all(not x.is_symlink() for x in p.parents),'Symlink parent: '+str(p))
    return p.read_bytes()
def write_new(p,value):
    p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f: json.dump(value,f,indent=2);f.write('\n')
def git(root,*args): return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
def inventory(root):
    root=pathlib.Path(root);result={}
    for p in sorted(root.rglob('*')):
        require(not p.is_symlink(),'Symlink in inventory: '+str(p))
        if p.is_file(): result[p.relative_to(root).as_posix()]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
    return result
def current_candidate(root,candidate):
    require(git(root,'rev-parse','HEAD')==candidate['commitSha'],'Runtime HEAD mismatch')
    require(git(root,'rev-parse','HEAD^{tree}')==candidate['treeSha'],'Runtime tree mismatch')
    require(not git(root,'status','--porcelain','--untracked-files=no'),'Tracked source not clean')
    paths=subprocess.check_output(['git','-C',str(root),'ls-files','-z']).decode().split('\0')[:-1]
    hashes=candidate['sourceFileSha256'];require(set(paths)==set(hashes),'Tracked path inventory mismatch')
    for rel,h in hashes.items(): require(sha(file_bytes(root/rel))==h,'Source hash mismatch: '+rel)
def freeze(a):
    root=pathlib.Path(a.checkout).resolve();base=readjson(a.checkpoint);candidate=readjson(a.candidate)
    require((base['commitSha'],base['treeSha'])==(BASE_COMMIT,BASE_TREE),'Wrong reviewed checkpoint')
    old=base['sourceFileSha256'];new=candidate['sourceFileSha256']
    require(set(new)-set(old)==ADDED and not set(old)-set(new),'Only one supporting file may be added')
    require({p for p in old if old[p]!=new[p]}==CHANGED,'Only two lifecycle test files may change')
    require((candidate['commitSha'],candidate['treeSha'])!=(BASE_COMMIT,BASE_TREE),'Amended support cannot retain original identity')
    current_candidate(root,candidate)
    package=root/'semester-space';dist=package/'dist';built=inventory(dist)
    require('index.html' in built and any(k.startswith('src/') for k in built),'Missing fresh dist')
    for p,h in new.items():
        if p=='semester-space/index.html' or p.startswith('semester-space/src/'):
            rel=p.removeprefix('semester-space/');require(built.get(rel,{}).get('sha256')==h,'Dist differs from tracked source: '+rel)
    approved=readjson(package/'tests/sa-001/gold/AVAILABLE_CONFIG_MEASURED.json')
    vendor=package/'src/import/vendor';vendor_bytes=file_bytes(vendor/'SHA256.json');declared=json.loads(vendor_bytes)
    require(sha(vendor_bytes)==approved['availableAssetManifestSha256'],'Generated vendor manifest differs from frozen approved available manifest')
    require(set(declared)=={asset['path'] for asset in approved['availableAssets']},'Unknown/missing vendor-manifest entry')
    require(set(inventory(vendor))==set(declared)|{'SHA256.json'},'Unknown/missing generated vendor file')
    expected_dist={'index.html'}|{p.removeprefix('semester-space/') for p in new if p.startswith('semester-space/src/')}|{'src/import/vendor/'+p for p in declared}|{'src/import/vendor/SHA256.json'}
    require(set(built)==expected_dist,'Unexpected/missing built file; cannot bless untracked build code')
    require(set(inventory(package/'src'))=={p.removeprefix('src/') for p in expected_dist if p.startswith('src/')},'Unexpected/missing source or generated-vendor file')
    for asset in approved['availableAssets']:
        rel=asset['path'];h=asset['sha256'];require(declared.get(rel)==h,'Vendor manifest mismatch: '+rel)
        require(sha(file_bytes(vendor/rel))==h,'Installed vendor mismatch: '+rel)
        require(built.get('src/import/vendor/'+rel,{}).get('sha256')==h,'Built vendor mismatch: '+rel)
    eroot=pathlib.Path(a.evidence_root).resolve();require(eroot.is_dir(),'Run evidence root must already exist')
    value={'version':'E-LOADED-ASSETS/1','status':'PRE_BROWSER_BUILD_FREEZE','runUuid':a.run_uuid,'evidenceRoot':str(eroot),'checkoutRoot':str(root),'baseCheckpoint':{'commitSha':BASE_COMMIT,'treeSha':BASE_TREE},'runtimeCandidate':{'commitSha':candidate['commitSha'],'treeSha':candidate['treeSha']},'checkpointIdentitySha256':sha(file_bytes(a.checkpoint)),'runtimeIdentitySha256':sha(file_bytes(a.candidate)),'sourceFileSha256':new,'buildFiles':built,'buildInventorySha256':sha(json.dumps(built,sort_keys=True,separators=(',',':')).encode()),'approvedAvailableAssetManifestSha256':approved['availableAssetManifestSha256'],'verifierSha256':sha(file_bytes(__file__)),'phasePolicySha256':sha(json.dumps(PHASE_POLICY,sort_keys=True,separators=(',',':')).encode())}
    write_new(a.out,value);print(json.dumps({'binding':str(pathlib.Path(a.out).resolve()),'sha256':sha(file_bytes(a.out))}))
def asset_path(url,origin):
    u=urllib.parse.urlsplit(url);o=urllib.parse.urlsplit(origin)
    require((u.scheme,u.netloc)==(o.scheme,o.netloc),'Off-origin HTTP response/request: '+url)
    require(not u.username and not u.password and not u.query and not u.fragment,'Noncanonical asset URL: '+url)
    decoded=urllib.parse.unquote(u.path,errors='strict')
    if decoded.startswith('/src/'):
        rel=decoded[1:];require('..' not in pathlib.PurePosixPath(rel).parts and '\\' not in rel,'Unsafe asset URL');return rel
    if decoded in ['/','/index.html']: return 'index.html'
    return None
# HAR bodies are browser-observed response payloads, not a second HTTP request or filesystem substitution.
def attached_body(z,content):
    if '_file' in content:
        name=content['_file'];require(name in z.namelist(),'HAR body attachment absent: '+str(name));return z.read(name),{'kind':'HAR_ATTACHMENT','entry':name}
    require('text' in content,'No response body retained in HAR')
    require(content.get('encoding')=='base64','Text-only HAR cannot certify byte-exact payload')
    return base64.b64decode(content['text'],validate=True),{'kind':'HAR_INLINE_BASE64'}
def trace_inventory(p):
    # Reuse existing traces for URL/timing/body corroboration where bodies are actually present.
    rows=[]
    with zipfile.ZipFile(p) as z:
        require(z.testzip() is None,'Trace CRC failed')
        for name in z.namelist():
            if not name.endswith('.network'): continue
            for n,line in enumerate(z.read(name).splitlines(),1):
                event=json.loads(line);snapshot=event.get('snapshot',{})
                if 'request' not in snapshot: continue
                content=snapshot.get('response',{}).get('content',{});ref=content.get('_sha1');body='resources/'+ref if ref else None
                rows.append({'url':snapshot['request']['url'],'status':snapshot.get('response',{}).get('status'),'networkEntry':name,'line':n,'bodyEntry':body if body in z.namelist() else None,'bodySha256':sha(z.read(body)) if body in z.namelist() else None})
    return rows
PHASES={'browser':{'native-before':'session-before-reopen-trace.zip','native-after':'session-after-reopen-trace.zip','retained-ui':'main-ui-trace.zip','fixture-pdf-ocr':'fixture-source-and-consent-trace.zip'},'e-finite':{'forgery-before':'forgery-before-reopen.zip','forgery-after':'finite-after-reopen.zip'}}
# Generated from the accompanying PHASE_ASSET_POLICY.json; inline to avoid another operator input.
PHASE_POLICY=json.loads('{"version":"E-PHASE-ASSET/1","status":"FROZEN_RECIPE_APPLICABILITY_NOT_EXECUTED_USAGE","phases":{"native-before":{"job":"browser","actions":["composeSourceRuntime imports","real timetable+calendar initial PDF review/accept","selective real notice PDF revision/accept","save raw bytes then close"],"location":"browser.mjs runBrowser: first launch through session-before-reopen-trace.zip","assets":{"compositionModules":{"classification":"MANDATORY","paths":["src/import/authority.js","src/controller.js","src/storage.js"],"because":"composeSourceRuntime unconditionally imports these before phase actions"},"appEntry":{"classification":"NOT_USED","paths":["src/main.js","index.html"],"because":"retained-ui alone navigates to the application root; other phases use test-entry plus explicit imports"},"pdfEngine":{"classification":"MANDATORY","paths":["src/import/vendor/pdf.mjs"],"because":"at least one genuine PDF decode in this context"},"pdfWorker":{"classification":"CONDITIONAL","paths":["src/import/vendor/pdf.worker.mjs"],"condition":"an actual PDF Worker event or script response activates binding; no request is invented for reader-only/fallback operation","absenceDisposition":"NO_OBSERVED_PDF_WORKER; worker-specific subtype not proved; never call it genuine Worker evidence"},"pdfFonts":{"classification":"CONDITIONAL","prefix":"src/import/vendor/standard_fonts/","condition":"only fonts actually requested by the source PDF; every observed response must match"},"ocrEntryWorkerLanguage":{"classification":"CONDITIONAL","paths":["src/import/vendor/tesseract.js","src/import/vendor/worker.min.js","src/import/vendor/eng.traineddata.gz"],"condition":"mandatory for original P3 OCR action; in PDF-only phases activated by observed OCR Worker/loader/core/language/binary request (possible real text-layer fallback)"},"ocrCoreWrapper":{"classification":"CONDITIONAL","suffix":".wasm.js","condition":"same OCR trigger; one or more actually loaded approved hardware variants, no forced variant filename"},"wasmBinaryBytes":{"classification":"CONDITIONAL","condition":"same OCR trigger; actual .wasm HTTP attachment OR recognised embedded binary in an actually fetched wrapper, distinctly labelled; instantiation unobserved"},"otherObservedAssets":{"classification":"CONDITIONAL","condition":"every observed /src/ and index response is still byte-compared regardless of table classification"},"documentImageHttpUploads":{"classification":"NOT_USED","because":"existing APIs receive owned PDF/image byte arrays; no HTTP source upload/request is required"},"serviceWorkers":{"classification":"NOT_USED","because":"not used by the frozen actions; any observation remains unsupported and blocks capture completeness"}}},"native-after":{"job":"browser","actions":["same-profile new persistent-context process","reload retained receipt bytes without source decoding","then real later-notice PDF review","physical-ACK fault and explicit reload"],"location":"browser.mjs runBrowser: second launch through session-after-reopen-trace.zip","assets":{"compositionModules":{"classification":"MANDATORY","paths":["src/import/authority.js","src/controller.js","src/storage.js"],"because":"composeSourceRuntime unconditionally imports these before phase actions"},"appEntry":{"classification":"NOT_USED","paths":["src/main.js","index.html"],"because":"retained-ui alone navigates to the application root; other phases use test-entry plus explicit imports"},"pdfEngine":{"classification":"MANDATORY","paths":["src/import/vendor/pdf.mjs"],"because":"at least one genuine PDF decode in this context"},"pdfWorker":{"classification":"CONDITIONAL","paths":["src/import/vendor/pdf.worker.mjs"],"condition":"an actual PDF Worker event or script response activates binding; no request is invented for reader-only/fallback operation","absenceDisposition":"NO_OBSERVED_PDF_WORKER; worker-specific subtype not proved; never call it genuine Worker evidence"},"pdfFonts":{"classification":"CONDITIONAL","prefix":"src/import/vendor/standard_fonts/","condition":"only fonts actually requested by the source PDF; every observed response must match"},"ocrEntryWorkerLanguage":{"classification":"CONDITIONAL","paths":["src/import/vendor/tesseract.js","src/import/vendor/worker.min.js","src/import/vendor/eng.traineddata.gz"],"condition":"mandatory for original P3 OCR action; in PDF-only phases activated by observed OCR Worker/loader/core/language/binary request (possible real text-layer fallback)"},"ocrCoreWrapper":{"classification":"CONDITIONAL","suffix":".wasm.js","condition":"same OCR trigger; one or more actually loaded approved hardware variants, no forced variant filename"},"wasmBinaryBytes":{"classification":"CONDITIONAL","condition":"same OCR trigger; actual .wasm HTTP attachment OR recognised embedded binary in an actually fetched wrapper, distinctly labelled; instantiation unobserved"},"otherObservedAssets":{"classification":"CONDITIONAL","condition":"every observed /src/ and index response is still byte-compared regardless of table classification"},"documentImageHttpUploads":{"classification":"NOT_USED","because":"existing APIs receive owned PDF/image byte arrays; no HTTP source upload/request is required"},"serviceWorkers":{"classification":"NOT_USED","because":"not used by the frozen actions; any observation remains unsupported and blocks capture completeness"}}},"retained-ui":{"job":"browser","actions":["composeSourceRuntime imports at test-entry","navigate to app root","display retained source history only; no selectSource/beginReview"],"location":"browser.mjs runBrowser: third launch through main-ui-trace.zip","assets":{"compositionModules":{"classification":"MANDATORY","paths":["src/import/authority.js","src/controller.js","src/storage.js"],"because":"composeSourceRuntime unconditionally imports these before phase actions"},"appEntry":{"classification":"MANDATORY","paths":["src/main.js","index.html"],"because":"retained-ui alone navigates to the application root; other phases use test-entry plus explicit imports"},"pdfEngine":{"classification":"NOT_USED","paths":["src/import/vendor/pdf.mjs"],"because":"no source decode action in retained-history display"},"pdfWorker":{"classification":"NOT_USED","paths":["src/import/vendor/pdf.worker.mjs"],"condition":"an actual PDF Worker event or script response activates binding; no request is invented for reader-only/fallback operation","absenceDisposition":"NO_OBSERVED_PDF_WORKER; worker-specific subtype not proved; never call it genuine Worker evidence"},"pdfFonts":{"classification":"NOT_USED","prefix":"src/import/vendor/standard_fonts/","condition":"only fonts actually requested by the source PDF; every observed response must match"},"ocrEntryWorkerLanguage":{"classification":"NOT_USED","paths":["src/import/vendor/tesseract.js","src/import/vendor/worker.min.js","src/import/vendor/eng.traineddata.gz"],"condition":"mandatory for original P3 OCR action; in PDF-only phases activated by observed OCR Worker/loader/core/language/binary request (possible real text-layer fallback)"},"ocrCoreWrapper":{"classification":"NOT_USED","suffix":".wasm.js","condition":"same OCR trigger; one or more actually loaded approved hardware variants, no forced variant filename"},"wasmBinaryBytes":{"classification":"NOT_USED","condition":"same OCR trigger; actual .wasm HTTP attachment OR recognised embedded binary in an actually fetched wrapper, distinctly labelled; instantiation unobserved"},"otherObservedAssets":{"classification":"CONDITIONAL","condition":"every observed /src/ and index response is still byte-compared regardless of table classification"},"documentImageHttpUploads":{"classification":"NOT_USED","because":"existing APIs receive owned PDF/image byte arrays; no HTTP source upload/request is required"},"serviceWorkers":{"classification":"NOT_USED","because":"not used by the frozen actions; any observation remains unsupported and blocks capture completeness"}}},"fixture-pdf-ocr":{"job":"browser","actions":["separate existing fixture profile","real PDF initial/revisions and legacy upgrades","P3 generated image through actual Tesseract OCR","P8 hybrid PDF uses PDF_TEXT carrier + visual review, not OCR requirement","other original source/history controls"],"location":"browser.mjs runBrowser: fourth launch through fixture-source-and-consent-trace.zip","assets":{"compositionModules":{"classification":"MANDATORY","paths":["src/import/authority.js","src/controller.js","src/storage.js"],"because":"composeSourceRuntime unconditionally imports these before phase actions"},"appEntry":{"classification":"NOT_USED","paths":["src/main.js","index.html"],"because":"retained-ui alone navigates to the application root; other phases use test-entry plus explicit imports"},"pdfEngine":{"classification":"MANDATORY","paths":["src/import/vendor/pdf.mjs"],"because":"at least one genuine PDF decode in this context"},"pdfWorker":{"classification":"CONDITIONAL","paths":["src/import/vendor/pdf.worker.mjs"],"condition":"an actual PDF Worker event or script response activates binding; no request is invented for reader-only/fallback operation","absenceDisposition":"NO_OBSERVED_PDF_WORKER; worker-specific subtype not proved; never call it genuine Worker evidence"},"pdfFonts":{"classification":"CONDITIONAL","prefix":"src/import/vendor/standard_fonts/","condition":"only fonts actually requested by the source PDF; every observed response must match"},"ocrEntryWorkerLanguage":{"classification":"MANDATORY","paths":["src/import/vendor/tesseract.js","src/import/vendor/worker.min.js","src/import/vendor/eng.traineddata.gz"],"condition":"mandatory for original P3 OCR action; in PDF-only phases activated by observed OCR Worker/loader/core/language/binary request (possible real text-layer fallback)"},"ocrCoreWrapper":{"classification":"MANDATORY","suffix":".wasm.js","condition":"same OCR trigger; one or more actually loaded approved hardware variants, no forced variant filename"},"wasmBinaryBytes":{"classification":"MANDATORY","condition":"same OCR trigger; actual .wasm HTTP attachment OR recognised embedded binary in an actually fetched wrapper, distinctly labelled; instantiation unobserved"},"otherObservedAssets":{"classification":"CONDITIONAL","condition":"every observed /src/ and index response is still byte-compared regardless of table classification"},"documentImageHttpUploads":{"classification":"NOT_USED","because":"existing APIs receive owned PDF/image byte arrays; no HTTP source upload/request is required"},"serviceWorkers":{"classification":"NOT_USED","because":"not used by the frozen actions; any observation remains unsupported and blocks capture completeness"}}},"forgery-before":{"job":"e-finite","actions":["real timetable+calendar initial PDF acceptance","local event then raw forgery callback negatives","save raw bytes before native reopen"],"location":"e-finite.mjs first launch through forgery-before-reopen.zip","assets":{"compositionModules":{"classification":"MANDATORY","paths":["src/import/authority.js","src/controller.js","src/storage.js"],"because":"composeSourceRuntime unconditionally imports these before phase actions"},"appEntry":{"classification":"NOT_USED","paths":["src/main.js","index.html"],"because":"retained-ui alone navigates to the application root; other phases use test-entry plus explicit imports"},"pdfEngine":{"classification":"MANDATORY","paths":["src/import/vendor/pdf.mjs"],"because":"at least one genuine PDF decode in this context"},"pdfWorker":{"classification":"CONDITIONAL","paths":["src/import/vendor/pdf.worker.mjs"],"condition":"an actual PDF Worker event or script response activates binding; no request is invented for reader-only/fallback operation","absenceDisposition":"NO_OBSERVED_PDF_WORKER; worker-specific subtype not proved; never call it genuine Worker evidence"},"pdfFonts":{"classification":"CONDITIONAL","prefix":"src/import/vendor/standard_fonts/","condition":"only fonts actually requested by the source PDF; every observed response must match"},"ocrEntryWorkerLanguage":{"classification":"CONDITIONAL","paths":["src/import/vendor/tesseract.js","src/import/vendor/worker.min.js","src/import/vendor/eng.traineddata.gz"],"condition":"mandatory for original P3 OCR action; in PDF-only phases activated by observed OCR Worker/loader/core/language/binary request (possible real text-layer fallback)"},"ocrCoreWrapper":{"classification":"CONDITIONAL","suffix":".wasm.js","condition":"same OCR trigger; one or more actually loaded approved hardware variants, no forced variant filename"},"wasmBinaryBytes":{"classification":"CONDITIONAL","condition":"same OCR trigger; actual .wasm HTTP attachment OR recognised embedded binary in an actually fetched wrapper, distinctly labelled; instantiation unobserved"},"otherObservedAssets":{"classification":"CONDITIONAL","condition":"every observed /src/ and index response is still byte-compared regardless of table classification"},"documentImageHttpUploads":{"classification":"NOT_USED","because":"existing APIs receive owned PDF/image byte arrays; no HTTP source upload/request is required"},"serviceWorkers":{"classification":"NOT_USED","because":"not used by the frozen actions; any observation remains unsupported and blocks capture completeness"}}},"forgery-after":{"job":"e-finite","actions":["same-profile native reopen and saved-byte equality","real source revisions and stage/qualifier/group controls","RACE01 two real notice reviews, delayed prepare-result delivery, actual mutation, fresh acceptance"],"location":"e-finite.mjs second launch through finite-after-reopen.zip","assets":{"compositionModules":{"classification":"MANDATORY","paths":["src/import/authority.js","src/controller.js","src/storage.js"],"because":"composeSourceRuntime unconditionally imports these before phase actions"},"appEntry":{"classification":"NOT_USED","paths":["src/main.js","index.html"],"because":"retained-ui alone navigates to the application root; other phases use test-entry plus explicit imports"},"pdfEngine":{"classification":"MANDATORY","paths":["src/import/vendor/pdf.mjs"],"because":"at least one genuine PDF decode in this context"},"pdfWorker":{"classification":"CONDITIONAL","paths":["src/import/vendor/pdf.worker.mjs"],"condition":"an actual PDF Worker event or script response activates binding; no request is invented for reader-only/fallback operation","absenceDisposition":"NO_OBSERVED_PDF_WORKER; worker-specific subtype not proved; never call it genuine Worker evidence"},"pdfFonts":{"classification":"CONDITIONAL","prefix":"src/import/vendor/standard_fonts/","condition":"only fonts actually requested by the source PDF; every observed response must match"},"ocrEntryWorkerLanguage":{"classification":"CONDITIONAL","paths":["src/import/vendor/tesseract.js","src/import/vendor/worker.min.js","src/import/vendor/eng.traineddata.gz"],"condition":"mandatory for original P3 OCR action; in PDF-only phases activated by observed OCR Worker/loader/core/language/binary request (possible real text-layer fallback)"},"ocrCoreWrapper":{"classification":"CONDITIONAL","suffix":".wasm.js","condition":"same OCR trigger; one or more actually loaded approved hardware variants, no forced variant filename"},"wasmBinaryBytes":{"classification":"CONDITIONAL","condition":"same OCR trigger; actual .wasm HTTP attachment OR recognised embedded binary in an actually fetched wrapper, distinctly labelled; instantiation unobserved"},"otherObservedAssets":{"classification":"CONDITIONAL","condition":"every observed /src/ and index response is still byte-compared regardless of table classification"},"documentImageHttpUploads":{"classification":"NOT_USED","because":"existing APIs receive owned PDF/image byte arrays; no HTTP source upload/request is required"},"serviceWorkers":{"classification":"NOT_USED","because":"not used by the frozen actions; any observation remains unsupported and blocks capture completeness"}}}},"rules":["MANDATORY means actual bytes must be observed for the specified action family, else INCOMPLETE.","CONDITIONAL activates only on its specified actual observation; absent unused asset is not treated as compromise.","NOT_USED describes frozen actions, not evidence that arbitrary software could not fetch it; any observed asset remains strictly compared and unexpected usage reported.","Unknown/missing response bytes, observed Worker root without body, unsupported Service/Blob Worker or request/HAR mismatch remain incomplete.","No asset table outcome proves WASM instantiation, module evaluation/importer graph or original historical forgery replay."]}')
def verify_phase(job,phase,trace_name,binding,binding_sha):
    sfile=job/'loaded-assets'/phase/'session.json';s=readjson(sfile)
    require(s['state']=='CLOSED_HAR_TO_BE_VERIFIED' and 'closeError' not in s,'Context close/HAR export incomplete')
    require(s['bindingSha256']==binding_sha and s['runUuid']==binding['runUuid'],'Session build/run binding mismatch')
    require(s['runtimeCandidate']==binding['runtimeCandidate'] and s['baseCheckpoint']==binding['baseCheckpoint'],'Session candidate mismatch')
    require(s['phase']==phase and s['tracePath']==str((job/trace_name).resolve()),'Wrong trace/phase association')
    require(s['profile'] and s['observersInstalledAt'] and s['closedAt'] and isinstance(s.get('browserVersion'),str) and s['browserVersion'],'Lifecycle/browser metadata missing')
    require(not s['services'],'Service Worker path unsupported; no silent proxy/cache attribution')
    trace=file_bytes(job/trace_name);corroboration=trace_inventory(job/trace_name)
    har_path=job/'loaded-assets'/phase/'network.har.zip';require(s['harPath']==str(har_path.resolve()),'Wrong HAR path')
    request_counts=collections.Counter();unmatched=[]
    for event in s['events']:
        u=urllib.parse.urlsplit(event['url'])
        if u.scheme not in ['http','https']: continue
        rel=asset_path(event['url'],s['origin'])
        if rel:
            require(event.get('finished') and not event.get('failure') and event.get('status')==200,'Incomplete/failed/non200 asset request: '+event['url'])
            request_counts[(event['method'],event['url'])]+=1
    rows=[];payloads={};har_counts=collections.Counter()
    with zipfile.ZipFile(har_path) as z:
        require(z.testzip() is None,'HAR CRC failed');require(len(z.namelist())==len(set(z.namelist())),'Duplicate HAR ZIP entries')
        manifests=[n for n in z.namelist() if n.endswith('.har')];require(len(manifests)==1,'Require exactly one HAR document')
        har=json.loads(z.read(manifests[0]));require(har.get('log',{}).get('version')=='1.2','Unknown HAR schema')
        for i,e in enumerate(har['log']['entries']):
            req,res=e['request'],e['response'];u=urllib.parse.urlsplit(req['url'])
            if u.scheme not in ['http','https']: continue
            rel=asset_path(req['url'],s['origin'])
            if rel is None: continue # /test-entry intentional404/favicons remain in raw HAR; never called assets.
            require(req['method']=='GET' and res['status']==200,'Asset method/status/redirect/cache refusal')
            headers={h['name'].lower():h['value'] for h in res['headers']}
            require(headers.get('content-encoding','').lower() in ['','identity'],'Transport content encoding not directly build-comparable')
            require(headers.get('cache-control','').lower()=='no-store','Unexpected cache policy')
            body,where=attached_body(z,res['content']);h=sha(body);expected=binding['buildFiles'].get(rel)
            require(expected is not None and h==expected['sha256'] and len(body)==expected['bytes'],'Loaded body differs from frozen build: '+rel)
            payloads[rel]=body;har_counts[(req['method'],req['url'])]+=1
            known=[v for v in corroboration if v['url']==req['url'] and v['status']==200 and v['bodySha256']]
            require(all(v['bodySha256']==h for v in known),'Existing trace body differs from HAR/build')
            rows.append({'entryIndex':i,'url':req['url'],'resourceType':e.get('_resourceType'),'path':rel,'status':200,'contentType':headers.get('content-type'),'bytes':len(body),'sha256':h,'body':where,'traceBodyCorroborations':known,'traceBodyAbsent':not known})
    require(har_counts==request_counts,'Context request ledger/HAR asset multiset differs')
    require(rows,'No actual browser-loaded asset response bytes')
    seen={r['path'] for r in rows}
    policy=PHASE_POLICY['phases'][phase];applicability=[]
    for group in ['compositionModules','appEntry','pdfEngine']:
        rule=policy['assets'][group];observed=[p for p in rule['paths'] if p in seen]
        if rule['classification']=='MANDATORY':
            for rel in rule['paths']: require(rel in seen,'INCOMPLETE mandatory '+phase+' '+group+': '+rel)
        applicability.append({'group':group,'policy':rule['classification'],'observed':observed,'disposition':'OBSERVED_AND_MATCHED' if observed else 'NOT_USED_BY_ACTIONS' if rule['classification']=='NOT_USED' else 'INCOMPLETE'})
    worker_bindings=[]
    for w in s['workers']:
        require(urllib.parse.urlsplit(w['url']).scheme in ['http','https'],'Blob/data worker lacks direct HTTP byte binding')
        rel=asset_path(w['url'],s['origin']);require(rel in seen,'Observed worker root body missing from HAR')
        worker_bindings.append({'worker':w,'resourcePath':rel,'sha256':binding['buildFiles'][rel]['sha256']})
    pdf_worker='src/import/vendor/pdf.worker.mjs'
    pdf_worker_seen=pdf_worker in seen or any(w['resourcePath']==pdf_worker for w in worker_bindings)
    if pdf_worker_seen: require(pdf_worker in seen,'INCOMPLETE observed PDF Worker lacks actual response body')
    applicability.append({'group':'pdfWorker','policy':policy['assets']['pdfWorker']['classification'],'active':pdf_worker_seen,'disposition':'OBSERVED_AND_MATCHED' if pdf_worker_seen else 'NOT_USED_BY_ACTIONS' if phase=='retained-ui' else 'NO_OBSERVED_PDF_WORKER_SUBTYPE_UNPROVED'})
    fonts=[p for p in seen if p.startswith('src/import/vendor/standard_fonts/')];applicability.append({'group':'pdfFonts','policy':policy['assets']['pdfFonts']['classification'],'observed':fonts,'disposition':'OBSERVED_AND_MATCHED' if fonts else 'NOT_REQUESTED_NOT_REQUIRED'})
    wasm={'httpResponses':[r for r in rows if r['path'].endswith('.wasm')],'embeddedBytesInLoadedWrappers':[],'instantiation':'NOT_OBSERVED_NOT_CLAIMED'}
    ocr_rule=policy['assets']['ocrEntryWorkerLanguage']['classification']
    ocr_observed=any(p.endswith('.wasm') or p.endswith('.wasm.js') or p in policy['assets']['ocrEntryWorkerLanguage']['paths'] for p in seen) or any(w['resourcePath']=='src/import/vendor/worker.min.js' for w in worker_bindings)
    ocr_active=ocr_rule=='MANDATORY' or ocr_observed
    if ocr_active:
        for rel in policy['assets']['ocrEntryWorkerLanguage']['paths']: require(rel in seen,'INCOMPLETE active OCR family lacks response body: '+rel)
        require(any(w['resourcePath']=='src/import/vendor/worker.min.js' for w in worker_bindings),'INCOMPLETE active OCR family has no observed genuine OCR worker')
        require(any(p.endswith('.wasm.js') for p in seen),'No actually fetched WASM wrapper script')
        if not wasm['httpResponses']:
            # Some pinned loader distributions embed bytes; do not invent a separate HTTP WASM response.
            for rel,body in payloads.items():
                if not rel.endswith('.wasm.js'): continue
                for match in re.finditer(rb'data:application/(?:wasm|octet-stream);base64,([A-Za-z0-9+/=]+)',body):
                    binary=base64.b64decode(match.group(1),validate=True)
                    if not binary.startswith(b'\x00asm'): continue
                    h=sha(binary);targets=[p for p,v in binding['buildFiles'].items() if p.endswith('.wasm') and v['sha256']==h and v['bytes']==len(binary)]
                    require(targets,'Embedded binary differs from every approved built WASM file')
                    wasm['embeddedBytesInLoadedWrappers'].append({'wrapperPath':rel,'wrapperSha256':sha(body),'dataUriByteOffset':match.start(),'binarySha256':h,'binaryBytes':len(binary),'matchingBuiltWasmPaths':targets,'classification':'OFFLINE_INFERENCE_FROM_FETCHED_WRAPPER_NOT_DISTINCT_RESPONSE_OR_INSTANTIATION'})
            require(wasm['embeddedBytesInLoadedWrappers'],'WASM byte coverage unavailable: neither actual HTTP payload nor recognised embedded bytes in fetched wrapper')
    applicability.append({'group':'ocrEntryWorkerLanguage+ocrCoreWrapper+wasmBinaryBytes','policy':ocr_rule,'conditionObserved':ocr_observed,'active':ocr_active,'disposition':'OBSERVED_AND_MATCHED' if ocr_active else 'NOT_USED_BY_ACTIONS' if ocr_rule=='NOT_USED' else 'CONDITION_NOT_OBSERVED_NOT_REQUIRED'})
    return {'phase':phase,'assetApplicability':applicability,'session':str(sfile),'sessionSha256':sha(file_bytes(sfile)),'profile':s['profile'],'nodePid':s['nodePid'],'browserVersion':s['browserVersion'],'closedAt':s['closedAt'],'harSha256':sha(file_bytes(har_path)),'traceSha256':sha(trace),'tracePath':str(job/trace_name),'responses':rows,'workers':worker_bindings,'wasm':wasm,'status':'ASSET_BYTES_MATCH_BUILD_NOT_SA_ACCEPTANCE'}
def verify(a):
    binding_bytes=file_bytes(a.binding);b=json.loads(binding_bytes);require(sha(binding_bytes)==a.binding_sha256,'Wrong binding SHA256')
    require(b['verifierSha256']==sha(file_bytes(__file__)),'Verifier changed since freeze')
    require(b.get('phasePolicySha256')==sha(json.dumps(PHASE_POLICY,sort_keys=True,separators=(',',':')).encode()),'Phase policy differs from pre-browser freeze')
    root=pathlib.Path(b['checkoutRoot']);current_candidate(root,{'commitSha':b['runtimeCandidate']['commitSha'],'treeSha':b['runtimeCandidate']['treeSha'],'sourceFileSha256':b['sourceFileSha256']})
    require(inventory(root/'semester-space/dist')==b['buildFiles'],'Build changed after pre-browser freeze')
    jobs={'browser':pathlib.Path(a.browser_output).resolve(),'e-finite':pathlib.Path(a.finite_output).resolve()};result={'version':'E-LOADED-ASSETS/1','bindingSha256':a.binding_sha256,'runUuid':b['runUuid'],'baseCheckpoint':b['baseCheckpoint'],'runtimeCandidate':b['runtimeCandidate'],'status':'VERIFYING_NOT_ACCEPTED','jobs':{}}
    try:
        for name,job in jobs.items():
            require(job.is_relative_to(pathlib.Path(b['evidenceRoot'])),'Cross-run job output')
            report=file_bytes(job/'report.json');parsed=json.loads(report)
            if name=='browser':
                require(parsed.get('status')=='EXECUTED_BROWSER_POPULATION_PASS_OTHER_GATES_SEPARATELY_REPORTED','Browser job not successful')
                actual_cases={c['id']:c for c in parsed['cases']}
                ocr=actual_cases['P3_ACTUAL_INSTALLED_OCR'];hybrid=actual_cases['P8_HYBRID_VISUAL_MEANING']
                require(ocr.get('status')=='PASS' and all(p['page']['content']['method']=='OCR' for p in ocr['actual']['actualMaterial']['pages']) and bool(ocr['actual']['actualMaterial']['pages']),'Original genuine OCR action/witness missing')
                require(hybrid.get('status')=='PASS' and len(hybrid['actual']['material']['pages'])==2 and all(p['page']['content']['method']=='PDF_TEXT' for p in hybrid['actual']['material']['pages']),'Original hybrid PDF_TEXT/visual action witness missing')
            else: require(parsed.get('runtime') in ['PARTIAL_ORIGINAL_FORGERY_ARTIFACT_BLOCKED','FOCUSED_CONTROLS_PASS_OTHER_GATES_OPEN'],'Finite focused controls failed')
            expected=PHASES[name];actual={p.parent.name for p in (job/'loaded-assets').glob('*/session.json')}
            require(actual==set(expected),'Missing or extra context phases')
            phases={phase:verify_phase(job,phase,trace,b,a.binding_sha256) for phase,trace in expected.items()}
            before,after=('native-before','native-after') if name=='browser' else ('forgery-before','forgery-after')
            require(phases[before]['profile']==phases[after]['profile'],'Native reopen used a different profile')
            meta_before=readjson(job/'loaded-assets'/before/'session.json');meta_after=readjson(job/'loaded-assets'/after/'session.json')
            require(meta_before['closedAt']<=meta_after['startedAt'],'Reopen preceded completion of old context.close')
            f1,f2=('before-native-close.json','after-native-reopen.json') if name=='browser' else ('before-forgery-reopen.json','after-forgery-reopen.json')
            raw=file_bytes(job/f1);require(raw==file_bytes(job/f2),'Native saved bytes changed/reseeded outcome mismatch')
            result['jobs'][name]={'reportSha256':sha(report),'phases':phases,'savedBytesSha256':sha(raw),'nativeReopen':{'sameProfile':True,'priorCloseCompleted':True,'equalSavedBytes':True,'browserProcessIdentity':'PERSISTENT_CONTEXT_CLOSE_AND_RELAUNCH_SEMANTICS; exact OS PID qualification stays F/D-owned'},'originalForgeries':parsed.get('originalForgeries',{'status':'NOT_THIS_JOB'})}
        result['status']='LOADED_BYTE_BINDING_COMPLETE_FOR_TWO_SCOPED_JOBS_ONLY'
        write_new(a.out,result)
    except Exception as e:
        result['status']='INCOMPLETE_OR_MISMATCH';result['error']=str(e);write_new(a.out,result);raise
    print(json.dumps({'result':str(pathlib.Path(a.out).resolve()),'sha256':sha(file_bytes(a.out)),'status':result['status']}))
def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
    f=sub.add_parser('freeze');f.add_argument('--checkout',required=True);f.add_argument('--checkpoint',required=True);f.add_argument('--candidate',required=True);f.add_argument('--evidence-root',required=True);f.add_argument('--run-uuid',required=True);f.add_argument('--out',required=True)
    v=sub.add_parser('verify');v.add_argument('--binding',required=True);v.add_argument('--binding-sha256',required=True);v.add_argument('--browser-output',required=True);v.add_argument('--finite-output',required=True);v.add_argument('--out',required=True)
    a=p.parse_args();freeze(a) if a.command=='freeze' else verify(a)
if __name__=='__main__': main()
