#!/usr/bin/env python3
"""Self-contained replay of the exact supplied E-C3 research checker on amended F fixtures.
No installed reader, private stage, profile3 writer, browser or production source invocation.
"""
import json,subprocess,sys,tempfile,zipfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'reference/E_C3_REVIEW_ORIGINAL.zip'
with tempfile.TemporaryDirectory(prefix='sa-c3-verified-') as temp:
 t=Path(temp)
 with zipfile.ZipFile(SOURCE) as z:z.extractall(t)
 inputs=t/'E_C3_REVIEW/inputs'
 for name in ('MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json','SECOND_SOURCE_SUPPORT.json'):
  shutil.copyfile(ROOT/'fixtures'/name, inputs/'F/fixtures'/name)
 out=t/'replayed_evidence';out.mkdir()
 result=subprocess.run(['node',str(t/'E_C3_REVIEW/research/check_c3.mjs'),str(inputs),str(out)],capture_output=True,text=True)
 if result.returncode:raise RuntimeError(f'E check failed: {result.returncode}: {result.stdout}\n{result.stderr}')
 message=json.loads(result.stdout.strip().splitlines()[-1]);checks=json.loads((out/'C3_CHECK_RESULTS.json').read_text())
 assert message['checks']==114 and message['preimages']==57 and message['findings']==[]
 assert checks['passedChecks']==114 and checks['preimageCount']==57 and checks['findings']==[]
 py=subprocess.run(['python3',str(t/'E_C3_REVIEW/research/verify_preimages.py'),str(out)],capture_output=True,text=True)
 if py.returncode:raise RuntimeError(f'E Python hash verification failed: {py.returncode}: {py.stdout}\n{py.stderr}')
 pre=json.loads(py.stdout.strip().splitlines()[-1]);assert pre['passed']==57 and pre['failed']==0
 summary={'status':'BOUNDED_AUTHORED_C3_CHECKER_REPLAY_PASS','nodeExit':result.returncode,'pythonExit':py.returncode,'relationshipChecks':114,'framedPreimages':57,'independentPythonPreimagesPassed':57,'C3Findings':[],'formalESignoff':'NOT_CLAIMED','realReaderOCR':'UNRUN','trustedStage':'UNRUN','profile3Storage':'UNRUN'}
 print(json.dumps(summary,indent=2))
