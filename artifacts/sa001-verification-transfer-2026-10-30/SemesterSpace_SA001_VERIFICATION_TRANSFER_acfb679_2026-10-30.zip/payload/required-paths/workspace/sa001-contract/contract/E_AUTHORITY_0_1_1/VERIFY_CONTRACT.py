"""Independent controlled-fixture verifier. Not a general JSON Schema engine or SA implementation.
Supports only the explicit shape keywords used in the supplied closed schema; relational checks are fixture checks.
"""
from pathlib import Path
import json,hashlib,re,datetime,struct,math,copy,base64
root=Path(__file__).resolve().parent
schema=json.loads((root/'AUTHORITY_EVIDENCE_0_1_1.schema.json').read_text());defs=schema['$defs']
def require(ok,msg):
 if not ok:raise AssertionError(msg)
def valid(x,s):
 if '$ref' in s:return valid(x,defs[s['$ref'].split('/')[-1]])
 if 'const'in s:return type(x)==type(s['const']) and x==s['const']
 if 'enum'in s:return x in s['enum']
 if 'oneOf'in s:return sum(valid(x,z) for z in s['oneOf'])==1
 if 'anyOf'in s:return any(valid(x,z) for z in s['anyOf'])
 t=s.get('type')
 if t=='null':return x is None
 if t=='boolean':return type(x)is bool
 if t=='integer':return type(x)is int and s.get('minimum',-math.inf)<=x<=s.get('maximum',math.inf)
 if t=='number':return type(x)in(int,float) and math.isfinite(x)
 if t=='string':
  if not isinstance(x,str) or not s.get('minLength',0)<=len(x)<=s.get('maxLength',math.inf):return False
  if 'pattern'in s and not re.search(s['pattern'],x):return False
  if s.get('format')=='date':
   try:datetime.date.fromisoformat(x)
   except ValueError:return False
  return True
 if t=='array':
  if not isinstance(x,list) or not s.get('minItems',0)<=len(x)<=s.get('maxItems',math.inf):return False
  if s.get('uniqueItems') and len({json.dumps(v,sort_keys=True,ensure_ascii=False)for v in x})!=len(x):return False
  return all(valid(v,s.get('items',{}))for v in x)
 if t=='object':
  return isinstance(x,dict) and set(s.get('required',[]))<=set(x) and (s.get('additionalProperties')is not False or set(x)<=set(s['properties'])) and all(valid(v,s['properties'][k])for k,v in x.items()if k in s.get('properties',{}))
 return True
def h_record(domain,record):
 # Fixtures deliberately avoid floating JSON numbers and non-BMP key names; Python is a hash verifier, not JS algorithm portability proof.
 wrapper={'canonicalProtocolVersion':'SA-C14N/0.1.1','projectionProtocolVersion':'E-PROJ/0.1.1','value':record}
 c=json.dumps(wrapper,sort_keys=True,separators=(',',':'),ensure_ascii=False)
 return hashlib.sha256(('SA-AUTH/0.1.1:'+domain).encode()+b'\0'+c.encode()).hexdigest()
contexts=[json.loads((root/'examples'/name).read_text())for name in ['INITIAL_COMPLETE_E_CONTEXT.json','REVISION_COMPLETE_E_CONTEXT.json']]
def relations(c):
 require(valid(c,defs['EvidenceContext']),'closed context shape')
 ins={x['intakeId']:x for x in c['sources']};pages={(p['runId'],p['intakeId'],p['pageNumber']):p for p in c['pageContents']}
 anchors={a['anchorId']:a for a in c['review']['anchors']};facts={f['factId']:f for f in c['review']['facts']};rawids={x['candidateId']for x in c['candidateRefs']}
 require(c['prepared']['reviewSha256']==h_record('review',c['review']),'review binding')
 require(c['groups']['reviewSha256']==c['prepared']['reviewSha256'],'group review binding')
 require(c['prepared']['groupsSha256']==h_record('groups',c['groups']),'groups binding')
 require(c['acceptedPayload']['preparedSha256']==h_record('prepared',c['prepared']),'prepared binding')
 require(c['prepared']['manifestSha256']==h_record('manifest',c['manifest']),'manifest binding')
 for run in c['runRecords']:
  require(run['decodeState']=='COMPLETE','failed decode cannot stage')
  require(run['observation']['actuallyUsedAssetSubset']is None and run['observation']['usageKnowledge']=='NOT_OBSERVED','no invented asset observation')
  for k in run['inputKnowledge']:
   require(k['intakeId']in ins,'foreign intake')
   require(k['knowledge']=='RETURNED_COMPLETE'and k['declaredPageCount']is not None,'unknown completed count')
   require(k['returnedPageNumbers']==list(range(1,k['declaredPageCount']+1)),'incomplete contiguous inventory')
   require(all((run['runId'],k['intakeId'],p)in pages for p in k['returnedPageNumbers']),'missing page')
  require(h_record('run',run)in c['prepared']['runSha256s'],'run hash')
 for a in anchors.values():
  require((a['runId'],a['intakeId'],a['pageNumber'])in pages,'cross-source page')
  require(set(a['qualifierAnchorIds'])<=set(anchors),'missing qualifier')
  if a['bboxF64']is not None:
   ns=[struct.unpack('>d',bytes.fromhex(v))[0]for v in a['bboxF64']]
   require(all(math.isfinite(n)for n in ns)and 0<=ns[0]<ns[2]<=1 and 0<=ns[1]<ns[3]<=1,'invalid geometry')
 for f in facts.values():require(set(f['anchorIds'])<=set(anchors)and set(f['sourceCandidateIds'])<=rawids,'fact dangling refs')
 for d in c['prepared']['effects']:
  require(set(d['factIds'])<=set(facts)and set(d['anchorIds'])<=set(anchors),'effect closure')
  require(d['changeSha256']==h_record('change',d['change']),'change hash')
  for side in ['before','after']:
   val=d['change'][side];commit=d[side]
   require(commit==({'presence':'ABSENT','valueSha256':None}if val is None else {'presence':'PRESENT','valueSha256':h_record('present-value',val)}),'presence/value hash')
 groups={g['groupId']:g for g in c['groups']['groups']};ids=[v for g in groups.values()for v in g['memberIds']]
 require(len(set(ids))==len(ids)and set(ids)==set(c['groups']['effectIds']),'complete partition')
 selected=set(c['prepared']['approvedEffectIds'])
 for g in groups.values():require(not(selected&set(g['memberIds']))or set(g['memberIds'])<=selected,'half dependency group')
 for d in c['prepared']['effects']:require(d['adoption']==('APPLIED'if d['change']['changeId']in selected else 'NOT_APPLIED'),'adoption mismatch')
 require(c['acceptedPayload']['approvedEffectIds']==c['prepared']['approvedEffectIds'],'accepted subset')
 require(c['acceptedPayload']['acceptedAt']['time']>=c['review']['reviewConfirmedAt']['time'],'acceptance precedes review')
 if c['prepared']['operation']=='INITIAL_IMPORT':
  require([i['role']for i in c['sources']]==['TIMETABLE','ACADEMIC_CALENDAR'],'paired role order')
  require(c['prepared']['initialIntent']['clockSlot']=='/snapshots/0/confirmedAt','clock slot')
 else:require(c['prepared']['initialIntent']is None,'revision clock exception')
 return True
for c in contexts:relations(c)
supports=[json.loads((root/'examples'/name).read_text())for name in ['INITIAL_SUPPORT.json','REVISION_SUPPORT.json']]
for c,s in zip(contexts,supports):
 require(h_record('bundle',s['bundle'])==c['review']['bundleSha256'],'bundle binding')
 require(h_record('raw-inventory',s['rawInventory'])==c['review']['rawInventorySha256'],'raw inventory binding')
 require(s['rawInventory']['sourceAliases']==c['sourceAliases'],'unaltered source aliases')
 require(s['rawInventory']['candidates']==c['candidateRefs'] and s['rawInventory']['issues']==c['rawIssues'],'unaltered candidate/issue inventory')
 rawpages={(p['content']['runId'],p['content']['intakeId'],p['content']['pageNumber']):p for p in s['rawPages']}
 for p in s['rawPages']:
  require(p['content'] in c['pageContents'],'raw page identity')
  require(h_record('raw-text',{'text':p['rawText']})==p['content']['rawTextSha256'],'raw text binding')
  require(h_record('raw-items',{'items':p['rawItems']})==p['content']['rawItemsSha256'],'raw items binding')
 for run in c['runRecords']:
  require(run['bundleSha256']==c['review']['bundleSha256'] and run['rawInventorySha256']==c['review']['rawInventorySha256'],'run inventory binding')
  for ref in run['returnedPages']:
   p=rawpages[(run['runId'],ref['intakeId'],ref['pageNumber'])]
   require(h_record('page',p['content'])==ref['pageContentSha256'],'returned page digest')
 anchors={a['anchorId']:a for a in c['review']['anchors']}
 def visit(aid,stack):
  require(aid not in stack,'qualifier cycle')
  for q in anchors[aid]['qualifierAnchorIds']:visit(q,stack|{aid})
 for a in anchors.values():
  visit(a['anchorId'],set());p=rawpages[(a['runId'],a['intakeId'],a['pageNumber'])]
  if a['mode']=='TEXT':
   loc=a['location'];text=p['rawText'] if loc['channel']=='PAGE_TEXT' else ' '.join(i['text']for i in p['rawItems'])
   encoded=text.encode('utf-16-le');start,end=loc['startUTF16'],loc['endUTF16']
   require(0<=start<end<=len(encoded)//2,'quote offsets')
   require(encoded[start*2:end*2].decode('utf-16-le')==a['rawQuote'],'source-specific raw quote')
  else:require(a['rawQuote'] is None and a['location'] is None and a['visualSha256']==p['content']['previewSha256'],'visual page binding')
 for g in c['groups']['groups']:
  edges=[e for e in c['groups']['edges'] if e['a'] in g['memberIds'] and e['b'] in g['memberIds']]
  v={'baseModelSha256':c['groups']['baseModelSha256'],'reviewSha256':c['groups']['reviewSha256'],'memberIds':g['memberIds'],'edges':edges}
  require(g['groupId']=='g:'+h_record('group-id',v),'generated group identity')
fixtures=json.loads((root/'examples/BYTE_FIXTURE_DESCRIPTORS.json').read_text())
for f in fixtures['inputs']:
 b=base64.b64decode(f['base64']);require(len(b)==f['byteLength'] and hashlib.sha256(b).hexdigest()==f['sha256'],'authored source byte fixture')
vec=json.loads((root/'VECTORS_0_1_1.json').read_text())['vectors']
for v in vec:
 p=bytes.fromhex(v['preimageUtf8Hex']);require(hashlib.sha256(p).hexdigest()==v['sha256'],'published sha')
 if v.get('framing')=='PLAIN_BYTES':require(p==base64.b64decode(v['rawBase64']),'plain-byte preimage')
 elif v.get('framing')=='RAW_DOMAIN_BYTES':require(p==('SA-AUTH/0.1.1:'+v['domain']).encode()+b'\0'+v['rawUtf8'].encode(),'byte-domain preimage')
 else:
  require(p==('SA-AUTH/0.1.1:'+v['domain']).encode()+b'\0'+v['canonical'].encode(),'canonical preimage')
  require(json.loads(v['canonical'])['value']==v['projection'],'canonical projection value')
# Shape expectations for all supported command variants have a syntactic closed inventory, not runtime dispatch claims.
require(all(d.get('additionalProperties')is False and set(d['required'])==set(d['properties'])for d in defs.values()if d.get('type')=='object'),'open record')
initial=json.loads((root/'examples/INITIAL_SUPPORT.json').read_text());expected=copy.deepcopy(initial['computedModel']);expected['snapshots'][0]['confirmedAt']=None
require(expected==initial['modelIntent'],'initial semantic slot')
actual=copy.deepcopy(initial['acceptedModel']);actual['snapshots'][0]['confirmedAt']=None
require(actual==initial['modelIntent'],'actual initial model drift outside slot')
require(h_record('model',initial['acceptedModel'])==contexts[0]['acceptedPayload']['acceptedModelSha256'],'actual accepted model digest')
rev=json.loads((root/'examples/REVISION_SUPPORT.json').read_text());require(h_record('model',rev['acceptedModel'])==contexts[1]['acceptedPayload']['acceptedModelSha256'],'revision model digest')
# Apply explicit negative fixture edits without claiming a production command/admission implementation.
neg=json.loads((root/'REJECTION_CASES_0_1_1.json').read_text());rejected=0;specified=0
for n in neg:
 x=copy.deepcopy(n['subject'])
 if n['path']:
  parts=n['path'].strip('/').split('/');p=x
  for k in parts[:-1]:p=p[int(k)]if isinstance(p,list)else p[k]
  k=parts[-1]
  if n['action']=='DELETE':
   if isinstance(p,list):del p[int(k)]
   else:del p[k]
  elif isinstance(p,list):
   if n['action']=='ADD':p.append(n['value'])
   else:p[int(k)]=n['value']
  else:p[k]=n['value']
 if n['expected']=='SHAPE_REJECT':require(not valid(x,defs['Review']if 'reviewId'in x else defs['Run']if 'runId'in x else defs['EvidenceContext']if 'projectionProtocolVersion'in x else defs['Prepared']),'negative shape should reject');rejected+=1
 elif n['expected']=='RELATION_REJECT':
  if 'projectionProtocolVersion'in x:
   try:relations(x)
   except AssertionError:rejected+=1
   else:raise AssertionError('negative relation accepted')
  else:require(len(x['members'])!=2,'missing slot');rejected+=1
 elif n['expected']=='NO_STAGE':require(x['decodeState']!='COMPLETE','failed state');rejected+=1
 elif n['expected']=='DEPENDENCY_REJECT':require(not set(x['requiredGroup'])<=set(x['selected']),'coupled subset');rejected+=1
 else:specified+=1
result={'status':'CONTRACT_FIXTURE_CHECKS_PASS','schemaClosedDefinitions':sum(1 for d in defs.values()if d.get('type')=='object'),'completeEContextsChecked':len(contexts),'publishedSha256PreimagesVerified':len(vec),'negativeFixtureExpectationsChecked':rejected,'nonExecutableGuaranteeStatements':specified,'actualReaderCoordinatorStorageExecution':'UNRUN','fullJSONSchemaEngine':'NOT_USED_LIMITED_DECLARED_FIXTURE_KEYWORD_CHECKER','productionChanges':False}
(root/'VERIFICATION_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
