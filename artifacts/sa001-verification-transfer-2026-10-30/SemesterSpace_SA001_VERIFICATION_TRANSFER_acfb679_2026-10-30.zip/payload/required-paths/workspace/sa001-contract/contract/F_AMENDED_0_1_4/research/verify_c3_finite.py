#!/usr/bin/env python3
"""Bounded E-C3-01/02 research fixture verifier. No SA profile3/runtime execution."""
from pathlib import Path
import json,hashlib,sys,copy
from jsonschema import Draft202012Validator
root=Path(__file__).resolve().parents[1]; fix=root/'fixtures'
checks=[]
def ok(name,x):
 if not x: raise AssertionError(name)
 checks.append(name); print('PASS',name)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def C(x):
 if isinstance(x,dict):return '{'+','.join(C(k)+':'+C(x[k]) for k in sorted(x,key=lambda k:k.encode('utf-16-be')))+'}'
 if isinstance(x,list):return '['+','.join(C(v) for v in x)+']'
 return json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def H(domain,x):return hashlib.sha256(('SA-AUTH/0.1.1:'+domain).encode()+b'\0'+C({'canonicalProtocolVersion':'SA-C14N/0.1.1','projectionProtocolVersion':'E-PROJ/0.1.1','value':x}).encode()).hexdigest()
def B(domain,x):return hashlib.sha256(('SA-AUTH/0.1.1:'+domain).encode()+b'\0'+json.dumps(x,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
m=read(fix/'MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json')
s=read(fix/'SECOND_SOURCE_SUPPORT.json')
l=read(fix/'LEDGER_CORRECTION_ACTUAL_OUTPUT.json')
proof=read(root/'evidence/C3_CORRECTED_COMMITMENTS.json')
oldRoot=Path(sys.argv[1]) if len(sys.argv)>1 else None
r1,r2=m['release']['provenance']['receipts'];c=r2['evidenceContext'];p=c['prepared'];g=c['groups'];a=c['acceptedPayload'];review=c['review']
E=read(root/'reference/E_AUTHORITY_EVIDENCE_0_1_1_UNCHANGED.schema.json')
F=read(root/'reference/SA001_PROFILE3_EMBEDDED_0.1.1_PROPOSED.schema.json')
ok('E81_F116_PRESERVED',len(E['$defs'])==81 and len(F['$defs'])==116 and all(F['$defs'][k]==v for k,v in E['$defs'].items()))
ok('MAIN_SCHEMA',Draft202012Validator(F).is_valid(m))
ok('SORTED_FACT_IDS',review['coverage'][2]['factIds']==['f10','f6'])
ok('SORTED_GROUP_EFFECT_IDS',g['effectIds']==['h10','h6'])
def scan(v,path=''):
 if isinstance(v,dict):
  for k,x in v.items():
   pth=path+'/'+k
   if (k.endswith('Ids') or k=='runSha256s') and isinstance(x,list) and all(isinstance(y,str) for y in x):
    ok('SORTED_UNIQUE '+pth,x==sorted(set(x),key=lambda z:z.encode('utf-16-be')))
   scan(x,pth)
 elif isinstance(v,list):
  for i,x in enumerate(v):scan(x,path+'/'+str(i))
scan(c)
oldlink=s['baseEnvelopeAtRevision8']['release']['calendar']['sourceRevision']['links'][0]
ok('H4_EXACT_PRIOR_LINK',oldlink['sourceRef']=='h4' and oldlink['targetId']=='2026-11-04' and oldlink['value']=={'date':'2026-11-04','label':'Holiday'})
ok('OMISSION_SINGLE_KEEP',len(review['omissions'])==1 and review['omissions'][0]['decision']=='KEEP_EXISTING' and review['omissions'][0]['priorLinkRef']=='h4')
omission=review['omissions'][0]
ok('OMISSION_SOURCE_SPECIFIC',omission['intakeId']=='ir2' and omission['sourceCandidateId'] is None and omission['anchorIds']==[] and omission['factIds']==[] and omission['missingMaterial'] and omission['reason'])
ok('SECOND_NEW_NOTICE_UNCHANGED',s['rawPDF']['sha256']==c['sources'][0]['sha256'] and sorted([x['factId'] for x in review['facts']])==['f10','f6'])
ok('H4_PHYSICAL_PRESERVATION',m['release']['calendar']['sourceRevision']['links'][0]==oldlink and m['model']['schedule']['holidays'][0]=={'date':'2026-11-04','label':'Holiday'})
ok('H5_IMMUTABLE_NOT_APPLIED',any(x['change']['changeId']=='h5' and x['adoption']=='NOT_APPLIED' for x in r1['evidenceContext']['prepared']['effects']))
ok('FIRST_RECEIPT_SAME_AS_BASE',r1==s['baseEnvelopeAtRevision8']['release']['provenance']['receipts'][0])
ok('ATTENDANCE_AND_SNAPSHOT_UNCHANGED',m['release']['attendance']==s['baseEnvelopeAtRevision8']['release']['attendance'] and m['model']['snapshots']==s['baseEnvelopeAtRevision8']['model']['snapshots'])
ok('REVIEW_HASH_CHAIN',H('review',review)==p['reviewSha256']==g['reviewSha256']==s['digestTable']['review2'])
for group in g['groups']:
 edges=[edge for edge in g['edges'] if edge['a'] in group['memberIds'] and edge['b'] in group['memberIds']]
 ok('GROUP_ID_'+group['memberIds'][0],group['groupId']=='g:'+H('group-id',{'baseModelSha256':g['baseModelSha256'],'reviewSha256':g['reviewSha256'],'memberIds':group['memberIds'],'edges':edges}))
for binding in p['effects']:
 ok('EFFECT_GROUP_'+binding['change']['changeId'],any(gr['groupId']==binding['groupId'] and binding['change']['changeId'] in gr['memberIds'] for gr in g['groups']))
ok('GROUP_ORDER',g['groups']==sorted(g['groups'],key=lambda q:q['groupId']))
ok('GROUPS_HASH_CHAIN',H('groups',g)==p['groupsSha256']==s['digestTable']['groups2'])
ok('APPROVED_GROUP_IDS',p['approvedGroupIds']==a['approvedGroupIds']==sorted(x['groupId'] for x in g['groups'] if 'h6' in x['memberIds']))
ok('APPROVED_EFFECT_UNCHANGED',p['approvedEffectIds']==a['approvedEffectIds']==['h6'] and [x['change']['changeId'] for x in p['effects']]==['h6','h10'])
ok('PREPARED_HASH_CHAIN',H('prepared',p)==a['preparedSha256']==s['digestTable']['prepared2'])
ok('REVISION_INTENT_HASH',H('revision-intent',{'proposalSha256':p['proposalSha256'],'groupsSha256':p['groupsSha256'],'approvedEffectIds':p['approvedEffectIds'],'approvedGroupIds':p['approvedGroupIds']})==a['semanticIntentSha256'])
ok('CONTEXT_HASH',H('evidence-context',c)==r2['evidenceContextSha256']==s['digestTable']['context2']==proof['correctedContextSha256'])
ok('RAW_BUILDER_PATCH_UNTOUCHED',B('source-patch-bytes',s['rawBuilderSourceRevisionPatch'])==a['sourceRevisionPatchSha256']==s['rawSourceRevisionPatchSha256']==proof['rawBuilderPatchSha256'])
ok('RETAINED_CROSSWALK_UNTOUCHED',m['release']['calendar']['sourceRevision']==s['assembledRetainedSourceRevision'])
ok('MODEL_AND_PRIOR_RELEASE_HASH_UNTOUCHED',H('model',m['model'])==a['acceptedModelSha256']==s['digestTable']['acceptedModel2'] and B('retained-release-bytes',s['baseEnvelopeAtRevision8']['release'])==a['priorReleaseSha256'])
ok('COPIED_LEDGER_CORRECTION_RECEIPTS',l['release']['provenance']['receipts']==m['release']['provenance']['receipts'] and l['code']=='DAY_CORRECTED' and l['model']['revision']==10)
# Mutation tests: stale hashes reject before later schema/authority checks. One canonical field change cannot be silently normalized.
bad=copy.deepcopy(c);bad['review']['coverage'][2]['factIds']=['f6','f10']
ok('UNSORTED_METADATA_STALE_HASH',H('review',bad['review'])!=p['reviewSha256'])
bad=copy.deepcopy(c);bad['groups']['effectIds']=['h6','h10']
ok('UNSORTED_GROUPS_STALE_HASH',H('groups',bad['groups'])!=p['groupsSha256'])
bad=copy.deepcopy(c);bad['review']['omissions']=[]
ok('OMISSION_REMOVAL_STALE_HASH',H('review',bad['review'])!=p['reviewSha256'])
if oldRoot is not None:
 oldfix=oldRoot/'fixtures'
 oldm=read(oldfix/'MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json');olds=read(oldfix/'SECOND_SOURCE_SUPPORT.json');oldl=read(oldfix/'LEDGER_CORRECTION_ACTUAL_OUTPUT.json')
 ok('MODEL_BYTE_OBJECT_UNCHANGED',m['model']==oldm['model'])
 ok('RETAINED_CALENDAR_UNCHANGED',m['release']['calendar']==oldm['release']['calendar'])
 ok('FIRST_RECEIPT_UNCHANGED',r1==oldm['release']['provenance']['receipts'][0])
 ok('LEDGER_HISTORY_UNCHANGED',m['release']['attendance']==oldm['release']['attendance'] and l['release']['attendance']==oldl['release']['attendance'])
 ok('RAW_SOURCE_PATCH_UNCHANGED',s['rawBuilderSourceRevisionPatch']==olds['rawBuilderSourceRevisionPatch'] and s['proposal']==olds['proposal'])
 ok('UNCHANGED_REVISION_EVIDENCE',r2['evidenceContext']['sources']==oldm['release']['provenance']['receipts'][1]['evidenceContext']['sources'] and r2['evidenceContext']['runRecords']==oldm['release']['provenance']['receipts'][1]['evidenceContext']['runRecords'])
print('C3_BOUNDED_ASSERTIONS_PASSED',len(checks))
print('LIMIT: AUTHOR-RECONSTRUCTED FIXTURES; NO INSTALLED READER, TRUSTED STAGE, PROFILE3, BROWSER, MIGRATION OR PERSISTENCE RUN')
