// Finite authored fixture transformation for E-C3-01/02. NOT a production writer or a stage.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual as equal} from 'node:util';
const from=process.argv[2],to=process.argv[3];
if(!from||!to) throw Error('Usage: node apply_c3_finite.mjs <unchanged-0.1.3-dir> <0.1.4-dir>');
const get=(n,base=from)=>JSON.parse(fs.readFileSync(path.join(base,'fixtures',n),'utf8'));
const put=(n,v)=>fs.writeFileSync(path.join(to,'fixtures',n),JSON.stringify(v,null,2)+'\n');
const C=v=>Array.isArray(v)?'['+v.map(C).join(',')+']':v!==null&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+C(v[k])).join(',')+'}':JSON.stringify(v);
const H=(domain,v)=>createHash('sha256').update('SA-AUTH/0.1.1:'+domain+'\0'+C({canonicalProtocolVersion:'SA-C14N/0.1.1',projectionProtocolVersion:'E-PROJ/0.1.1',value:v})).digest('hex');
const B=(domain,v)=>createHash('sha256').update('SA-AUTH/0.1.1:'+domain+'\0'+JSON.stringify(v)).digest('hex');
const check=(msg,test)=>{if(!test)throw Error('PRECONDITION: '+msg);};
const m=get('MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json');
const s=get('SECOND_SOURCE_SUPPORT.json');
const correction=get('LEDGER_CORRECTION_ACTUAL_OUTPUT.json');
const old={m:structuredClone(m),s:structuredClone(s),correction:structuredClone(correction)};
const [r1,r2]=m.release.provenance.receipts,c=r2.evidenceContext;
check('old context digest',r2.evidenceContextSha256==='1e9bca91b2f22d53e1b6b8f0373b055b2940d64c04560c872cafd1a471880114' && H('evidence-context',c)===r2.evidenceContextSha256);
check('raw captured builder digest',B('source-patch-bytes',s.rawBuilderSourceRevisionPatch)==='17ecc6e699bcb7b6bee7674fe80b2f2f4bdca29581a811204066d0be7adb04bb');
check('historical h4 link',s.baseEnvelopeAtRevision8.release.calendar.sourceRevision.links.some(x=>x.sourceRef==='h4'&&x.targetId==='2026-11-04'));
check('h4 absent from second new notice',!c.review.facts.some(x=>x.factId==='h4')&&c.review.omissions.length===0);
check('two exact ordering defects',equal(c.review.coverage[2].factIds,['f6','f10'])&&equal(c.groups.effectIds,['h6','h10']));
// E-C3-01: sort only typed metadata ID sets; preserve computational changes and native B2 arrays.
c.review.coverage[2].factIds=['f10','f6'];
c.groups.effectIds=['h10','h6'];
// E-C3-02: source-specific prior-link disposition. Not a fabricated quote from REV2.
c.review.omissions.push({
 omissionId:'omission-prior-h4-retained-rev2',
 intakeId:'ir2',
 sourceCandidateId:null,
 priorLinkRef:'h4',
 missingMaterial:'Previously accepted source link h4: Holiday 04.11.2026, retained from REV-example.pdf; this independent second notice does not restate that earlier holiday.',
 anchorIds:[],
 decision:'KEEP_EXISTING',
 factIds:[],
 reason:'The second notice states holidays on 06.11.2026 and 10.11.2026 only. Its omission of the earlier h4 holiday is not evidence of cancellation or replacement. Keep the existing 04.11.2026 holiday and its prior source provenance unchanged.'
});
// Hashes propagate through entire second-review dependency graph; NO editing of the raw builder patch.
const rev=H('review',c.review);
c.groups.reviewSha256=rev;
c.prepared.reviewSha256=rev;
for (const group of c.groups.groups){
 group.memberIds.sort();
 const edges=c.groups.edges.filter(x=>group.memberIds.includes(x.a)&&group.memberIds.includes(x.b));
 group.groupId='g:'+H('group-id',{baseModelSha256:c.groups.baseModelSha256,reviewSha256:rev,memberIds:group.memberIds,edges});
}
c.groups.groups.sort((a,b)=>a.groupId<b.groupId?-1:a.groupId>b.groupId?1:0);
for (const binding of c.prepared.effects){
 const g=c.groups.groups.find(g=>g.memberIds.includes(binding.change.changeId));
 check('group exists for '+binding.change.changeId,!!g);
 binding.groupId=g.groupId;
}
const approved=c.groups.groups.filter(g=>g.memberIds.some(x=>c.prepared.approvedEffectIds.includes(x))).map(g=>g.groupId).sort();
c.prepared.approvedGroupIds=approved;
c.acceptedPayload.approvedGroupIds=[...approved];
const groupsSha=H('groups',c.groups);
c.prepared.groupsSha256=groupsSha;
c.acceptedPayload.preparedSha256=H('prepared',c.prepared);
c.acceptedPayload.semanticIntentSha256=H('revision-intent',{proposalSha256:c.prepared.proposalSha256,groupsSha256:c.prepared.groupsSha256,approvedEffectIds:c.prepared.approvedEffectIds,approvedGroupIds:c.prepared.approvedGroupIds});
r2.evidenceContextSha256=H('evidence-context',c);
s.digestTable.review2=rev;
s.digestTable.groups2=groupsSha;
s.digestTable.prepared2=c.acceptedPayload.preparedSha256;
s.digestTable.context2=r2.evidenceContextSha256;
// Ledger-correction fixture has a second copied receipt. Update ONLY that second copy to bind corrected context.
check('copied old first receipt immutable',equal(correction.release.provenance.receipts[0],r1));
correction.release.provenance.receipts[1]=structuredClone(r2);
// Freeze retained history, model, raw patch, old trusted commitments, and the captured source bytes.
check('first receipt unmodified',equal(r1,old.m.release.provenance.receipts[0]));
check('attendance unmodified',equal(m.release.attendance,old.m.release.attendance));
check('snapshots unmodified',equal(m.model.snapshots,old.m.model.snapshots));
check('model unmodified',equal(m.model,old.m.model));
check('calendar retained unchanged',equal(m.release.calendar,old.m.release.calendar));
check('prior crosswalk untouched',equal(s.assembledRetainedSourceRevision,old.s.assembledRetainedSourceRevision));
check('second proposal untouched',equal(s.proposal,old.s.proposal));
check('raw builder patch untouched',equal(s.rawBuilderSourceRevisionPatch,old.s.rawBuilderSourceRevisionPatch));
check('actual raw patch hash unchanged',c.acceptedPayload.sourceRevisionPatchSha256==='17ecc6e699bcb7b6bee7674fe80b2f2f4bdca29581a811204066d0be7adb04bb');
check('all prepared effects untouched but group refs',c.prepared.effects.every((e,i)=>{const v=old.m.release.provenance.receipts[1].evidenceContext.prepared.effects[i];return equal({...e,groupId:v.groupId},{...v,groupId:v.groupId});}));
check('old ledger correction history immutable',equal(correction.release.attendance,old.correction.release.attendance));
// Validate recursively sorted ID metadata and unique ID sets in second context.
const unsorted=[];
function scan(v,p){if(v===null||typeof v!=='object')return;for (const [k,x] of Object.entries(v)){
 const q=p+'/'+k;if((k.endsWith('Ids')||k==='runSha256s')&&Array.isArray(x)&&x.every(y=>typeof y==='string')){
  const y=[...x].sort();if(!equal(x,y)||new Set(x).size!==x.length)unsorted.push(q);
 }
 scan(x,q);
}}
scan(c,'/release/provenance/receipts/1/evidenceContext');check('sorted ID metadata',unsorted.length===0);
for (const [name,value] of [['MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json',m],['SECOND_SOURCE_SUPPORT.json',s],['LEDGER_CORRECTION_ACTUAL_OUTPUT.json',correction]])put(name,value);
const hashReport={classification:'AUTHORED_RESEARCH_C3_FIXTURE_ONLY_NOT_TRUSTED_STAGE',priorContextSha256:old.m.release.provenance.receipts[1].evidenceContextSha256,correctedContextSha256:r2.evidenceContextSha256,oldReviewSha256:old.s.digestTable.review2,newReviewSha256:rev,oldGroupsSha256:old.s.digestTable.groups2,newGroupsSha256:groupsSha,oldPreparedSha256:old.s.digestTable.prepared2,newPreparedSha256:c.acceptedPayload.preparedSha256,oldSemanticIntentSha256:old.m.release.provenance.receipts[1].evidenceContext.acceptedPayload.semanticIntentSha256,newSemanticIntentSha256:c.acceptedPayload.semanticIntentSha256,rawBuilderPatchSha256:c.acceptedPayload.sourceRevisionPatchSha256,oldGroupIds:old.m.release.provenance.receipts[1].evidenceContext.groups.groups.map(g=>g.groupId),newGroupIds:c.groups.groups.map(g=>g.groupId),metadataUnsortedPaths:unsorted,priorOmission:c.review.omissions[0],changes:['E-C3-01','E-C3-02']};
fs.writeFileSync(path.join(to,'evidence','C3_CORRECTED_COMMITMENTS.json'),JSON.stringify(hashReport,null,2)+'\n');
console.log(JSON.stringify({status:'C3_RECOMPUTED',...hashReport},null,2));
