# SemesterSpace Diamond — Chat F SA-001 C3 0.1.4 PROPOSED

**Begin with `00_A_HANDOFF_C3_0.1.4.md`.** This supersedes older `00_A_HANDOFF_C1_C2.md`, `README_START_HERE.md` and other 0.1.3 narrative statements wherever C3 second-receipt hashes differ. The old material is copied for C1/C2 traceability; old 0.1.3 hashes in historical logs are not current 0.1.4 values.

C3 source findings: `reference/E_C3_REVIEW_ORIGINAL.zip` is Chat E's exact unchanged 27 October 2026 review. Original F: `reference/F_C1C2_0.1.3_ORIGINAL.zip`. No production source bundled or edited.

Primary corrected fixtures: `fixtures/MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json`, `fixtures/SECOND_SOURCE_SUPPORT.json`, `fixtures/LEDGER_CORRECTION_ACTUAL_OUTPUT.json`. New recalculated digests: `evidence/C3_CORRECTED_COMMITMENTS.json`. Exact old/new JSON-pointer change list: `evidence/C3_EXACT_CHANGED_PATHS.json`.

To verify without installed SA implementation:

```sh
python3 verify_f011_contract.py
python3 research/verify_c1_c2.py
python3 research/verify_c3_finite.py
python3 research/replay_e_c3.py
sha256sum -c SHA256SUMS.txt
```

`research/replay_e_c3.py` uses a temporary workspace, extracts the original Chat E review ZIP, overlays only the two amended author fixtures, and reruns E's unchanged Node checker plus independent Python hash-verifier. It should report 114 relationships, 57 preimages and no C3 findings. It is a **research checker outcome**, not formal Chat E signoff. See `evidence/C3_RUNS` for raw logs and `evidence/C3_EXIT_CODES.json` for exit codes.

To reproduce the 74 assertions **including original input comparisons** use `python3 research/verify_c3_finite.py /PATH/TO/0.1.3_PROPOSED`. Without the original reference it still runs core checks. Optional pure-interface replay requires owner-pinned `88d606e` source checkout and does not change production.

No real reader, private stage, browser, profile3 storage writer or acceptance run. All F011 152 proposed runtime variants remain UNRUN. OMR-01 closed; SA-001 OPEN P1. Send to E for targeted re-review, then A; no D release approval implied.
