# Semantic, retention and capacity disposition — R3

## Semantic boundary

The following source/probe observations were reported in E's earlier targeted review against supplied 88d606e selected importer files; they were **not rerun in R3**. No production source changed. Authority binding must preserve these limitations rather than imply their resolution.

| Family | Prior evidence / remaining problem | PROPOSED honest reviewed resolution |
|---|---|---|
| SEM-01 | Earlier synthetic probes: “No holiday” and “Holiday cancelled” produce HOLIDAY/ADD_HOLIDAY. | Preserve raw quote/candidate. Explicit no-applicable-effect exclusion for negation; affirmative reviewed withdrawal matched to a real existing holiday for REMOVE_HOLIDAY. Never rewrite the raw sentence. |
| SEM-02 | Earlier probes: 11/02/2026 silently becomes 11 February; 07–08 can become 19–08; missing section yields no rows; Devanagari dates unsupported. | Bind actual context and explicit date convention/reason. Correct derived time/date only, retaining raw text. Unresolved identity/layout/language stays blocked or separately reviewed manual completion; invalid intervals cannot compile. |
| SEM-03 | Earlier probes: two discrete dates become an interval including a false holiday; moved exam produces multiple events. | Bind a reviewed date SET or one move retaining canonical event identity. Retire false derived effects with reasoned tombstones; preserve raw candidates. Group source-coupled effects. |
| SEM-04 | Source inspection: >=30 text characters may select PDF_TEXT while a raster body/footnote is unread. Actual hybrid/OCR execution remains UNRUN. | Full returned decode is distinct from full meaning. P8 uses a true text caption as CARRIER and visual region/transcription as meaning; qualifying footnotes/scope retained. Entirely visual/no captured text cannot satisfy the unchanged preparer's nonempty evidence requirement and remains unsupported. |

The fixed fields bind a local interpretation to captured material. They do not establish issuer truth, absence of other notices, correctness of a translation, an operator's comprehension, or university-independent support. Issuer status is UNVERIFIED; reviewer kind is LOCAL_OPERATOR. No passing authority gate substitutes for semantic extraction/review release gates.

## Compact audit and loss after reload

**PROPOSED:** retain all material text anchor quotes, exact source/run/page/channel/offsets, geometry, recursive header/legend/footnote qualifiers, factual correction/meaning/reason, full scope/date convention, source-specific coverage and omissions, issue decisions, effect/group/induced-delta and partial-adoption context. Complete raw inventory references/hashes persist; entire raw text/items, originals and previews do not.

After reload one can inspect what was asserted, selected and omitted, the governing retained quotations and the commitments/identity relationships. One cannot recover the complete page layout, rerun OCR, inspect unquoted pixels/text, verify a visual transcription against its image, reconstruct an earlier whole model from a digest, or revive a capability. A visual digest does not make the underlying image available. Re-upload creates a new intake/run/review. Any audit presentation must state those availability limits, and must not draw a fabricated page from coordinates/transcription.

No hash-only replacement for a necessary qualifier, silent clipping, pruning of old receipts or unmarked summary is permitted. If complete evidence cannot fit, reject before the write with retained data intact. F must express the complete context in its grammar; an unknown-field extension holding this packet is insufficient.

## Measurement protocol and finite hold

The 512KiB/receipt and 2MiB/envelope caps remain **PROPOSED and unvalidated**. INPUT_AND_SIZE_OBSERVATIONS.json records escaped UTF-8 bytes for the two authored E context objects only. They are neither receipt/envelope totals nor reader/device measurements; no capacity extrapolation is claimed.

Required joint E/F capacity experiment, **UNRUN**: independently specify rights-cleared synthetic 20-page text and hybrid documents with footnotes, multi-cohort scope, exclusions, Unicode and escaped characters; decode with the actual installed reader/local OCR; record returned method/pages/issues and complete reviewer context. Measure raw source bytes, captured session material and final serialized receipt/envelope separately. Build 12- and 24-revision histories with actual independent and coupled effects, preserved unselected effects, real day-close/correction journal entries and all prior receipts. Recompute bindings at every step; duplicated stale fixture digests are not valid histories.

At and just below the actual byte cap, attempt a normal close/correction. Include exact-cap and cap+1 UTF-8 admission, existing valid oversized profile3 reload as read-only recoverable, and host quota/postwrite uncertainty separately. No space-reserve promise until measurements support it. Record installed artifact identity, elapsed latency and peak memory on the named Windows/mobile device; absent access means UNRUN, never estimated performance scores. Browser/profile3 behavior follows the future authorized candidate, not these research scripts.

Owner disposition must set usable history/headroom and understandable write refusal after measurements. F's full-profile examples and final precedence remain prerequisites. A/D may review the E contract now, but this packet cannot close capacity or authorize implementation.
