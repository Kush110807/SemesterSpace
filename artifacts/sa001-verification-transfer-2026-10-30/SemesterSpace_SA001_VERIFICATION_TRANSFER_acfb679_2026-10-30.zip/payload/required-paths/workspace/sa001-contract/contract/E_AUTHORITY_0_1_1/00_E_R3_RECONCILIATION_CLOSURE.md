# Chat E — revised authority/evidence contract

26 October 2026 · E-SA-R3 · 0.1.1 PROPOSED · Research only

**E's assigned contract delta is complete for F's embedding review. Integrated contract readiness remains OPEN; SA-001 remains OPEN P1.** This packet supplies closed E records, commands/options, binding rules and regenerated expected vectors. It does not supply F's final receipt/envelope grammar, an implementation or a source-acceptance credential.

Evidence labels: **OBSERVED** means inspected supplied source/packet; **REPRODUCED** means the bounded checks recorded here; **PROPOSED** means normative future design; **UNRUN** means no execution evidence. No finding below establishes issuer authenticity or reviewer comprehension.

## Reconciliation decisions

| A clause / conflict | Decision | Exact disposition and location |
|---|---|---|
| A-R2-01; conflict 1 | ACCEPT | Unchanged genuine reader; approved available manifest supplied privately by composition, embedded within the already proposed main.js path. Actually-used subset explicitly null/NOT_OBSERVED. Opaque/failed/cancelled decode cannot stage. Complete decode with PARTIAL interpretation can review. Document 01 §§1–2; schema Observation/InputKnowledge/Run. |
| A-R2-02; conflict 3 | AMEND, supplied | Closed InitialOptions/RevisionOptions, BeginReviewIntent, twenty ReviewCommand variants, typed EffectEdit and separate public Preview/DisplayMaterial. No public raw-inventory replacement, issue deletion, completion setter, arbitrary proposal or JSON options bag. Extraction hints are captured in Run. Document 01 §4 and exact schema. |
| A-R2-03; conflicts 2–4 | AMEND, supplied | One E-PROJ/SA-C14N/SA-AUTH 0.1.1 graph; explicit nulls/presence, exact Unicode, set versus array order, normalized binary64 authority geometry, raw computational aliases, independent source-byte commitments. All new protocol-framed vectors regenerated. Document 02, schema and VECTORS. |
| A-R2-04; conflict 2 | AMEND, supplied | Total eight-kind policy; complete effect→fact→anchor/group links, old/new target commitments, induced deltas and APPLIED/NOT_APPLIED/NO_OP inventory. Independent same-document holidays remain separately selectable; unknown independence groups conservatively or blocks. Whole proposal.unresolved=[] mandatory. Document 03; schema Groups/EffectBinding. |
| A-R2-05; conflict 4 | ACCEPT, specified | Only the newly created /snapshots/0/confirmedAt is normalized in initial intent. Recompile/expand/validate at acceptance; every other field must match. Computation/review/acceptance clocks and actual accepted model/payload hashes are distinct; no receipt self-hash cycle. Documents 01 §5 and 02. |
| A-R2-06; conflict 2 | AMEND, E portion supplied | Fixed EvidenceContext retains scope, recursive qualifiers, corrections, issue/coverage/omission/adoption closure. NOT_RETAINED originals/previews, LOCAL_OPERATOR and UNVERIFIED remain explicit. F must embed the fixed fields with no opaque extension escape hatch. Document 01 §7 and document 05. |
| A-R2-07–11; conflicts 5–7 | OPEN, F integration | No competing storage grammar is introduced. F owns full profile3 precedence, legacy preservation, consent, immutable receipts, caps, recoverable oversize and write uncertainty. E specifies presence tags and honest descriptor/proxy limits as integration inputs. |

## E-B1–B4 closure

| Prior blocker | E disposition | Remaining finite integration/gate |
|---|---|---|
| E-B1 observation | ACCEPT — contract choice resolved by A; exact knowledge fields supplied. | No reader/loader change. Runtime asset selection remains unobserved by design. Approved composition must deliver the literal manifest from the reviewed build, never a caller's record. |
| E-B2 private interpretation/group bridge | AMEND — complete closed sidecar and operation-specific adapter rules supplied. | F embeds fields; A/D review supported adapter behavior. Genuine positives remain UNRUN. Pure visual/no-text remains unsupported. No T2-LINK or parser repair. |
| E-B3 initial intent/clock | ACCEPT — exact slot, intent graph and actual-payload commitments supplied. | F embeds both commitments/clocks; later candidate must demonstrate acceptance parity outside the single slot. |
| E-B4 compact completeness/capacity | AMEND — E context inventory and availability policy supplied; OPEN for integrated/capacity readiness. | F must embed it, supply four full-envelope examples and precedence/cap rules. Realistic reader/history/capacity measurements and owner disposition remain required. No silent pruning or truncation. |

## What was verified

**REPRODUCED:** reconciliation input manifest 4/4; retained selected reference source hashes 17/17; two authored complete E context graphs pass the supplied limited shape/referential checker; all 68 published SHA-256 preimages recompute; eleven negative fixture expectations reject in their stated controlled checks. One additional Proxy guarantee limitation is a specification statement, not an executable rejection. Raw text/item/page/bundle/inventory bindings, literal UTF-16 quote offsets, acyclic qualifiers and generated component IDs are checked for these examples. See VERIFICATION_RESULT.json and INPUT_AND_SIZE_OBSERVATIONS.json.

The Node generator and Python verifier are research fixture tools, **not production modules or a general hostile-object/JSON Schema validator**. They implement no SA coordinator, storage or authorization. Python's controlled fixture verification is not proof of all JS numeric/key-order cases across runtimes.

**PROPOSED examples:** INITIAL_COMPLETE_E_CONTEXT and REVISION_COMPLETE_E_CONTEXT instantiate every required E-context field. SUPPORT files give authored raw/computational/model expectations. BYTE_FIXTURE_DESCRIPTORS contains independently authored synthetic PDF bytes. Preview commitments are explicitly expected fixture placeholders, not measured JPEG renderings. These examples test serialization/binding design; they cannot be submitted as real-reader receipts, source approval or F's complete profile examples. Replacing a placeholder with actual extraction requires regenerating every downstream bound record, not patching one digest.

**UNRUN:** genuine PDF-text/OCR/coordinator positives P1–P9 (P2 is manual), integrated profile3 validation/reopen/storage, runtime browser asset observation, 20-page/hybrid installed-reader measurements, 12/24-revision real histories, near-cap ordinary attendance updates and device peak-memory trials. No qualifying installed-reader execution environment was established; chromium/chromium-browser were absent. Small fixture sizes cannot validate the provisional 512KiB/2MiB caps.

SEM-01–04 remain distinct semantic/release limitations. Document 05 preserves the previously observed wrong meanings and permitted correction boundaries; no fresh semantic replay or parser improvement is claimed.

## Handoff

F consumes this exact 0.1.1 E inventory, embeds it in one closed profile3 grammar, and supplies MANUAL, DOCUMENT, LEGACY_UPGRADE and multi-receipt/nonempty-ledger full examples. A reconciles the combined schema, hashes and finite owner decisions before D's targeted review. No automatic implication of agreement or freeze follows from this handoff.

The proposed nine production paths remain unchanged; none was edited. No Codex task, repository action, training, service/API purchase, institutional-document collection, source acceptance or deployment occurred. Research scripts only generate/check this packet's authored contract artifacts.

Start with this document; 01 is the normative authority contract, 02 canonical rules, 03 dependencies, 04 nine positive recipes, 05 semantic/retention/capacity limits. AUTHORITY_EVIDENCE_0_1_1.schema.json is the closed shape inventory. EXPECTED_DIGESTS.md indexes the exact preimages in VECTORS_0_1_1.json. SHA256SUMS.txt covers the delivered files.
