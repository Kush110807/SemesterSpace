# SA-AUTH/0.1.1 — total dependency policy / PROPOSED

**AMEND:** use generated connected components of supported, validated effects and recorded causal facts. A source page/hash shared by two effects is NOT itself a dependency. An arbitrary caller `groupId` or “independent” checkbox establishes nothing. Unknown coupling prevents partial selection. The eight existing effect kinds remain unchanged.

## Total per-kind footprint rules

Every effect contributes its canonical target, referenced registers/sessions/events, old and new service dates, originating fact IDs and any induced model delta. Footprints are conservative authority metadata, not a replacement planner.

| Existing kind | Atomic unit and coupling footprint |
|---|---|
| ADD_SESSION | One once-assigned extra occurrence ID with register/date/start/end/weight/origin/template identity. Couple to effects creating/requiring its dependencies, same-target modifications and events linked to it. A newly created register/policy is not expressible in these effects: UNRESOLVED, never invent it. |
| EDIT_SESSION | Entire before→after row is atomic, including a move's old/new dates. A canonical occurrence move uses this single effect, not cancellation plus new ID. Couple old/new date schedule modifiers, linked event edits and all effects required by the same source move/swap fact. |
| CANCEL_SESSION | Entire canonical row retained with cancelled=true. Couple effects expressing one cancellation/replacement transaction and linked-event operations. Source cancellation cannot rewrite actual attendance or bypass history. |
| ADD_HOLIDAY | One date/value plus its induced schedule changes. All dates of one atomic source interval/date-set are one fact group unless the source/review records genuinely separate independently applicable claims. Couple same-date holiday/pattern/session effects and events depending on affected sessions. |
| REMOVE_HOLIDAY | Canonical current date/value plus affirmative withdrawal. Couple to the same withdrawal/replacement fact, other modifiers of that date and affected session/event identities. Multiple competing notices remain unresolved unless a supported governing interpretation is explicitly reviewed. |
| REPLACE_PATTERN | Service date, borrowed weekday and entire induced schedule delta are atomic. Any “in lieu of” displaced date must be explicitly interpreted; if source means changes on both dates, group their supported effects. Couple explicit occurrence edits on that date and linked events. Do not infer a second cancellation from a weekday name. |
| UPSERT_EVENT | Entire independent-or-linked event before→after is atomic; preserve existing event ID. Couple changes to its old/new linked session, moves/swaps and source-coupled withdrawal/replacement facts. A linked event with null date remains subject to existing builder/T2-LINK behavior, not patched here. |
| TEACHING_END | Boundary and all induced projection consequences are atomic. Conservatively join every non-no-op change in that proposal to its group; no partial independence claim across a changed horizon in this slice. This intentionally limits selection in horizon-changing proposals. |

## Deterministic grouping procedure

1. Require the internally prepared proposal's **whole** `unresolved` array empty. Raw issues must all have retained dispositions; critical material may still block. No “unresolved only in unselected effects” exemption.
2. Create vertices for exact `changeId`s. Non-no-op effects reference internally registered FactDecision IDs and evidence closure. Current computational proposal lacks enough causal data: the coordinator sidecar must preserve effect→fact→source candidate/anchor identity when preparing it. It is bound into review/prepared hashes; not added to engine DTOs.
3. Add edges for same canonical write target, known source-coupled fact (range/move/swap/withdrawal plus replacement), reference creation/use, same affected service-date schedule controls, or linked session/event relation. Add old and new dates/IDs, not only `after`. Existing unrelated effects on different dates and targets get no edge merely for sharing an input source.
4. Obtain induced changes by invoking the **existing builder/expander through its public computational boundary** on the whole candidate and where valid on candidate components; compare stable-ID keyed before/after data. Retain exact induced deltas with causal changeIds. This is structural comparison, not reimplementation of attendance, overlap, history or event meaning. Do not assume `sourceRevisionPatch.links` lists every reprojected session: it lists accepted explicit changes.
5. If footprint/causality/independence cannot be established, join the affected unknown component; if its extent is unknown, join the whole proposal. Mark group knowledge CONSERVATIVE_FULL. Validate that full supported group with the existing builder. A full group that still has unsupported semantics, ambiguous identity or builder failure stays UNRESOLVED/blocked; grouping cannot repair it. Do not use an unsound per-effect failed-build result as proof of independence.
6. Connected components are required groups. Each groupId is "g:" plus H(group-id,{baseModelSha256,reviewSha256,memberIds,edges}), using the0.1.1 framing in file02, sorted member IDs and sorted internal component edges. It is not a caller label. Group array is sorted by generated ID; member IDs are sorted unique; all effects appear exactly once. Record NO_OP groups explicitly; they mint no privilege or ownership witness and may be omitted from applied changes.
7. Approved IDs must be a union of complete groups, within the captured full proposal. A proper subset of a required component rejects. Same-target competing changes reject through the existing builder even if they share a group. Build/evaluate the entire selected union jointly against the exact current base; do not infer combined validity from individual success.
8. Receipt lists the full reviewed effect inventory with each effect APPLIED / NOT_APPLIED / NO_OP, its group/fact linkage, exact applied subset and induced deltas. Unselected source links/history remain intact. A selected subset never means the entire new notice was adopted; presentation must show partial adoption.

Finite examples:

- Two independent singleton holiday facts on 4 and 5 November: groups {h4},{h5}; {h4} is permitted after source-wide review, leaving h5 NOT_APPLIED. It does not assert a current complete-calendar adoption.
- One instruction “withdraw holiday on 4 November and use Monday pattern that day”: {REMOVE_HOLIDAY, REPLACE_PATTERN} is one group. Either half rejects; full group must pass the builder.
- Move of canonical event e1 via one UPSERT_EVENT is already atomic; do not add a second event or cancellation. A two-event swapped timetable is one reviewed swap group.
- TEACHING_END plus additions inside/outside old/new horizon: whole non-no-op proposal grouped; builder decides legality. Do not simulate its horizon rules.
- Any missing dependency link, unsupported recurring-pattern/policy change or unresolvable linked event: explicit unresolved. Passing the “whole group” is not an escape hatch.

F must agree the receipt's compact descriptions/induced-delta commitments. D independently checks missing-edge and over-grouping controls. This policy preserves useful independent selection without claiming optimal independence classification.
