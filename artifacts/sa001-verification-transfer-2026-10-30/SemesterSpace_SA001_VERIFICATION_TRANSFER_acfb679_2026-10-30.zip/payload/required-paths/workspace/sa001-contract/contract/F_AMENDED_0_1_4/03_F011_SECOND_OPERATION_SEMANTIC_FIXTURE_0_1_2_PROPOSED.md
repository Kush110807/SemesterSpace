# A-F011-03 — Coherent authored two-document, one-ledger-operation fixture

**Evidence class: AUTHORED SEMANTIC GRAPH / NOT A TRUSTED-STAGE EXECUTION.** Never count this fixture as a real reader, OCR, private stage, controller acceptance, browser persistence or issuer proof. It supplements, **without changing**, the earlier `MULTI_RECEIPT_WITH_LEDGER_SHAPE_ONLY.json` fixture, which remains shape-only. E 0.1.1's 81 record definitions are unchanged; the second evidence context uses E's exact grammar and hashing protocol rather than a new schema.

## Files

- `fixtures/MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json`: complete proposed envelope3 with two nonidentical document contexts and ledger history.
- `fixtures/SECOND_SOURCE_SUPPORT.json`: full independent source byte descriptor, raw-page text/item transcript, bundle/raw inventory, source-specific proposal, base profile3 envelope at revision8, accepted revision9 model and SHA commitments.
- `fixtures/REV2-authored.pdf`: **actual authored synthetic source bytes** included in package; source SHA is computed from its contents, **not** an invented name-derived digest. The PDF was not fed through the unchanged reader/OCR in this research task.
- `verify_f011_contract.py`: nonmutating fixture-schema, independent graph/canonical digest, historical preservation, and source-byte checks.

## Exact timeline

| Step | Model revision | Source/operation | Material consequences |
|---|---:|---|---|
| Base | 6 | Retained real E-authored release1/profile2 base | Legacy snapshots retained, raw-envelope SHA anchored |
| Document operation 1 | 7 | Source `REV-example.pdf`, E's unchanged first context, `receipt-revision` | Reviewed `Holiday 04.11.2026`, applied one effect; `05.11` proposed but NOT_APPLIED; applied revision and first source link retained |
| Ordinary ledger | 8 | Actual previously supplied DIAMOND-001 `evaluateDayClose` fixture output | Two confirmed attendance records and one closed day for 2026-11-02 at 14:00; first receipt unchanged |
| Document operation 2 | 9 | Newly authored distinct `REV2-authored.pdf`, `receipt-revision-2`, run `run-revision-2` | New source actual byte hash `84247958d18d83d8cf95c2e346c7230f024dd78bcdaacc35d2dc3bcfb1a8fa53`; reviewed 06.11 and 10.11, applied 06.11 holiday, NOT_APPLIED 10.11; cancelled Friday teaching session only; old 04.11 holiday, first receipt and ledger remain unchanged |

The second source has different original PDF bytes, byte SHA, intakeId `ir2`, slot epoch3, run/page refs, raw-text/raw-items and raw-candidate hashes, anchor quote/offsets, review with its own confirmed clock 14:10, group IDs bound to actual base model revision8, prepared computation clock 14:11, approved subset and accepted payload at 14:12. The second acceptedModel SHA binds revision9 and the old model's snapshots remain unchanged. The first receipt accepts revision7 and is validated against that historical model, **not** today's revision9. The ledger confirmation is independent of both receipts.

The source crosswalk uses the new source identity and keeps the prior linked `h4` entry with the previous source hash and source history; its `links[]` entries preserve old opaque B2 metadata. Applied revisions preserve both original and subsequent entries and their clocks. Neither original legacy source evidence, historical snapshot confirmation, nor first receipt is restamped. `initialOrigin=LEGACY_UNATTESTED` and the exact original `legacyBase` remain immutable.

## Verified authored invariants

- Complete envelope, E context, nested graph and fixed-record closed schema: **PASS** for generated authored bytes.
- Recomputed `H('evidence-context', secondContext)` and `H('prepared')`, `H('review')`, `H('groups')`, `H('model', acceptedRevision9)` matched stored contextual digests; `rawEnvelopeSha256` and `priorReleaseSha256` bind the exact first-receipt-plus-ledger revision8 base.
- Raw source `sha256(REV2-authored.pdf)` matches the intake; authored page text and `PAGE_TEXT` UTF-16 anchor offsets match the quotes; the candidate IDs and source refs are disjoint from operation1.
- Both receipts have separate IDs and sources; each is associated with its own base and accepted revision. First receipt bytes are preserved unchanged, and the actual provided ledger journal's records/closures are preserved at revision9. No hidden source/receipt rewrite is needed to make the fixture validate.

**Limits:** The second semantic computation, compiled proposal and applied model are **independent authored expected support records**, not outputs of the unchanged `extractCalendarRevision`/builder running on `REV2-authored.pdf`. E's authoritative context definition has **not been edited**, but E has not separately acknowledged this newly authored semantic graph. A should obtain E confirmation specifically for the new graph/source semantics (not re-audit the 81 exactly matched schema definitions). D may evaluate this as a *contract-research semantic fixture*, but must not count it as a genuine two-stage authority-positive execution. That execution is a post-authorization implementation gate, as A's F011 placement correctly states.
