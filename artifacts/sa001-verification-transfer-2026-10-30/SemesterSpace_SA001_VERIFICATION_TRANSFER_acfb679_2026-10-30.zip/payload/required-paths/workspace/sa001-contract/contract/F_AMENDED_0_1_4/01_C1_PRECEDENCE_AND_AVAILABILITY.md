# C1: exact integrity, unknown-field and oracle readiness rule (0.1.3 PROPOSED)

## First-match precedence — no change to accepted B2 0.2.3/OMR-01

For recognized profile3: P0 expectation checks; P1 read; P2 missing; P3 JSON/root; P4 supported-versus-future version detection; P5a/b admitted combination/tag shape; **P5c known-core structural integrity AND all E-context digest-chain checks including every retained unknown-key/value in canonical preimages**; **P6a rewrite-safety unknown-fixed-field scan**; P6b retained size limits; P7 expected-empty, model identity and revision, and consent-bound base drift; P8 candidate/profile3 explicit-release and detached JSON admission; P9 whole serialized-envelope parse/value round-trip; P10 single write failure; P11 acknowledged save. Error strings never select branches. For unsupported outer4, no body walk. For supported but corrupt known records, P5c wins over unknown; for a digest-valid unknown field, P6a wins over P7. No candidate accessor before P8. Values containing unknown keys remain part of canonical domain inputs.

**Important two-pass schema distinction:** E's full JSON Schema and F's closed record inventory prohibit extensions and thus full-schema validation *fails* for digest-valid unknown-field fixtures. P5c integrity validation therefore must validate the recognized field types/references/digests **without classifying unknown fixed keys as malformed**; it MUST include them in E canonical preimages, not project them away. P6a separately performs closed-field enforcement and returns `PERSISTED_REWRITE_UNSUPPORTED`. Treating an additionalProperties violation as P5c `CORE_INVALID` in these digest-valid cases violates the proposed first-match contract. This is a validator-design requirement for A/D, not an alteration to E's 81 schema definitions.

**Path selection:** At each fixed record, traverse own keys in ascending **UTF-16 code-unit** lexicographic order, descend known child fixed records depth-first, and traverse arrays by ascending numerical indices. Return first unknown fixed key encountered. Apply RFC 6901 escaping only when emitting the path (`~` -> `~0`, `/` -> `~1`). Do not depend on insertion/key order of input serialized text. In `F-SA-09-multiple-unknown-sorted`, `/a~0field` wins over `/z~1field`. For receipt arrays, lower indices win; for multiple independent subtrees, define the same deterministic recursive traversal. This parallels the accepted B2 profile traversal; do not retroactively revise B2 results.

**Receipt meaning versus JSON representation:** The canonical E-domain value commits *all* keys, including unknown extensions. Once committed, those values, ordered arrays, meaningful strings and clock fields cannot be changed without invalidating hashes. A new admitted whole-envelope write may serialize JSON object keys in a different order or use different whitespace **only** if detached parsed values are equal and every value/digest/history invariant holds. This never licenses changing the exact original stored string during a no-write rejection, nor replacing a historical `rawEnvelopeSha256` commitment with the hash of a reserialized copy. Raw-source-patch SHA uses the actual original `JSON.stringify(rawBuilderPatch)` bytes; it must not hash the assembled retained crosswalk.

## Precise dependency account

| Category | Variant count | What is supplied | What has executed |
|---|---:|---|---|
| Concrete base + mutation recipe | 127 | Source JSON bytes, pointer/serializer/hostile mutation recipe | No profile3 runtime |
| New concrete digest-valid unknown fixture | 4 | Full new JSON preimages and recalculated commitment chain | Hash/schema research verified; no profile3 runtime |
| Private-controller stage/consent dependent | 17 | Input states and expected results; no genuine private handles | No SA controller runtime |
| Pure ledger candidate | 1 | `LEDGER_CORRECTION_ACTUAL_OUTPUT.json` from real pinned `evaluateDayClose` | Pure ledger executed, profile3 SAVE UNRUN |
| Future stage/evidence builder | 1 | `F-SA-40-profile3-upgrade-pending` symbolic recipe only | Candidate not emitted, no runtime |
| Suite/not applicable to one call | 2 | Out-of-scope/suite statements | Not directly executable |
| **Total defined** | **152** | Unique IDs and numeric expectations | **0 profile3 runtime variants passed or executed** |

These are **readiness categories**, not 152 emitted concrete candidate envelopes or a passing acceptance suite. Unchanged E/F definitions stay frozen as reviewed; new fixtures are deliberately authored. No source credentials or trust capabilities are derived from the receipt or a hash.
