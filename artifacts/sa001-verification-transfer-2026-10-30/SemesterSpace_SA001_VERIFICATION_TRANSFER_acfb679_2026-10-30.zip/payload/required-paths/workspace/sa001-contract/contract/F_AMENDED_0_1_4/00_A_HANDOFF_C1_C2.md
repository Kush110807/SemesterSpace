# SemesterSpace Diamond — Chat F, C1/C2 finite contract amendments

**Document status:** `F-SA-C1C2/0.1.3 PROPOSED`, research-only, 2026-10-27.
**Disposition:** C1/C2 amendments ready for **targeted Chat E review**, NOT writable-profile or production authorization. A's integrated SA-001 contract remains on HOLD pending E concurrence, A reconciliation and D review. DIAMOND-SA-001 remains OPEN P1. Accepted OMR-01/T1 `88d606ea940be945fa55124671c1a8deb57c7b04` unchanged.

## Closure matrix

| A finding | Exact corrected artifact | Evidence and treatment | Status |
|---|---|---|---|
| C1: `F-SA-09-anchor`, `F-SA-09-review`, `F-SA-09-clock`, `F011-X-18-unknown-e-field` stale commitments | `F011_EXACT_TEST_VARIANTS_0_1_3_PROPOSED.json`, four `fixtures/UNKNOWN_VALID_*.json` | Original four become **P5c** `PERSISTED_DATA_INVALID/CORE_INVALID`; four new `-digest-valid` siblings recompute review/groups/prepared/context commitments and expect **P6a** `PERSISTED_REWRITE_UNSUPPORTED/UNRECOGNIZED_RETAINED_FIELD` at exact pointer. Prior content untouched. | Repaired as authored oracle; runtime UNRUN |
| C1: `F011-X-16a` incoherent successful upgrade | `fixtures/E2_REVISION_BASE.json` unchanged, adjusted `F011-X-16a`, added `F011-X-16a-stale-base-negative` | Positive binds **stored rev6/base6/accepted rev7** with exact bytes SHA `709093c4...16681`. Original rev8/base6 mismatch retained as `SA_UPGRADE_CONSENT_STALE/BASE_BYTES_CHANGED`, no write. Private consent is an **unimplemented recipe**, not a minted live token. | Repaired model inputs; runtime UNRUN |
| C1: `F-SA-31-explicit-attendance` nonexistent interface | `research/replay_pure_interfaces.mjs`, `fixtures/LEDGER_CORRECTION_ACTUAL_OUTPUT.json` | Verified 32 source hashes; actual `evaluateDayClose({model,journal,request,clock})` using `correctionOfDayKey`. `DAY_CORRECTED`, rev10, four records, two closures, both receipts retained. | Existing **pure ledger** executed; proposed profile3 save UNRUN |
| C1: `F-SA-40-profile3-upgrade-pending` symbolic builder | `F011_EXACT_TEST_VARIANTS_0_1_3_PROPOSED.json` | Explicitly `FUTURE_SA_REVIEW_BUILDER_UNRUN`, not emitted; requires a real, separately reviewed operation and base-specific authority. | Dependency OPEN; expected profile3 behavior defined but UNRUN |
| C1: deterministic unknown and serialization | `01_C1_PRECEDENCE_AND_AVAILABILITY.md`, `F-SA-09-multiple-unknown-sorted` | P5c commitments before P6a unknown, P7 conflicts and candidate access; root collision demonstrates path escaping/order. | Proposed contract rule; runtime UNRUN |
| C2: `secondSourceRevisionPatch` was hybrid | `fixtures/SECOND_RAW_BUILDER_PATCH.json`, `fixtures/SECOND_ASSEMBLED_RETAINED_CROSSWALK.json`, revised `SECOND_SOURCE_SUPPORT.json` | Actual unmodified builder returns **one h6 link**, no history. Assembled retained crosswalk has **two links + history** and root identity fields. | Pure builder independently replayed |
| C2: wrong `sourceRevisionPatchSha256` | Revised second receipt in `fixtures/MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json`, `evidence/C2_CORRECTED_HASHES.json` | `SA-AUTH/0.1.1:source-patch-bytes\0` + UTF-8 native `JSON.stringify(rawPatch)` yields **`17ecc6e699bcb7b6bee7674fe80b2f2f4bdca29581a811204066d0be7adb04bb`**. New E context commitment **`1e9bca91b2f22d53e1b6b8f0373b055b2940d64c04560c872cafd1a471880114`**. | Authored commitments verified; live acceptance UNRUN |

**Preservation:** Previous receipt byte-value, model snapshots and complete ledger journal compare equal to the revision8 base. Previous source link remains deep-equal, unchanged; new link and sourceHistory reside only in the controller-assembled retained record. Historical clocks are not restamped. `E81/F116` schema definitions unchanged (embedded schema SHA-256 `bf34087ccd398aa14d36e1575c6ffa8e64f82b3bcd6f0ad290544b9be4b89238`). No original E domain projection or canonicalization rule was altered.

## Corrected, precise result expectations

- **Stale digest four cases:** `P5c / FAILED / PERSISTED_DATA_INVALID / CORE_INVALID / null path / getItem=1 / setItem=0 / candidate getters=0 / persisted bytes exactly UNCHANGED`.
- **Digest-valid unknown siblings:** `P6a / FAILED / PERSISTED_REWRITE_UNSUPPORTED / UNRECOGNIZED_RETAINED_FIELD / precise original pointer / getItem=1 / setItem=0 / candidate getters=0 / persisted bytes exactly UNCHANGED`.
- **F011-X-16a coherent positive:** `P11 / ACCEPTED / SA_ACCEPTED / ONE_ENVELOPE_WRITE`, but **only when real stage/base/profile-bound one-use consent exists**; not an executed SA runtime test. The `E2_REVISION_BASE.json` file (rev6) exactly supplies the committed base bytes; candidate rev7. No token was minted.
- **F011-X-16a stale-base negative:** `SA-PRE / REJECTED / SA_UPGRADE_CONSENT_STALE / BASE_BYTES_CHANGED / getItem=1 / setItem=0`, raw unchanged. Rev8 cannot be authorized by rev6-bound consent.
- **F-SA-31:** independent real pure ledger `DAY_CORRECTED` derived, proposed storage `P11 / SAVE_OK` **UNRUN**; no magical `evaluateDayCorrection` export.
- **F-SA-40:** symbolic future builder, **not a concrete emitted candidate**, acceptance outcome purely normative and UNRUN.

## Evidence/verification ledger

- `evidence/VERIFIER_C1C2.log`: **52/52** authored and research relationship assertions PASS; exit 0.
- `evidence/VERIFIER_F011_INHERITED.log`: **46/46** inherited authored structural checks PASS; exit 0. Intentionally unknown-field fixtures are *not full-schema valid*; this is exactly the P6a condition and is handled separately by C1 verifier.
- `evidence/PURE_INTERFACES.log`: pinned actual source verification **32/32**, independent builder one-link patch and real ledger correction; exit 0. `evidence/PURE_BINDINGS.json` holds the output identities.
- `evidence/EXIT_CODES.json`: shell exit codes with exact commands.
- `SHA256SUMS.txt`: SHA-256 manifest for all bundled files other than the manifest itself. ZIP extracted and manifest rechecked before delivery.

No profile3 implementation exists here. **All 152 storage/stage/browser oracle variants are UNRUN**. 127 have concrete base+mutation recipes, 4 have newly emitted digest-valid base fixtures, 17 require future private stage, 2 are non-single-call or out of scope, 1 is a research-executed ledger candidate with proposed save UNRUN, and 1 requires the not-yet-existent SA review builder. Existing builder and ledger probes do **not** transform those 152 into runtime passes. The 20-page/hybrid, 12/24 revision/browser durability and genuine second trusted-stage execution remain unperformed.

## Required targeted Chat E concurrence

E must independently inspect (i) new second authored PDF/source transcript, raw page quote/UTF-16 anchors and date/scope, (ii) independent h6 *applied* and h10 *not applied* group semantics, (iii) historical h4/h5 and retained legacy/source qualifiers, (iv) distinction between one-link raw builder patch and complete retained two-link crosswalk, (v) corrected raw patch digest and dependent receipt context digest, (vi) E-canonical unknown-field commitments without dropping extension keys or minting authority, and (vii) ledger/historical snapshots and first receipt immutability. Mark the second operation **AUTHORED / NOT_TRUSTED_STAGE / READER_AND_BROWSER_UNRUN**. An actual PDF SHA does not prove institution authenticity.

Chat A must reconcile any E amendment before submitting an **exact** contract version to D. No authorization to implement, merge, migrate or release is conveyed.
