# SemesterSpace Diamond — Chat F E-C3-01/02 finite amended closure

**Version:** `F-SA-C3/0.1.4 PROPOSED` · 27 October 2026 · authored research contract fixture only.  
**Status:** **F AMENDMENTS READY FOR TARGETED E RE-REVIEW**, not E's formal signoff, not an implementable SA profile3 approval. DIAMOND-SA-001 remains **OPEN P1**; accepted DIAMOND-001 `88d606ea940be945fa55124671c1a8deb57c7b04` / OMR-01 remains closed and unchanged.

## Exact E-C3 closure matrix

| E finding | Corrected file/path | Evidence / result | Boundary |
|---|---|---|---|
| **E-C3-01** ID-set normalization | `fixtures/MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json` `/release/provenance/receipts/1/evidenceContext/review/coverage/2/factIds` and `/groups/effectIds` | `['f10','f6']` and `['h10','h6']`, respectively, in UTF-16 order; all relevant second-context `*Ids`/`runSha256s` scanned unique/sorted; new review and group hashes recompute. | Do **not** sort computational `proposal.changes`, `prepared.effects`, source capture, existing Model1, or B2 arrays. |
| **E-C3-02** missing prior notice disposition | Same fixture, `/release/provenance/receipts/1/evidenceContext/review/omissions/0` | Exact typed omission: `omissionId='omission-prior-h4-retained-rev2'`, `intakeId='ir2'`, `sourceCandidateId=null`, `priorLinkRef='h4'`, `missingMaterial` identifies old 04.11 holiday, `anchorIds=[]`, `decision='KEEP_EXISTING'`, `factIds=[]`, explicit explanatory `reason`. | Not a quote from new source or evidence of issuer authenticity; no withdrawal inferred. Prior h4 link, h5 NOT_APPLIED, ledger and first receipt intact. |
| Dependent commitments | Same receipt and `fixtures/SECOND_SOURCE_SUPPORT.json` `digestTable`; matching copy in `fixtures/LEDGER_CORRECTION_ACTUAL_OUTPUT.json` | Recomputed group IDs, `reviewSha256`, `groupsSha256`, `preparedSha256`, `semanticIntentSha256`, `evidenceContextSha256`; source patch binding and accepted model unchanged. | No new protocol/schema version; fresh raw builder output untouched. |
| Regression / semantic checker | `research/verify_c3_finite.py`, `research/replay_e_c3.py`, `evidence/C3_RUNS/` | Inherited F011 **46/46**, C1/C2 **52/52**, standalone C3 **74/74**, E-published checker on amended fixture **114/114** with **zero** C3 findings and independent Python **57/57** preimages; unchanged pure computational source **32/32** hashes checked and ledger output identical. | These are authored research and existing pure computations; reader/OCR, private stage, writable profile3/browser and release tests **UNRUN**. |

## Recomputed second-operation commitments

| Commitment | Before C3 | After C3 |
|---|---|---|
| Review H(review) | `6b1af4ab6647d34bb841b83ca7c3441b5aba27c579043f86a80ec642ac9d206a` | `048a1087cd55fd535adf8b97f6d29f04aac3f2653ac74c1395cd4581c3a221fd` |
| Groups H(groups) | `601176158f0576d255f5b0e43d64f790ebb51c63f0aef5f99b6e8a2455054a90` | `a39c89612a92d669160b9055018013d4ae23e677bda8360c5b1e689b044cb3c7` |
| Prepared H(prepared) | `b56315ae542ea9f861476483136ef2abebee25958c74520b2f95a94bb3e6e82c` | `7a52df8871ed63cbea4d7de39597a8c69e32cb5f010011ee474d837866ba1695` |
| Semantic intent H(revision-intent) | `7848ad1ff39b90046504089e49bb2e373c637445360e0aeca663c61f89a4ec23` | `9675cda730c5293cb201e1c5d14bc2a4526e63db8118fe34587cdde0c64e58dd` |
| Second EvidenceContext H | `1e9bca91b2f22d53e1b6b8f0373b055b2940d64c04560c872cafd1a471880114` | `6e6449ab9c0381553e8cde32346738ef3f688207dcf91fe5002f23b15b7bb773` |
| **Actual raw `buildRevisionCandidate.sourceRevisionPatch` B hash** | `17ecc6e699bcb7b6bee7674fe80b2f2f4bdca29581a811204066d0be7adb04bb` | **UNCHANGED** `17ecc6e699bcb7b6bee7674fe80b2f2f4bdca29581a811204066d0be7adb04bb` |

New group IDs (sorted by exact string):

- `g:057bf6427f00f45ae289fdc90a9cb2745cdd9b9dee7fb0ca9c9a6f30ce02cc26`
- `g:a9fbeb842c022572c357c9c9b4120069da377e29a465204eb8bd4841fc4beb7e`

The first receipt's original evidence-context hash, accepted historical model's exact clock values, old source crosswalk/history, ledger records, and legacy base are unchanged. The second source's actual synthetic PDF bytes and authored text/anchors are unchanged. Raw builder patch has **one** selected `h6` link and **no sourceHistory**; assembled retained crosswalk has old `h4` plus selected `h6` and source history. `AcceptedPayload.sourceRevisionPatchSha256` continues to commit to the **raw one-link builder output** rather than the assembled crosswalk.

## Explicit old/new separation

The prior reviewed authored 0.1.3 data and its 57 original E preimages remain archival. The new 0.1.4 fixture has different *second* review/selection commitments; its 57 newly generated preimages are in `evidence/C3_RUNS/E_RECHECK/CANONICAL_PREIMAGES.json`. The original E C3 checker is included **unaltered** as an archived ZIP, and `research/replay_e_c3.py` substitutes only the two amended inputs when running it. This produces zero findings but is not a substitute for E's new human concurrence. There are **no revisions** to E's 81 normative schema definitions or F's 116 embedded definitions.

## Independent reproducible commands

From the extracted `SemesterSpace_F_SA001_C3_0.1.4_PROPOSED` folder:

```sh
python3 verify_f011_contract.py
python3 research/verify_c1_c2.py
python3 research/verify_c3_finite.py
python3 research/replay_e_c3.py
sha256sum -c SHA256SUMS.txt
```

For prior-byte comparison pass an extracted original F 0.1.3 folder to `research/verify_c3_finite.py /ABS/PATH/TO/F_C1C2_0.1.3_PROPOSED` (as used in the supplied log). To repeat the bounded *actual unchanged builder/ledger* replay using the independently obtained pinned T1 source:

```sh
node research/replay_pure_interfaces.mjs --source-root /ABS/PATH/TO/AUTHENTIC_88d606e/semester-space --reference-root . --out /ABS/NEW_EMPTY_OUTPUT_DIR
```

The output directory must not exist at invocation. Published `evidence/C3_RUNS/PURE_REPLAY.log` records 32/32 validated source files, captured builder hash, and ledger correction result. `LEDGER_CORRECTION_ACTUAL_OUTPUT.json` was checked against a fresh, independently replayed `evaluateDayClose` correction output, including the corrected copy of second receipt.

## Verification scope / required E response

Chat E should independently re-inspect **only** normalized metadata IDs, `h4` specific omission and the newly derived review/group/prepared/intent/context hashes and preserved historical records. Confirm that h4's absence from the independent notice is not treated as withdrawal and h5 remains NOT_APPLIED. The unchanged raw builder commitment is already supported by actual pure output, not a newly guessed hybrid.

**Honest limits:** Authored fixture and computational replay do **not** prove PDF.js/Tesseract extraction, real document interpretation, private source-authority capability, live stage/controller acceptance, persistence profile3, browser reload, 12/24-revision capacity or D release clearance. F011's **152 runtime variants remain UNRUN**; no new source writer was implemented. `evidence/C3_EXACT_CHANGED_PATHS.json` distinguishes every affected fixture path from historical values. No production code, GitHub state, schemas, accepted T1 contract, migrations, merge or deployment changed.

**F C3 AMENDMENTS READY FOR TARGETED E RE-REVIEW.**
