# SA-C14N/0.1.1 — exact binding and canonical protocol

## Version and compatibility

All protocol projections use E-PROJ/0.1.1. Hashes below use SA-AUTH/0.1.1 domain labels and a wrapper identifying canonical protocol SA-C14N/0.1.1. The0.1.0 vector hashes are not reused under new labels. Package/source/asset byte SHA-256 values remain their observed byte identities, not rehashed merely because the protocol changed.

Canonical algorithm C is deterministic JS JSON serialization on admitted JSON: recursively sort object keys with JS default UTF-16 code-unit order; JSON.stringify each primitive; join without insignificant whitespace, BOM or newline. Arrays preserve order unless the field normalization below explicitly says set/keyed collection. Nonfinite numbers/-0, unsupported values, sparse arrays/cycles/hooks/custom prototypes are not admitted. Strings preserve exact code points/whitespace and distinguish NFC/NFD; no case folding, normalization, transliteration or rounding. New authority strings with unpaired UTF-16 surrogates cannot enter a ready record. This is not an RFC8785 implementation or a cross-language conformance claim.

An alternative runtime is supported only after its canonical/F64/UTF-8 conformance vectors produce exactly these bytes/hashes. Runtime/tool version strings are record labels; changing the algorithm requires a new protocol label, not pretending its output is compatible. A controlled fixture calculator does not establish production runtime admission.

Canonical framing:

`W(x) = {canonicalProtocolVersion:"SA-C14N/0.1.1",projectionProtocolVersion:"E-PROJ/0.1.1",value:x}`

`H(domain,x) = SHA256(UTF8("SA-AUTH/0.1.1:" + domain) || 0x00 || UTF8(C(W(x))))`

`B(domain,bytes) = SHA256(UTF8("SA-AUTH/0.1.1:" + domain) || 0x00 || bytes)`

All returned hex is lowercase64hex. Source original SHA-256 and supplied available asset manifest SHA-256 are **plain byte SHA256**, no wrapper/prefix. `retained-source-bytes`, `retained-release-bytes` and `source-patch-bytes` use B over exact native JSON.stringify bytes of the internally detached admitted retained source/release/patch object. Those commitments preserve B2 opaque values, spelling, nulls and historical strings without projecting them through new fixed records; original base-envelope binding separately hashes the original stored UTF-8 string. A byte commitment is not interpreted as a canonical semantic projection. F's roundtrip equality/opaque preservation still applies; JSON hooks are never used to cleanse unadmitted input.

Presence: ABSENT means no target; commitment `{presence:"ABSENT",valueSha256:null}`. PRESENT commits the actual value with H(present-value,value), even when value is JSON null and the owning grammar permits null. There is no “absence uses null value” collapse. Eight current target payload grammars require typed nonnull objects when present; this does not reinterpret an opaque retained null.

## Complete domain graph

| Domain | Exact projected value / origin |
|---|---|
| manifest | ApprovedManifest, internally delivered by approved composition |
| intake | Intake, actual source-byte SHA/role/slot/name/length/sniffed type |
| bundle | Bundle with fixed role-ordered members and exact intake hashes/epochs |
| raw-text | `{text:<captured page.text>}` |
| raw-items | `{items:<captured RawItem array, original order>}` |
| page | PageContent; previewSha256 is plain SHA of actual captured preview JPEG bytes |
| raw-candidate | Exact admitted raw parser candidate computational record, original fields/arrays; private capture only. No public payload or receipt escape hatch; CandidateRef stores only its identity/kind/source/page references and digest. |
| raw-inventory | RawInventory exact aliases/page refs/candidate refs/issues, original emission ordering |
| run | Run; COMPLETE only from genuine full returned inventory; actually-used assets null/NOT_OBSERVED |
| anchor | Anchor; cross-source/qualifier references validated before review |
| review | Review, including operation-specific typed options, all normalized decisions, interpreted rows/effects and trusted review clock |
| model | Full internally admitted actual Model1 object; no clock normalization |
| initial-model-intent | Full expanded initial Model1 copy with **only** snapshots[0].confirmedAt replaced by null. This object is an intent projection, not an admitted stored Model1. Every other field and array order is exact. |
| proposal | Complete internally generated proposalVersion1 DTO, full ordered changes and unresolved array; no caller DTO |
| change | One exact ComputationalChange; typed target payloads, fixed before/after/evidence/match/history fields |
| present-value | Actual present target value, distinguishing explicit JSON null from absence |
| group-id | `{baseModelSha256,reviewSha256,memberIds,edges}` for one connected component; memberIds/edges sorted as below |
| groups | Groups including complete components, causal edges and induced deltas |
| revision-intent | `{proposalSha256,groupsSha256,approvedEffectIds,approvedGroupIds}`; whole proposal unresolved=[] and selected union validated |
| prepared | Prepared exact captured operation/base/run/review/groups/options-derived result/selection/clock data |
| accepted-payload | AcceptedPayload with actual final expanded model commitment and acceptance clock; no new receipt/envelope self-reference |
| evidence-context | Complete closed EvidenceContext embedded by F into its separately fixed receipt. It includes AcceptedPayload, not a digest of its own containing receipt. |

The new receipt body's exact F root may have its own fixed commitment after embedding; E does not define a competing receipt root or include it recursively in accepted-payload. Original/source strings and source/asset SHA values are not “proof of issuer.”

## Ordering and geometry

- ID-set fields (`*Ids`, except semantically ordered existing model/proposal arrays) and `runSha256s` are sorted/unique with duplicate input rejected, not silently deduplicated. Normalization happens in the private typed adapter before hashing.
- Bundle/source records use role order TIMETABLE then ACADEMIC_CALENDAR; revision has only calendar. InputKnowledge/sourceAliases/page refs use the same role order, then page ascending. Manifest components/assets sort by name/path. Typed count/rule/source-applicability collections sort by registerId/intake's role.
- Group members are ID sets; edges sort `(a,b,reason)` with a<b; group records sort groupId; induced deltas sort `(targetKind,targetId)`. These are metadata collections, not reordered computational change application.
- Raw items/candidates/issues preserve capture order. Review anchors/facts/coverage/omissions/decisions preserve their recorded order. Proposal changes and all admitted Model1/B2 opaque arrays remain exactly ordered. Array reordering is not object-key normalization.
- F64 uses DataView/setFloat64 big-endian byte representation of the captured finite binary64,16lowercasehex.0.1=`3fb999999999999a`;0.25=`3fd0000000000000`. No decimal rounding. Anchor bounds are normalized; raw positions retain raw coordinate representation/dimensions. No original-PDF inverse transform is invented.
- Explicit null is required wherever schema permits it; a missing key is an admission error, not an alternative canonical null. Unknown fixed fields reject. Opaque B2 values are intentionally not new E fixed records.

## Admission and proxies

The shape/schema does not authorize an operation. Public intent is admitted as ordinary data using descriptor-based construction; fixed fields are read from admitted descriptors, not arbitrary `.toJSON` hooks. For ordinary non-proxy objects this can reject getters/accessors without invoking them. JavaScript has no universal trap-free Proxy detector: reflective enumeration/descriptor queries can trigger proxy traps. Such behavior is not promised impossible. Trap/descriptor failures reject before promotion; no source/capability authority derives from the inspected DTO. The excluded compromised-same-origin arbitrary-code guarantee is unchanged. Preserve existing B2 admission semantics separately; do not advertise the research calculator as a hostile-object validator.

## Conformance inventory

`VECTORS_0_1_1.json` includes exact canonical strings, full framed UTF-8 hex and SHA-256 for the complete typed initial and revision context graphs plus comparison/negative shapes. `EXPECTED_DIGESTS.md` is the digest index. `VERIFY_CONTRACT.py` checks published preimages, supported shape rules/references and selected relational invariants; it is fixture verification, not a production authority/storage implementation. No transcript constitutes a real extraction receipt or a live stage.
