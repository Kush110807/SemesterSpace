#!/usr/bin/env python3
"""Bounded authored C1/C2 contract verifier. Never exercises a profile3/stage writer."""
from pathlib import Path
from hashlib import sha256
import json,sys
from jsonschema import Draft202012Validator
B=Path(__file__).resolve().parents[1]
F=B/'fixtures';N=0

def load(p):return json.loads(Path(p).read_text(encoding='utf8'))
def test(label,condition):
 global N
 if not condition:raise AssertionError(label)
 N+=1;print('PASS',label)
def js(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def C(v):
 if isinstance(v,dict):return '{'+','.join(C(k)+':'+C(v[k]) for k in sorted(v,key=lambda k:k.encode('utf-16-be')))+'}'
 if isinstance(v,list):return '['+','.join(C(w) for w in v)+']'
 return js(v)
def H(dom,v):return sha256(b'SA-AUTH/0.1.1:'+dom.encode()+b'\0'+C({'canonicalProtocolVersion':'SA-C14N/0.1.1','projectionProtocolVersion':'E-PROJ/0.1.1','value':v}).encode()).hexdigest()
def Bhash(dom,v):return sha256(b'SA-AUTH/0.1.1:'+dom.encode()+b'\0'+js(v).encode()).hexdigest()
def ptr(root,path):
 x=root
 for k in path.lstrip('/').split('/'):
  k=k.replace('~1','/').replace('~0','~');x=x[int(k)] if isinstance(x,list) else x[k]
 return x
def mut(x,path,v):
 a=x;ks=[k.replace('~1','/').replace('~0','~') for k in path.lstrip('/').split('/')]
 for k in ks[:-1]:a=a[int(k)] if isinstance(a,list) else a[k]
 if isinstance(a,list):a[int(ks[-1])]=v
 else:a[ks[-1]]=v

e_schema=load(B/'reference/E_AUTHORITY_EVIDENCE_0_1_1_UNCHANGED.schema.json')
f_schema=load(B/'reference/SA001_PROFILE3_EMBEDDED_0.1.1_PROPOSED.schema.json')
test('E81_UNCHANGED_F116_EXACT',len(e_schema['$defs'])==81 and len(f_schema['$defs'])==116 and all(f_schema['$defs'][k]==v for k,v in e_schema['$defs'].items()))
O=load(B/'F011_EXACT_TEST_VARIANTS_0_1_3_PROPOSED.json');V={v['variantId']:v for v in O['variants']}
test('VARIANT_UNIQUENESS_AND_UNRUN',len(V)==len(O['variants'])==O['variantCount']==152 and all(v['execution']=='UNRUN' for v in V.values()))
test('ONE_FUTURE_BUILDER_DEPENDENCY',O['exactFixtureAvailability']['FUTURE_SA_REVIEW_BUILDER_UNRUN']==1 and V['F-SA-40-profile3-upgrade-pending']['fixture']['candidate'].startswith('@fixtureBuilder'))
for id in ['F-SA-09-anchor','F-SA-09-review','F-SA-09-clock','F011-X-18-unknown-e-field']:
 v=V[id];mutation=v['fixture']['mutations'][0];base=load(F/'FRESH_DOCUMENT.json');receipt=base['release']['provenance']['receipts'][0]
 test('BASE_INTEGRITY_'+id,H('evidence-context',receipt['evidenceContext'])==receipt['evidenceContextSha256'])
 mut(base,mutation['path'],mutation['value']);test('STALE_REJECTS_P5c_'+id,H('evidence-context',receipt['evidenceContext'])!=receipt['evidenceContextSha256'] and v['expected']['phase']=='P5c' and v['expected']['code']=='PERSISTED_DATA_INVALID')
 sibling=V[id+'-digest-valid'];obj=load(F/sibling['fixture']['stored'].split('/')[-1]);rc=obj['release']['provenance']['receipts'][0];e=rc['evidenceContext'];p=e['prepared'];g=e['groups'];a=e['acceptedPayload'];
 test('EXTRA_RETAINED_'+id,ptr(obj,mutation['path'])==mutation['value'])
 test('REVIEW_DIGEST_'+id,H('review',e['review'])==p['reviewSha256']==g['reviewSha256'])
 test('GROUPS_DIGEST_'+id,H('groups',g)==p['groupsSha256'])
 test('PREPARED_DIGEST_'+id,H('prepared',p)==a['preparedSha256'])
 test('E_CONTEXT_COMMIT_'+id,H('evidence-context',e)==rc['evidenceContextSha256'])
 test('UNKNOWN_P6a_'+id,sibling['expected']['phase']=='P6a' and sibling['expected']['path']==mutation['path'] and sibling['expected']['setItemCount']==0)
# Closed E/F schemas reject the deliberately unknown field; P5c's integrity structural gate must not misclassify digest-valid unknowns as corruption.
schema=load(B/'reference/SA001_PROFILE3_EMBEDDED_0.1.1_PROPOSED.schema.json');val=Draft202012Validator(schema)
for sibling in [V[i+'-digest-valid'] for i in ['F-SA-09-anchor','F-SA-09-review','F-SA-09-clock','F011-X-18-unknown-e-field']]:
 obj=load(F/sibling['fixture']['stored'].split('/')[-1]);test('CLOSED_SCHEMA_INTENTIONALLY_UNKNOWN_'+sibling['variantId'],not val.is_valid(obj))
# Multiple-field selection: decoded JS keys sort by UTF16; paths encoded per RFC 6901.
v=V['F-SA-09-multiple-unknown-sorted'];x=load(F/'FRESH_DOCUMENT.json');
for m in v['fixture']['mutations']:mut(x,m['path'],m['value'])
unknowns=sorted([k for k in x if k not in ['schemaVersion','model','release']],key=lambda s:s.encode('utf-16-be'))
test('UNKNOWN_PATH_UTF16_AND_RFC6901',unknowns==['a~field','z/field'] and v['expected']['path']=='/a~0field')
# Correct base profile2 rev6 raw SHA and receipt binding, not rev8.
v=V['F011-X-16a'];base=load(F/'E2_REVISION_BASE.json');candidate=load(F/'LEGACY_UNATTESTED_UPGRADE.json');c=candidate['release']['provenance']['receipts'][0]['evidenceContext'];cons=v['fixture']['mutations'][0]['value'];b=c['acceptedPayload']['base']
test('F011X16a_MATCHING_MODEL_REVISION',base['model']['revision']==b['modelRevision']==cons['modelRevision']==6 and candidate['model']['revision']==7)
test('F011X16a_MATCHING_RAW_BYTES',sha256(js(base).encode()).hexdigest()==b['rawEnvelopeSha256']==cons['rawEnvelopeSha256'])
test('F011X16a_MATCHING_RECEIPT_STAGE',c['prepared']['stageId']==cons['stageId'] and c['prepared']['stageGeneration']==cons['stageGeneration'] and c['acceptedPayload']['receiptId']==cons['receiptId'])
test('F011X16a_OLD_MISMATCH_NEGATIVE',V['F011-X-16a-stale-base-negative']['expected']['code']=='SA_UPGRADE_CONSENT_STALE' and load(F/'E2_WITH_REAL_LEDGER_HISTORY.json')['model']['revision']==8)
# Actual untouched source computational probe results; script also reruns source on demand.
pure=load(B/'evidence/PURE_BINDINGS.json');s=load(F/'SECOND_SOURCE_SUPPORT.json');m=load(F/'MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json');r1,r2=m['release']['provenance']['receipts']
test('PURE_BUILDER_SOURCE_HASHES',pure['verifiedSha256Count']==32 and pure['sourceCommit']=='88d606ea940be945fa55124671c1a8deb57c7b04')
test('ACTUAL_PATCH_ONE_LINK',s['rawBuilderSourceRevisionPatch']==load(F/'SECOND_RAW_BUILDER_PATCH.json') and len(s['rawBuilderSourceRevisionPatch']['links'])==1)
test('C2_SOURCE_PATCH_COMMIT',Bhash('source-patch-bytes',s['rawBuilderSourceRevisionPatch'])==s['rawSourceRevisionPatchSha256']==r2['evidenceContext']['acceptedPayload']['sourceRevisionPatchSha256']==pure['builderRawPatchSha256'])
test('C2_ASSEMBLED_TWO_LINKS',len(s['assembledRetainedSourceRevision']['links'])==2 and all(m['release']['calendar']['sourceRevision'][k]==v for k,v in s['assembledRetainedSourceRevision'].items()))
test('C2_CONTEXT_RECOMMITTED',H('evidence-context',r2['evidenceContext'])==r2['evidenceContextSha256']==s['digestTable']['context2'])
test('C2_HISTORICAL_IMMUTABILITY',r1==s['baseEnvelopeAtRevision8']['release']['provenance']['receipts'][0] and m['release']['attendance']==s['baseEnvelopeAtRevision8']['release']['attendance'] and m['model']['snapshots']==s['baseEnvelopeAtRevision8']['model']['snapshots'])
c=load(F/'LEDGER_CORRECTION_ACTUAL_OUTPUT.json');v=V['F-SA-31-explicit-attendance']
test('FSA31_ACTUAL_API_BINDING',c['ok'] and c['code']=='DAY_CORRECTED' and c['model']['revision']==10 and v['fixture']['mutations'][0]['op']=='evaluateDayCloseCorrectionFromFixture')
test('FSA31_REAL_CORRECTION_CHAIN',len(c['release']['attendance']['records'])==4 and len(c['release']['attendance']['closedDays'])==2 and c['release']['provenance']['receipts']==m['release']['provenance']['receipts'])
print('C1_C2_RESEARCH_ASSERTIONS_PASSED',N)
print('ALL SA IMPLEMENTATION/STAGE/PROFILE3/BROWSER TEST VARIANTS UNRUN')
