// Pure, read-only research replay: no SA stage, no profile3 writer, no production edits.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath,pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';import {isDeepStrictEqual} from 'node:util';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const params=process.argv.slice(2);function arg(k){let i=params.indexOf(k);if(i<0||!params[i+1])throw Error('Missing '+k);return path.resolve(params[i+1]);}
const source=arg('--source-root'),out=arg('--out');if(fs.existsSync(out))throw Error('Output already exists');
const inputRoot=arg('--reference-root');const ref=JSON.parse(fs.readFileSync(path.join(inputRoot,'evidence/A_EXISTING_INTERFACES.json')));
const sha=x=>createHash('sha256').update(x).digest('hex');let checked=0;
for(const [name,expected] of Object.entries(ref.extractedSourceSha256)){const buf=fs.readFileSync(path.join(source,name));if(sha(buf)!==expected)throw Error(`Wrong pinned source ${name}`);checked++}
const read=name=>JSON.parse(fs.readFileSync(path.join(root,'fixtures',name),'utf8'));
const support=read('SECOND_SOURCE_SUPPORT.json'),actualBundle=read('MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json');
const {buildRevisionCandidate}=await import(pathToFileURL(path.join(source,'src/import/revision.js')));
const ledger=await import(pathToFileURL(path.join(source,'src/attendance/ledger.js')));
const got=buildRevisionCandidate({model:support.baseEnvelopeAtRevision8.model,proposal:support.proposal,acceptedChangeIds:['h6'],clock:support.acceptedAt});
if(!got.ok)throw Error('Builder declined: '+JSON.stringify(got.issues));
if(!isDeepStrictEqual(got.sourceRevisionPatch,support.rawBuilderSourceRevisionPatch))throw Error('Builder raw patch mismatch');
const builderSha=sha(Buffer.concat([Buffer.from('SA-AUTH/0.1.1:source-patch-bytes\0'),Buffer.from(JSON.stringify(got.sourceRevisionPatch))]));
if(builderSha!==support.rawSourceRevisionPatchSha256)throw Error('Builder raw commitment differs');
let expected=structuredClone(support.secondAcceptedModel);expected.revision=support.baseEnvelopeAtRevision8.model.revision;
if(!isDeepStrictEqual(expected,got.proposedModel))throw Error('Builder model differs');
if(!isDeepStrictEqual(actualBundle.release.calendar.sourceRevision.links[0],support.baseEnvelopeAtRevision8.release.calendar.sourceRevision.links[0]))throw Error('Old link lost');
if(!isDeepStrictEqual(actualBundle.release.provenance.receipts[0],support.baseEnvelopeAtRevision8.release.provenance.receipts[0]))throw Error('Old receipt lost');
if(actualBundle.release.provenance.receipts[1].evidenceContext.acceptedPayload.sourceRevisionPatchSha256!==builderSha)throw Error('Receipt binds wrong patch');
const request={date:'2026-11-02',dayKey:'ledger-day-2026-11-02-correction',expectedModelRevision:actualBundle.model.revision,correctionOfDayKey:'ledger-day-2026-11-02',confirmCompleteDay:true,confirmNoUnlistedMeetings:true,marks:actualBundle.release.attendance.records.map(t=>({occurrenceId:t.occurrenceId,registerId:t.registerId,disposition:t.occurrenceId.includes('t-lab')?'ATTENDED':'MISSED',note:'Synthetic authored correction'}))};
const clock={date:'2026-11-02',time:'15:00',timeZone:'Asia/Kolkata'};
if(typeof ledger.evaluateDayCorrection!=='undefined')throw Error('Unexpected evaluateDayCorrection export');
const correction=ledger.evaluateDayClose({model:actualBundle.model,journal:actualBundle.release.attendance,request,clock});
if(!correction.ok || correction.code!=='DAY_CORRECTED'||correction.proposedModel?.revision!==10)throw Error('Ledger correction mismatched '+JSON.stringify(correction.issues));
const released=structuredClone(actualBundle.release);released.attendance=correction.proposedJournal;
if(!isDeepStrictEqual(released.provenance.receipts,actualBundle.release.provenance.receipts))throw Error('Receipts changed');
const output={classification:'EXISTING_PURE_INTERFACE_OUTPUT_NOT_PROFILE3_OR_AUTHORITY',sourceCommit:ref.commit,verifiedSha256Count:checked,exportUsed:'evaluateDayClose',request,clock,code:correction.code,ok:correction.ok,issues:correction.issues,model:correction.proposedModel,release:released};
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'LEDGER_CORRECTION_ACTUAL_OUTPUT.json'),JSON.stringify(output,null,2)+'\n');
fs.writeFileSync(path.join(out,'PURE_BINDINGS.json'),JSON.stringify({classification:output.classification,sourceCommit:ref.commit,verifiedSha256Count:checked,builderRawPatchSha256:builderSha,builderRawPatchLinkCount:got.sourceRevisionPatch.links.length,assembledRetainedLinks:actualBundle.release.calendar.sourceRevision.links.length,firstReceiptPreserved:true,ledgerCode:correction.code,modelRevision:correction.proposedModel.revision},null,2)+'\n');
console.log(JSON.stringify({ok:true,pureOnly:true,checked,rawPatchSha256:builderSha,ledgerCode:correction.code,modelRevision:correction.proposedModel.revision}));
