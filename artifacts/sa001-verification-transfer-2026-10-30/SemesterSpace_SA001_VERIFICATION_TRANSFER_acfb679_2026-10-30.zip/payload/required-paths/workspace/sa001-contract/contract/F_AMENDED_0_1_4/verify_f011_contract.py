#!/usr/bin/env python3
"""READ-ONLY authored schema/graph/oracle/limit verifier. NOT profile3 runtime acceptance."""
from pathlib import Path
import json,hashlib,sys,subprocess
from jsonschema import Draft202012Validator
B=Path(__file__).resolve().parent
F=B/'fixtures'
CVER='SA-C14N/0.1.1'; PVER='E-PROJ/0.1.1'
def load(path):return json.loads(Path(path).read_text(encoding='utf8'))
def js(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def C(v):
    if isinstance(v,dict):return '{'+','.join(C(k)+':'+C(v[k]) for k in sorted(v,key=lambda k:k.encode('utf-16-be')))+'}'
    if isinstance(v,list):return '['+','.join(C(x) for x in v)+']'
    return js(v)
def sha(raw):return hashlib.sha256(raw if isinstance(raw,bytes) else raw.encode()).hexdigest()
def H(domain,v):return sha(('SA-AUTH/0.1.1:'+domain).encode()+b'\0'+C({'canonicalProtocolVersion':CVER,'projectionProtocolVersion':PVER,'value':v}).encode())
def Bhash(domain,v):return sha(('SA-AUTH/0.1.1:'+domain).encode()+b'\0'+v.encode())
schema=load(B/'reference/SA001_PROFILE3_EMBEDDED_0.1.1_PROPOSED.schema.json')
validator=Draft202012Validator(schema)
check_count=0

def test(name,ok):
    global check_count
    assert ok,name
    check_count+=1
    print('PASS',name)
# Fixture structural checks. These do not establish valid production reader/engine behavior.
for p in sorted(F.glob('*.json')):
    obj=load(p)
    if isinstance(obj,dict) and obj.get('schemaVersion')==3 and not p.name.startswith('UNKNOWN_VALID_'):
        errs=list(validator.iter_errors(obj));test('SCHEMA '+p.name,not errs)
old=load(F/'LEGACY_UNATTESTED_UPGRADE.json')
new=load(F/'MULTI_RECEIPT_SEMANTIC_AUTHORED_NOT_TRUSTED_STAGE.json')
support=load(F/'SECOND_SOURCE_SUPPORT.json')
rc1,rc2=new['release']['provenance']['receipts'];c2=rc2['evidenceContext']
receipt_bytes=(F/'REV2-authored.pdf').read_bytes()
test('SECOND_ACTUAL_SOURCE_BYTES',sha(receipt_bytes)==c2['sources'][0]['sha256']==support['rawPDF']['sha256'] and len(receipt_bytes)==support['rawPDF']['byteLength'])
test('E_CONTEXT_0_1_1_FRAMING',H('evidence-context',rc1['evidenceContext'])==rc1['evidenceContextSha256'] and H('evidence-context',c2)==rc2['evidenceContextSha256'])
test('DIFFERENT_DISTINCT_RECEIPTS',rc1['receiptId']!=rc2['receiptId'] and c2['sources'][0]['sha256']!=rc1['evidenceContext']['sources'][0]['sha256'])
test('TRUE_STAGED_MODEL_CHAIN',rc1['evidenceContext']['acceptedPayload']['newAppliedRevision']['modelRevision']==7 and support['baseEnvelopeAtRevision8']['model']['revision']==8 and new['model']['revision']==9)
test('PREVIOUS_RECEIPT_IMMUTABLE',rc1==support['baseEnvelopeAtRevision8']['release']['provenance']['receipts'][0] and rc1==old['release']['provenance']['receipts'][0])
test('LEDGER_PRESERVED',new['release']['attendance']==support['baseEnvelopeAtRevision8']['release']['attendance'] and len(new['release']['attendance']['records'])==2 and len(new['release']['attendance']['closedDays'])==1)
test('SNAPSHOTS_UNRESTAMPED',new['model']['snapshots']==support['baseEnvelopeAtRevision8']['model']['snapshots'])
test('SOURCE_CROSSWALK_AND_HISTORY',len(new['release']['calendar']['sourceRevision']['sourceHistory'])==1 and len(new['release']['calendar']['sourceRevision']['links'])==2 and new['release']['calendar']['sourceRevision']['links'][0]==support['baseEnvelopeAtRevision8']['release']['calendar']['sourceRevision']['links'][0])
test('REVISION_APPLICATIONS',len(new['release']['calendar']['appliedRevisions'])==2 and new['release']['calendar']['appliedRevisions'][0]==support['baseEnvelopeAtRevision8']['release']['calendar']['appliedRevisions'][0])
test('BASE_RAW_SHA',H('model',support['baseEnvelopeAtRevision8']['model'])==c2['groups']['baseModelSha256'] and sha(js(support['baseEnvelopeAtRevision8']))==c2['prepared']['base']['rawEnvelopeSha256'])
test('BASE_RELEASE_SHA',Bhash('retained-release-bytes',js(support['baseEnvelopeAtRevision8']['release']))==c2['prepared']['base']['priorReleaseSha256']==c2['acceptedPayload']['priorReleaseSha256'])
test('REVIEW_GROUP_PREPARED_MODEL_DIGEST',H('review',c2['review'])==c2['prepared']['reviewSha256']==c2['groups']['reviewSha256'] and H('groups',c2['groups'])==c2['prepared']['groupsSha256'] and H('prepared',c2['prepared'])==c2['acceptedPayload']['preparedSha256'] and H('model',new['model'])==c2['acceptedPayload']['acceptedModelSha256'])
test('RUN_AND_PAGE_RELATIONS',H('bundle',support['bundle'])==c2['runRecords'][0]['bundleSha256']==c2['review']['bundleSha256'] and H('run',c2['runRecords'][0])==c2['prepared']['runSha256s'][0] and H('raw-inventory',support['rawInventory'])==c2['runRecords'][0]['rawInventorySha256'] and H('page',c2['pageContents'][0])==c2['runRecords'][0]['returnedPages'][0]['pageContentSha256'])
test('RAW_TEXT_ITEMS',H('raw-text',{'text':support['rawPageText']})==c2['pageContents'][0]['rawTextSha256'] and H('raw-items',{'items':support['rawItems']})==c2['pageContents'][0]['rawItemsSha256'])
for a in c2['review']['anchors']:
    span=a['location'];test('QUOTED_ANCHOR_'+a['anchorId'],support['rawPageText'][span['startUTF16']:span['endUTF16']]==a['rawQuote'])
for cref,expected in zip(c2['candidateRefs'],support['rawInventory']['candidates']):test('RAW_CANDIDATE_'+cref['candidateId'],cref==expected)
test('REAL_SECOND_EFFECT_NOT_FIRST_DUPLICATE',c2['prepared']['approvedEffectIds']==['h6'] and c2['prepared']['effects'][0]['change']['after']['date']=='2026-11-06' and c2['prepared']['effects'][1]['adoption']=='NOT_APPLIED' and new['model']['schedule']['holidays']==[{'date':'2026-11-04','label':'Holiday'},{'date':'2026-11-06','label':'Holiday'}])
test('RECEIPT_ACCEPTANCE_CLOCK_AFTER_LEDGER',c2['review']['reviewConfirmedAt']['time']=='14:10' and c2['prepared']['computationClock']['time']=='14:11' and c2['acceptedPayload']['acceptedAt']['time']=='14:12' and new['release']['attendance']['closedDays'][0]['confirmedAt']['time']=='14:00')
# Published initial E context vectors were checked in the previous package and remain independent of this authored second source.
fi=load(F/'CAPACITY_FIXTURES_INDEX.json')
for row in fi['receipt']:
    obj=load(F/row['file']);test('RECEIPT_UTF8_'+str(row['bytes']),len(js(obj['release']['provenance']['receipts'][0]).encode())==row['bytes'])
for row in fi['envelope']:
    obj=load(F/row['file']);test('ENVELOPE_UTF8_'+str(row['bytes']),len(js(obj).encode())==row['bytes'])
both=load(F/'BOTH_CAPS_EXCEEDED.json');test('BOTH_LIMITS_REAL',len(js(both).encode())==2097153 and len(js(both['release']['provenance']['receipts'][0]).encode())==524289)
test('OPAQUE_B2_UNKNOWN_FIELDS_PRESERVED',validator.is_valid(new) and validator.is_valid(both))
# Type schema declarations are closed and validate an accepted discriminated read projection.
read_schema=load(B/'F011_TYPED_LOAD_RESULT_0_1_2_PROPOSED.schema.json');rd=Draft202012Validator(read_schema)
saved={'model':new['model'],'release':new['release'],'persistence':{'status':'SAVED','code':'LOAD_OK','reason':'NONE','path':None,'message':'valid e3'},'profile3':{'envelopeVersion':3,'rewriteAllowed':True,'rawEnvelopeSha256':sha(js(new))}}
readonly={'model':both['model'],'release':both['release'],'persistence':{'status':'SAVED_READ_ONLY','code':'PERSISTED_REWRITE_UNSUPPORTED','reason':'RETAINED_LIMIT_EXCEEDED','path':'/release/provenance/receipts/0','message':'exceeds receipt cap'},'profile3':{'envelopeVersion':3,'rewriteAllowed':False,'rawEnvelopeSha256':sha(js(both))}}
quarantine={'model':None,'release':None,'persistence':{'status':'QUARANTINED','code':'UNSUPPORTED_PERSISTED_VERSION','reason':'VERSION','path':'/schemaVersion','message':'unknown profile'},'profile3':None}
for name,res in [('SAVED',saved),('READ_ONLY',readonly),('QUARANTINED',quarantine)]:test('TYPED_RESULT_'+name,rd.is_valid(res))
# Every family and scalar expectation field specified; none is a runtime result.
oracle=load(B/'F011_EXACT_TEST_VARIANTS_0_1_3_PROPOSED.json')
vs=oracle['variants'];test('ORACLE_UNIQUE_AND_NUMERIC',len(vs)==len(set(v['variantId'] for v in vs))==oracle['variantCount'] and all(isinstance(v['expected']['getItemCount'],int) and isinstance(v['expected']['setItemCount'],int) and isinstance(v['expected']['candidateGetterInvocations'],int) and v['execution']=='UNRUN' for v in vs))
test('ORACLE_ALL_FAMILIES',all('F-SA-'+str(i).zfill(2) in set(v['originalCase'] for v in vs) for i in range(1,47)))
test('ORACLE_ALL_PHASES',all(p in {v['expected']['phase'] for v in vs} for p in ['P0','P1','P2','P3','P4','P5a','P5b','P5c','P6a','P6b','P7','P8a','P8b','P8c','P9','P10','P11']))
print('FIXTURE_CHECKS_PASSED',check_count)
print('IMPORTANT: READ-ONLY SCHEMA/GRAPH TESTS ONLY. New coordinator/stage/browser/reader/12-24 histories remain UNRUN.')
