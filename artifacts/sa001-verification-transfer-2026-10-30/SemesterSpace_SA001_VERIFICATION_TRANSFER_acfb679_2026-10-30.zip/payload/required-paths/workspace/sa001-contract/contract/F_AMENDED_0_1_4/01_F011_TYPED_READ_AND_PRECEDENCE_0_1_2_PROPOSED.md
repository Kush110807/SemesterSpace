# A-F011-01 — Exact profile3 load/controller ABI and precedence

**Status: PROPOSED / READ-ONLY CONTRACT RESEARCH.** This document supplements the embedded 0.1.1 E/F schema without changing any of the accepted B2 0.2.3/OMR-01 code, external legacy status messages, or history semantics. It does **not** enable a writable profile3.

## 1. Discriminated load result (only recognized envelope3)

```ts
type Sha256 = string;      // /^([a-f0-9]{64})$/
type JsonPointer = string; // RFC6901 pointer, including root "" for root itself; / for full-envelope limit path by explicit contract

type Load3Writable = {
  model: Model1;
  release: Release2;
  persistence: {
    status: 'SAVED'; code: 'LOAD_OK'; reason: 'NONE';
    path: null; message: string;
  };
  profile3: {
    envelopeVersion: 3;
    rewriteAllowed: true;
    rawEnvelopeSha256: Sha256; // sha256 of exact originally read UTF-8 raw-string bytes
  };
};

type Load3ReadOnly = {
  model: Model1 & UnknownNestedRetainedJson; // actual bytes/keys; known model core checked at P5c
  release: Release2 & UnknownNestedRetainedJson;
  persistence: {
    status: 'SAVED_READ_ONLY';
    code: 'PERSISTED_REWRITE_UNSUPPORTED';
    reason: 'UNRECOGNIZED_RETAINED_FIELD' | 'RETAINED_LIMIT_EXCEEDED';
    path: JsonPointer;          // exact FIRST unknown/limit location
    message: string;
  };
  profile3: {
    envelopeVersion: 3;
    rewriteAllowed: false;
    rawEnvelopeSha256: Sha256;
  };
};

type Load3Quarantined = {
  model: null;
  release: null;
  persistence: {
    status: 'QUARANTINED';
    code: 'STORAGE_READ_FAILED' | 'PERSISTED_DATA_INVALID' |
          'UNSUPPORTED_PERSISTED_VERSION' | 'PERSISTED_REWRITE_UNSUPPORTED';
    reason: 'THREW' | 'JSON_OR_ROOT' | 'VERSION' |
            'VERSION_SHAPE' | 'CORE_INVALID' | 'UNSUPPORTED_COMBINATION';
    path: null | JsonPointer;
    message: string;
  };
  profile3: null;
};

type Load3 = Load3Writable | Load3ReadOnly | Load3Quarantined;
```

For the quarantine union, permitted `(code,reason,path)` combinations are exactly: `(STORAGE_READ_FAILED,THREW,null)`, `(PERSISTED_DATA_INVALID,JSON_OR_ROOT,null)`, `(PERSISTED_DATA_INVALID,VERSION_SHAPE,null)`, `(PERSISTED_DATA_INVALID,CORE_INVALID,null)`, `(UNSUPPORTED_PERSISTED_VERSION,VERSION,<tag pointer>)`, and `(PERSISTED_REWRITE_UNSUPPORTED,UNSUPPORTED_COMBINATION,'/release')`. **No** `SAVED_READ_ONLY` for corrupt, unsupported-future, or unadmitted-combination data. A loaded unsupported envelope4 does not expose its body. E3 core-valid unknown fields and oversized retained data **do** expose complete retained model/release as read-only, never silently projected down.

**Legacy compatibility is structural as well as behavioral.** When `loadModel` encounters envelope1 or envelope2, return the currently accepted B2/OMR shape and statuses verbatim; do **not** graft `code`, `reason`, `path` or `profile3` onto e1/e2 results, nor change `NOT_SAVED` and `QUARANTINED` behavior for those records. Missing key has the unchanged legacy `NOT_SAVED` shape, not `Load3`. If a future version is encountered, use the new e3-aware dispatcher only to classify its unsupported outer version and keep existing e1/e2 outcomes unchanged.

`profile3.rawEnvelopeSha256` is a **digest**, not raw bytes or a capability. Keep exact raw JSON text private to storage/composition until the next single-command reread; do not send it to UI, persist it to a secondary key, or interpret the digest as permission to write. The controller must reread and classify current storage **on every authorized write**, compare live private binding plus exact raw digest, and not treat public profiles/digests/reloaded receipts as private stage authority. The controller's in-memory accepted state swaps only on acknowledged successful commit. A same-digest reread alone is not an atomic CAS across tabs.

## 2. Controller / UI projection for `SAVED_READ_ONLY`

```ts
type Profile3Display = {
  mode: 'personal';
  model: Model1; release: Release2; // retained historical inspection, never mutating storage
  persistenceStatus: 'SAVED_READ_ONLY';
  reason: 'UNRECOGNIZED_RETAINED_FIELD' | 'RETAINED_LIMIT_EXCEEDED';
  path: string;
  canPersistMutation: false;
  canReviewHistory: true;
  canResumeSourceStage: false;
  canReuseUpgradeConsent: false;
  canClaimExportImplemented: false;
};
```

Set every controller pathway that would persist (`attendance`, `correction`, `snapshot`, `calendar acceptance`, `thresholds`, `commitments`, `source revision`, `reset/downgrade`) to an upfront read-only guard with typed result `PERSISTED_REWRITE_UNSUPPORTED` and retained `reason/path`; **0 setItem calls, no accepted-memory promotion**. Never overwrite the stored key to obtain a usable state. In read-only mode the UI may display existing model and release, historical inspection and an explanation, not active completion widgets purporting to save. The old `Today`/`Calendar`/`Updates`/`Setup` four destinations remain navigable as inspection only. Do not offer a “repair” or “reset” that discards receipt history. There is no implemented exporter or backup. If evidence text is available in retained receipts, render it as retained quotation; original assets/previews are still `NOT_RETAINED`, and no source stage handles/capability registry survive reload. Calling `onRefresh` cannot silently convert `SAVED_READ_ONLY` to `SAVED`; a trusted reload must reclassify current bytes before any write.

**Separate scoped interface requirement:** adding this *proposed* new status requires existing controller/UI/shared type coordination within A's already proposed production ownership. If the nine-file scope does not include the existing shared status union or all persistence mutation entrypoints, A must issue an explicit scope delta before implementation. No new export/backup tool is silently authorized.

## 3. Single first-match classifier

The new profile3 writes use the existing one-key storage. The phase order is frozen: **P0 invalid options** (read count 0), **P1 read throws**, **P2 expected-exists but absent**, **P3 malformed raw JSON/root**, **P4 well-formed unsupported version discriminator**, **P5a supported-but-unadmitted combination**, **P5b absent/ill-typed/zero/negative/malformed version or required component**, **P5c other corrupt core** (including broken digest/graph/history), **P6a first unknown fixed record**, **P6b first retained exceeded cap**, **P7 optimistic conflicts**, **P8a omitted explicit release**, **P8b detached hostile/non-JSON/core-invalid candidate**, **P8c new receipt exceeds per-receipt cap**, **P9 full serializer throw, nonstring, invalid JSON, roundtrip mismatch or total new envelope limit**, **P10 `setItem` throws**, **P11 returns**. P0/P1/P2/P3 and B2 semantics remain as previously accepted; P4 uses the recognized version registry, not error-string parsing.

**P4 version tag scan:** `/schemaVersion` first; on supported outer3, `/model/schemaVersion`, `/release/version`, `/release/attendance/version`, `/release/calendar/version`, `/release/calendar/sourceRevision/version` if present, `/release/provenance/version`, then receipts in **ascending array index**, and for each receipt `receiptVersion`, `authorityProtocolVersion`, `canonicalProtocolVersion`, `provenanceProtocolVersion`, `evidenceContext/projectionProtocolVersion`. Do not inspect any body when the outer version is well-formed-but-unsupported (e.g. envelope4 with no model/release). Well-formed future semver-protocol strings or positive integer version tags route to P4; string `'1'`, null, negative, 0, malformed protocol string route P5b. Scan known discriminators before P5b irrespective of a second malformed tag. E's software component/reader/parser/OCR labels are retained **observations**, not P4 profile tags.

**Old/new table** (apply the frozen B2 0.2.3 classifier literally to outer1/2):

| Stored combination | First branch | Code / reason | Path | Read exposure |
|---|---|---|---|---|
| e1/model1/no release | B2 admitted | legacy `SAVED` | — | original Model1; journal fabricated only in-memory per B2 |
| e1/model1/release1 | B2 P5a | `PERSISTED_REWRITE_UNSUPPORTED / UNSUPPORTED_COMBINATION` | `/release` | no rewrite |
| e1/model1/release2 | B2 P4 | `UNSUPPORTED_PERSISTED_VERSION / VERSION` | `/release/version` | no rewrite |
| e2/model1/release1 | B2 admitted | legacy `SAVED` | — | full original Model1/Release1 |
| e2/model1/release2/prov1 | B2 P4 | `UNSUPPORTED_PERSISTED_VERSION / VERSION` | `/release/version` | no rewrite |
| e2/release1 plus unknown `provenance` | B2 P6 | `PERSISTED_REWRITE_UNSUPPORTED / UNRECOGNIZED_RETAINED_FIELD` | `/release/provenance` | no rewrite |
| e3/model1/release1 | P5a | `PERSISTED_REWRITE_UNSUPPORTED / UNSUPPORTED_COMBINATION` | `/release` | quarantine, do not upgrade |
| e3/model1/release2/prov1 | P5c/P6 depending content, else P7…P11 | admitted if exact graph valid | — | `SAVED` |
| e3/prov missing/null/bad version | P5b | `PERSISTED_DATA_INVALID / VERSION_SHAPE` | null | quarantine |
| e3/prov2 | P4 | `UNSUPPORTED_PERSISTED_VERSION / VERSION` | `/release/provenance/version` | quarantine |
| e3/prov1/receipt2 | P4 | `UNSUPPORTED_PERSISTED_VERSION / VERSION` | `/release/provenance/receipts/0/receiptVersion` | quarantine |
| e3/prov1/E-PROJ/0.2.0 | P4 | `UNSUPPORTED_PERSISTED_VERSION / VERSION` | `/release/provenance/receipts/0/evidenceContext/projectionProtocolVersion` | quarantine |
| e4/absent body | P4 | `UNSUPPORTED_PERSISTED_VERSION / VERSION` | `/schemaVersion` | quarantine, do not access body |
| e3 core valid but unknown fixed field | P6a | `PERSISTED_REWRITE_UNSUPPORTED / UNRECOGNIZED_RETAINED_FIELD` | first sorted JSON Pointer | `SAVED_READ_ONLY` |
| e3 core valid but over retained size | P6b | `PERSISTED_REWRITE_UNSUPPORTED / RETAINED_LIMIT_EXCEEDED` | first violating receipt pointer, else `/` | `SAVED_READ_ONLY` |

**Important typed-schema split:** The associated `Profile3LoadReadOnly` JSON Schema has `model`/`release` as retained JSON objects rather than strict `$ref` to the closed writable subrecords. This is intentional: a valid-core P6a record contains an unknown nested fixed key that strict closed `$defs` must reject on writing. The read-only result is only admissible after an independent P5c known-field/semantic validator succeeds and P6a/P6b classifies the retained bytes; the loose read-result shell is NOT a substitute for core validation. `Load3Writable` still uses strict admitted Model1/Release2 refs.

**P5c versus P6a:** JSON Schema `additionalProperties:false` alone cannot classify unknown-retained fields as P6a without also rejecting otherwise valid core. Use two logically separate checks: validate known required fields + relational/digest commitments without projecting away unknown fields or changing input; then detect unknown fixed fields in preserved records. A record with both unknown field and corrupt recognized field is P5c (not read-only). Preserve B2 `links[].value` opaque JSON entirely, including optional omission and `null` distinction. Do not infer stage authority from persisted E metadata or retained receipts.

**P6b precise order:** only for otherwise valid, recognized e3. First check *retained per-receipt serialized JSON UTF-8 bytes* by ascending zero-based receipt index; first size greater than **524288** returns pointer `/release/provenance/receipts/<i>` (no history pruning). Only if all receipts pass, check the exact retained full raw UTF-8 envelope serialization bytes, limit **2097152**, result path `/`. At exact equality admit. A record with valid core, first-unknown-field AND oversize is P6a. Future/malformed version or invalid digest AND oversize stops at P4/P5, never P6. Candidate per-receipt limits P8c, total proposed serialized envelope cap P9, after all earlier persisted fences/consent checks. A hostile serializer that changes records must fail semantic roundtrip P9 *before* applying actual envelope limit. The underlying localStorage quota may be smaller due to UTF-16 accounting and unrelated origin data; limit admission is **not** quota success.

**P7:** EXPECTED_EMPTY, expectedModelId mismatch, expectedRevision mismatch, or trusted legacy-upgrade base-byte drift after applicable stored fences. The last is controller-private and must not be reclassified as ordinary model mismatch; use the existing conflict-family code `PERSISTED_CONFLICT/BASE_BYTES_CHANGED` when the storage operation is attempted, and controller `SA_UPGRADE_CONSENT_STALE/BASE_BYTES_CHANGED` when private consent invalidates earlier. P8a must reject explicit-release omission on recognized source-e3 or trusted target-e3 with `CANDIDATE_INVALID/CORE_INVALID`, path `/release` and **no candidate getters**, including no-options and fresh MANUAL/DOCUMENT target. Existing e2 OMR omission guard stays unchanged. Omission never creates an empty release2.

## 4. Postwrite uncertainty and reload

All accepted domain changes plus receipt append are serialized once and passed to exactly one `setItem`. `setItem` which returns normally is P11 `SAVED/SAVE_OK`; only after this acknowledgment may controller swap accepted memory. A conforming throw is P10 `STORAGE_WRITE_FAILED/THREW`, one attempt, no compensating write; raw bytes unchanged under conforming-storage assumption. A synthetic commit-then-throw can change physical bytes despite a throw: controller must report `SA_COMMIT_UNCERTAIN/STORAGE_ACK_UNCERTAIN`, freeze stage, require explicit authoritative reload, and never retry the old stage automatically. A failure in UI/controller acknowledgment **after** successful `setItem` similarly yields `SA_COMMIT_UNCERTAIN/POST_WRITE_ACK_FAILED` when detectable, no second write; new load returns historical receipt only, zero source authority handles/consent. Typed controller results are `{status:'REJECTED'|'ACCEPTED'|'UNCERTAIN',code: SA_* family,reason:fixed enum,path:null}`. Unlike storage P0–P11, the controller result is not derived from arbitrary thrown exception text. No inferred `ALREADY_APPLIED` from receiptId match.

Normal reload of a core-valid e3 may restore the durable model, release and historical receipts, **not** live stage/issued capability/one-use consent/reader inventory. A successful e3 read does not turn historical evidence into current authorization. The loaded dataset can initiate new user-confirmed ordinary operations only through the trusted controller path. `SAVED_READ_ONLY` specifically prohibits all persistence mutations and remains inspectable. No backup/export/migration functionality exists merely because raw bytes were readable.

## 5. Exclusion boundary

Single-controller ID/revision/raw-envelope hash/handle matching is **not writer serialization**, same-ID/revision ABA prevention, a migration tool, a durable idempotency-receipt system or proof of crash-proof persistence. Pre-B2 tabs cannot be forced to cooperate. The new typed read-only projection and write gate are **proposed** to the A-owned integration and relevant existing UI/shared types, not a new repository service. No production changes, database decision, exporter or tenth path are authorized.
