"""Research artifact generator: closed JSON schemas only, no authority implementation."""
import json,copy
from pathlib import Path
D={}
def ref(n):return {'$ref':'#/$defs/'+n}
def arr(t):return {'type':'array','items':t}
def en(*v):return {'enum':list(v)}
def const(v):return {'const':v}
def nullable(t):return {'anyOf':[t,{'type':'null'}]}
def obj(**p):return {'type':'object','properties':p,'required':list(p),'additionalProperties':False}
def rec(n,**p):D[n]=obj(**p);return ref(n)
S={'type':'string'};ID={'type':'string','minLength':1,'maxLength':256};NOTE={'type':'string','minLength':1}
N={'type':'integer','minimum':0,'maximum':9007199254740991};P={'type':'integer','minimum':1,'maximum':9007199254740991}
B={'type':'boolean'};H={'type':'string','pattern':'^[a-f0-9]{64}$'};DAY={'type':'string','format':'date','pattern':'^\\d{4}-\\d{2}-\\d{2}$'}
TM={'type':'string','pattern':'^(?:[01]\\d|2[0-3]):[0-5]\\d$'};ROLE=en('TIMETABLE','ACADEMIC_CALENDAR');OP=en('INITIAL_IMPORT','CALENDAR_REVISION')
F64={'type':'string','pattern':'^[0-9a-f]{16}$'}
IDS={'type':'array','items':ID,'uniqueItems':True}
Clock=rec('Clock',date=DAY,time=TM,timeZone=const('Asia/Kolkata'))
Item=rec('RawItem',text=S,xF64=F64,yF64=F64,wF64=F64,hF64=F64,confidenceF64=nullable(F64))
Issue=rec('Issue',issueId=ID,code=ID,path=nullable(S),message=S,severity=en('ERROR','WARNING','UNKNOWN'),candidateIds=IDS,anchorIds=IDS)
ManifestComponent=rec('ManifestComponent',name=ID,version=nullable(S),sha256=nullable(H),basis=en('SOURCE_PACKAGE_BYTES','LOCKFILE_PIN','AVAILABLE_ASSET_BYTES','UNKNOWN'))
ManifestAsset=rec('ManifestAsset',path=ID,sha256=H)
Manifest=rec('ApprovedManifest',manifestId=ID,origin=const('COMPOSITION_APPROVED_ARTIFACT'),sourceRef=nullable(S),components=arr(ManifestComponent),availableAssetManifestSha256=H,availableAssets=arr(ManifestAsset))
Intake=rec('Intake',intakeId=ID,role=ROLE,slotEpoch=N,fileName=S,sha256=H,byteLength={'type':'integer','minimum':1,'maximum':15728640},mime=en('application/pdf','image/png','image/jpeg'))
Bundle=rec('Bundle',operation=OP,members=arr(rec('BundleMember',role=ROLE,intakeId=ID,intakeSha256=H,slotEpoch=N)))
Observation=rec('Observation',identityBasis=const('APPROVED_AVAILABLE_MANIFEST'),manifestSha256=H,actuallyUsedAssetSubset=const(None),usageKnowledge=const('NOT_OBSERVED'),reason=const('UNCHANGED_READER_DOES_NOT_REPORT_ACTUALLY_USED_ASSET_SUBSET'))
Failure=rec('Failure',code=ID,message=S)
InputKnowledge=rec('InputKnowledge',intakeId=ID,knowledge=en('RETURNED_COMPLETE','DISCOVERED_ONLY','UNKNOWN'),declaredPageCount=nullable(P),returnedPageNumbers={'type':'array','items':P,'uniqueItems':True},failedPageNumbers=const(None),failedPageKnowledge=const('NOT_OBSERVED'))
PageContent=rec('PageContent',runId=ID,intakeId=ID,pageNumber=P,method=en('PDF_TEXT','OCR'),width=P,height=P,rawTextSha256=H,rawItemsSha256=H,previewSha256=H,previewKind=const('JPEG_PREVIEW'))
RawPage=rec('RawPage',content=PageContent,rawText=S,rawItems=arr(Item))
PageRef=rec('PageRef',intakeId=ID,pageNumber=P,pageContentSha256=H)
SourceAlias=rec('SourceAlias',intakeId=ID,runId=ID,computationalSourceId=ID)
CandidateRef=rec('CandidateRef',candidateId=ID,intakeId=ID,kind=ID,rawRecordSha256=H,pageNumbers={'type':'array','items':P,'uniqueItems':True})
RawInventory=rec('RawInventory',runId=ID,sourceAliases=arr(SourceAlias),pages=arr(PageRef),candidates=arr(CandidateRef),issues=arr(Issue))
ReaderConfig=rec('ReaderConfig',profileVersion=const('PINNED_READER_PROFILE/1'),ocrLanguage=const('eng'),ocrOem=const(1),ocrPsm=const('3'),preserveInterwordSpaces=const('1'),cacheMethod=const('none'),imagePreprocessor=const('textCanvas'),pdfPreprocessor=const('NONE'),pdfTextThreshold=const(30))
ExtractionArguments=rec('ExtractionArguments',section=nullable(ID),subgroup=nullable(S),programmingGroup=nullable(S))
Run=rec('Run',extractionArguments=ExtractionArguments,runId=ID,jobEpoch=N,bundleSha256=H,observation=Observation,readerConfig=ReaderConfig,decodeState=en('COMPLETE','FAILED','CANCELLED','UNSUPPORTED','OPAQUE_FAILURE'),semanticState=en('CANDIDATES','PARTIAL','UNSUPPORTED'),inputKnowledge=arr(InputKnowledge),returnedPages=arr(PageRef),rawInventorySha256=nullable(H),failure=nullable(Failure))
Bbox={'type':'array','items':F64,'minItems':4,'maxItems':4}
Location=rec('TextLocation',channel=en('PAGE_TEXT','ITEMS_JOIN'),startUTF16=N,endUTF16=N)
Anchor=rec('Anchor',anchorId=ID,intakeId=ID,runId=ID,pageNumber=P,role=en('CONTENT','HEADER','LEGEND','FOOTNOTE','COHORT','TIME','PUBLICATION','CARRIER'),mode=en('TEXT','VISUAL'),bboxF64=nullable(Bbox),rawQuote=nullable(S),location=nullable(Location),visualSha256=nullable(H),qualifierAnchorIds=IDS,nullBoxReason=nullable(NOTE))
Scope=rec('Scope',institution=S,academicYear=S,term=en('ODD','EVEN'),degreeGroup=en('UG','PG','PHD','OTHER'),semesterNumber=P,programme=S,section=ID,subgroup=nullable(S),programmingGroup=nullable(S),isTeachingAssistant=nullable(B),effectiveStart=DAY,effectiveEnd=DAY,dateOrder=en('DMY','MDY','YMD','UNRESOLVED'),dateOrderReason=NOTE,calendar=const('GREGORIAN'),timeZone=const('Asia/Kolkata'))
Meaning=rec('Meaning',kind=en('SESSION','HOLIDAY','NON_TEACHING','REPLACEMENT','WORKING_DAY_NOTICE','TEACHING_BOUNDARY','EXAM_WINDOW','ACADEMIC_ACTIVITY','VACATION','UNKNOWN'),polarity=en('AFFIRMATIVE','NEGATED','WITHDRAWN','UNKNOWN'),dateForm=en('SINGLE','SET','INTERVAL','MOVE','UNKNOWN'),dates={'type':'array','items':DAY,'uniqueItems':True},fromDate=nullable(DAY),toDate=nullable(DAY),allDay=nullable(B),startTime=nullable(TM),endTime=nullable(TM),targetIds=IDS)
Correction=rec('Correction',kind=en('TRANSCRIPTION','INTERPRETATION'),text=S,reason=NOTE)
Fact=rec('Fact',factId=ID,sourceCandidateIds=IDS,anchorIds=IDS,decision=en('REPRESENT','EXCLUDE','KEEP_EXISTING','UNRESOLVED'),correction=nullable(Correction),meaning=Meaning,effectIds=IDS,reason=NOTE)
Coverage=rec('Coverage',intakeId=ID,pageNumber=P,area=en('OBLIGATIONS','SUBSTITUTIONS','NON_TEACHING','BOUNDARIES_SCOPE'),decision=en('ENTERED','NONE_APPLICABLE','UNRESOLVED'),factIds=IDS,reason=NOTE)
Omission=rec('Omission',omissionId=ID,intakeId=ID,sourceCandidateId=nullable(ID),priorLinkRef=nullable(ID),missingMaterial=nullable(NOTE),anchorIds=IDS,decision=en('KEEP_EXISTING','NO_APPLICABLE_EFFECT','REPRESENTED','UNRESOLVED'),factIds=IDS,reason=NOTE)
IssueDecision=rec('IssueDecision',issueId=ID,decision=en('BLOCKING','ACKNOWLEDGED','RESOLVED_BY_DECISION'),factIds=IDS,reason=NOTE)
Counts=rec('Counts',attended=N,held=N)
Rule=rec('Rule',registerId=ID,requiredBps={'type':'integer','minimum':1,'maximum':10000},personalMinBps=nullable({'type':'integer','minimum':1,'maximum':10000}),bufferBps={'type':'integer','minimum':0,'maximum':10000})
CountEntry=rec('CountEntry',registerId=ID,attended=N,held=N)
Preferences=rec('Preferences',candidateStart=DAY,candidateEnd=DAY,preferredDates={'type':'array','items':DAY,'uniqueItems':True},requestedDays=N,notes=S)
Replacement=rec('Replacement',date=DAY,weekday={'type':'integer','minimum':1,'maximum':7},confirmed=B)
SourceApplicability=rec('SourceApplicability',intakeId=ID,institutionConfirmed=B,termConfirmed=B,cohortConfirmed=B,reason=NOTE)
SnapshotSettings=rec('SnapshotSettings',date=DAY,confirmed=B,completeToday=B,counts=arr(CountEntry))
# No arbitrary options bag. Private IDs/display metadata/clock are created by coordinator.
InitialSettings=rec('InitialSettings',horizonConfirmed=B,sourceApplicability=arr(SourceApplicability),protectedSubjectIds=IDS,registerRules=arr(Rule),snapshot=SnapshotSettings,preferences=Preferences,replacements=arr(Replacement),holidayTeachingDates={'type':'array','items':DAY,'uniqueItems':True})
InitialOptions=rec('InitialOptions',operation=const('INITIAL_IMPORT'),modelId=ID,sourceLabel=S,preparedOn=DAY,scope=Scope,settings=InitialSettings,clockPolicy=const('ONLY_NEW_INITIAL_SNAPSHOT_CONFIRMEDAT'))
RevisionOptions=rec('RevisionOptions',operation=const('CALENDAR_REVISION'),scope=Scope,legacySourceReviewed=B,legacySourceNote=S,priorSourceRevisionSha256=H,sourceCoverageConfirmed=B,coverageNote=NOTE)
Options={'oneOf':[InitialOptions,RevisionOptions]}
Review=rec('Review',reviewId=ID,revision=N,operation=OP,runIds=IDS,bundleSha256=H,rawInventorySha256=H,scope=Scope,anchors=arr(Anchor),facts=arr(Fact),coverage=arr(Coverage),omissions=arr(Omission),issueDecisions=arr(IssueDecision),options=Options,reviewerKind=const('LOCAL_OPERATOR'),issuerStatus=const('UNVERIFIED'),reviewConfirmedAt=Clock)
Session=rec('Session',id=ID,registerId=ID,date=DAY,start=TM,end=TM,weight=P,protected=B,cancelled=B,origin=en('weekly','extra'),templateId=nullable(ID))
Event=rec('Event',id=ID,title=S,cancelled=B,sessionId=nullable(ID),date=nullable(DAY),start=nullable(TM),end=nullable(TM))
Holiday=rec('Holiday',date=DAY,label=S);Boundary=rec('Boundary',date=DAY)
TargetValue={'oneOf':[Session,Event,Holiday,Replacement,Boundary]}
# Full values at the computational boundary are typed; stored commitments distinguish absence from present null by tagged digest.
PresenceValue={'oneOf':[obj(presence=const('ABSENT'),value=const(None)),obj(presence=const('PRESENT'),value=TargetValue)]}
TargetCommitment=rec('TargetCommitment',presence=en('ABSENT','PRESENT'),valueSha256=nullable(H))
Evidence=rec('LegacyEvidence',sourceId=ID,page=P,excerpt=NOTE,basis=en('DIRECT_SOURCE','EXPLICIT_CANCELLATION','REVIEWED_OFFICIAL_CORRECTION'))
KINDS=('ADD_SESSION','EDIT_SESSION','CANCEL_SESSION','ADD_HOLIDAY','REMOVE_HOLIDAY','REPLACE_PATTERN','UPSERT_EVENT','TEACHING_END')
Change=rec('ComputationalChange',changeId=ID,kind=en(*KINDS),occurrenceId=nullable(ID),before=nullable(TargetValue),after=nullable(TargetValue),evidence=Evidence,match=en('EXACT_ID','REVIEWED_CROSSWALK','ADDED','AMBIGUOUS'),affectsConfirmedHistory=B)
ProposalSource=rec('ProposalSource',sha256=H,fileName=S,role=const('ACADEMIC_CALENDAR'),coverage=en('COMPLETE','PARTIAL','UNSUPPORTED'),section=nullable(S),pageRefs={'type':'array','items':S})
ProposalScope=rec('ProposalScope',start=DAY,end=DAY,section=ID,subgroup=nullable(S),programmingGroup=nullable(S))
Proposal=rec('ComputationalProposal',proposalVersion=const(1),proposalId=ID,baseModelRevision=N,source=ProposalSource,scope=ProposalScope,changes=arr(Change),unresolved=arr(rec('ProposalIssue',code=ID,sourceRef=S,message=S)),createdAtUntrusted=const(None))
EffectBinding=rec('EffectBinding',change=Change,changeSha256=H,factIds=IDS,anchorIds=IDS,groupId=ID,adoption=en('APPLIED','NOT_APPLIED','NO_OP'),targetKind=en('SESSION','EVENT','HOLIDAY','PATTERN','TEACHING_END'),targetId=ID,before=TargetCommitment,after=TargetCommitment)
Induced=rec('InducedDelta',adoption=en('APPLIED','NOT_APPLIED'),targetKind=en('SESSION','EVENT'),targetId=ID,beforeValue=PresenceValue,afterValue=PresenceValue,causeEffectIds=IDS,linkedEventIds=IDS)
Edge=rec('DependencyEdge',a=ID,b=ID,reason=en('SAME_TARGET','ATOMIC_FACT','REFERENCE','DATE_SCHEDULE','LINKED_SESSION_EVENT','TEACHING_END','UNKNOWN_EXTENT'))
Group=rec('DependencyGroup',groupId=ID,knowledge=en('ESTABLISHED','CONSERVATIVE_FULL'),memberIds=IDS,reasons={'type':'array','items':en('SAME_TARGET','ATOMIC_FACT','REFERENCE','DATE_SCHEDULE','LINKED_SESSION_EVENT','TEACHING_END','UNKNOWN_EXTENT','INDEPENDENT_SINGLETON'),'uniqueItems':True})
Groups=rec('Groups',baseModelSha256=nullable(H),reviewSha256=H,effectIds=IDS,edges=arr(Edge),groups=arr(Group),inducedDeltas=arr(Induced))
Base=rec('BaseBinding',mode=const('personal'),controllerEpoch=ID,modelId=nullable(ID),modelRevision=nullable(N),envelopeVersion=nullable(en(1,2,3)),rawEnvelopeSha256=nullable(H),priorReleaseSha256=nullable(H))
InitialIntent=rec('InitialIntent',modelIntentSha256=H,clockSlot=const('/snapshots/0/confirmedAt'),slotValue=const(None),computationClock=Clock)
Prepared=rec('Prepared',operation=OP,stageId=ID,stageGeneration=N,base=Base,manifestSha256=H,bundleSha256=H,runSha256s={'type':'array','items':H,'uniqueItems':True},reviewSha256=H,groupsSha256=H,rawInventorySha256=H,computationClock=Clock,initialIntent=nullable(InitialIntent),proposalSha256=nullable(H),effects=arr(EffectBinding),approvedEffectIds=IDS,approvedGroupIds=IDS,unresolved=const([]))
AppliedRevision=rec('NewAppliedRevision',proposalId=ID,sourceSha256=H,appliedAt=Clock,modelRevision=N,changeIds=IDS)
Accepted=rec('AcceptedPayload',operation=OP,receiptId=ID,preparedSha256=H,semanticIntentSha256=H,base=Base,acceptedModelSha256=H,priorReleaseSha256=nullable(H),sourceRevisionPatchSha256=nullable(H),newAppliedRevision=nullable(AppliedRevision),approvedEffectIds=IDS,approvedGroupIds=IDS,acceptedAt=Clock)
InitialMapping=rec('InitialMapping',factId=ID,recordKind=en('COURSE','REGISTER','WEEKLY_TEMPLATE','EVENT','HOLIDAY','PATTERN','BOUNDARY','SNAPSHOT_INPUT','POLICY_INPUT','PREFERENCE_INPUT'),recordIds=IDS,modelPaths={'type':'array','items':S,'uniqueItems':True},origin=en('SOURCE_REVIEW','OPERATOR_ASSERTION'),anchorIds=IDS)
D['Prepared']['properties']['initialMappings']=arr(InitialMapping);D['Prepared']['required'].append('initialMappings')
Context=rec('EvidenceContext',projectionProtocolVersion=const('E-PROJ/0.1.1'),sources=arr(Intake),manifest=Manifest,runRecords=arr(Run),pageContents=arr(PageContent),sourceAliases=arr(SourceAlias),candidateRefs=arr(CandidateRef),rawIssues=arr(Issue),review=Review,groups=Groups,prepared=Prepared,acceptedPayload=Accepted,originalAvailability=const('NOT_RETAINED'),visualAvailability=const('NOT_RETAINED'))
# Public review payloads: every operation is closed; handles are separate nonserializable API arguments.
TimetableDecision=rec('TimetableDecision',rowId=ID,weekday={'type':'integer','minimum':1,'maximum':7},start=TM,end=TM,applicability=en('UNRESOLVED','APPLIES','DOES_NOT_APPLY'),groupChoice=nullable(S),treatment=en('UNRESOLVED','ATTENDANCE','COMPULSORY_ZERO_UNITS','OPTIONAL','BREAK'),weight=nullable(P),reason=S,decision=en('UNREVIEWED','CONFIRMED','CORRECTED'))
CalendarDecision=rec('CalendarDecision',rowId=ID,title=S,kind=en('HOLIDAY','NON_TEACHING','REPLACEMENT','WORKING_DAY_NOTICE','TEACHING_BOUNDARY','EXAM_WINDOW','ACADEMIC_ACTIVITY','VACATION','UNKNOWN'),startDate=nullable(DAY),endDate=nullable(DAY),term=en('ODD','EVEN','BOTH','UNSPECIFIED'),audienceText=nullable(S),applicability=en('UNRESOLVED','APPLIES','DOES_NOT_APPLY'),treatment=en('UNRESOLVED','HOLIDAY','NON_TEACHING','REPLACEMENT','TEACHING_BOUNDARY','COMPULSORY','INFORMATION_ONLY','DOES_NOT_APPLY'),replacementWeekday=nullable({'type':'integer','minimum':1,'maximum':7}),allDay=nullable(B),startTime=nullable(TM),endTime=nullable(TM),reason=S,decision=en('UNREVIEWED','CONFIRMED','CORRECTED'),anchorIds=IDS)
SessionEdit=rec('SessionEdit',registerId=ID,date=DAY,start=TM,end=TM,weight=P,protected=B,cancelled=B)
EventEdit=rec('EventEdit',title=S,cancelled=B,sessionId=nullable(ID),date=nullable(DAY),start=nullable(TM),end=nullable(TM))
EffectEdit=rec('EffectEdit',effectId=ID,kind=en(*KINDS),sourceCandidateId=nullable(ID),targetId=nullable(ID),anchorIds=IDS,carrierAnchorId=ID,basis=en('DIRECT_SOURCE','EXPLICIT_CANCELLATION','REVIEWED_OFFICIAL_CORRECTION'),session=nullable(SessionEdit),event=nullable(EventEdit),holiday=nullable(Holiday),pattern=nullable(Replacement),teachingEnd=nullable(DAY),matchMode=en('EXISTING','DISTINCT_ADDITION','UNRESOLVED'),matchReason=S,reason=S,reconciliationNote=nullable(NOTE),applicability=en('APPLIES','DOES_NOT_APPLY','UNRESOLVED'),effectiveDateReviewed=B,includeInComparison=B)
ManualTT=rec('ManualTimetable',subjectName=NOTE,registerName=NOTE,registerKind=en('THEORY','PRACTICAL','ACTIVITY'),anchorIds=IDS,weekday={'type':'integer','minimum':1,'maximum':7},start=TM,end=TM,weight=P,treatment=en('ATTENDANCE','COMPULSORY_ZERO_UNITS','OPTIONAL','BREAK'),reason=NOTE)
commands=[]
def cmd(tag,**p):commands.append(obj(type=const(tag),**p))
cmd('SET_SCOPE',scope=Scope)
cmd('SET_INITIAL_SETTINGS',settings=InitialSettings)
cmd('SET_REVISION_SETTINGS',legacySourceReviewed=B,legacySourceNote=S,sourceCoverageConfirmed=B,coverageNote=S)
cmd('REVIEW_SUBJECT',subjectId=ID,name=NOTE,decision=en('UNREVIEWED','CONFIRMED','CORRECTED'),reason=S)
cmd('REVIEW_REGISTER',registerId=ID,name=NOTE,decision=en('UNREVIEWED','CONFIRMED','CORRECTED'),reason=S)
cmd('REVIEW_TIMETABLE_ROW',value=TimetableDecision)
cmd('REVIEW_CALENDAR_ROW',value=CalendarDecision)
cmd('ADD_MANUAL_TIMETABLE_ROW',value=ManualTT)
cmd('ADD_MANUAL_CALENDAR_ROW',anchorIds=IDS,reason=NOTE)
cmd('ADD_EFFECT',kind=en(*KINDS),sourceCandidateId=nullable(ID),anchorIds=IDS,reason=NOTE)
cmd('REVIEW_EFFECT',value=EffectEdit)
cmd('RETIRE_DERIVED_EFFECT',effectId=ID,reason=NOTE)
cmd('SELECT_TEXT_ANCHOR',intakeId=ID,runId=ID,pageNumber=P,role=D['Anchor']['properties']['role'],channel=en('PAGE_TEXT','ITEMS_JOIN'),startUTF16=N,endUTF16=N,bboxF64=nullable(Bbox),qualifierAnchorIds=IDS,nullBoxReason=nullable(NOTE))
cmd('SELECT_VISUAL_ANCHOR',intakeId=ID,runId=ID,pageNumber=P,role=D['Anchor']['properties']['role'],bboxF64=Bbox,qualifierAnchorIds=IDS)
cmd('ADD_FACT',sourceCandidateIds=IDS,anchorIds=IDS,reason=NOTE)
cmd('RECORD_FACT',value=Fact)
cmd('RECORD_COVERAGE',value=Coverage)
cmd('RECORD_OMISSION',value=Omission)
cmd('DISPOSE_ISSUE',value=IssueDecision)
cmd('CONFIRM_REVIEW')
SubjectDecision=rec('SubjectDecision',subjectId=ID,name=NOTE,decision=en('UNREVIEWED','CONFIRMED','CORRECTED'),reason=S)
RegisterDecision=rec('RegisterDecision',registerId=ID,name=NOTE,decision=en('UNREVIEWED','CONFIRMED','CORRECTED'),reason=S)
Interpretation=rec('Interpretation',subjects=arr(SubjectDecision),registers=arr(RegisterDecision),timetableRows=arr(TimetableDecision),calendarRows=arr(CalendarDecision),effects=arr(EffectEdit),retiredEffects=arr(rec('RetiredEffect',effectId=ID,reason=NOTE)))
D['Review']['properties']['interpretation']=Interpretation;D['Review']['required'].append('interpretation')
D['ReviewCommand']={'oneOf':commands}
D['ReviewMutation']=obj(expectedReviewRevision=N,command=ref('ReviewCommand'))
D['PrepareIntent']=obj(operation=OP,expectedReviewRevision=N,approvedEffectIds=IDS,expectedModelId=nullable(ID),expectedModelRevision=nullable(N))
D['AcceptIntent']=obj(operation=OP,confirmation=const(True))
D['Preview']=obj(previewVersion=const('SA-PREVIEW/0.1.1'),reviewId=ID,reviewRevision=N,operation=OP,phase=en('READING','REVIEW','BLOCKED','PREPARED','APPLYING','ACCEPTED','REVOKED'),sourceIds=IDS,issueIds=IDS,unresolvedFactIds=IDS,effectIds=IDS,groupIds=IDS,approvedEffectIds=IDS,sourceStatus=const('UNVERIFIED'),originalAvailability=en('SESSION_ONLY','NOT_RETAINED'))
D['BeginReviewIntent']=obj(operation=OP,extractionArguments=ExtractionArguments)
D['DisplayMaterial']=obj(displayVersion=const('SA-DISPLAY/0.1.1'),sources=arr(Intake),pages=arr(obj(page=RawPage,previewDataUrl=S)))
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:semesterspace:sa-e:0.1.1','$comment':'E authority/evidence shape contract only. Relational rules in revised contract are also normative. Not a capability or storage implementation.','$defs':D,'oneOf':[ref(n) for n in ['ApprovedManifest','Intake','Bundle','RawPage','RawInventory','Run','Anchor','Review','Groups','Prepared','AcceptedPayload','EvidenceContext','ReviewMutation','PrepareIntent','AcceptIntent','Preview']]}
Path(__file__).with_name('AUTHORITY_EVIDENCE_0_1_1.schema.json').write_text(json.dumps(schema,indent=2)+'\n')
print('closed definitions',len(D),'review commands',len(commands))
