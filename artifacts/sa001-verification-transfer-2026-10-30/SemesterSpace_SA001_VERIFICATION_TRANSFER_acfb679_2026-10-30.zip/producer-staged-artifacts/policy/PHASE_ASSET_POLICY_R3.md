# ASSET-01 — frozen phase applicability

M = mandatory for the stated action; C = conditional on the stated observation; N = not used by the frozen actions. All observed responses still undergo byte comparison. This table describes actions, not an executed asset inventory.

| Phase | Existing actual actions |
|---|---|
| native-before | composeSourceRuntime imports; real timetable+calendar initial PDF review/accept; selective real notice PDF revision/accept; save raw bytes then close |
| native-after | same-profile new persistent-context process; reload retained receipt bytes without source decoding; then real later-notice PDF review; physical-ACK fault and explicit reload |
| retained-ui | composeSourceRuntime imports at test-entry; navigate to app root; display retained source history only; no selectSource/beginReview |
| fixture-pdf-ocr | separate existing fixture profile; real PDF initial/revisions and legacy upgrades; P3 generated image through actual Tesseract OCR; P8 hybrid PDF uses PDF_TEXT carrier + visual review, not OCR requirement; other original source/history controls |
| forgery-before | real timetable+calendar initial PDF acceptance; local event then raw forgery callback negatives; save raw bytes before native reopen |
| forgery-after | same-profile native reopen and saved-byte equality; real source revisions and stage/qualifier/group controls; RACE01 two real notice reviews, delayed prepare-result delivery, actual mutation, fresh acceptance |

| Asset family | native-before | native-after | retained-ui | fixture-pdf-ocr | forgery-before | forgery-after |
|---|---|---|---|---|---|---|
| Composition authority/controller/storage | M | M | M | M | M | M |
| App index + main.js | N | N | M | N | N | N |
| PDF engine pdf.mjs | M | M | N | M | M | M |
| PDF Worker root | C | C | N | C | C | C |
| PDF standard fonts actually requested | C | C | N | C | C | C |
| OCR loader + Worker + eng data | C | C | N | M | C | C |
| Actually chosen WASM wrapper(s) | C | C | N | M | C | C |
| HTTP WASM bytes / recognised embedded bytes | C | C | N | M | C | C |
| Every other observed app asset | C | C | C | C | C | C |
| HTTP source-document/image transfer | N | N | N | N | N | N |
| Service Worker path | N | N | N | N | N | N |

PDF Worker C activates on its actual Worker event or script response. With neither, no body is invented and the Worker-specific subtype is explicitly unproved. Every observed Worker still requires its actual matching fetched body. A valid reader-only/fallback operation is not labelled compromised merely for omitting a particular Worker. An actual Worker lacking a body is incomplete.

OCR C in text-PDF phases activates if actual OCR loader, Worker, language/core/wrapper or binary requests occur. Active OCR requires complete actual response evidence for the family; a partial request cannot be ignored. In fixture-pdf-ocr it is M regardless of preliminary requests because P3 explicitly invokes the installed OCR reader. The verifier requires the existing P3 material method OCR and P8 material PDF_TEXT/visual path; P8 alone does not establish OCR.

Fonts are required only when actually requested. OCR binary coverage admits actual HTTP WASM bodies, or precisely labelled offline inference from a recognised embedded data URI in an actually fetched wrapper matching approved binary bytes. Neither proves instantiation. Unrequested hardware variants have no invented fetch requirement. Language bytes are compared as the actual gzip file when served without Content-Encoding.

N is an action classification, never a byte-comparison exemption. Unexpected app assets remain in raw evidence and are compared; observed OCR activates full checks even in a nominally N phase. Unsupported Service/blob Worker capture is still incomplete. Source PDF/image input bytes travel through the original owned-byte API, not a required HTTP upload.

The complete predicates and per-phase action explanations are in PHASE_ASSET_POLICY.json. Policy is inline in the unchanged verifier CLI; its canonical value hash is bound at freeze and rechecked at verify. Existing action/source-line pointers are in RACE01_ASSERTION_MAP.json and FINAL_IDENTITIES_FOR_F.json.
