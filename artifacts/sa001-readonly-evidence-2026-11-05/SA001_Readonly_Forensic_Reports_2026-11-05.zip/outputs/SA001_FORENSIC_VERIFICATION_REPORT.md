# SA-001 forensic verification report to Chat A HQ

Authority **HQ-SA001-CODEX-READONLY-2026-11-05-r1**. Run **41387922793**, attempt **1**; workflow repository commit **1e4413f6791fd76d5676494ff007f35712813d60**. **SA-001 OPEN P1 — evidence reconciliation complete within supplied subset; security closure not established.** No implementation, application tests, CI, network requests, commits, pushes, PRs, deployment or activation occurred.

## Scope and identities

**DERIVED SUBSET RECONCILIATION.** Uploaded handoff ZIP SHA-256 `fa91e9d80740f0eeb7c2a22cac8aac91a274c6c2bc655b5e3b66440a5f71c64d`, 24,878,795 bytes. All 170 listed original members independently match raw SHA-256 and size in `SOURCE_MEMBER_MANIFEST.json`. The 837-entry root ledger and 333-entry included nested ledger give 334 available hash links, all matching; the missing ledger members were not thereby verified. HQ CSV/addenda were used only as reference, not as independent execution or copied truth. [D] was read in full.

The separate original archive upload cannot be read through the available download tool because it exceeds its 32 MiB limit; no local copy was found. Owner-reported original is `SA001-application-41387922793-1-original.zip`, 488,716,152 bytes, SHA-256 `a49b957235ecb48660d16bb91665a8db3a10373b295b740526e545ce99f22a6e`. Its whole-archive integrity, complete population and absence of omitted evidence are **NOT_OBSERVED**, not a mismatch or a proved absence. No substitute archive was treated as the original.

Available application checkout `/workspace/SemesterSpace-sa-001` is clean at `acfb6799f699b7868612db346958c9e3d710680f`, tree `6b2e0336582a6f205c48374c058b1ac2798fff15`, parent `aec0abb117939b2819ebcd7b0b426e8243705e65`. That is not the workflow-repository commit. The latter is not in this local object database and was not fetched. All 269 historical Git source blobs match [L] `/historicalSourceFileSha256`; current files match 268/269 effective runtime hashes. The declared exception is `semester-space/tests/sa-001/e-finite.mjs`: local historical SHA `588f3a11b97b35f8478b1116fa912c7d742c3229bad2e207e6fd145a22e19479`, effective SHA `9a520213a68a951676b89085bb74179dcf29cf31b8a434603b8c1f8a2fe7a3d7`. [L] `/sourceAdmission` declares `HISTORICAL_HEAD_WITH_ONE_REVIEWED_WORKTREE_OVERLAY`, approval-record SHA `5b4360e6094732adc756a831582049ab8e7f0c94605423a57a3f953b02f0d58d`. Overlay bytes/approval record and complete verification-repository source are unavailable here. This known declared difference is not silently normalized. Local controller/storage/browser harness match effective hashes and can support bounded static analysis; the complete runtime source admission remains PENDING_REVIEW.

## Owner-facing gates

| Gate | Outcome / disposition | Exact boundary |
|---|---|---|
| Supplied original-member checks | PASS / VERIFIED | 170 raw member identities; no full original archive attestation |
| Original full ZIP integrity/completeness | UNVERIFIED / NOT_OBSERVED | Oversized original inaccessible through tool |
| F152 observed-field reconciliation | PASS for available fields / VERIFIED | 1,539 MATCH, 26 optional absent success fields; 20 missing |
| 18 getter observations | UNVERIFIED / NOT_OBSERVED | No counter in report or four surviving trace-result populations; no complete getter instrumentation |
| Two byte-disposition observations | UNVERIFIED / NOT_OBSERVED | F-SA-28 and F-SA-29 lack immediate case-bound byte pairs |
| 131 storage full-case reconciliation | UNVERIFIED / PENDING_REVIEW | Storage observations survive; controller/authority/ACK/native integration not case-bound |
| External B2/OMR suite | PASS historical transcript / VERIFIED | 191 pass; no new execution or full-case promotion |
| Two excluded guarantees | OUT_OF_SCOPE | F-SA-34/35; owner coexistence/activation judgment remains separate |
| Job 28 six phases | PASS bounded bytes / VERIFIED | 182 body records, 34 paths, 41 Worker-root events; no module evaluation/SA acceptance claim |
| Complete same-run source/build/verifier provenance | UNVERIFIED / PENDING_REVIEW | Declared overlay and full build/verifier receipts not supplied |
| Historical forged-stage exact replay | UNVERIFIED / NOT_OBSERVED | Explicitly blocked missing original bytes |
| UX03 / UX04 | UNRUN / NOT_OBSERVED | Qualified screen-reader/non-author walkthrough remain human gates |
| Independent E/F/D and owner closure | PENDING_REVIEW | No independent acceptance conveyed by this static investigation |

No observed evidence contradiction remains after correcting the investigator's own parser assumptions. This does not establish that unobserved acceptance gates would pass. **Full-case acceptance remains 0/152**, with 150 entries PENDING_REVIEW (including one external dependency) and two OUT_OF_SCOPE; 149 are single-operation cases with surviving partial observations.

## F152: complete source-based reconciliation

`SA001_152_CASE_ACCEPTANCE_MATRIX.csv` contains exactly 152 unique IDs, original comparator/register indices, per-case original storage/browser path and SHA-256, unchanged oracle expectations, actual field states, byte hashes, explicit dispositions, static branch pointers, variant-dependent controller analysis and unresolved integration requirements. `analysis/field-reconciliation.json` provides all 1,585 field-level computations and source pointers. Counts were independently derived from [C], [B], [REG] and all 131 individual storage records; no HQ acceptance labels were adopted. The unchanged local active IMPL04 oracle SHA `5628adc49a277b4b283fb9cdfbc082924048dc24e018db415b2e9c768f3497a1` also matches all 152 expected tuples. That local-input comparison does not itself prove the historical runner's input admission.

Original populations: **131 PARTIAL_STORAGE_OBSERVABLE_MATCH; 18 PARTIAL_MISSING_OBSERVABLE; one EXTERNAL_SUITE_DEPENDENCY; two EXCLUDED_NOT_SINGLE_CALL**. Optional reason/path absent on admitted success remain absent; they are ABI-compatible, not synthesized telemetry or failures. Field counts are not unique test counts.

For the 131 storage records, all original per-case vectors, register actuals, tuples, read/write/getter counters and byte dispositions agree. The 131 literal before/after pairs independently hash to their reported digests: 108 failed unchanged, 13 saved changed, seven successful load unchanged, three read-only load unchanged. Diagnostic full loaded objects compare unchanged in all 118 relevant failure/load rows; where a parsed persisted model/release and a successful diagnostic state exist they agree. This is evidence from archived standalone helper executions, not a new save/load test. `inputGraphUnchanged=true` is a surviving reported flag; original hostile object graphs are not reconstructible from it alone. Diagnostic reads are explicitly excluded from attempt counts, and do not imply a native browser reopen or private capability inspection.

Variant-dependent remaining memory obligations are **108 UNCHANGED; 13 ADVANCE_AFTER_ACK; seven LOAD_VALIDATED_STATE; three READ_ONLY_INSPECTION_ONLY**. Composition: five B2_FROZEN, 116 PROFILE3 saves, ten LOADER_E3 loads. Each ID is independently crosswalked in `analysis/131-storage-integration-crosswalk.json`. For 13 saves, a successful setItem and final state cannot establish controller promotion only after physical ACK. For 108 failures, storage retention does not observe the controller's accepted memory or revocation. Seven load states do not establish controller view or restored-authority absence; three read-only loads also need writer-entrypoint fences. Some malformed helper inputs are not genuine public source operations; F/D must explicitly adjudicate applicability and bind shared invariants rather than mint fake stage capabilities. No expected field is deleted or waived.

Static effective-hash-matched source shows persisted checks before candidate build/access and core-before-unknown order (`storage.js:489–515,546–564`), single physical write (`588–589`), and controller uncertainty before promotion (`controller.js:467–476`). `analysis/131-storage-integration-crosswalk.json` maps every expected phase to source. This supports order review but not dynamic phase telemetry. Actual collision recipes and source paths must be reviewed per ID before using a tuple as first-match proof; a failure message alone is insufficient. Existing recorded collision cases should be adjudicated before commissioning any rerun.

F-SA-31's archived actual `DAY_CORRECTED` result has proposed model/journal deeply equal to the persisted model/attendance, revision10, four attendance records/two closed days; receipts and original official snapshot IDs are unchanged. This correspondence is independently checked from [F31] `/actualLedger/result`, not a fabricated partial ledger or fresh engine execution.

## Eighteen getter gaps and two byte gaps

`SA001_MISSING_EVIDENCE_RESOLUTION.csv` lists exactly 20 missing field observations, one getter requirement for each of these 18 original cases plus two byte requirements:

- `F011-X-15-required`.
- `F011-X-15-declined`.
- `F011-X-15-stage`.
- `F011-X-15-base`.
- `F011-X-16a`.
- `F-SA-26-commit-throw`.
- `F-SA-27a`.
- `F-SA-23-decline`.
- `F-SA-24-subset`.
- `F-SA-24-base-bytes`.
- `F-SA-24-epoch`.
- `F-SA-24-stage`.
- `F-SA-24-profile`.
- `F-SA-25-genuine-shape`.
- `F-SA-28-reload-reuse`.
- `F-SA-29-manual-revision`.
- `F-SA-40-profile3-upgrade-pending`.
- `F011-X-16a-stale-base-negative`.

All expect getter count0, but the 18 browser `/actual` objects lack a candidate-getter observation. The four surviving Playwright `trace.trace` streams were decoded statically (including serialized result/reference objects) and their result keys inspected. No getter counter was recovered. The hash-matched harness tracks storage reads/writes (`browser.mjs:18–21`) and captures bytes in `attempt` (`47`), while `cloneStage`/`noStage` (`50–51`) return only result/reads/writes. Missing getter fields/events are not evidence of zero; source-level early return is supporting static evidence only. No dummy getter, no fabricated stage and no source redesign may replace the missing actual boundary observation.

For **F-SA-28**, [B] `/cases/4/actual` contains only result/reads/writes. [TA] trace calls `call@55` and later `call@61` have equal surrounding bytes, SHA `e205516af2c42deb47d068af98db20e2a1e0cc8b0a4c7a3ba4c2ec05f9afcacc`; `call@57` executes cloneStage between them, but `call@59` prepares another revision before the later snapshot. This is genuine corroborating bracketing evidence, not an immediate operation-bound post record or complete all-write event log. Persisted-byte disposition remains NOT_OBSERVED for acceptance; F/D may adjudicate the precise weaker inference without relabeling it direct telemetry.

For **F-SA-29**, [B] `/cases/26/actual` likewise has only result/reads/writes. [TF] calls `call@265` seed, `call@267` noStage, then `call@269` seed the next fixture. Seed input and returned memory do not directly observe post-operation bytes before overwrite. Status and zero writes cannot fill the missing byte field. Exact call IDs, NDJSON line locations, decoded values and trace-member SHA identities are retained in `analysis/trace-observations.json` and decoded trace audits.

Sixteen other browser cases have raw byte pairs and memory snapshots. The two IMPL01 fault controls [B] `/cases/5/actual` and `/cases/8/actual` both record one read/one write, different before/after bytes, after exactly equal attempted bytes, and unchanged accepted model/release before explicit reload. They return exact UNCERTAIN `SA_COMMIT_UNCERTAIN` tuples (`STORAGE_ACK_UNCERTAIN` and `POST_WRITE_ACK_FAILED` respectively). These are physical-write-before-fault controls, not identical/no-op fixture writes or late post-promotion exceptions. Shared old-stage denial and explicit-reload records survive, but they do not establish all case-specific native-reopen/authority assertions. F-SA-40's real browser result retains the old h4 link with both value/changeId absent, full attendance and snapshots; ACK order still is not implied by snapshots alone. Detailed history/opaque-link checks are in `analysis/retained-history-checks.json`.

Several consent negatives explicitly use `LABELED_TRUSTED_RESOLVER_HEADER_FAULT_AFTER_REAL_READER_STAGE`; report that seam honestly. They demonstrate controlled internal rejection after a real reader stage, not that every malformed header is reachable by an ordinary untrusted caller. Full-case source/authority assertions need their actual binding reviewed.

## Other mandatory distinctions

The companion phase report validates Job28 bytes without asserting module evaluation, WASM instantiation or complete build provenance. The external/excluded report treats B2/OMR, old clients, two writers and historical forged-stage limitations under [D], without inventing an exception. E new-forgery negatives and browser names are not the missing historical original. UX03/04 remain UNRUN_NO_TESTER as recorded in [B]; neither belongs in a manufactured F152 pass tally. Independent E/F/D reviews and A/owner disposition remain required. T2-LINK OPEN P2, Open Interval and mathematical objectives are separate; nothing here closes or implements them.

## Reproducibility and preservation

Run only `python3 analysis/investigate.py`, then `python3 analysis/supplement.py` against the stated paths/inputs to reproduce the machine reconciliation (the second adds applicability/history columns). Both final static analyses exited0. Their source hashes, raw stdout/stderr/exits, checking script, 170-member results, every field computation and original-member source index are included. `analysis/COMMAND_RECEIPTS.json` identifies earlier investigator-only failed attempts and their causes; all are preserved. Those attempts were parser assumptions (WASM loader offset, `/`→index.html response normalization, proposedModel/proposedJournal key naming), not observed candidate failures. No evidence was edited to make a check pass.

The six requested reports are under `outputs/`; independent machine audits under `analysis/`. Original evidence and frozen review are packaged unchanged under `input/` for reproducibility; the unprovided full original ZIP is not included. Repository preservation receipts compare initial/final HEAD/parent/tree, status, refs/worktrees and all 269 local file hashes. No original or repository file was modified. No test, helper, installation, build, source module import or CI execution occurred; Python only parsed and hashed existing evidence. Cryptographic consistency is not independent runtime security acceptance.


Evidence identities (each label below resolves to the unchanged supplied file; a pointer following a label identifies the claim):

- [C] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/oracle-comparator-outputs/reconciliation.json` — SHA-256 `be9cc57136556404d3b47d51c1d57dc3afcfa314b0885db121489b563f37a75c`.
- [B] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/browser-native-connected-outputs/report.json` — SHA-256 `1fcf981c8d612af1d1d0bb634e0e2106bda0e576b67ca0672a45aeafbf61161f`.
- [REG] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/oracle-storage-outputs/register.json` — SHA-256 `60d3c2dfd5e1533c249f153c1f461fe526dc8e64e37cbf6ec71c130374b4b1f2`.
- [L] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/loaded-assets-binding.json` — SHA-256 `4f8463c56557eb542cc2efae8929db8a2d3d475f55727e15effa6acbe65c006d`.
- [J] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/loaded-asset-verification-outputs/binding-result.json` — SHA-256 `62a9d90909df5f41c5f5833e33a07cff763f696765757953e2b1144dbc6493a4`.
- [D] `HQ_REFERENCE/SemesterSpace_Chat_D_SA001_Independent_Integrated_Contract_Review_2026-10-27.md` — SHA-256 `2997d18ea97084e7facd7bbf3a7f6ed12ff1b579cd82b5a1c5852cbc7e541758`. HQ-supplied historical review reference; not an original run member.
- [F31] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/oracle-storage-outputs/F-SA-31-explicit-attendance.json` — SHA-256 `1a4efa29389578d371dfa95093b0d9def0de964bc1b39ddab760f2a3665216e9`.
- [TA] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/browser-native-connected-outputs/session-after-reopen-trace.zip` — SHA-256 `cc9f30bb1e0002943ec600741209987ad0365623e34f104149244e262666d2e1`.
- [TF] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/browser-native-connected-outputs/fixture-source-and-consent-trace.zip` — SHA-256 `c70bd3d67704aadab5822f5755dbb34eeee87b6deff533e495c71d784d48f13a`.
- [FM] `FINAL_SHA256.json` — SHA-256 `df3cec74201df2228673711eccf3f1aed33e79290a6c089cfc2f6387df54d347`.
- [NM] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/FINAL_ARTIFACT_HASHES.json` — SHA-256 `86e18926266bf6ea303005cb639ed23e457fbaaf4c0871ce0025f1e8657b31bd`.
- [ST] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/oracle-storage.meta.json` — SHA-256 `db4aac5ae42ab07f1243101f34226f0aa13ddf21a3fd15ab8364c8556d2c8661`.
- [AI] `APPLICATION_APPROVAL_IDENTITY.json` — SHA-256 `8e6b9c79830614116f467132532e6e1e54b4f85edea5422ba2a7ec9478617fa3`.
