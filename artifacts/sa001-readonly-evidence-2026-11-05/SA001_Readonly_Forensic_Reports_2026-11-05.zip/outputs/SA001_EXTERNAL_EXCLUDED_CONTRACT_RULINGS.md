# External and excluded variants: evidence and proposed rulings for A/F/D

These are investigative findings, not new contract acceptance or a waiver. The frozen D review [D], sections 3–5, is a contract review; its historical engineering-authorization wording does not rescind later authorizations. It also does not accept this candidate or this run.

| Case | Evidence disposition | Proposed independent review treatment |
|---|---|---|
| F-SA-33-legacy-suite | VERIFIED historical suite transcript/exit and locally available test-file hash correspondence; full case PENDING_REVIEW | External dependency, not a single-call SA pass. Review the exact admitted effective source and suite coverage; no rerun is justified solely because comparator placed it outside storage cases. |
| F-SA-34-pre-B2 | OUT_OF_SCOPE guarantee; operational coexistence PENDING_REVIEW | Old uncooperative client is not fenced under accepted contract. Preserve this limitation; zero read/write expectations in placeholder metadata are not measurements. |
| F-SA-35-multi-tab | OUT_OF_SCOPE guarantee; operational coexistence PENDING_REVIEW | No multi-writer serialization guarantee exists. Do not invent a serialized-write pass or silently add a feature/test obligation. |

F-SA-33 appears in [C] `/cases` under that exact ID (matrix contains its index and register binding). [BM] `/argv` records `node --test tests/diamond-001/storage.test.mjs tests/diamond-001/omitted-release-acceptance.test.mjs tests/diamond-001/omitted-release-precedence.test.mjs`, cwd `/workspace/sa001-final-operator-disposable/semester-space`. It records EXITED/0, start `2026-11-02T04:22:05.044032+00:00`, finish `2026-11-02T04:22:05.515027+00:00`. [BT] independently contains sequential `ok 1` through `ok 191`, TAP plan `1..191`, tests/pass 191, failure/cancel/skip/todo 0. Raw stdout digest matches `/stdoutSha256`. The three local test files match [L] `/sourceFileSha256`, with exact per-file hashes in `analysis/b2-tap-checks.json`. This is preserved producer execution, not a new independent run. stderr bytes are not included; metadata declares the empty-byte digest but that is not independent observation of the file.

The transcript includes F-S31/F-S32 full-release omission rejection, admitted absent-store/legacy and explicit-full-release controls, precedence/candidate getter fences, and retained S01–S30 storage controls. Test names and source correspondence are fully exported in the audit. Names alone do not establish every asserted safety property: F/D should inspect those exact hash-bound assertions under the unchanged accepted B2/OMR contract. No application tests were executed here. Do not add these 191 to the separately recorded 638 full-suite tests or F152 fields as unique security cases; suites overlap.

For F-SA-34/35, [C] `/cases` and `/oracleExpectedUnchanged/reason` explicitly say `OLD_CLIENT_NOT_FENCED` and `NO_WRITER_SERIALIZATION`; [D] sections 3/5 retain old-client coexistence and owner activation decisions. An exclusion is neither observed safe behaviour nor permission to activate. A/D should record acceptance of these exact scope limits in their security disposition; the owner must separately resolve any activation/coexistence policy. No broad waiver or new implementation of fencing/serialization is proposed.

Historical forged-stage obligation remains separate. [EF] `/originalForgeries/status` says `BLOCKED_MISSING_ORIGINAL_BYTES`; [J] `/jobs/e-finite/originalForgeries` repeats it. E cases `E_NEW_NONEMPTY_FABRICATED_SOURCE`, `E_NEW_NONEMPTY_UNRELATED_QUOTE` and `E_NEW_NONEMPTY_CROSS_SOURCE_PAGE999` are new nonempty negative controls, with before/after records. Browser case `AUTH_ORIGINAL_RAW_FORGERY_CLOSED` is an execution label, not provenance for the missing historical exploit bytes. Static rejection of raw proposal/apply routes, new negatives, source hashes and D's older pure research do not recreate or execute the original historical attack.

Disposition: historical exact-input replay NOT_OBSERVED. Recover original archived payload bytes plus SHA-256, original invocation and authentic baseline failure evidence first. If irretrievable, only A/D and the owner can adjudicate a narrowly described historical-evidence qualification through the established process; no automatic exception is present in [D], and none is granted here. A newly authored attack may supplement future verification but must never be renamed the historical original. SA-001 stays OPEN P1.


Evidence identities (each label below resolves to the unchanged supplied file; a pointer following a label identifies the claim):

- [C] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/oracle-comparator-outputs/reconciliation.json` — SHA-256 `be9cc57136556404d3b47d51c1d57dc3afcfa314b0885db121489b563f37a75c`.
- [BM] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/b2-omr.meta.json` — SHA-256 `56a2dfebeb92039fbb56a3da02d8d56ee264da9034645db964d5df15c93425aa`.
- [BT] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/b2-omr.stdout` — SHA-256 `11727e92d539b7fa94d41fbec0eb54a73c0a377dabefde8d2013eeeb81adc224`.
- [L] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/loaded-assets-binding.json` — SHA-256 `4f8463c56557eb542cc2efae8929db8a2d3d475f55727e15effa6acbe65c006d`.
- [D] `HQ_REFERENCE/SemesterSpace_Chat_D_SA001_Independent_Integrated_Contract_Review_2026-10-27.md` — SHA-256 `2997d18ea97084e7facd7bbf3a7f6ed12ff1b579cd82b5a1c5852cbc7e541758`. HQ-supplied historical review reference; not an original run member.
- [EF] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/e-finite-outputs/report.json` — SHA-256 `a6230040ac85211f1dd83913ca434f7fc58707d2868d85d53b17b6d3fbbd1ce2`.
- [J] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/loaded-asset-verification-outputs/binding-result.json` — SHA-256 `62a9d90909df5f41c5f5833e33a07cff763f696765757953e2b1144dbc6493a4`.
- [B] `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/browser-native-connected-outputs/report.json` — SHA-256 `1fcf981c8d612af1d1d0bb634e0e2106bda0e576b67ca0672a45aeafbf61161f`.
