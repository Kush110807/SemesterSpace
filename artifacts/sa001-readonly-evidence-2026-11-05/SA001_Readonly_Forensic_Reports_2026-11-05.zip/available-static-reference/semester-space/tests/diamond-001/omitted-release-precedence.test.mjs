import {test,recordEvidence} from './evidence.mjs';
import assert from 'node:assert/strict';
import {saveModel,loadModel,makeEmptyRelease} from '../../src/storage.js';
import {makeCombinedModel} from '../../src/shared/fixtures.js';
import {validateModel} from '../../src/engine/index.js';
import {evaluateDayClose} from '../../src/attendance/ledger.js';
const clone=structuredClone,ceiling={date:'9999-12-31',time:'23:59',timeZone:'Asia/Kolkata'};
function base(){const model=makeCombinedModel();return {schemaVersion:2,model,release:makeEmptyRelease(model)}}
function history(){
 const e=base(),r=evaluateDayClose({model:e.model,journal:e.release.attendance,request:{expectedModelRevision:e.model.revision,dayKey:'OMR-day',date:'2026-11-02',marks:[{occurrenceId:'s1',registerId:'lecture',disposition:'ATTENDED',note:'actual ledger output'}],confirmCompleteDay:true,confirmNoUnlistedMeetings:true},clock:{date:'2026-11-02',time:'10:00',timeZone:'Asia/Kolkata'}});
 assert.equal(r.ok,true);e.model=r.proposedModel;e.release.attendance=r.proposedJournal;e.release.attendance.reconciliationIssues.push('Retain actual reconciliation');
 const sha='a'.repeat(64),event={id:'OMR-source',title:'Exam',cancelled:false,sessionId:null,date:'2026-11-03',start:'14:00',end:'15:00'};e.model.events.push(event);
 e.release.calendar.appliedRevisions=[{proposalId:'OMR-revision',sourceSha256:sha,appliedAt:{date:'2026-11-02',time:'10:00',timeZone:'Asia/Kolkata'},modelRevision:e.model.revision,changeIds:['OMR-change']}];
 e.release.calendar.sourceRevision={version:1,sha256:sha,fileName:'source.pdf',source:{sha256:sha,fileName:'source.pdf'},scope:{start:'2026-11-01',end:'2026-11-04',section:'Q',subgroup:null,programmingGroup:null},links:[{sourceRef:'OMR-change',changeId:'OMR-change',kind:'UPSERT_EVENT',targetId:event.id,value:{...event,opaque:{nested:[1,null,{retain:true}]}},evidence:{sourceId:'source',page:1,excerpt:'Exam',basis:'DIRECT_SOURCE'},sourceSha256:sha}],sourceHistory:[{sha256:'b'.repeat(64),fileName:'prior.pdf'}]};return e;
}
function disk(raw,readFault=false){let reads=0,writes=0;return {getItem(){reads++;if(readFault)throw Object.assign(Error('STALE'),{code:'PERSISTED_CONFLICT'});return raw},setItem(k,v){writes++;raw=v},get raw(){return raw},get counts(){return {reads,writes}},reset(){reads=0;writes=0}}}
const existing={expectedRevision:0,expectedModelId:makeCombinedModel().id};
const collisions=[
 ['P0-invalid-expectation',e=>e,{expectedRevision:-1,expectedModelId:existing.expectedModelId},'CANDIDATE_INVALID','INVALID_EXPECTATION',null,0],
 ['P1-read-exception',e=>e,existing,'STORAGE_READ_FAILED','THREW'],
 ['P2-missing',()=>null,existing,'PERSISTED_CONFLICT','MISSING'],
 ['P3-invalid-json',()=>'{',existing,'PERSISTED_DATA_INVALID','JSON_OR_ROOT'],
 ['P4-future-version',e=>({...e,schemaVersion:3}),existing,'UNSUPPORTED_PERSISTED_VERSION','VERSION','/schemaVersion'],
 ['P4-malformed-version',e=>({...e,schemaVersion:'bad'}),existing,'PERSISTED_DATA_INVALID','VERSION_SHAPE'],
 ['P5-invalid-core',e=>{e.model.schedule.initialized=false;return e},existing,'PERSISTED_DATA_INVALID','CORE_INVALID'],
 ['P5-invalid-release',e=>{e.release.attendance.officialSnapshotIds=['missing'];return e},existing,'PERSISTED_DATA_INVALID','CORE_INVALID'],
 ['P6-unknown-record',e=>({...e,unrecognized:true}),existing,'PERSISTED_REWRITE_UNSUPPORTED','UNRECOGNIZED_RETAINED_FIELD','/unrecognized'],
 ['P7-expected-empty',e=>e,{expectedRevision:null},'PERSISTED_CONFLICT','EXPECTED_EMPTY'],
 ['P7-id-conflict',e=>e,{expectedRevision:0,expectedModelId:'other'},'PERSISTED_CONFLICT','MODEL_ID'],
 ['P7-revision-conflict',e=>e,{expectedRevision:1,expectedModelId:existing.expectedModelId},'PERSISTED_CONFLICT','MODEL_REVISION']
];
for(const [id,mutate,options,code,reason,path=null,reads=1] of collisions)test('OMR-01 omission collision '+id,()=>{
 const value=mutate(base()),bytes=typeof value==='string'||value===null?value:JSON.stringify(value),d=disk(bytes,id==='P1-read-exception');let calls=0;const candidate={get id(){calls++;throw Error('candidate accessed')}};
 const result=saveModel(d,candidate,undefined,options);
 recordEvidence('OMR-'+id,{storedBytes:bytes,candidate,options,release:undefined,mutate,readFault:id==='P1-read-exception'},{code,reason,path,reads,writes:0,hooks:0},{...result,...d.counts,hooks:calls},{bytesAfter:d.raw});
 assert.deepEqual({status:result.status,code:result.code,reason:result.reason,path:result.path},{status:'FAILED',code,reason,path});assert.deepEqual(d.counts,{reads,writes:0});assert.equal(d.raw,bytes);assert.equal(calls,0);
});
for(const nonempty of [false,true])for(const expectation of ['matching','omitted'])for(const hostile of [false,true])test(`OMR-01 envelope2 ${nonempty?'history':'empty'} ${expectation} ${hostile?'hostile':'valid'} candidate`,()=>{
 const e=nonempty?history():base(),inputBefore=clone(e),d=disk(JSON.stringify(e)),pre=loadModel(d,validateModel,ceiling);assert.equal(pre.persistence.status,'SAVED');assert.deepEqual(pre.model,e.model);assert.deepEqual(pre.release,e.release);d.reset();
 let calls=0;const candidate=hostile?{get revision(){calls++;throw Error('candidate getter')}}:clone(e.model);if(!hostile)candidate.revision++;const candidateBefore=hostile?null:clone(candidate),bytes=d.raw;
 const options=expectation==='matching'?{expectedRevision:e.model.revision,expectedModelId:e.model.id}:{};
 // Two-argument call tests actual omission; matching call passes explicit undefined.
 const result=expectation==='omitted'?saveModel(d,candidate):saveModel(d,candidate,undefined,options),counts=d.counts;
 recordEvidence(`OMR-P8-${nonempty?'history':'empty'}-${expectation}-${hostile?'hostile':'valid'}`,{storedBytes:bytes,candidate,options,release:undefined,actualArgumentCount:expectation==='omitted'?2:4},{code:'CANDIDATE_INVALID',reason:'CORE_INVALID',path:'/release',reads:1,writes:0,hooks:0},{...result,...counts,hooks:calls},{bytesAfter:d.raw,acceptedBefore:pre,originalInput:e,candidateAfter:hostile?null:candidate});
 assert.deepEqual({status:result.status,code:result.code,reason:result.reason,path:result.path},{status:'FAILED',code:'CANDIDATE_INVALID',reason:'CORE_INVALID',path:'/release'});assert.deepEqual(counts,{reads:1,writes:0});assert.equal(d.raw,bytes);assert.equal(calls,0);assert.deepEqual(e,inputBefore);if(!hostile)assert.deepEqual(candidate,candidateBefore);
 const after=loadModel(d,validateModel,ceiling);assert.equal(after.persistence.status,'SAVED');assert.deepEqual(after.model,pre.model);assert.deepEqual(after.release,pre.release);
 if(nonempty){assert.ok(after.release.attendance.records.length);assert.ok(after.release.attendance.closedDays.length);assert.ok(after.model.snapshots.length>after.release.attendance.officialSnapshotIds.length);assert.deepEqual(after.release.attendance.officialSnapshotIds,['snapshot-1']);assert.equal(after.release.calendar.sourceRevision.links[0].value.opaque.nested[2].retain,true)}
});
for(const kind of ['absent','legacy','explicit'])test('OMR-01 no-expectation compatibility '+kind,()=>{
 const e=kind==='explicit'?history():base(),stored=kind==='absent'?null:kind==='legacy'?{schemaVersion:1,model:e.model}:e,d=disk(stored===null?null:JSON.stringify(stored)),candidate=clone(e.model),before=clone(e);candidate.revision++;
 const result=kind==='explicit'?saveModel(d,candidate,clone(e.release)):saveModel(d,candidate);
 recordEvidence('OMR-compat-'+kind,{stored,candidate,release:kind==='explicit'?e.release:undefined,options:{}},{code:'SAVE_OK',reads:1,writes:1},{...result,...d.counts},{bytesAfter:d.raw});
 assert.equal(result.code,'SAVE_OK');assert.deepEqual(d.counts,{reads:1,writes:1});assert.deepEqual(JSON.parse(d.raw),{schemaVersion:2,model:candidate,release:e.release});assert.deepEqual(e,before);
});
test('OMR-01 explicit null remains invalid, with retained bytes',()=>{
 const e=history(),d=disk(JSON.stringify(e)),bytes=d.raw,candidate=clone(e.model);candidate.revision++;
 const result=saveModel(d,candidate,null,{expectedRevision:e.model.revision,expectedModelId:e.model.id});
 recordEvidence('OMR-explicit-null',{storedBytes:bytes,candidate,release:null},{code:'CANDIDATE_INVALID',reads:1,writes:0},{...result,...d.counts},{bytesAfter:d.raw});
 assert.equal(result.status,'FAILED');assert.equal(result.code,'CANDIDATE_INVALID');assert.deepEqual(d.counts,{reads:1,writes:0});assert.equal(d.raw,bytes);
});
