// Independent Chat A acceptance tests. No production edits. Set SS_CANDIDATE_ROOT
// to the candidate's semester-space directory. Two safety tests fail before repair.
import test from 'node:test';
import assert from 'node:assert/strict';
import {saveModel,loadModel,makeEmptyRelease} from '../../src/storage.js';
import {makeCombinedModel} from '../../src/shared/fixtures.js';
import {evaluateDayClose} from '../../src/attendance/ledger.js';
import {validateModel} from '../../src/engine/index.js';
const clone=structuredClone;
const ceiling={date:'9999-12-31',time:'23:59',timeZone:'Asia/Kolkata'};
function base(){const model=makeCombinedModel();return {schemaVersion:2,model,release:makeEmptyRelease(model)}}
function diskFor(envelope){let raw=envelope===null?null:JSON.stringify(envelope),reads=0,writes=0;return {
 getItem(){reads++;return raw},setItem(key,value){writes++;raw=value},
 bytes:()=>raw,counts:()=>({reads,writes}),reset(){reads=0;writes=0}
}}
function reload(disk){return loadModel(disk,validateModel,ceiling)}
function calendarFixture(){
 const e=base(),sha='a'.repeat(64),event={id:'source-event',title:'Exam',cancelled:false,sessionId:null,date:'2026-11-03',start:'14:00',end:'15:00'};
 e.model.events.push(event);
 e.release.calendar.appliedRevisions=[{proposalId:'reviewed-revision',sourceSha256:sha,appliedAt:{date:'2026-11-01',time:'08:00',timeZone:'Asia/Kolkata'},modelRevision:0,changeIds:['source-change']}];
 e.release.calendar.sourceRevision={version:1,sha256:sha,fileName:'source.pdf',source:{sha256:sha,fileName:'source.pdf'},scope:{start:'2026-11-01',end:'2026-11-04',section:'Q',subgroup:null,programmingGroup:null},links:[{sourceRef:'source-change',changeId:'source-change',kind:'UPSERT_EVENT',targetId:event.id,value:{...event,opaque:{nested:[1,null,{retain:true}]}},evidence:{sourceId:'source',page:1,excerpt:'Exam',basis:'DIRECT_SOURCE'},sourceSha256:sha}],sourceHistory:[{sha256:'b'.repeat(64),fileName:'prior.pdf'}]};
 return e;
}
function attendanceFixture(){
 const e=base(),r=evaluateDayClose({model:e.model,journal:e.release.attendance,request:{expectedModelRevision:e.model.revision,dayKey:'A-S32-day',date:'2026-11-02',marks:[{occurrenceId:'s1',registerId:'lecture',disposition:'ATTENDED',note:'confirmed actual'}],confirmCompleteDay:true,confirmNoUnlistedMeetings:true},clock:{date:'2026-11-02',time:'10:00',timeZone:'Asia/Kolkata'}});
 assert.equal(r.ok,true,JSON.stringify(r));e.model=r.proposedModel;e.release.attendance=r.proposedJournal;e.release.attendance.reconciliationIssues.push('Retained reconciliation issue');return e;
}
for(const [id,fixture] of [['F-S31',calendarFixture],['F-S32',attendanceFixture]])test(id+' existing envelope2 omitted release must fail closed',()=>{
 const e=fixture(),disk=diskFor(e),pre=reload(disk);assert.equal(pre.persistence.status,'SAVED');assert.deepEqual(pre.model,e.model);assert.deepEqual(pre.release,e.release);
 const before=disk.bytes(),candidate=clone(e.model),releaseBefore=clone(e.release);candidate.revision++;
 disk.reset();const result=saveModel(disk,candidate,undefined,{expectedRevision:e.model.revision,expectedModelId:e.model.id}),counts=disk.counts(),after=disk.bytes();
 const restored=reload(disk);
 console.log('A_S31_S32_OBSERVATION '+JSON.stringify({id,result,...counts,bytesEqual:after===before,reloadStatus:restored.persistence.status,beforeRelease:e.release,afterRelease:JSON.parse(after).release}));
 assert.equal(result.status,'FAILED');assert.equal(result.code,'CANDIDATE_INVALID');assert.equal(result.reason,'CORE_INVALID');assert.equal(result.path,'/release');assert.deepEqual(counts,{reads:1,writes:0});assert.equal(after,before);
 assert.equal(restored.persistence.status,'SAVED');assert.deepEqual(restored.model,e.model);assert.deepEqual(restored.release,e.release);assert.deepEqual(e.release,releaseBefore);
});
test('compat empty store EXPECTED_EMPTY can initialize omitted release',()=>{
 const e=base(),disk=diskFor(null);const result=saveModel(disk,e.model,undefined,{expectedRevision:null});assert.equal(result.code,'SAVE_OK');assert.deepEqual(disk.counts(),{reads:1,writes:1});assert.deepEqual(JSON.parse(disk.bytes()),e);
});
test('compat admitted legacy envelope1 can save omitted release',()=>{
 const e=base(),legacy={schemaVersion:1,model:clone(e.model)},disk=diskFor(legacy);const result=saveModel(disk,e.model,undefined,{expectedRevision:e.model.revision,expectedModelId:e.model.id});assert.equal(result.code,'SAVE_OK');assert.deepEqual(disk.counts(),{reads:1,writes:1});assert.deepEqual(JSON.parse(disk.bytes()),e);
});
test('compat envelope2 explicit complete release preserves history',()=>{
 const e=calendarFixture(),disk=diskFor(e),model=clone(e.model);model.revision++;
 const result=saveModel(disk,model,clone(e.release),{expectedRevision:e.model.revision,expectedModelId:e.model.id});assert.equal(result.code,'SAVE_OK');assert.deepEqual(disk.counts(),{reads:1,writes:1});assert.deepEqual(JSON.parse(disk.bytes()),{schemaVersion:2,model,release:e.release});
});
