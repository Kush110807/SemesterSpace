import {validDate, validTime, validClock} from './engine/common.js';
import {IMPORT_SOURCE_PREFIX} from './import/coverage.js';
import { PASS_STATUSES } from './shared/constants.js';
import { FIXED_CLOCK, makeDemoModel } from './shared/fixtures.js';
import { loadModel, saveModel, makeEmptyRelease, validateRelease as validateLegacyRelease, equalJSON, hashAuthority, hashAuthorityBytes } from './storage.js';

export function currentClock() {
  const parts = new Intl.DateTimeFormat('en-GB', {timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23'}).formatToParts(new Date());
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  return {date: `${p.year}-${p.month}-${p.day}`, time: `${p.hour}:${p.minute}`, timeZone: 'Asia/Kolkata'};
}
const copy = value => structuredClone(value);
const validateRelease=(release,model)=>validateLegacyRelease(release?.version===2?{version:1,attendance:release.attendance,calendar:release.calendar}:release,model);
const passes = result => PASS_STATUSES.includes(result?.status);
const required = (condition, message) => { if (!condition) throw new Error(message); };
const unique = list => Array.isArray(list) && list.length === new Set(list).size;
// Course/register rows contain only primitive JSON fields. Ignore row/property order,
// but require identical IDs and values so initialization cannot remap snapshot counts.
function sameRoster(current, incoming) {
  if (!Array.isArray(incoming) || incoming.length !== current.length || incoming.some(row=>!row || typeof row!=='object')) return false;
  const byId=new Map(incoming.map(row=>[row.id,row]));
  return byId.size===current.length && current.every(row=>{
    const candidate=byId.get(row.id),keys=Object.keys(row);
    return candidate && Object.keys(candidate).length===keys.length && keys.every(key=>Object.hasOwn(candidate,key) && Object.is(row[key],candidate[key]));
  });
}

export function createController({engine, render, storage, clock = currentClock, attendance = null, revision = null, sourceAuthority = null, persistenceContext = null, controllerEpoch = null}) {
  const activeSA=sourceAuthority!==null||persistenceContext!==null||controllerEpoch!==null;
  const exactMethods=(value,keys)=>value&&typeof value==='object'&&Reflect.ownKeys(value).length===keys.length&&keys.every(k=>Object.getOwnPropertyDescriptor(value,k)?.value instanceof Function);
  if(activeSA&&(!exactMethods(sourceAuthority,['bindHost','resolveForAcceptance','computeAccepted','createReceipt','finishAcceptance','invalidate'])||typeof persistenceContext!=='function'||typeof controllerEpoch!=='string'||controllerEpoch.length>256||!controllerEpoch.trim()))throw new TypeError('Complete trusted source bootstrap required');
  const permits=new WeakMap(),consents=new WeakMap();let applying=false,uncertain=false;
  const sa=(status,code,reason)=>({status,code,reason,path:null});
  function authorizeTransition(permit,header,current) {
    const record=permits.get(permit);if(!record||record.consumed||!applying||record.epoch!==controllerEpoch||record.transition!==header.transition||record.target!==header.targetEnvelopeVersion)return {ok:false,error:sa('REJECTED','SA_AUTH_INVALID','NO_LIVE_STAGE')};
    record.consumed=true;
    if(!validClock(record.clock))return {ok:false,error:sa('REJECTED','SA_CLOCK_CONFLICT','INVALID_CLOCK')};
    if(record.source&&current.rawEnvelopeSha256!==record.base.rawEnvelopeSha256)return {ok:false,error:sa('REJECTED','SA_UPGRADE_CONSENT_STALE','BASE_BYTES_CHANGED')};
    if(record.source&&record.prepared.base.controllerEpoch!==controllerEpoch)return {ok:false,error:sa('REJECTED','SA_UPGRADE_CONSENT_STALE','CONTROLLER_EPOCH_CHANGED')};
    return {ok:true};
  }
  const context=activeSA?persistenceContext(Object.freeze({controllerEpoch,authorizeTransition})):null;
  if(activeSA&&!exactMethods(context,['load','captureBase','commit']))throw new TypeError('Invalid persistence context surface');
  const loaded = context?context.load((m,c)=>engine.validateModel(m,c),clock()):loadModel(storage, (m,c) => engine.validateModel(m,c), clock());
  let state = {mode:'personal', model:loaded.model, release:loaded.release, month:clock().date.slice(0,7), selectedDate:null, manualDates:[], batch:null, persistence:loaded.persistence, notice:''};
  let results = {runtime:'NO_SETUP',evaluation:null,search:null,error:null};
  const witnesses=new Map();
  let personal = null;
  let stagedRevision = null; // ephemeral, not persisted or trusted after model changes
  const now = () => state.mode === 'demo' ? copy(FIXED_CLOCK) : clock();
  // RC-001.3: a read-only, transient presentation projection. Proposals remain
  // outside persisted release data and are cleared on every accepted mutation.
  // This does NOT constitute a file-to-proposal adapter or permission to apply.
  const projectedState = () => ({...copy(state), stagedCalendarRevision: stagedRevision === null ? null : copy(stagedRevision)});
  const emit = () => render(projectedState(), copy(results), callbacks);
  function fail(error) {
    results = {runtime:error.name === 'EngineUnavailable' ? 'ENGINE_UNAVAILABLE' : 'ERROR', evaluation:null,search:null,error:error.message};
    state.notice = error.message;
    state.batch = null;
  }
  function evaluate(additionalDates = []) {
    if (!state.model) { results = {runtime:'NO_SETUP',evaluation:null,search:null,error:null}; return null; }
    const evaluation = engine.evaluatePlan(state.model, {additionalDates, clock:now()});
    results = {runtime:'READY', evaluation, search:null,error:null};
    return evaluation;
  }
  function transact(update, {requirePassing=false} = {}) {
    assertWritable();required(state.model, 'Create a setup first.');
    const model = copy(state.model);
    const release=copy(state.release ?? makeEmptyRelease(model));
    const transactionClock=now();
    update(model,transactionClock,release);
    model.revision = state.model.revision + 1;
    const validation = engine.validateModel(model, transactionClock);
    required(validation.ok, validation.issues.map(x => x.message).join(' '));
    // Compute before swapping state: unexpected engine errors must not partially commit.
    const evaluation = engine.evaluatePlan(model, {additionalDates:[],clock:transactionClock});
    if (requirePassing && !passes(evaluation)) {
      state.batch=null;
      results={runtime:'READY',evaluation,search:null,error:null};
      state.notice='Acceptance blocked by the final evaluation. No dates were committed or saved.';
      return false;
    }
    // All persisted mutations (not just release callbacks) use the same
    // save-before-state-swap guard. Failed writes cannot create a phantom
    // snapshot, edit, or deleted commitment in the running UI.
    const saved=state.mode==='demo'
      ? {status:'DEMO_MEMORY',message:'Synthetic demo; fixed clock; changes are in memory only.'}
      : persistOrdinary(model,release,'ORDINARY',transactionClock);
    state.persistence=uncertain?{status:'UNCERTAIN',message:'Write acknowledgment is uncertain. Reload saved state before continuing.'}:saved;
    if(saved.status==='FAILED') {
      state.notice='Acceptance failed because the complete change could not be saved. Nothing was committed.';
      return false;
    }
    invalidateSource('MODEL_CHANGED');witnesses.clear();
    state.model = model; state.release = release; stagedRevision=null;
    state.batch = null; state.manualDates = [];
    state.notice = 'Updated; previous suggestions cleared. Commitments are retained for review.';
    results = {runtime:'READY',evaluation,search:null,error:null};
    return true;
  }
  function guarded(action) {
    return payload => { try { action(payload); } catch(error) { fail(error); } emit(); };
  }
  function future(session) {
    const c = now();
    required(session.date > c.date || (session.date === c.date && session.start > c.time), 'Only not-yet-started future meetings can be edited. Update completed-day attendance first.');
  }
  function holiday(m, date, confirmed) {
    if (m.schedule.holidays.some(h => h.date === date)) {
      required(confirmed || m.schedule.holidayTeachingDates.includes(date), 'Confirm that teaching occurs on this holiday.');
      if (!m.schedule.holidayTeachingDates.includes(date)) m.schedule.holidayTeachingDates.push(date);
    }
  }
  // Strict atomic path for the new release features. No durable or in-memory
  // acceptance until a complete validated single-envelope write succeeds.
  function commitRelease(candidateModel, candidateRelease, transactionClock) {
    assertWritable();const previous=state.model;
    required(previous,'Create a setup first.');
    const model=copy(candidateModel),release=copy(candidateRelease);
    model.revision=previous.revision+1;
    const validation=engine.validateModel(model,transactionClock);
    required(validation.ok,validation.issues.map(x=>x.message).join(' '));
    validateRelease(release,model);
    const evaluation=engine.evaluatePlan(model,{additionalDates:[],clock:transactionClock});
    const saved=state.mode==='demo'
      ? {status:'DEMO_MEMORY',message:'Demo changes never overwrite personal storage.'}
      : persistOrdinary(model,release,'ORDINARY',transactionClock);
    if(saved.status==='FAILED') {
      state.persistence=uncertain?{status:'UNCERTAIN',message:'Write acknowledgment is uncertain. Reload saved state before continuing.'}:saved;
      return {ok:false,code:'PERSISTENCE_FAILED',modelRevision:previous.revision,
        engineStatus:null,issues:[{code:'PERSISTENCE_FAILED',message:saved.message}]};
    }
    invalidateSource('MODEL_CHANGED');witnesses.clear();
    state.model=model;state.release=release;state.persistence=uncertain?{status:'UNCERTAIN',message:'Write acknowledgment is uncertain. Reload saved state before continuing.'}:saved;
    state.batch=null;state.manualDates=[];stagedRevision=null;
    results={runtime:'READY',evaluation,search:null,error:null};
    return {ok:true,code:'COMMITTED',modelRevision:model.revision,
      engineStatus:evaluation.status,issues:[]};
  }
  function releaseOperation(fn) {
    return request => {
      if(state.mode==='personal'&&!canWrite()){const response={ok:false,code:state.persistence.code??'PERSISTENCE_FAILED',reason:state.persistence.reason??'RELOAD_REQUIRED',path:state.persistence.path??null,modelRevision:state.model?.revision??null,engineStatus:results.evaluation?.status??null,issues:[]};state.notice='Saved state is inspection only or uncertain; persistence is unavailable.';emit();return response;}
      let response;
      try { response=fn(request); }
      catch(error) {
        // Do not use fail(): that would hide last valid evaluation as if it were corrupt.
        state.notice=error.message;
        const code=/^([A-Z][A-Z0-9_]+):/.exec(error.message)?.[1]??'REJECTED';
        response={ok:false,code,modelRevision:state.model?.revision??null,
          engineStatus:results.evaluation?.status??null,issues:[{code,message:error.message}]};
      }
      emit();
      return copy(response);
    };
  }
  const sameJSON=(left,right)=>JSON.stringify(left)===JSON.stringify(right);
  // B produces new journal entries; only A may accept and persist them.
  // Refuse worker responses that rewrite history, forget an occurrence, or
  // supply records that differ from what the student explicitly confirmed.
  function verifyDayJournal(previous, candidate, request, model, transactionClock) {
    const old=previous.attendance, next=candidate.attendance;
    for(const key of ['records','closedDays','reconciliationIssues'])
      required(Array.isArray(next[key]) && next[key].length>=old[key].length &&
        old[key].every((row,i)=>sameJSON(row,next[key][i])),
        `Daily worker cannot rewrite existing ${key}.`);
    required(sameJSON(old.officialSnapshotIds,next.officialSnapshotIds),
      'Daily worker cannot alter official snapshot history.');
    const newRecords=next.records.slice(old.records.length);
    const newDays=next.closedDays.slice(old.closedDays.length);
    required(newDays.length===1 && newRecords.length===request.marks.length,
      'Daily worker must append exactly one complete day and one record per mark.');
    const day=newDays[0];
    required(day.dayKey===request.dayKey && day.date===request.date &&
      day.noUnlistedMeetings===true && day.sourceModelRevision===model.revision &&
      day.supersedesDayKey===(request.correctionOfDayKey??null) &&
      sameJSON(day.confirmedAt,transactionClock),
      'Daily worker returned an inconsistent completed-day attestation.');
    required(unique(day.recordIds) && day.recordIds.length===newRecords.length &&
      newRecords.every(r=>day.recordIds.includes(r.recordId)),
      'Daily closure and appended record IDs do not match.');
    const priorDay=request.correctionOfDayKey
      ? old.closedDays.find(d=>d.dayKey===request.correctionOfDayKey) : null;
    const priorByOccurrence=new Map((priorDay?.recordIds??[]).map(id=>{
      const record=old.records.find(r=>r.recordId===id);return [record.occurrenceId,record];
    }));
    const marks=new Map(request.marks.map(mark=>[mark.occurrenceId,mark]));
    required(marks.size===request.marks.length,'Duplicate attendance mark.');
    for(const row of newRecords){
      const mark=marks.get(row.occurrenceId);
      const meeting=model.sessions.find(s=>s.id===row.occurrenceId);
      const prior=priorByOccurrence.get(row.occurrenceId);
      required(mark && meeting && row.dayKey===request.dayKey &&
        row.date===request.date && row.registerId===mark.registerId &&
        row.weight===meeting.weight && row.disposition===mark.disposition &&
        row.note===mark.note && row.sourceModelRevision===model.revision &&
        sameJSON(row.confirmedAt,transactionClock) &&
        row.supersedesRecordId===(prior?.recordId??null) &&
        row.recordRevision===(prior?prior.recordRevision+1:1),
        `Daily worker record does not match the confirmed occurrence ${row.occurrenceId}.`);
    }
  }
  function stableHistory(oldModel,newModel,allowAttendanceDerived=false,transactionClock=null) {
    for(const key of ['id','schemaVersion','timeZone','context','courses','registers','commitments','preferences'])
      required(sameJSON(oldModel[key],newModel[key]),`Release update cannot modify ${key}.`);
    required(Array.isArray(newModel.snapshots) && newModel.snapshots.length>=oldModel.snapshots.length &&
      oldModel.snapshots.every((v,i)=>sameJSON(v,newModel.snapshots[i])), 'Cannot rewrite any saved snapshot.');
    if(!allowAttendanceDerived) {
      required(sameJSON(oldModel.snapshots,newModel.snapshots), 'Calendar revision cannot change snapshots.');
      required(sameJSON(oldModel.attendanceConfirmation,newModel.attendanceConfirmation), 'Calendar revision cannot advance attendance.');
      const c=transactionClock;
      required(c,'Transaction clock required for historical comparison.');
      const recorded=new Set((state.release?.attendance?.records??[]).map(r=>r.occurrenceId));
      const fixedThrough=oldModel.snapshots.at(-1).date;
      for(const field of ['holidays','replacements']) {
        const oldPast=oldModel.schedule[field].filter(r=>r.date<=fixedThrough);
        const newPast=newModel.schedule[field].filter(r=>r.date<=fixedThrough);
        required(sameJSON(oldPast,newPast),`Cannot alter confirmed historical ${field}.`);
      }
      required(sameJSON(oldModel.schedule.holidayTeachingDates.filter(d=>d<=fixedThrough),
        newModel.schedule.holidayTeachingDates.filter(d=>d<=fixedThrough)),
        'Cannot alter historical teaching-on-holiday confirmations.');
      for(const old of oldModel.events) {
        const linked=old.sessionId?oldModel.sessions.find(s=>s.id===old.sessionId):null;
        const eventDate=old.date??linked?.date;
        if(eventDate && (eventDate<=fixedThrough || eventDate<c.date))
          required(sameJSON(old,newModel.events.find(e=>e.id===old.id)),
            `Cannot silently modify historical compulsory event ${old.id}.`);
      }
      for(const old of oldModel.sessions)if(old.date<=oldModel.snapshots.at(-1).date ||
          old.date<c.date || old.date===c.date&&old.start<=c.time || recorded.has(old.id)) {
        const next=newModel.sessions.find(s=>s.id===old.id);
        required(next&&sameJSON(old,next),`Historical attendance occurrence ${old.id} cannot be rewritten by a calendar revision.`);
      }
    } else {
      for(const key of ['schedule','sessions','events'])
        required(sameJSON(oldModel[key],newModel[key]),`Day confirmation cannot rewrite ${key}.`);
    }
  }
  const sameSource = (a,b) => revision?.revisionKey ? revision.revisionKey(a)===revision.revisionKey(b) : sameJSON(a,b);
  // RC-001.4 source crosswalk merge: never discard prior/unselected effects.
  // Importer is pure and cannot stamp, persist or silently rewrite history.
  function mergeSourceRevision(previous, proposal, patch, ids) {
    required(patch?.version === 1 && sameSource(patch.source,proposal.source) &&
      sameSource(patch.scope,proposal.scope) && Array.isArray(patch.links),
      'REVISION_METADATA_INVALID: candidate source/coverage metadata does not match the staged proposal.');
    const expected = new Set(ids), collected = new Set(), incoming = [];
    for (const link of patch.links) {
      required(link && expected.has(link.changeId) && !collected.has(link.changeId),
        'REVISION_METADATA_INVALID: missing, duplicated or unselected source crosswalk.');
      const change = proposal.changes.find(c=>c.changeId===link.changeId);
      const target = ['ADD_SESSION','EDIT_SESSION','CANCEL_SESSION'].includes(change.kind)
        ? change.occurrenceId : change.after?.id ?? change.after?.date ?? change.before?.date;
      required(link.sourceRef===change.changeId && link.kind===change.kind &&
        link.targetId===target && sameSource(link.value,change.after) &&
        sameSource(link.evidence,change.evidence),
        'REVISION_METADATA_INVALID: source crosswalk is inconsistent with reviewed change.');
      incoming.push({...copy(link),sourceSha256:proposal.source.sha256});
      collected.add(link.changeId);
    }
    required(collected.size===expected.size,
      'REVISION_METADATA_INVALID: candidate omitted an accepted source crosswalk.');
    const priorLinks = Array.isArray(previous?.links) ? previous.links : [];
    const changedTargets=new Set(incoming.map(l=>`${l.kind}:${l.targetId}`));
    const retained=priorLinks.filter(l=>!changedTargets.has(`${l.kind}:${l.targetId}`)).map(copy);
    // A historical source link may predate per-link SHA tracking. Explicitly
    // bind it to the prior source; never infer that it came from this new file.
    for (const l of retained) l.sourceSha256 ??= previous.sha256;
    const oldSource=previous?.source ?? (previous ? {sha256:previous.sha256,fileName:previous.fileName} : null);
    const history=Array.isArray(previous?.sourceHistory) ? copy(previous.sourceHistory) : [];
    if (oldSource && !history.some(s=>s.sha256===oldSource.sha256 && s.fileName===oldSource.fileName))
      history.push(copy(oldSource));
    return {version:1,sha256:proposal.source.sha256,fileName:proposal.source.fileName,
      source:copy(proposal.source),scope:copy(proposal.scope),links:[...retained,...incoming],sourceHistory:history};
  }
  // Manual event command: branch-owned outcomes, never classified from errors.
  const eventKeys=['id','title','cancelled','sessionId','date','start','end'];
  const exactData=(value,keys)=>{
    if(!value || typeof value!=='object' || Array.isArray(value) || ![Object.prototype,null].includes(Object.getPrototypeOf(value)))return false;
    const d=Object.getOwnPropertyDescriptors(value),own=Reflect.ownKeys(d);
    return own.length===keys.length && keys.every(k=>d[k]?.enumerable && Object.hasOwn(d[k],'value'));
  };
  function clockIssues(c) {
    if(!validClock(c))return {code:'VALIDATION_REJECTED',reason:'INVALID_CLOCK'};
    try {
      const v=engine.validateModel(state.model,{date:'9999-12-31',time:'23:59',timeZone:'Asia/Kolkata'});
      if(!v.ok)return {code:'VALIDATION_REJECTED',reason:'INVALID_RETAINED_MODEL',issues:v.issues};
      validateRelease(state.release,state.model);
    }catch{return {code:'VALIDATION_REJECTED',reason:'INVALID_RETAINED_RECORD'};}
    const rows=[];
    const add=(clock,path,kind)=>rows.push({clock,path,kind});
    state.model.snapshots.forEach((r,i)=>add(r.confirmedAt,`model.snapshots[${i}].confirmedAt`,'SNAPSHOT'));
    state.release.attendance.records.forEach((r,i)=>add(r.confirmedAt,`release.attendance.records[${i}].confirmedAt`,'ATTENDANCE'));
    state.release.attendance.closedDays.forEach((r,i)=>add(r.confirmedAt,`release.attendance.closedDays[${i}].confirmedAt`,'DAY_CLOSE'));
    state.release.calendar.appliedRevisions.forEach((r,i)=>add(r.appliedAt,`release.calendar.appliedRevisions[${i}].appliedAt`,'CALENDAR_REVISION'));
    for(const [path,value] of [['results.evaluation',results.evaluation],['results.search.evaluation',results.search?.evaluation],['state.batch',state.batch],['state.batch.evaluation',state.batch?.evaluation]])if(value?.evaluatedAt)add(value.evaluatedAt,path+'.evaluatedAt','DECISION_OBSERVATION');
    if(rows.some(r=>!validClock(r.clock)))return {code:'VALIDATION_REJECTED',reason:'INVALID_RETAINED_CLOCK'};
    const later=rows.filter(r=>r.clock.date>c.date || r.clock.date===c.date && r.clock.time>c.time);
    if(state.model.snapshots.some(r=>r.date>c.date) || later.length)return {code:'CLOCK_CONFLICT',reason:'RETAINED_CLOCK',offending:later,capturedClock:copy(c)};
    try {const current=engine.validateModel(state.model,c);if(!current.ok)return {code:'VALIDATION_REJECTED',reason:'CURRENT_MODEL_INVALID',issues:current.issues};}
    catch{return {code:'VALIDATION_REJECTED',reason:'CURRENT_MODEL_VALIDATION'};}
    return null;
  }
  function eventTarget(e) {
    if(!exactData(e,eventKeys) || typeof e.id!=='string'||!e.id.trim() || typeof e.title!=='string'||!e.title.trim()||typeof e.cancelled!=='boolean')return null;
    if(e.sessionId===null)return validDate(e.date)&&validTime(e.start)&&validTime(e.end)&&e.start<e.end?{date:e.date,start:e.start,occurrenceId:null}:null;
    if(typeof e.sessionId!=='string'||e.date!==null||e.start!==null||e.end!==null)return null;
    const row=state.model.sessions.find(r=>r.id===e.sessionId);
    return row?{date:row.date,start:row.start,occurrenceId:row.id}:null;
  }
  function historyTarget(target,side,eventId,c) {
    const baseline=state.model.snapshots.reduce((d,r)=>r.date>d?r.date:d,'');
    let reason=null;
    if(target.date<=baseline)reason='SNAPSHOT_COVERED';
    else if(target.date<c.date)reason='PAST_DATE';
    else if(target.date===c.date && target.start<=c.time)reason='STARTED';
    else if(target.occurrenceId && (state.release.attendance.records.some(r=>r.occurrenceId===target.occurrenceId)||state.release.attendance.closedDays.some(d=>d.recordIds.some(id=>state.release.attendance.records.some(r=>r.recordId===id&&r.occurrenceId===target.occurrenceId)))))reason='CONFIRMED_OCCURRENCE';
    return reason?{side,eventId,...target,reason,baseline}:null;
  }
  function ownership(eventId) {
    const cal=state.release.calendar,source=cal.sourceRevision;
    let ambiguous=false,bound=false;
    if(!source)ambiguous=cal.appliedRevisions.length>0 || state.model.context.sourceLabel.startsWith(IMPORT_SOURCE_PREFIX);
    else if(source.version!==1)ambiguous=true;
    else {
      // An empty crosswalk cannot attribute retained applied changes, even to a witnessed local row.
      if(source.links.length===0 && cal.appliedRevisions.some(row=>row.changeIds.length>0))ambiguous=true;
      if(state.model.context.sourceLabel.startsWith(IMPORT_SOURCE_PREFIX))ambiguous=true; // original import has no durable event crosswalk
      for(const link of source.links) {
        if(link.kind==='UPSERT_EVENT' && link.targetId===eventId)bound=true;
        let resolved;
        if(['ADD_SESSION','EDIT_SESSION','CANCEL_SESSION'].includes(link.kind))resolved=state.model.sessions.some(r=>r.id===link.targetId);
        else if(link.kind==='UPSERT_EVENT')resolved=state.model.events.some(r=>r.id===link.targetId);
        else if(link.kind==='ADD_HOLIDAY')resolved=state.model.schedule.holidays.some(r=>r.date===link.targetId);
        else if(link.kind==='REMOVE_HOLIDAY')resolved=link.value===null&&!state.model.schedule.holidays.some(r=>r.date===link.targetId);
        else if(link.kind==='REPLACE_PATTERN')resolved=state.model.schedule.replacements.some(r=>r.date===link.targetId);
        else if(link.kind==='TEACHING_END')resolved=state.model.schedule.teachingEnd===link.targetId;
        else resolved=false;
        if(!resolved)ambiguous=true;
      }
    }
    return {bound,ambiguous};
  }
  function manualEvent(request) {
    const done=(code,details={})=>{
      const ok=['COMMITTED','DEMO_APPLIED','NO_CHANGE'].includes(code);
      const messages={NO_CHANGE:'No change. No save was attempted.',SOURCE_CHANGE_BLOCKED:'This event has retained source evidence. Source changes require review.',SOURCE_REVIEW_REQUIRED:details.reason==='DATASET_SOURCE_RESTRICTION'?'Source history is incomplete; changes to existing events are temporarily blocked.':"This event’s local entry cannot be established in this session.",HISTORY_PROTECTED:'Historical correction is unsupported; the old or proposed event is protected.',CLOCK_CONFLICT:'The clock precedes retained facts or decisions. Review the clock and explicitly revalidate.',STALE_REVISION:'This draft has an older model or revision. Refresh and review before submitting again.',PERSISTENCE_FAILED:'The complete change could not be saved. Accepted data and draft are retained.',VALIDATION_REJECTED:'The event command or retained data is invalid.',COMMITTED:'Event saved in this browser. Local edit permission expires on reload, mode switch or another kind of change.',DEMO_APPLIED:'Demo event applied in memory only.'};
      if(code==='CLOCK_CONFLICT')state.clockConflict=copy(details);
      if(['COMMITTED','DEMO_APPLIED','NO_CHANGE'].includes(code))state.clockConflict=null;
      state.notice=messages[code]??'Event command rejected.';
      const result={ok,code,effect:code==='COMMITTED'||code==='DEMO_APPLIED'?'MUTATED':'NONE',commitState:code==='COMMITTED'?'DURABLE':code==='DEMO_APPLIED'?'MEMORY_ONLY':'NONE',modelRevision:state.model?.revision??null,...details};
      state.eventCommandResult=copy(result);emit();return copy(result);
    };
    try {
      const keys=['requestVersion','mode','expectedModelId','expectedModelRevision','operation','targetEventId','event'];
      if(!exactData(request,keys)||request.requestVersion!==1||!['personal','demo'].includes(request.mode)||typeof request.expectedModelId!=='string'||!request.expectedModelId.trim()||!Number.isSafeInteger(request.expectedModelRevision)||request.expectedModelRevision<0||!['CREATE','UPDATE'].includes(request.operation)||!exactData(request.event,eventKeys))return done('VALIDATION_REJECTED',{reason:'REQUEST_PROFILE'});
      if(request.operation==='CREATE'?request.targetEventId!==null:typeof request.targetEventId!=='string'||!request.targetEventId.trim())return done('VALIDATION_REJECTED',{reason:'TARGET_PROFILE'});
      const e=request.event;
      if(typeof e.id!=='string'||!e.id.trim()||typeof e.title!=='string'||!e.title.trim()||typeof e.cancelled!=='boolean'||(e.sessionId!==null&&typeof e.sessionId!=='string')||request.operation==='UPDATE'&&e.id!==request.targetEventId)return done('VALIDATION_REJECTED',{reason:'EVENT_PROFILE'});
      if(e.sessionId===null ? !validDate(e.date)||!validTime(e.start)||!validTime(e.end)||e.start>=e.end : !e.sessionId.trim()||e.date!==null||e.start!==null||e.end!==null)return done('VALIDATION_REJECTED',{reason:'EVENT_UNION'});
      if(!state.model)return done('VALIDATION_REJECTED',{reason:'NO_SETUP'});
      if(!canWrite())return done('PERSISTENCE_FAILED',{persistence:copy(state.persistence)});
      if(request.mode!==state.mode||request.expectedModelId!==state.model.id||request.expectedModelRevision!==state.model.revision)return done('STALE_REVISION');
      const c=copy(now()),conflict=clockIssues(c);if(conflict)return done(conflict.code,conflict);
      const old=state.model.events.find(r=>r.id===e.id),target=eventTarget(e);
      if(!target || (request.operation==='CREATE'?!!old:!old))return done('VALIDATION_REJECTED',{reason:'EVENT_REFERENCE'});
      const before=old?eventTarget(old):null;if(old&&!before)return done('VALIDATION_REJECTED',{reason:'OLD_REFERENCE'});
      if(old && equalJSON(old,e))return done('NO_CHANGE');
      const protectedTarget=(before&&historyTarget(before,'OLD',e.id,c))||historyTarget(target,'NEW',e.id,c);
      if(protectedTarget)return done('HISTORY_PROTECTED',{history:protectedTarget});
      if(old) {
        const source=ownership(e.id);
        if(source.bound)return done('SOURCE_CHANGE_BLOCKED');
        if(source.ambiguous)return done('SOURCE_REVIEW_REQUIRED',{reason:'DATASET_SOURCE_RESTRICTION'});
        const witness=witnesses.get(e.id);
        if(!witness || witness.mode!==state.mode||witness.modelId!==state.model.id||witness.revision!==state.model.revision||!equalJSON(witness.value,old))return done('SOURCE_REVIEW_REQUIRED',{reason:'LOCAL_ORIGIN_UNPROVEN'});
      }
      const model=copy(state.model),release=copy(state.release);
      if(old)model.events[model.events.findIndex(r=>r.id===e.id)]=copy(e);else model.events.push(copy(e));
      model.revision++;
      if(!Number.isSafeInteger(model.revision))return done('VALIDATION_REJECTED',{reason:'REVISION_OVERFLOW'});
      let evaluation;
      try{const v=engine.validateModel(model,c);if(!v.ok)return done('VALIDATION_REJECTED',{issues:v.issues});validateRelease(release,model);evaluation=engine.evaluatePlan(model,{additionalDates:[],clock:c});}
      catch{return done('VALIDATION_REJECTED',{reason:'CANDIDATE_EVALUATION'});}
      let saved;
      if(state.mode==='personal') {
        try{saved=persistOrdinary(model,release,'ORDINARY',c);}catch{return done('PERSISTENCE_FAILED',{reason:'UNCLASSIFIED'});}
        if(saved?.code!=='SAVE_OK'||saved.status!=='SAVED') {
          const code=saved?.code==='PERSISTED_CONFLICT'?'STALE_REVISION':saved?.code==='CANDIDATE_INVALID'?'VALIDATION_REJECTED':'PERSISTENCE_FAILED';
          return done(code,{persistence:saved??null});
        }
      } else saved={status:'DEMO_MEMORY',message:'Demo changes are in memory only.'};
      for(const [id,w] of witnesses) {
        if(w.mode!==state.mode||w.modelId!==model.id||!equalJSON(w.value,state.model.events.find(r=>r.id===id)))witnesses.delete(id);
        else w.revision=model.revision;
      }
      witnesses.set(e.id,{mode:state.mode,modelId:model.id,revision:model.revision,value:copy(e)});
      invalidateSource('MODEL_CHANGED');state.model=model;state.release=release;state.persistence=uncertain?{status:'UNCERTAIN',message:'Write acknowledgment is uncertain. Reload saved state before continuing.'}:saved;state.batch=null;state.manualDates=[];stagedRevision=null;
      results={runtime:'READY',evaluation,search:null,error:null};
      return done(state.mode==='demo'?'DEMO_APPLIED':'COMMITTED',{engineStatus:evaluation.status});
    } catch{return done('VALIDATION_REJECTED',{reason:'COMMAND_INSPECTION'});}
  }
  function canWrite(){return !uncertain&&!applying&&!['SAVED_READ_ONLY','QUARANTINED','UNCERTAIN'].includes(state.persistence.status);}
  function assertWritable(){required(canWrite(),state.persistence.status==='SAVED_READ_ONLY'?'PERSISTED_REWRITE_UNSUPPORTED: Retained data is inspection only.':'Saved state is unavailable, busy or uncertain; reload explicitly.');}
  function invalidateSource(reason){if(activeSA)sourceAuthority.invalidate(reason);}
  function captureAcceptedBase(){
    assertWritable();required(state.mode==='personal','Source operations are unavailable in demo.');
    const b=context.captureBase();required(b.rewriteAllowed,'Retained saved data is read-only.');
    return {binding:{mode:'personal',controllerEpoch,modelId:b.model?.id??null,modelRevision:b.model?.revision??null,envelopeVersion:b.envelopeVersion,rawEnvelopeSha256:b.rawEnvelopeSha256,priorReleaseSha256:b.priorReleaseSha256},model:copy(b.model),release:copy(b.release)};
  }
  function contextOptions(b){return b.model?{expectedRevision:b.model.revision,expectedModelId:b.model.id,expectedRawEnvelopeSha256:b.rawEnvelopeSha256}:{expectedRevision:null,expectedRawEnvelopeSha256:null};}
  function newPermit(record){const permit=Object.freeze({});permits.set(permit,{...record,epoch:controllerEpoch,consumed:false});return permit;}
  function persistOrdinary(model,release,transition='ORDINARY',transactionClock=now()) {
    if(!activeSA)return saveModel(storage,model,release,state.model?{expectedRevision:state.model.revision,expectedModelId:state.model.id}:{expectedRevision:null});
    assertWritable();const b=context.captureBase(),target=transition==='MANUAL_INITIAL'||b.envelopeVersion===3?3:2;
    const permit=newPermit({transition,target,base:b,source:false,clock:copy(transactionClock)});applying=true;
    try{const attempt=context.commit({options:contextOptions(b),targetEnvelopeVersion:target,transition,permit,buildCandidate:()=>({model,release})});
      if(attempt.writeAttempted&&!attempt.writeAcknowledged){uncertain=true;invalidateSource('COMMIT_UNCERTAIN');state.persistence={status:'UNCERTAIN',message:'Write acknowledgment was lost. Reload saved state before continuing.'};return {...attempt.result,status:'FAILED'};}
      if(attempt.kind==='STORAGE'&&attempt.result?.status==='SAVED'&&(attempt.result.code!=='SAVE_OK'||attempt.writeAttempted!==true||attempt.writeAcknowledged!==true)){uncertain=true;invalidateSource('COMMIT_UNCERTAIN');state.persistence={status:'UNCERTAIN',message:'Save acknowledgment is invalid. Reload saved state before continuing.'};return {status:'FAILED',code:'STORAGE_WRITE_FAILED',reason:null,path:null,message:'Save acknowledgment is invalid; saved bytes may have changed.'};}
      return attempt.kind==='STORAGE'?attempt.result:{status:'FAILED',code:'PERSISTED_CONFLICT',reason:attempt.result.reason,path:null,message:'Private write authorization refused.'};
    }finally{permits.delete(permit);applying=false;}
  }
  function recordUpgradeDecision(stage,intent) {
    if(!canWrite()||state.mode!=='personal')return {ok:false,error:{code:'SA_AUTH_INVALID',reason:'NO_LIVE_STAGE',path:null,message:'No writable personal source operation.'}};
    const resolved=sourceAuthority.resolveForAcceptance(stage,{operation:'CALENDAR_REVISION',confirmation:true});if(!resolved.ok)return resolved;
    const p=resolved.value.prepared;
    if(![1,2].includes(p.base.envelopeVersion))return {ok:false,error:{code:'SA_INPUT_INVALID',reason:'WRONG_OPERATION',path:null,message:'This operation is not a legacy upgrade.'}};
    consents.set(stage,{decision:intent.decision,prepared:copy(p),base:copy(p.base)});
    return {ok:true,value:{decision:intent.decision,recorded:true}};
  }
  function acceptStage(stage,intent) {
    if(!activeSA||!canWrite()||state.mode!=='personal')return sa('REJECTED','SA_AUTH_INVALID','NO_LIVE_STAGE');
    const resolved=sourceAuthority.resolveForAcceptance(stage,intent);if(!resolved.ok)return resolved.error.code==='SA_INPUT_INVALID'?sa('REJECTED','SA_AUTH_INVALID','INVALID_INTENT'):sa('REJECTED',resolved.error.code,resolved.error.reason);
    const {lease,prepared}=resolved.value;let outcome='REJECTED',permit=null,attempt=null;
    try {
      const base=captureAcceptedBase(),transactionClock=copy(now()),initial=prepared.operation==='INITIAL_IMPORT',transition=initial?'DOCUMENT_INITIAL':'DOCUMENT_REVISION';
      if(!initial&&[1,2].includes(base.binding.envelopeVersion)) {
        const consent=consents.get(stage);if(!consent)return sa('REJECTED','SA_UPGRADE_CONSENT_REQUIRED','CONSENT_REQUIRED');
        if(consent.decision==='DECLINE')return sa('REJECTED','SA_UPGRADE_CONSENT_DECLINED','CONSENT_DECLINED');
        const previous=consent.prepared;
        const difference=previous.stageId!==prepared.stageId?'STAGE_CHANGED':previous.stageGeneration!==prepared.stageGeneration?'STAGE_GENERATION_CHANGED':previous.base.controllerEpoch!==prepared.base.controllerEpoch?'CONTROLLER_EPOCH_CHANGED':previous.base.envelopeVersion!==prepared.base.envelopeVersion?'PROFILE_MISMATCH':previous.base.rawEnvelopeSha256!==prepared.base.rawEnvelopeSha256||previous.base.priorReleaseSha256!==prepared.base.priorReleaseSha256?'BASE_BYTES_CHANGED':!equalJSON(previous.approvedEffectIds,prepared.approvedEffectIds)||!equalJSON(previous.approvedGroupIds,prepared.approvedGroupIds)?'APPROVED_SUBSET_CHANGED':!equalJSON(previous,prepared)?'STAGE_CHANGED':null;
        if(difference)return sa('REJECTED','SA_UPGRADE_CONSENT_STALE',difference);
      }
      if(!equalJSON(base.binding,prepared.base))return sa('REJECTED','SA_AUTH_STALE','NO_LIVE_STAGE');
      if(!validClock(transactionClock))return sa('REJECTED','SA_CLOCK_CONFLICT','INVALID_CLOCK');
      if(transactionClock.date+'T'+transactionClock.time<prepared.computationClock.date+'T'+prepared.computationClock.time)return sa('REJECTED','SA_CLOCK_CONFLICT','REVIEW_CLOCK');
      if(state.model){const conflict=clockIssues(transactionClock);if(conflict)return sa('REJECTED','SA_CLOCK_CONFLICT',conflict.reason==='INVALID_CLOCK'?'INVALID_CLOCK':'RETAINED_CLOCK');}
      const sb=context.captureBase();permit=newPermit({transition,target:3,base:sb,prepared,source:true,lease,clock:transactionClock});applying=true;
      let acceptedModel,acceptedRelease,evaluation,domainFailure=null;const domainAbort=Object.freeze({});
      attempt=context.commit({options:contextOptions(sb),targetEnvelopeVersion:3,transition,permit,buildCandidate:()=>{
        const computed=sourceAuthority.computeAccepted(lease,{base,clock:transactionClock});if(!computed.ok){domainFailure=sa('REJECTED',computed.error.code,computed.error.reason);throw domainAbort;}
        const value=computed.value,model=copy(value.proposedModel);model.revision=initial?0:state.model.revision+1;
        if(!initial){try{stableHistory(state.model,model,false,transactionClock);}catch{domainFailure=sa('REJECTED','SA_HISTORY_PROTECTED','HISTORY_PROTECTED');throw domainAbort;}}
        const release=initial?makeEmptyRelease(model):copy(state.release);let application=null;
        if(!initial){
          const proposal={source:value.sourceRevisionPatch?.source,scope:value.sourceRevisionPatch?.scope,changes:prepared.effects.map(e=>e.change)};
          application={proposalId:`revision:${proposal.source.sha256}:${state.model.revision}:${prepared.reviewSha256}`,sourceSha256:proposal.source.sha256,appliedAt:transactionClock,modelRevision:model.revision,changeIds:copy(prepared.approvedEffectIds)};
          release.calendar.appliedRevisions.push(application);
          release.calendar.sourceRevision=mergeSourceRevision(state.release.calendar.sourceRevision,proposal,value.sourceRevisionPatch,prepared.approvedEffectIds);
        }
        const receipt=sourceAuthority.createReceipt(lease,{acceptedModel:model,priorRelease:base.release,sourceRevisionPatch:value.sourceRevisionPatch,newAppliedRevision:application,acceptedAt:transactionClock});required(receipt.ok,'Source receipt construction refused.');
        if(release.version!==2){release.version=2;release.provenance={version:1,initialOrigin:initial?'DOCUMENT':'LEGACY_UNATTESTED',legacyBase:initial?null:{envelopeVersion:sb.envelopeVersion,modelId:sb.model.id,modelRevision:sb.model.revision,rawEnvelopeSha256:sb.rawEnvelopeSha256},receipts:[]};}
        release.provenance.receipts.push(copy(receipt.value));
        const check=engine.validateModel(model,transactionClock);required(check.ok,'Source model failed validation.');validateRelease(release,model);evaluation=engine.evaluatePlan(model,{additionalDates:[],clock:transactionClock});acceptedModel=model;acceptedRelease=release;return {model,release};
      }});
      if(attempt.kind==='AUTHORITY')return attempt.result;
      if(attempt.writeAttempted&&!attempt.writeAcknowledged){uncertain=true;outcome='UNCERTAIN';state.persistence={status:'UNCERTAIN',message:'Write acknowledgment is uncertain. Reload saved state; do not retry the old stage.'};invalidateSource('COMMIT_UNCERTAIN');return sa('UNCERTAIN','SA_COMMIT_UNCERTAIN','STORAGE_ACK_UNCERTAIN');}
      if(attempt.result?.status!=='SAVED'||attempt.result?.code!=='SAVE_OK'||attempt.writeAttempted!==true||attempt.writeAcknowledged!==true||!acceptedModel||!acceptedRelease){
        if(attempt.writeAttempted||attempt.writeAcknowledged||attempt.result?.status==='SAVED'){uncertain=true;outcome='UNCERTAIN';state.persistence={status:'UNCERTAIN',message:'Saved bytes may have changed but the acknowledgment was invalid. Reload saved state explicitly.'};invalidateSource('COMMIT_UNCERTAIN');return sa('UNCERTAIN','SA_COMMIT_UNCERTAIN','POST_WRITE_ACK_FAILED');}
        const failures=['STORAGE_READ_FAILED','PERSISTED_DATA_INVALID','UNSUPPORTED_PERSISTED_VERSION','PERSISTED_REWRITE_UNSUPPORTED','PERSISTED_CONFLICT','CANDIDATE_INVALID','SERIALIZATION_FAILED','STORAGE_WRITE_FAILED','PROVENANCE_LIMIT_EXCEEDED'];return domainFailure??sa('REJECTED','SA_PERSISTENCE_FAILED',failures.includes(attempt.result?.code)?attempt.result.code:'CANDIDATE_INVALID');
      }
      // Render is an observable host acknowledgment boundary; do it before accepted memory promotion.
      try{render({...projectedState(),notice:'Source write acknowledged; updating accepted state.'},copy(results),callbacks);}catch{uncertain=true;outcome='UNCERTAIN';state.persistence={status:'UNCERTAIN',message:'Saved bytes may have changed. Explicit reload required.'};invalidateSource('COMMIT_UNCERTAIN');return sa('UNCERTAIN','SA_COMMIT_UNCERTAIN','POST_WRITE_ACK_FAILED');}
      state.model=acceptedModel;state.release=acceptedRelease;state.persistence=attempt.result;state.batch=null;state.manualDates=[];state.clockConflict=null;state.notice='Reviewed source change saved locally. Institutional authenticity is unverified.';witnesses.clear();stagedRevision=null;results={runtime:'READY',evaluation,search:null,error:null};outcome='ACCEPTED';
      return sa('ACCEPTED','SA_ACCEPTED','ONE_ENVELOPE_WRITE');
    }finally{if(permit)permits.delete(permit);consents.delete(stage);applying=false;sourceAuthority.finishAcceptance(lease,outcome);if(outcome==='ACCEPTED')invalidateSource('MODEL_CHANGED');try{emit();}catch{/* Post-promotion display failure is not a lost storage acknowledgment. */}}
  }

  const callbacks = {
    onEnterDemo: guarded(() => {
      if (state.mode === 'demo') return;
      invalidateSource('MODE_CHANGED');witnesses.clear();personal = copy(state);stagedRevision=null;
      state = {...state, clockConflict:null,mode:'demo',model:makeDemoModel(),release:makeEmptyRelease(makeDemoModel()),month:FIXED_CLOCK.date.slice(0,7),selectedDate:null,manualDates:[],batch:null,notice:'DEMO ONLY — clock fixed at 2 November 2026, 08:00 IST.',persistence:{status:'DEMO_MEMORY',message:'Demo changes never overwrite personal storage.'}};
      evaluate();
    }),
    onExitDemo: guarded(() => {
      if (personal) {
        invalidateSource('MODE_CHANGED');witnesses.clear();state = personal; personal = null;
        const evaluation=evaluate(state.batch?.dates ?? []);
        if (!passes(evaluation)) state.batch=null;
      }
    }),
    onReplaceSetup: guarded(({model}) => {
      assertWritable();required(typeof model?.context?.sourceLabel==='string'&&!model.context.sourceLabel.startsWith(IMPORT_SOURCE_PREFIX),'Document-origin setup requires a live source review.');
      required(!state.model, 'Setup replacement is allowed only before initialization. Use update actions to preserve history and commitments.');
      const transactionClock=copy(now());
      const candidate = copy(model);
      required(candidate.snapshots.length === 1 && candidate.commitments.length === 0, 'A new setup starts with one confirmed snapshot and no commitments.');
      candidate.revision = 0;
      // This is a newly confirmed setup, not an import of historical attestations.
      candidate.snapshots[0].confirmedAt=copy(transactionClock);
      if (!candidate.schedule.initialized) {
        const expanded = engine.expandSchedule({schedule:candidate.schedule,courses:candidate.courses,registers:candidate.registers,extraSessions:candidate.sessions,overrides:[]});
        required(expanded.ok,expanded.issues.map(x=>x.message).join(' '));
        candidate.sessions = expanded.sessions; candidate.schedule.initialized = true;
      }
      const check = engine.validateModel(candidate,transactionClock);
      required(check.ok,check.issues.map(x=>x.message).join(' '));
      const evaluation=engine.evaluatePlan(candidate,{additionalDates:[],clock:transactionClock});
      const release=activeSA?{...makeEmptyRelease(candidate),version:2,provenance:{version:1,initialOrigin:'MANUAL',legacyBase:null,receipts:[]}}:makeEmptyRelease(candidate);
      const saved=state.mode==='demo'?{status:'DEMO_MEMORY',message:'Demo changes never overwrite personal storage.'}
        :persistOrdinary(candidate,release,'MANUAL_INITIAL',transactionClock);
      if(saved.status==='FAILED') {state.persistence=uncertain?{status:'UNCERTAIN',message:'Write acknowledgment is uncertain. Reload saved state before continuing.'}:saved;state.notice='Initial setup could not be persisted; no setup was accepted.';return;}
      invalidateSource('DATASET_CHANGED');witnesses.clear();state.model = candidate;state.release=release;stagedRevision=null; state.month = transactionClock.date.slice(0,7);
      results={runtime:'READY',evaluation,search:null,error:null};state.persistence=uncertain?{status:'UNCERTAIN',message:'Write acknowledgment is uncertain. Reload saved state before continuing.'}:saved;
    }),
    onInitializeSchedule: guarded(({draft}) => transact(m => {
      required(!m.schedule.initialized, 'Recurring schedule already initialized; edit individual future meetings.');
      required(sameRoster(m.courses,draft.courses) && sameRoster(m.registers,draft.registers), 'Schedule draft courses and registers must exactly match the existing roster. Initialize the full roster through initial setup instead.');
      const expanded = engine.expandSchedule(draft);
      required(expanded.ok,expanded.issues.map(x=>x.message).join(' '));
      m.schedule = {...copy(draft.schedule),initialized:true}; m.sessions = expanded.sessions;
    })),
    onSetPreferences: guarded(preferences => transact(m => { m.preferences = copy(preferences); })),
    onSetThreshold: guarded(({registerId,requiredBps,personalMinBps,bufferBps}) => transact(m => {
      const r = m.registers.find(x => x.id === registerId); required(r, 'Unknown register.');
      Object.assign(r,{requiredBps,personalMinBps,bufferBps});
    })),
    onSetCourseProtection: guarded(({courseId,mustAttend}) => transact(m => {
      const course = m.courses.find(c=>c.id===courseId); required(course,'Unknown course.'); course.mustAttend = mustAttend;
    })),
    onConfirmSnapshot: guarded(({date,counts,confirmed,completeToday}) => {
      required(state.model && confirmed === true, 'Explicit official snapshot confirmation is required.');
      const transactionClock=now();
      const latest=state.model.snapshots.at(-1);
      required(date>=latest.date, 'REQUIRES_CHRONOLOGICAL_OFFICIAL_SNAPSHOT: official date cannot predate the last derived or official snapshot.');
      const sequence=latest.sequence+1;
      const officialSnapshot={id:`${state.model.id}:snapshot:${sequence}`,sequence,date,
        counts:copy(counts),confirmed:true,completeToday,confirmedAt:copy(transactionClock)};
      // Existing controller-only harnesses remain supported for legacy empty
      // journals. Real browser app injects B and always uses its cutover logic.
      if (!attendance?.reconcileOfficialSnapshot) {
        required(state.release.attendance.records.length===0 && state.release.attendance.closedDays.length===0,
          'ATTENDANCE_ADAPTER_MISSING: cannot reconcile existing daily history without B.');
        transact((m,c,release) => {
          m.snapshots.push({...officialSnapshot,confirmedAt:copy(c)});
          release.attendance.officialSnapshotIds.push(officialSnapshot.id);
          m.attendanceConfirmation={throughDate:date,noUnlistedClasses:true};
        });
        return;
      }
      const proposed=attendance.reconcileOfficialSnapshot({previousModel:copy(state.model),
        journal:copy(state.release.attendance),officialSnapshot,clock:transactionClock});
      required(proposed?.ok,
        `${proposed?.code??'OFFICIAL_RECONCILIATION_FAILED'}: ${(proposed?.issues??[]).map(x=>x.message).join(' ')}`);
      stableHistory(state.model,proposed.proposedModel,true,transactionClock);
      const newSnapshots=proposed.proposedModel.snapshots;
      required(newSnapshots.length===state.model.snapshots.length+1 &&
        sameJSON(newSnapshots.at(-1),officialSnapshot),
        'Official reconciliation cannot rewrite snapshots or alter the authoritative attestation.');
      const release=copy(state.release),old=release.attendance;
      const next=proposed.proposedJournal;
      required(sameJSON(old.records,next.records) && sameJSON(old.closedDays,next.closedDays) &&
        next.officialSnapshotIds.length===old.officialSnapshotIds.length+1 &&
        old.officialSnapshotIds.every((id,i)=>next.officialSnapshotIds[i]===id) &&
        next.officialSnapshotIds.at(-1)===officialSnapshot.id &&
        next.reconciliationIssues.length>=old.reconciliationIssues.length &&
        old.reconciliationIssues.every((msg,i)=>next.reconciliationIssues[i]===msg),
        'Official reconciliation must preserve the complete confirmed attendance journal.');
      release.attendance=copy(next);
      const committed=commitRelease(proposed.proposedModel,release,transactionClock);
      if(!committed.ok) {
        state.notice='Official snapshot was not accepted; persistence failed without changing history.';
        return;
      }
      state.notice=next.reconciliationIssues.length>old.reconciliationIssues.length
        ? 'Official baseline superseded derived totals; attendance discrepancy or incomplete interval retained for review.'
        : 'Official attendance baseline saved; earlier daily records retained for audit.';
    }),
    onConfirmGap: guarded(confirmation => transact(m => {m.attendanceConfirmation=copy(confirmation);})),
    onSetTeachingEnd: guarded(({date,confirmed}) => transact(m => {m.schedule.teachingEnd=date;m.schedule.confirmed=confirmed;})),
    onAddSession: guarded(({session,teachingOnHolidayConfirmed}) => transact(m => {
      future(session); required(!m.sessions.some(x=>x.id===session.id),'Session ID already exists.');
      holiday(m,session.date,teachingOnHolidayConfirmed);m.sessions.push(copy(session));
    })),
    onEditSession: guarded(({sessionId,changes,teachingOnHolidayConfirmed}) => transact(m => {
      const s = m.sessions.find(x=>x.id===sessionId);required(s,'Unknown session.'); future(s);
      const allowed = ['date','start','end','registerId','weight','protected','cancelled'];
      required(Object.keys(changes).every(k=>allowed.includes(k)), 'Session ID and origin cannot be changed.');
      Object.assign(s,copy(changes));future(s); if (!s.cancelled) holiday(m,s.date,teachingOnHolidayConfirmed);
    })),
    onUpsertEvent: manualEvent,
    onUncommit: guarded(({commitmentId}) => transact(m => {
      required(m.commitments.some(x=>x.id===commitmentId),'Unknown commitment.');
      m.commitments=m.commitments.filter(x=>x.id!==commitmentId);
    })),
    onSelectDate: guarded(({date}) => {state.selectedDate=date;}),
    onSetMonth: guarded(({month}) => {required(/^\d{4}-(0[1-9]|1[0-2])$/.test(month),'Invalid month.');state.month=month;}),
    onSetManualDates: guarded(({dates}) => {
      // A rejected new selection must not leave an older selection available to check.
      state.manualDates=[];state.batch=null;
      required(unique(dates),'Select unique dates.');state.manualDates=copy(dates);evaluate();
    }),
    onCheckManual: guarded(() => {
      const conflict=state.model&&clockIssues(now());if(conflict){state.clockConflict=copy(conflict);state.notice=conflict.code+': Explicit revalidation required.';return;}
      state.clockConflict=null;
      const evaluation = evaluate(state.manualDates);
      state.batch = passes(evaluation) && state.manualDates.length ? {modelRevision:state.model.revision,evaluatedAt:now(),dates:copy(state.manualDates),evaluation} : null;
      state.notice = state.batch ? 'Manual dates checked together. Explicit acceptance is still required.' : 'No passing manual selection to accept.';
    }),
    onSuggest: guarded(() => {
      const conflict=state.model&&clockIssues(now());if(conflict){state.clockConflict=copy(conflict);state.notice=conflict.code+': Explicit revalidation required.';return;}
      state.clockConflict=null;
      required(state.model,'Create a setup first.');
      const search = engine.suggestPlan(state.model,{clock:now()});
      results={runtime:'READY',evaluation:search.evaluation,search,error:null};
      state.batch = search.batch && passes(search.batch.evaluation) ? copy(search.batch) : null;
      state.notice=search.search.requested===null ? 'Invalid request. Correct the setup issues before searching.' : `Found ${search.search.found} days using this search; requested ${search.search.requested}.`;
    }),
    onAccept: guarded(({dates,modelRevision}) => {
      required(state.batch && state.model,'No current checked batch to accept.');
      if(state.clockConflict){state.notice='CLOCK_CONFLICT: Explicit revalidation required before accepting.';return;}
      const conflict=clockIssues(now());if(conflict){state.clockConflict=copy(conflict);state.notice=conflict.code+': Explicit revalidation required.';return;}
      required(modelRevision===state.model.revision && modelRevision===state.batch.modelRevision,'Stale suggestion revision. Generate a new batch.');
      required(unique(dates) && dates.length>0 && dates.every(d=>state.batch.dates.includes(d)), 'Accept a unique nonempty subset of the displayed batch.');
      const evaluation=engine.evaluatePlan(state.model,{additionalDates:dates,clock:now()});
      if (!passes(evaluation)) {
        state.batch=null; results={runtime:'READY',evaluation,search:null,error:null};state.notice='Acceptance blocked after current-time revalidation. No dates were committed.';return;
      }
      const committed=transact(m => {
        for(const date of dates) m.commitments.push({id:`${m.id}:commit:${m.revision+1}:${date}`,date,createdAtRevision:m.revision+1});
      },{requirePassing:true});
      if (committed) state.notice='Selected dates committed together. Other future sessions are assumed attended.';
    }),
    onConfirmAttendanceDay: releaseOperation(request => {
      required(state.model,'Create a setup first.');
      required(typeof request?.dayKey==='string' && request.dayKey &&
        /^\d{4}-\d{2}-\d{2}$/.test(request.date) && Array.isArray(request.marks),
        'Day confirmation requires a valid date, durable day key and marks.');
      required(request.confirmCompleteDay===true && request.confirmNoUnlistedMeetings===true,
        'Explicit complete-day and no-unlisted-meetings confirmations are required.');
      const previousDay=state.release.attendance.closedDays.find(d=>d.dayKey===request.dayKey);
      if(previousDay) {
        const actual=previousDay.recordIds.map(id=>state.release.attendance.records.find(r=>r.recordId===id));
        const original=actual.map(r=>[r.occurrenceId,r.registerId,r.disposition,r.note]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
        const incoming=request.marks.map(r=>[r.occurrenceId,r.registerId,r.disposition,r.note]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)));
        required(previousDay.date===request.date &&
          previousDay.supersedesDayKey===(request.correctionOfDayKey??null) &&
          request.confirmCompleteDay===true && request.confirmNoUnlistedMeetings===true &&
          sameJSON(original,incoming),'IDEMPOTENCY_CONFLICT: dayKey was already used with different attendance evidence.');
        return {ok:true,code:'ALREADY_CONFIRMED',modelRevision:state.model.revision,
          dayKey:request.dayKey,snapshotId:null,registerTotals:null,
          engineStatus:results.evaluation?.status??null,issues:[]};
      }
      required(request.expectedModelRevision===state.model.revision,
        'STALE_MODEL_REVISION: attendance draft must be refreshed.');
      const closedSameDate=state.release.attendance.closedDays.filter(d=>d.date===request.date);
      if(!closedSameDate.length) {
        const snapshotDate=state.model.snapshots.at(-1).date;
        const nextDate=new Date(Date.parse(`${snapshotDate}T00:00:00Z`)+86400000).toISOString().slice(0,10);
        required(request.date===nextDate,
          `UNRESOLVED_GAP: first confirm the entire day ${nextDate} before advancing attendance.`);
      }
      if(closedSameDate.length) {
        const superseded=new Set(closedSameDate.map(d=>d.supersedesDayKey).filter(Boolean));
        required(typeof request.correctionOfDayKey==='string' &&
          closedSameDate.some(d=>d.dayKey===request.correctionOfDayKey && !superseded.has(d.dayKey)),
          'A previously confirmed day needs an explicit correction reference and a new dayKey.');
        const officialDates=state.model.snapshots.filter(s=>state.release.attendance.officialSnapshotIds.includes(s.id)).map(s=>s.date);
        required(request.date>officialDates.at(-1), 'REQUIRES_OFFICIAL_RECONCILIATION: correction is at or before the latest official baseline.');
      }
      const meetingRows=state.model.sessions.filter(s=>!s.cancelled && s.date===request.date);
      const expected=new Map(meetingRows.map(s=>[s.id,s]));
      const listed=new Set();
      for(const mark of request.marks){
        required(mark && typeof mark.occurrenceId==='string' && !listed.has(mark.occurrenceId),
          'Duplicate/invalid attendance mark.');
        listed.add(mark.occurrenceId);
        const meeting=expected.get(mark.occurrenceId);
        required(meeting && meeting.registerId===mark.registerId,'Unknown session or register in attendance mark.');
        required(['ATTENDED','MISSED','NOT_HELD'].includes(mark.disposition) && typeof mark.note==='string',
          'Every occurrence must have an explicit completed disposition.');
      }
      required(listed.size===expected.size,'UNRESOLVED_OCCURRENCES: every scheduled noncancelled occurrence needs a mark.');
      const transactionClock=now();
      required(request.date<=transactionClock.date && meetingRows.every(s=>s.date<transactionClock.date || s.end<=transactionClock.time),
        'Cannot confirm the date before every scheduled occurrence has ended.');
      required(attendance && typeof attendance.evaluateDayClose==='function',
        'Daily attendance logic has not been integrated from B.');
      const proposed=attendance.evaluateDayClose({model:copy(state.model),
        journal:copy(state.release.attendance),request:copy(request),clock:transactionClock});
      if(!proposed?.ok) return {ok:false,code:proposed?.code??'DAY_REJECTED',
        modelRevision:state.model.revision,dayKey:null,snapshotId:null,
        registerTotals:null,engineStatus:results.evaluation?.status??null,issues:proposed?.issues??[]};
      required(proposed.idempotent!==true,'Worker cannot claim an unknown day key was already confirmed.');
      required(proposed.proposedModel&&proposed.proposedJournal,'B must return a full proposed model and journal.');
      stableHistory(state.model,proposed.proposedModel,true,transactionClock);
      required(proposed.proposedModel.snapshots.length===state.model.snapshots.length+1 &&
        sameJSON(proposed.proposedModel.snapshots.at(-1).confirmedAt,transactionClock),
        'Daily derived snapshot must be appended exactly once with the authoritative controller clock.');
      const release=copy(state.release);release.attendance=copy(proposed.proposedJournal);
      const oldRecordIds=new Set(state.release.attendance.records.map(r=>r.recordId));
      const oldDayKeys=new Set(state.release.attendance.closedDays.map(d=>d.dayKey));
      required(release.attendance.records.filter(r=>!oldRecordIds.has(r.recordId))
        .every(r=>sameJSON(r.confirmedAt,transactionClock)) &&
        release.attendance.closedDays.filter(d=>!oldDayKeys.has(d.dayKey))
        .every(d=>sameJSON(d.confirmedAt,transactionClock)),
        'New attendance attestations must use the controller transaction clock.');
      const newlyClosed=release.attendance.closedDays.find(d=>d.dayKey===request.dayKey);
      required(newlyClosed && newlyClosed.date===request.date &&
        newlyClosed.supersedesDayKey===(request.correctionOfDayKey??null),
        'Daily worker did not return the confirmed day or correction reference.');
      verifyDayJournal(state.release,release,request,state.model,transactionClock);
      const appended=proposed.proposedModel.snapshots.at(-1);
      const previous=state.model.snapshots.at(-1);
      required(appended.sequence===previous.sequence+1 && appended.confirmed===true &&
        appended.date===(request.correctionOfDayKey ? previous.date : request.date) &&
        sameJSON(proposed.proposedModel.attendanceConfirmation,
          {throughDate:appended.date,noUnlistedClasses:true}),
        'Daily worker snapshot does not advance confirmed attendance consistently.');
      const committed=commitRelease(proposed.proposedModel,release,transactionClock);
      if(!committed.ok) return {...committed,dayKey:null,snapshotId:null,registerTotals:null};
      state.notice='Confirmed daily attendance saved; plan and retained commitments recalculated.';
      return {...committed,code:'DAY_CONFIRMED',dayKey:request.dayKey,
        snapshotId:state.model.snapshots.at(-1).id,registerTotals:proposed.registerTotals??null};
    }),
    onProposeCalendarRevision: () => ({ok:false,code:'SOURCE_REVIEW_REQUIRED',modelRevision:state.model?.revision??null,proposalId:null,changeCount:0,issues:[{code:'SA_AUTH_INVALID',message:'A live source review is required.'}]}),
    onApplyCalendarRevision: () => ({ok:false,code:'SOURCE_REVIEW_REQUIRED',modelRevision:state.model?.revision??null,appliedChangeIds:[],preservedCommitmentIds:[],engineStatus:results.evaluation?.status??null,issues:[{code:'SA_AUTH_INVALID',message:'A live source review is required.'}]}),
    onReloadSavedState: guarded(() => {
      required(state.mode==='personal','Exit demo before reloading personal state.');
      invalidateSource('RELOADED');witnesses.clear();stagedRevision=null;
      const next=context?context.load((m,c)=>engine.validateModel(m,c),clock()):loadModel(storage,(m,c)=>engine.validateModel(m,c),clock());
      uncertain=false;state={...state,model:next.model,release:next.release,persistence:next.persistence,batch:null,manualDates:[],clockConflict:null,notice:'Saved state reloaded; prior source authority and consent were discarded.'};evaluate();
    }),
    onRefresh: guarded((request={}) => {
      if(state.clockConflict && request.explicit!==true){state.notice='CLOCK_CONFLICT: Use Recheck current plan for explicit revalidation.';return;}
      const conflict=state.model&&clockIssues(now());if(conflict){state.clockConflict=copy(conflict);state.notice=conflict.code+': Explicit revalidation required.';return;}
      state.clockConflict=null;
      const evaluation=evaluate(state.batch?.dates ?? []);
      if (!passes(evaluation) || state.batch?.modelRevision!==state.model?.revision) state.batch=null;
    }),
  };
  if(activeSA)sourceAuthority.bindHost(Object.freeze({captureBase:captureAcceptedBase,captureClock:()=>copy(now()),acceptStage,recordUpgradeDecision}));
  try {evaluate();} catch(error) {fail(error);}
  emit();
  return {callbacks,getState:projectedState,getResults:()=>copy(results)};
}
