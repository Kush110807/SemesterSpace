#!/usr/bin/env python3
"""Static evidence-only auditor. Never imports application modules or executes helpers."""
import base64,collections,csv,hashlib,json,os,pathlib,re,subprocess,sys,zipfile
P=pathlib.Path('/workspace/sa001-readonly-investigation-input-2026-11-05')
W=pathlib.Path('/workspace/sa001-readonly-investigation-2026-11-05')
O=W/'outputs'; A=W/'analysis'; REPO=pathlib.Path('/workspace/SemesterSpace-sa-001')
R=next((P/'RECOVERED_APPLICATION_EVIDENCE').iterdir()); prefix=R.relative_to(P).as_posix()
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_bytes())
def dump(p,d): p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def compact(d): return json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def ptr(d,p):
 for k in p.strip('/').split('/') if p else []:
  k=k.replace('~1','/').replace('~0','~'); d=d[int(k)] if isinstance(d,list) else d[k]
 return d
M=read(P/'SOURCE_MEMBER_MANIFEST.json'); members={x['source_path']:x for x in M['members']}; failures=[]
def check(ok,msg):
 if not ok: failures.append(msg)
 return bool(ok)
def cite(path,pointer=''):
 path=path.relative_to(P).as_posix() if isinstance(path,pathlib.Path) else path
 return {'source_path':path,'pointer':pointer,'sha256':sha((P/path).read_bytes()),'manifested_original':path in members}
member_rows=[]
for name,v in members.items():
 b=(P/name).read_bytes(); ok=len(b)==v['size_bytes'] and sha(b)==v['sha256'];check(ok,'member identity '+name)
 member_rows.append(dict(source_path=name,size_bytes=len(b),sha256=sha(b),disposition='VERIFIED' if ok else 'FAILED'))
check(len(members)==170,'170 unique members')
rootledger=read(P/'FINAL_SHA256.json'); nested=read(R/'FINAL_ARTIFACT_HASHES.json')['hashes']; links=[]
for name,v in members.items():
 if name in rootledger: links.append(dict(source_path=name,ledger='FINAL_SHA256.json',match=check(rootledger[name]==v['sha256'],'root ledger '+name)))
 rel=name[len(prefix)+1:] if name.startswith(prefix+'/') else None
 if rel in nested: links.append(dict(source_path=name,ledger=prefix+'/FINAL_ARTIFACT_HASHES.json',match=check(nested[rel]==v['sha256'],'nested ledger '+name)))
dump(A/'member-checks-recomputed.json',member_rows);dump(A/'ledger-link-checks.json',links)
Cpath=R/'oracle-comparator-outputs/reconciliation.json'; Bpath=R/'browser-native-connected-outputs/report.json';Regpath=R/'oracle-storage-outputs/register.json'
C=read(Cpath);B=read(Bpath);Reg=read(Regpath); reg={x['id']:x for x in Reg['results']}
check(len(C['cases'])==152 and len(reg)==152,'case populations unique152');check(len({x['id'] for x in C['cases']})==152,'comparator unique152')
rows=[]; fields=[]; gaps=[]; bytechecks=[];memchecks=[]
classification=collections.Counter(); fieldstates=collections.Counter(); phases=collections.Counter(); integration=collections.Counter()
for i,c in enumerate(C['cases']):
 id=c['id']; cl=c['classification'];classification[cl]+=1; phases[c.get('phase',{}).get('expected','NONE')]+=1
 check(c['oracleExpectedUnchanged']==reg[id]['expected'],'register expectations '+id)
 is_storage=cl=='PARTIAL_STORAGE_OBSERVABLE_MATCH'; is_browser=cl=='PARTIAL_MISSING_OBSERVABLE'; raw=None; actual=None; source=None;pointer=''
 if is_storage:
  source=R/'oracle-storage-outputs'/f'{id}.json';raw=read(source);actual=raw['actual'];pointer='/actual'
  check(raw['vector']['variantId']==id,'variant ID '+id);check(raw['vector']['expected']==c['oracleExpectedUnchanged'],'variant expected '+id)
  check(actual==reg[id]['actual'],'raw/register actual '+id)
 elif is_browser:
  source=Bpath;pointer=c['sourceReportPointer']+'/actual';br=ptr(B,c['sourceReportPointer']);check(br['id']==id,'browser ID '+id);actual=br['actual'];raw={'actual':actual}
 per=[];missing=[]
 for q in c.get('checks',[]):
  f=q['field'];expect=q['expectation'];fieldstates[q['state']]+=1;present=False;val=None;detail=''
  if f=='persistedByteDisposition' and is_browser:
   present='before' in actual and 'after' in actual
   if present: val='UNCHANGED' if actual['before']==actual['after'] else 'CHANGED'
  elif f=='unchangedDiagnosticReload':
   present='diagnosticReload' in actual and 'before' in actual['diagnosticReload'] and 'after' in actual['diagnosticReload']
   if present: val=actual['diagnosticReload']['before']['loaded']==actual['diagnosticReload']['after']['loaded'];detail='Full diagnostic loaded objects compared; not native controller reopen'
  elif f=='hashDispositionConsistency':
   present=actual.get('beforeSha256','__missing__')!='__missing__' and actual.get('afterSha256','__missing__')!='__missing__'
   if present:val='UNCHANGED' if actual['beforeSha256']==actual['afterSha256'] else 'CHANGED'
  elif f=='acceptedMemoryDisposition':
   present='memoryBefore' in actual and 'memoryAfter' in actual
   if present:
    equal=all(actual['memoryBefore'].get(k)==actual['memoryAfter'].get(k) for k in ['model','release']);val='UNCHANGED' if equal else 'CHANGED_SNAPSHOT_ONLY';detail='Compared model/release only; does not establish ACK ordering'
  else:
   try: val=ptr(raw,q['sourcePointer']);present=True
   except (KeyError,IndexError,TypeError):pass
  state='MATCH' if present and val==expect else 'MISMATCH' if present else 'ABI_OPTIONAL_ABSENT' if f in ['reason','path'] and expect is None else 'MISSING'
  check(state==q['state'],f'field reconciliation {id} {f}: {state} vs {q["state"]}')
  arow=dict(case_id=id,field=f,expected=expect,actual_present=present,actual=val,computed_state=state,disposition='VERIFIED' if state in ['MATCH','ABI_OPTIONAL_ABSENT'] else 'NOT_OBSERVED' if state=='MISSING' else 'FAILED',source=cite(source,pointer+q['sourcePointer'].removeprefix('/actual')),detail=detail)
  per.append(arow);fields.append(arow)
  if state=='MISSING':
   missing.append(f);gaps.append(dict(case_id=id,missing_requirement=f,expected=compact(expect),disposition='NOT_OBSERVED',resolution='No preserved invocation counter; new completely instrumented observation requires authorization' if f=='candidateGetterInvocations' else 'No directly bound per-operation pre/post byte pair; do not infer from writes/status',source_path=source.relative_to(P).as_posix(),source_sha256=sha(source.read_bytes()),json_pointer=pointer,q_source_pointer=q['sourcePointer'],trace_followup='analysis/trace-observations.json'))
 byte='NOT_OBSERVED';bc={}
 if is_storage or (is_browser and 'before' in actual and 'after' in actual):
  before=raw['before'] if is_storage else actual['before'];after=raw['after'] if is_storage else actual['after'];disp='UNCHANGED' if before==after else 'CHANGED'
  bc=dict(case_id=id,source=cite(source,pointer if is_browser else ''),before_sha256=None if before is None else sha(before.encode()),after_sha256=None if after is None else sha(after.encode()),disposition=disp,bytes_equal=before==after)
  if is_storage:
   check(bc['before_sha256']==actual['beforeSha256'],'before raw hash '+id);check(bc['after_sha256']==actual['afterSha256'],'after raw hash '+id);check(disp==actual['persistedByteDisposition'],'byte disposition '+id)
   bc['diagnostic_reload']=actual.get('diagnosticReload');bc['input_graph_unchanged_reported']=actual.get('inputGraphUnchanged');bc['input_graph_independent_reconstruction']='NOT_OBSERVED'
  if 'attempted' in actual:bc['after_equals_attempted']=after==actual['attempted'];bc['attempted_sha256']=sha(actual['attempted'].encode()) if isinstance(actual['attempted'],str) else None
  bytechecks.append(bc);byte='VERIFIED: '+disp
 if is_browser and 'memoryBefore' in actual and 'memoryAfter' in actual:
  mb=actual['memoryBefore'];ma=actual['memoryAfter'];memchecks.append(dict(case_id=id,model_equal=mb.get('model')==ma.get('model'),release_equal=mb.get('release')==ma.get('release'),source=cite(source,pointer+'/memoryBefore,/memoryAfter')))
 required={k:v for k,v in c['oracleExpectedUnchanged'].items() if k not in [q['field'] for q in c.get('checks',[])]}
 for k in required:integration[k]+=1
 rr=dict(case_id=id,component=c['component'],operation=c['operation'],archived_classification=cl,full_case_disposition='OUT_OF_SCOPE' if cl=='EXCLUDED_NOT_SINGLE_CALL' else 'PENDING_REVIEW',full_case_accepted=False,oracle_expected=compact(c['oracleExpectedUnchanged']),observed_field_states=compact({x['field']:x['computed_state'] for x in per}),missing_observations=compact(missing),persisted_bytes=byte,before_sha256=bc.get('before_sha256'),after_sha256=bc.get('after_sha256'),remaining_expected_fields=compact(required),integration_needed=compact(c.get('integrationNeeded',[])),unasserted=compact(c.get('unasserted',[])),phase=compact(c.get('phase',{})),phase_disposition='NOT_OBSERVED' if 'phase' in c else 'OUT_OF_SCOPE',controller_memory_disposition='NOT_OBSERVED: standalone storage' if is_storage else 'VERIFIED_SNAPSHOT_ONLY' if actual and 'memoryBefore' in actual else 'NOT_OBSERVED',reload_authority_disposition='NOT_OBSERVED: diagnostic load is not native authority inspection' if is_storage else 'PENDING_REVIEW: shared lifecycle evidence not case-bound' if is_browser else 'OUT_OF_SCOPE' if cl=='EXCLUDED_NOT_SINGLE_CALL' else 'PENDING_REVIEW',source_path=source.relative_to(P).as_posix() if source else '',source_sha256=sha(source.read_bytes()) if source else '',source_pointer=pointer,comparator_path=Cpath.relative_to(P).as_posix(),comparator_sha256=sha(Cpath.read_bytes()),comparator_pointer=f'/cases/{i}',register_path=Regpath.relative_to(P).as_posix(),register_sha256=sha(Regpath.read_bytes()),register_pointer='/results/'+str(next(k for k,v in enumerate(Reg['results']) if v['id']==id)))
 rows.append(rr)
def csvout(path,rs):
 with path.open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(rs[0]));writer.writeheader();writer.writerows(rs)
csvout(O/'SA001_152_CASE_ACCEPTANCE_MATRIX.csv',rows);csvout(O/'SA001_MISSING_EVIDENCE_RESOLUTION.csv',gaps)
dump(A/'field-reconciliation.json',fields);dump(A/'raw-byte-and-reload-checks.json',bytechecks);dump(A/'browser-memory-checks.json',memchecks)
# Decode Playwright's serialized values, never evaluate JavaScript expressions.
def decode(x,refs=None):
 refs={} if refs is None else refs
 if not isinstance(x,dict):return x
 if 'ref' in x:return refs.get(x['ref'],{'unresolved_ref':x['ref']})
 if 'o' in x:
  out={};refs[x.get('id')]=out
  for pair in x['o']:out[pair['k']]=decode(pair['v'],refs)
  return out
 if 'a' in x:
  out=[];refs[x.get('id')]=out;out.extend(decode(y,refs) for y in x['a']);return out
 for k in ['s','n','b']: 
  if k in x:return x[k]
 if 'v' in x:return None if x['v']=='null' else {'playwright_special':x['v']}
 return x
traces=[]; trace_data={}
for zpath in sorted((R/'browser-native-connected-outputs').glob('*trace.zip')):
 with zipfile.ZipFile(zpath) as z:
  b=z.read('trace.trace');events=[json.loads(x) for x in b.splitlines()];before={e['callId']:(i,e) for i,e in enumerate(events) if e['type']=='before'};calls=[]
  for i,e in enumerate(events):
   if e['type']!='after' or e.get('callId') not in before:continue
   bi,be=before[e['callId']];v=decode(e.get('result',{}).get('value',{}));expr=be.get('params',{}).get('expression','')
   # Save decoded results in separate evidence audit without executable evaluation.
   calls.append(dict(call_id=e['callId'],before_line=bi+1,after_line=i+1,expression=expr,result=v,params=be.get('params',{})))
  row=dict(source=cite(zpath),trace_member='trace.trace',trace_sha256=sha(b),calls=calls)
  trace_data[zpath.name]=row
  traces.append(dict(source=row['source'],trace_member='trace.trace',trace_sha256=sha(b),call_count=len(calls),getter_counter_result_paths=[]))
# Recover exact gap-associated calls and bracketing snapshots, without equating absence to zero.
after=trace_data['session-after-reopen-trace.zip'];acalls={x['call_id']:x for x in after['calls']}
manual=trace_data['fixture-source-and-consent-trace.zip'];mcalls={x['call_id']:x for x in manual['calls']}
trace_summary={'trace_sources':traces,'F-SA-28-reload-reuse':dict(source=after['source'],trace_sha256=after['trace_sha256'],before_call='call@55',operation_call='call@57',later_before_call='call@61',before_raw_sha256=sha(acalls['call@55']['result']['raw'].encode()),later_before_sha256=sha(acalls['call@61']['result']['before'].encode()),equal_bracketing_bytes=acalls['call@55']['result']['raw']==acalls['call@61']['result']['before'],operation_keys=list(acalls['call@57']['result']),disposition='NOT_OBSERVED',reason='Equal surrounding snapshots corroborate retention but later snapshot follows revision preparation; no immediate operation-bound post-byte record or complete all-writes observer; no getter counter'), 'F-SA-29-manual-revision':dict(source=manual['source'],trace_sha256=manual['trace_sha256'],seed_call='call@265',operation_call='call@267',next_seed_call='call@269',operation_keys=list(mcalls['call@267']['result']),disposition='NOT_OBSERVED',reason='Seed input and loaded state do not constitute observed persisted pre/post bytes; next seed overwrites storage before direct post capture')}
for name,td in trace_data.items():dump(A/('decoded-'+name.removesuffix('.zip')+'.json'),td)
dump(A/'trace-observations.json',trace_summary)
# Independent HAR attachment, session, worker root, and embedded Wasm checks.
Lpath=R/'loaded-assets-binding.json';Jpath=R/'loaded-asset-verification-outputs/binding-result.json';L=read(Lpath);J=read(Jpath)
check(sha(Lpath.read_bytes())==J['bindingSha256'],'binding raw SHA')
phase_rows=[];response_audit=[]
for job,jv in J['jobs'].items():
 for phase,ph in jv['phases'].items():
  sub='browser-native-connected-outputs' if job=='browser' else 'e-finite-outputs';d=R/sub/'loaded-assets'/phase;sp=d/'session.json';hp=d/'network.har.zip';s=read(sp)
  check(sha(sp.read_bytes())==ph['sessionSha256'],job+'/'+phase+' session hash');check(sha(hp.read_bytes())==ph['harSha256'],job+'/'+phase+' HAR hash')
  check(s['bindingSha256']==J['bindingSha256'],job+'/'+phase+' binding session');check(s['phase']==phase,job+'/'+phase+' phase session');check(s['runtimeCandidate']==J['runtimeCandidate'],job+'/'+phase+' candidate session')
  with zipfile.ZipFile(hp) as hz:
   har=read_har=json.loads(hz.read('har.har'));entries=har['log']['entries'];bodies={};har_success=[]
   for n,e in enumerate(entries):
    url=e['request']['url'];pp=url.split('/',3)[-1].split('?',1)[0]
    if e['response']['status']==200 and pp in L['buildFiles']:har_success.append(n)
   for k,response in enumerate(ph['responses']):
    ent=entries[response['entryIndex']];att=ent['response']['content'].get('_file');body=hz.read(att);bodies[response['path']]=body
    ok=sha(body)==response['sha256']==L['buildFiles'][response['path']]['sha256'] and len(body)==response['bytes']==L['buildFiles'][response['path']]['bytes'] and ent['request']['url']==response['url'] and ent['response']['status']==response['status'] and att==response['body']['entry']
    check(ok,f'HAR body {job}/{phase}/{k}');response_audit.append(dict(job=job,phase=phase,source=cite(hp),har_pointer=f'/log/entries/{response["entryIndex"]}',attachment=att,path=response['path'],sha256=sha(body),bytes=len(body),disposition='VERIFIED' if ok else 'FAILED',binding_result_pointer=f'/jobs/{job}/phases/{phase}/responses/{k}'))
   check(har_success==[v['entryIndex'] for v in ph['responses']],job+'/'+phase+' all success build responses accounted')
   # Match response events as multiset, including duplicates; no request absence claims.
   ev=collections.Counter((v['url'],v.get('status')) for v in s['events'] if v.get('status') is not None)
   hv=collections.Counter((v['request']['url'],v['response']['status']) for v in entries)
   session_subset=all(hv[k]>=n for k,n in ev.items());check(session_subset,job+'/'+phase+' session events present in HAR')
   workers=[]
   for wk in ph['workers']:
    ok=wk['worker'] in s['workers'] and wk['resourcePath'] in bodies and sha(bodies[wk['resourcePath']])==wk['sha256'];check(ok,job+'/'+phase+' worker root')
    workers.append(dict(path=wk['resourcePath'],sha256=wk['sha256'],subtype='OCR' if 'worker.min.js' in wk['resourcePath'] else 'PDF',disposition='VERIFIED' if ok else 'FAILED'))
   check(len(workers)==len(s['workers']),job+'/'+phase+' worker count')
   wasm=[]
   for w in ph['wasm']['embeddedBytesInLoadedWrappers']:
    wb=bodies[w['wrapperPath']];off=w['embeddedByteOffset'];tail=wb[off:];m=re.match(rb'wa\?\?=Ga\("([A-Za-z0-9+/=]+)"',tail)
    binary=base64.b64decode(m.group(1),validate=True) if m else b''
    ok=sha(wb)==w['wrapperSha256'] and len(binary)==w['binaryBytes'] and sha(binary)==w['binarySha256'] and binary[:4]==b'\0asm';check(ok,job+'/'+phase+' embedded WASM')
    for bp in w['matchingBuiltWasmPaths']:check(L['buildFiles'][bp]['sha256']==sha(binary),job+'/'+phase+' WASM manifest')
    wasm.append(dict(wrapper=w['wrapperPath'],offset=off,binary_sha256=sha(binary),binary_bytes=len(binary),disposition='VERIFIED' if ok else 'FAILED',instantiation='NOT_OBSERVED'))
  trace_path=R/sub/pathlib.Path(ph['tracePath']).name;trace_present=trace_path.exists()
  if trace_present:check(sha(trace_path.read_bytes())==ph['traceSha256'],job+'/'+phase+' trace SHA')
  phase_rows.append(dict(job=job,phase=phase,status=ph['status'],session=cite(sp),har=cite(hp),binding_result=cite(Jpath,f'/jobs/{job}/phases/{phase}'),response_count=len(ph['responses']),session_event_count=len(s['events']),har_entry_count=len(entries),session_events_matched=session_subset,worker_roots=workers,wasm=wasm,trace_present=trace_present,trace_source=cite(trace_path) if trace_present else None,trace_advertised_sha256=ph['traceSha256'],profile=s['profile'],browser_version=s['browserVersion'],node_pid=s['nodePid']))
dump(A/'job28-response-body-checks.json',response_audit);dump(A/'job28-phase-checks.json',phase_rows)
# Read-only available source inventory comparison. Does not fetch or mutate refs/index.
def git(*args):
 z=subprocess.run(['git','-C',str(REPO),*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 return z
source_checks=[]
for path,h in L['sourceFileSha256'].items():
 b=(REPO/path).read_bytes() if (REPO/path).is_file() else None
 source_checks.append(dict(path=path,effective_sha256=h,local_sha256=sha(b) if b is not None else None,effective_match=b is not None and sha(b)==h,historical_expected=L['historicalSourceFileSha256'].get(path)))
source_history=[]
for path,h in L['historicalSourceFileSha256'].items():
 z=git('show','acfb6799f699b7868612db346958c9e3d710680f:'+path);source_history.append(dict(path=path,expected_sha256=h,sha256=sha(z.stdout),match=z.returncode==0 and sha(z.stdout)==h));check(source_history[-1]['match'],'historical source '+path)
dump(A/'source-identity-checks.json',dict(effective=source_checks,historical=source_history,source_admission=L['sourceAdmission']))
# TAP transcript identity and counts; this is parsing historical execution, not rerunning tests.
meta=read(R/'b2-omr.meta.json');tap=(R/'b2-omr.stdout').read_text();testlines=[(int(n),name) for n,name in re.findall(r'^ok (\d+) - (.*)$',tap,re.M)];footers=dict(re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',tap,re.M))
check(sha((R/'b2-omr.stdout').read_bytes())==meta['stdoutSha256'],'B2 transcript SHA');check([n for n,_ in testlines]==list(range(1,192)),'B2 sequential191');check(footers.get('pass')=='191' and footers.get('fail')=='0','B2 TAP result');check(meta['exitCode']==0 and meta['status']=='EXITED','B2 process exit')
b2tests=[]
for path in meta['argv'][2:]:
 pp='semester-space/'+path;h=sha((REPO/pp).read_bytes());b2tests.append(dict(path=pp,sha256=h,effective_expected=L['sourceFileSha256'][pp],match=h==L['sourceFileSha256'][pp]));check(h==L['sourceFileSha256'][pp],'B2 source '+path)
dump(A/'b2-tap-checks.json',dict(meta=cite(R/'b2-omr.meta.json'),stdout=cite(R/'b2-omr.stdout'),test_names=testlines,footers=footers,test_sources=b2tests,stderr_present=(R/'b2-omr.stderr').exists(),stderr_reported_sha256=meta['stderrSha256']))
summary=dict(scope='DERIVED SUBSET RECONCILIATION',authority='HQ-SA001-CODEX-READONLY-2026-11-05-r1',script_sha256=sha(pathlib.Path(__file__).read_bytes()),source_members=len(members),member_checks=len(member_rows),root_ledger_entries=len(rootledger),nested_ledger_entries=len(nested),checked_ledger_links=len(links),classifications=dict(classification),field_states=dict(fieldstates),missing_observations=len(gaps),storage_cases=sum(x['archived_classification']=='PARTIAL_STORAGE_OBSERVABLE_MATCH' for x in rows),browser_cases=sum(x['archived_classification']=='PARTIAL_MISSING_OBSERVABLE' for x in rows),raw_byte_pairs=len(bytechecks),browser_memory_pairs=len(memchecks),expected_phase_populations=dict(phases),unreconciled_expectation_populations=dict(integration),job28_phases=len(phase_rows),job28_response_records=len(response_audit),worker_roots=sum(len(x['worker_roots']) for x in phase_rows),effective_source_matches=sum(x['effective_match'] for x in source_checks),effective_source_files=len(source_checks),historical_source_matches=sum(x['match'] for x in source_history),full_case_accepted=0,failures=failures,original_archive_attestation='NOT_OBSERVED',application_executions=0,network_requests=0)
dump(A/'summary.json',summary);print(json.dumps(summary,indent=2));sys.exit(1 if failures else 0)
