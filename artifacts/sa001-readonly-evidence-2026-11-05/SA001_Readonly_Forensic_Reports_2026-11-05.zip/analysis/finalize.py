#!/usr/bin/env python3
"""Verify preservation, validate report population, and package locally. No network/write to Git."""
import csv,hashlib,json,os,pathlib,shutil,subprocess,sys,zipfile
P=pathlib.Path('/workspace/sa001-readonly-investigation-input-2026-11-05');W=pathlib.Path('/workspace/sa001-readonly-investigation-2026-11-05');A=W/'analysis';O=W/'outputs';repo=pathlib.Path('/workspace/SemesterSpace-sa-001')
def load(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def cmd(argv):
 z=subprocess.run(argv,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 return dict(exit=z.returncode,stdout=z.stdout,stderr=z.stderr)
git=['git','-C',str(repo)];after={'identity':cmd(git+['rev-parse','HEAD','HEAD^','HEAD^{tree}']),'status':cmd(git+['status','--porcelain=v1','--untracked-files=all']),'refs':cmd(git+['show-ref']),'worktrees':cmd(git+['worktree','list','--porcelain']),'historicalApprovedCommitLocalObject':cmd(git+['cat-file','-e','1e4413f6791fd76d5676494ff007f35712813d60^{commit}'])}
dump(A/'after-repository-readonly-state.json',after);before=load(A/'before-repository-readonly-state.json');checks={k:after[k]==before[k] for k in ['identity','status','refs','worktrees']}
local=load(A/'source-identity-checks.json')['effective'];checks['all269_local_source_bytes_unchanged']=all(sha(repo/x['path'])==x['local_sha256'] for x in local);checks['source_member_bytes_unchanged']=all(sha(P/m['source_path'])==m['sha256'] and (P/m['source_path']).stat().st_size==m['size_bytes'] for m in load(P/'SOURCE_MEMBER_MANIFEST.json')['members'])
rows=list(csv.DictReader((O/'SA001_152_CASE_ACCEPTANCE_MATRIX.csv').open()));gaps=list(csv.DictReader((O/'SA001_MISSING_EVIDENCE_RESOLUTION.csv').open()));checks['matrix152_unique']=len(rows)==len({r['case_id'] for r in rows})==152;checks['gap_population20']=len(gaps)==20 and sum(r['missing_requirement']=='candidateGetterInvocations' for r in gaps)==18 and sum(r['missing_requirement']=='persistedByteDisposition' for r in gaps)==2
checks['final_static_analysis_clear']=load(A/'summary.json')['failures']==[] and load(A/'supplement-summary.json')['errors']==[]
checks['full_case_acceptance_zero']=all(r['full_case_accepted']=='False' for r in rows);checks['all_rows_original_source_identity']=all(r['source_path'] and r['source_sha256'] and r['comparator_pointer'] for r in rows)
# Cross-check final CSV pointers and per-case SHA against actual unchanged sources.
for row in rows:
 if sha(P/row['source_path'])!=row['source_sha256']:raise RuntimeError('CSV SHA '+row['case_id'])
checks['required_deliverables_exist']=all((O/n).exists() for n in ['SA001_152_CASE_ACCEPTANCE_MATRIX.csv','SA001_MISSING_EVIDENCE_RESOLUTION.csv','SA001_JOB28_PHASE_VALIDATION.md','SA001_EXTERNAL_EXCLUDED_CONTRACT_RULINGS.md','SA001_FORENSIC_VERIFICATION_REPORT.md','SA001_TARGETED_NEW_EVIDENCE_PLAN.md'])
dump(A/'preservation-and-output-validation.json',checks)
versions={'python':cmd([sys.executable,'--version']),'git':cmd(['git','--version'])};dump(A/'tool-versions.json',versions)
receipts={'scope':'STATIC_EVIDENCE_PARSING_ONLY; no application/test/helper imports or execution','commands':[{'argv':['python3',str(A/'attempt1-investigate.py')],'actual_script_at_time':str(A/'attempt1-investigate.py'),'script_sha256':sha(A/'attempt1-investigate.py'),'exit':1,'stdout':'analysis/attempt1-investigate.stdout','stderr':'analysis/attempt1-investigate.stderr','qualification':'First attempt script was then named investigate.py; preserved copy. Parser error at embedded WASM loader prefix; no candidate execution.'},{'argv':['python3',str(A/'attempt2-investigate.py')],'actual_script_at_time':str(A/'attempt2-investigate.py'),'script_sha256':sha(A/'attempt2-investigate.py'),'exit':1,'stdout':'analysis/attempt2-investigate.stdout','stderr':'analysis/attempt2-investigate.stderr','qualification':'Second attempt then named investigate.py; false audit assumption omitted root / to index.html normalization; all actual listed bodies matched.'},{'argv':['python3',str(A/'investigate.py')],'script_sha256':sha(A/'investigate.py'),'exit':int((A/'investigate.exit').read_text()),'stdout':'analysis/investigate.stdout','stderr':'analysis/investigate.stderr'},{'argv':['python3',str(A/'attempt1-supplement.py')],'script_sha256':sha(A/'attempt1-supplement.py'),'exit':1,'stdout':'analysis/attempt1-supplement.stdout','stderr':'analysis/attempt1-supplement.stderr','qualification':'First supplemental attempt then named supplement.py; own static decoder used model/journal instead of actual proposedModel/proposedJournal keys.'},{'argv':['python3',str(A/'supplement.py')],'script_sha256':sha(A/'supplement.py'),'exit':int((A/'supplement.exit').read_text()),'stdout':'analysis/supplement.stdout','stderr':'analysis/supplement.stderr'},{'argv':['python3',str(A/'write_reports.py')],'script_sha256':sha(A/'write_reports.py'),'exit':0,'stdout':'Rendered four requested Markdown reports, two existing required CSVs and source index.','qualification':'Report rendering only'},{'argv':['python3',str(A/'finalize.py')],'script_sha256':sha(pathlib.Path(__file__)),'qualification':'Exit and stdout stored alongside resulting bundle after process returns; read-only Git queries and local packaging only'}],'git_queries':{'environment':'GIT_OPTIONAL_LOCKS=0','repository':str(repo),'commands':['git rev-parse HEAD HEAD^ HEAD^{tree}','git status --porcelain=v1 --untracked-files=all','git show-ref','git worktree list --porcelain','git cat-file -e 1e4413f6791fd76d5676494ff007f35712813d60^{commit}','git show acfb6799f699b7868612db346958c9e3d710680f:<each of 269 source paths>'],'results':'before/after-repository-readonly-state.json; source-identity-checks.json; command results unchanged/no network'},'not_executed':['application tests','application modules','installed helper programs','npm installation/check/test/build','browser','CI','network operations','git commit/push/fetch/ref update','deployment/activation'],'failed_investigator_attempts_are_not_candidate_failures':True}
dump(A/'COMMAND_RECEIPTS.json',receipts)
if not all(checks.values()):print(json.dumps(checks,indent=2));sys.exit(1)
# Copy only useful hash-bound static source for code-level review; this is not a frozen runtime checkout.
ref=W/'available-static-reference';ref.mkdir(exist_ok=True);reference_rows=[]
for path in ['semester-space/src/controller.js','semester-space/src/storage.js','semester-space/tests/sa-001/browser.mjs','semester-space/tests/diamond-001/storage.test.mjs','semester-space/tests/diamond-001/omitted-release-acceptance.test.mjs','semester-space/tests/diamond-001/omitted-release-precedence.test.mjs']:
 dest=ref/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/path,dest);reference_rows.append(dict(original_local_path=str(repo/path),packaged_path=str(dest.relative_to(W)),sha256=sha(dest),scope='Static copied reference, effective manifest matches; no execution'))
gold=pathlib.Path('/workspace/sa001-exec05-er3-staged-external-2026-10-30/frozen-unchanged/F011_EXACT_TEST_VARIANTS_A_IMPL04_CORRECTED.json');shutil.copyfile(gold,ref/gold.name);reference_rows.append(dict(original_local_path=str(gold),packaged_path='available-static-reference/'+gold.name,sha256=sha(gold),scope='Local frozen active oracle reference; not included original run member'))
dump(ref/'REFERENCE_IDENTITIES.json',reference_rows)
readme='''# SA-001 read-only forensic investigation — 2026-11-05

SA-001 OPEN P1. DERIVED SUBSET RECONCILIATION. Full-case acceptance 0/152.

Start with outputs/SA001_FORENSIC_VERIFICATION_REPORT.md. Six requested deliverables are in outputs/. SOURCE_INDEX.csv resolves original paths/hashes; analysis/ has exact per-field, case, byte, trace, source and phase checks, script identities and command receipts. All final static analyses passed; earlier investigator parsing attempts remain preserved and explained, not counted as application failures.

input/ is the unchanged extracted supplied derived handoff, not the original complete artifact. The oversized original archive was inaccessible. available-static-reference/ contains selected local hash-matched source and active oracle solely for static review; it is not the complete effective runtime checkout (e-finite reviewed overlay is unavailable). No inherited results become new independent runs.

Reproduce on the recorded existing workspace with python3 analysis/investigate.py and python3 analysis/supplement.py, then optionally render reports with python3 analysis/write_reports.py. Scripts record absolute input/output/repository paths. On another machine review path constants in a separate copy and supply the same verified repository/local references; source-dependent checks cannot reproduce solely from this incomplete runtime source subset. Never execute packaged application/source/helper code under this read-only authority. Decoded trace expression strings are inert evidence, not scripts to run.

MANIFEST.json and SHA256SUMS.txt cover all packaged files except those two manifest files and README if generated later (here README precedes manifest, so it is included). ZIP_SHA256.txt outside the ZIP identifies the complete archive. No original archive-wide attestation, application execution, GitHub upload, source mutation, commit, push, CI, deployment or activation occurred. Current authority forbids GitHub writes; package is local only.
'''
(W/'README.md').write_text(readme)
# Package reproducible evidence copies without modifying original input files.
files=[]
for root,arcroot in [(W,'') ,(P,'input')]:
 for f in sorted(root.rglob('*')):
  if not f.is_file():continue
  if root==W and (f.name in ['MANIFEST.json','SHA256SUMS.txt'] or f.suffix=='.zip' or f.name.startswith('ZIP_')):continue
  name=(pathlib.PurePosixPath(arcroot)/f.relative_to(root).as_posix()).as_posix();files.append((f,name))
manifest=[dict(path=n,size_bytes=f.stat().st_size,sha256=sha(f)) for f,n in files];dump(W/'MANIFEST.json',manifest);(W/'SHA256SUMS.txt').write_text(''.join(f'{r["sha256"]}  {r["path"]}\n' for r in manifest))
archive=W.parent/'SA001_Readonly_Forensic_Reports_2026-11-05.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f,n in files:z.write(f,n)
 z.write(W/'MANIFEST.json','MANIFEST.json');z.write(W/'SHA256SUMS.txt','SHA256SUMS.txt')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for m in manifest:assert hashlib.sha256(z.read(m['path'])).hexdigest()==m['sha256']
info=dict(archive=str(archive),size_bytes=archive.stat().st_size,sha256=sha(archive),manifested_files=len(manifest),all_preservation_checks=checks,full_case_accepted=0,SA001='OPEN P1',github_upload='NOT_PERFORMED_PROHIBITED')
dump(W/'ZIP_IDENTITY.json',info);(W/'ZIP_SHA256.txt').write_text(info['sha256']+'  '+archive.name+'\n');print(json.dumps(info,indent=2))
