#!/usr/bin/env python3
"""Additional static crosswalk/history checks; no application imports or execution."""
import pathlib,json,hashlib,csv,collections,re,sys
P=pathlib.Path('/workspace/sa001-readonly-investigation-input-2026-11-05');W=pathlib.Path('/workspace/sa001-readonly-investigation-2026-11-05');A=W/'analysis';O=W/'outputs';R=next((P/'RECOVERED_APPLICATION_EVIDENCE').iterdir());repo=pathlib.Path('/workspace/SemesterSpace-sa-001')
def load(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def compact(d):return json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def cite(p,pointer=''):return dict(source_path=p.relative_to(P).as_posix(),sha256=sha(p.read_bytes()),pointer=pointer)
C=load(R/'oracle-comparator-outputs/reconciliation.json');B=load(R/'browser-native-connected-outputs/report.json');L=load(R/'loaded-assets-binding.json');errors=[]
goldpath=pathlib.Path('/workspace/sa001-exec05-er3-staged-external-2026-10-30/frozen-unchanged/F011_EXACT_TEST_VARIANTS_A_IMPL04_CORRECTED.json');gold=load(goldpath);gm={x['variantId']:x for x in gold['variants']};gc=[]
for c in C['cases']:
 ok=gm[c['id']]['expected']==c['oracleExpectedUnchanged'];gc.append(dict(case_id=c['id'],match=ok));
 if not ok:errors.append('local active oracle expectations '+c['id'])
dump(A/'local-active-oracle-comparison.json',dict(path=str(goldpath),sha256=sha(goldpath.read_bytes()),provenance='Existing frozen local input, not an original member of supplied run subset; does not establish historical run input admission',cases=gc))
# Map static branches for review without asserting dynamic phase telemetry.
storage=repo/'semester-space/src/storage.js';controller=repo/'semester-space/src/controller.js';browser=repo/'semester-space/tests/sa-001/browser.mjs'
static_sources=[dict(path=str(p),sha256=sha(p.read_bytes()),runtime_manifest_path=p.relative_to(repo).as_posix(),runtime_hash_match=sha(p.read_bytes())==L['sourceFileSha256'][p.relative_to(repo).as_posix()],disposition='VERIFIED_STATIC_IDENTITY_NOT_EXECUTED_BEHAVIOUR') for p in [storage,controller,browser]]
phase_map={'P0':'storage.js:546 (legacy saveModel:265–271)','P1':'storage.js:549 (legacy:273)','P2':'storage.js:550 (legacy:274)','P3':'storage.js:507 / commit:551–553 (legacy:277–278)','P4':'storage.js:489–497,509 (legacy:279–288)','P5a':'storage.js:498,511 (legacy:289)','P5b':'storage.js:499,512 (legacy:290)','P5c':'storage.js:472–487,513 (legacy:291–292)','P6a':'storage.js:514 (legacy:293–294)','P6b':'storage.js:502–504,515','P7':'storage.js:556–560 (legacy:295–299)','P8a':'storage.js:561–564 (legacy:303–306)','P8b':'storage.js:566–581 (legacy:307–310)','P8c':'storage.js:582','P9':'storage.js:583–587 (legacy:312–316)','P10':'storage.js:588 (legacy:317)','P11':'storage.js:589 (legacy:318)','LOAD':'storage.js:531–539','SA-PRE':'controller.js:432–448','SA-POST':'controller.js:467–476'}
applicability=[];memgroups=collections.Counter()
for c in C['cases']:
 if c['classification']!='PARTIAL_STORAGE_OBSERVABLE_MATCH':continue
 id=c['id'];exp=c['oracleExpectedUnchanged'];mem=exp['acceptedMemoryDisposition'];memgroups[mem]+=1;raw=load(R/'oracle-storage-outputs'/f'{id}.json');diag=raw['actual'].get('diagnosticReload',{});dr=diag.get('after',{}).get('loaded',{});bef=None;aft=None
 try:bef=json.loads(raw['before']) if raw['before'] is not None else None
 except (ValueError,TypeError):pass
 try:aft=json.loads(raw['after']) if raw['after'] is not None else None
 except (ValueError,TypeError):pass
 if mem=='ADVANCE_AFTER_ACK':need='Successful save observed at storage boundary; controller promotion order and acknowledged full accepted model/release not measured. Bind to exact legacy/profile3 caller and physical ACK trace, especially cap-boundary and attendance variants; synthetic authored receipt does not issue source authority.'
 elif mem=='LOAD_VALIDATED_STATE':need='Full loader object observed; controller acceptance/view and no restored live authority not measured. Read-only/native lifecycle evidence must be bound separately; no migration may be inferred.'
 elif mem=='READ_ONLY_INSPECTION_ONLY':need='Full read-only loader object observed; exercise/bind all mutation fences separately. Returned read-only status is not proof UI and attendance writers are fenced.'
 else:need='Failure/read-only tuple and bytes observed at storage boundary; controller model/release retention not measured. Bind any reachable controller failure handling; adjudicate helper-only invalid inputs explicitly without fabricating a live source stage.'
 reload_consistency=None
 if aft and dr.get('model') is not None:
  reload_consistency=dr['model']==aft.get('model') and dr['release']==aft.get('release')
  # Legacy e1 loads can synthesize an empty release, not omit stored history.
  if aft.get('schemaVersion')==1:reload_consistency=dr['model']==aft.get('model')
  if not reload_consistency:errors.append('diagnostic reload mismatch '+id)
 applicability.append(dict(case_id=id,operation=c['operation'],component=c['component'],expected=exp,source=cite(R/'oracle-storage-outputs'/f'{id}.json'),controller_requirement=need,authority_requirement='No live issuer/controller-stage observations in this standalone result. NONE/0 after reload is not proven by diagnostic JSON. First bind existing genuine lifecycle/non-authority controls, then request only uncovered transitions.',phase_source_map=phase_map.get(exp['phase']),phase_disposition='PENDING_REVIEW: static order and tuple agree; no dynamic phase event. Mutation recipes/collision coverage require per-ID adjudication.',reported_input_immutability=raw['actual'].get('inputGraphUnchanged'),input_immutability_disposition='VERIFIED_AS_REPORTED_BOOLEAN; original mutable graph not serialized, cannot reconstruct hostile getter effects',complete_diagnostic_reload=bool(diag),diagnostic_reload_consistent_with_persisted_model_release=reload_consistency,native_process_reload_disposition='NOT_OBSERVED_PER_VARIANT',source_stage_disposition='OUT_OF_SCOPE_FOR_HELPER_EXECUTION; source capability obligations remain pending for real application route'))
dump(A/'131-storage-integration-crosswalk.json',dict(static_sources=static_sources,static_phase_map=phase_map,memory_groups=dict(memgroups),cases=applicability))
# History comparisons on genuine recorded browser output: structural assertions, not execution.
history=[]
for entry in B['cases']:
 act=entry.get('actual',{});id=entry['id']
 if not all(k in act for k in ['memoryBefore','memoryAfter','before','after']):continue
 mb,ma=act['memoryBefore'],act['memoryAfter'];br,ar=mb.get('release'),ma.get('release');bm,am=mb.get('model'),ma.get('model')
 if id not in [x['id'] for x in C['cases']]:continue
 data=dict(case_id=id,source=cite(R/'browser-native-connected-outputs/report.json',f'/cases/{B["cases"].index(entry)}/actual'),result=act['result'],reads=act['reads'],writes=act['writes'],persisted_changed=act['before']!=act['after'],after_equals_attempted=act['after']==act.get('attempted'),accepted_model_unchanged=bm==am,accepted_release_unchanged=br==ar)
 if br and ar:
  data['attendance_equal']=br['attendance']==ar['attendance'];data['applied_revisions_retained_prefix']=ar['calendar']['appliedRevisions'][:len(br['calendar']['appliedRevisions'])]==br['calendar']['appliedRevisions'];data['snapshots_equal']=bm['snapshots']==am['snapshots']
  old=br.get('provenance',{}).get('receipts',[]);new=ar.get('provenance',{}).get('receipts',[]);data['receipts_retained_prefix']=new[:len(old)]==old
  if id=='F-SA-40-profile3-upgrade-pending':
   oldlinks=br['calendar']['sourceRevision']['links'];newlinks=ar['calendar']['sourceRevision']['links'];data['all_original_links_retained_exactly']=all(x in newlinks for x in oldlinks);data['original_optional_absence']=[dict(sourceRef=x.get('sourceRef'),value_present='value' in x,changeId_present='changeId' in x) for x in oldlinks]
 history.append(data)
# Actual ledger output correspondence to persisted candidate, not a fresh ledger run.
raw=load(R/'oracle-storage-outputs/F-SA-31-explicit-attendance.json');before=json.loads(raw['before']);after=json.loads(raw['after']);lr=raw['actualLedger']['result'];ledger=dict(source=cite(R/'oracle-storage-outputs/F-SA-31-explicit-attendance.json','/actualLedger/result'),result_keys=list(lr),result_code=lr.get('code'),model_revision=after['model']['revision'],attendance_records=len(after['release']['attendance']['records']),closed_days=len(after['release']['attendance']['closedDays']),model_matches_ledger=after['model']==lr.get('model'),journal_matches_ledger=after['release']['attendance']==lr.get('journal'),receipts_unchanged=before['release']['provenance']['receipts']==after['release']['provenance']['receipts'],official_snapshot_ids_unchanged=before['release']['attendance']['officialSnapshotIds']==after['release']['attendance']['officialSnapshotIds'])
if not ledger['model_matches_ledger'] or not ledger['journal_matches_ledger']: errors.append('F31 ledger correspondence')
dump(A/'retained-history-checks.json',dict(browser=history,ledger=ledger))
# Independent hash-check continuity files, not copied reported hashes.
native=[]
for sub,bef,aft,expected in [('browser-native-connected-outputs','before-native-close.json','after-native-reopen.json','browser'),('e-finite-outputs','before-forgery-reopen.json','after-forgery-reopen.json','e-finite')]:
 bp=R/sub/bef;ap=R/sub/aft;J=load(R/'loaded-asset-verification-outputs/binding-result.json')['jobs'][expected]
 rec=dict(before=cite(bp),after=cite(ap),bytes_equal=bp.read_bytes()==ap.read_bytes(),sha256=sha(bp.read_bytes()),matches_advertised_hash=sha(bp.read_bytes())==J['savedBytesSha256'],model_revision=load(bp)['model']['revision'],receipt_count=len(load(bp)['release']['provenance']['receipts']),full_parsed_state_equal=load(bp)==load(ap),native_reopen_reported=J['nativeReopen'],disposition='VERIFIED_BYTE_EQUALITY; PROCESS_AND_LIFETIME_QUALIFICATION_PENDING_REVIEW')
 native.append(rec)
 if not rec['bytes_equal'] or not rec['matches_advertised_hash']:errors.append('native continuity '+sub)
dump(A/'native-byte-continuity-checks.json',native)
# Enrich the complete matrix; original values/expected fields stay unchanged.
rows=list(csv.DictReader((O/'SA001_152_CASE_ACCEPTANCE_MATRIX.csv').open()));amap={x['case_id']:x for x in applicability}
for row in rows:
 id=row['case_id'];ap=amap.get(id);row['independent_controller_analysis']=ap['controller_requirement'] if ap else 'Browser snapshots establish only recorded state pairs; native capability and ACK/phase proof remain separately bound' if row['archived_classification']=='PARTIAL_MISSING_OBSERVABLE' else 'External suite execution record verified; no single-call telemetry' if id=='F-SA-33-legacy-suite' else 'Frozen contract excludes the guarantee; no runtime zero-write observation'
 row['static_source_phase_map']=phase_map.get(json.loads(row['oracle_expected'])['phase'],'NOT_APPLICABLE')
 row['static_source_paths_hashes']=compact(static_sources[:2]);row['diagnostic_reload_state_consistency']=str(ap['diagnostic_reload_consistent_with_persisted_model_release']) if ap else 'NOT_APPLICABLE'
 if id=='F-SA-33-legacy-suite':row['source_path']=(R/'b2-omr.meta.json').relative_to(P).as_posix();row['source_sha256']=sha((R/'b2-omr.meta.json').read_bytes());row['source_pointer']='/exitCode'
 if id in ['F-SA-34-pre-B2','F-SA-35-multi-tab']:row['source_path']=row['comparator_path'];row['source_sha256']=row['comparator_sha256'];row['source_pointer']=row['comparator_pointer']+'/oracleExpectedUnchanged'
with (O/'SA001_152_CASE_ACCEPTANCE_MATRIX.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
dump(A/'supplement-summary.json',dict(script_sha256=sha(pathlib.Path(__file__).read_bytes()),local_active_oracle_hash=sha(goldpath.read_bytes()),oracle_expectation_matches=sum(x['match'] for x in gc),storage_cases=len(applicability),memory_groups=dict(memgroups),ledger=ledger,native_pairs=len(native),errors=errors));print(json.dumps(load(A/'supplement-summary.json'),indent=2));sys.exit(1 if errors else 0)
