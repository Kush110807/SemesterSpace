# SA-001 read-only forensic investigation — 2026-11-05

SA-001 OPEN P1. DERIVED SUBSET RECONCILIATION. Full-case acceptance 0/152.

Start with outputs/SA001_FORENSIC_VERIFICATION_REPORT.md. Six requested deliverables are in outputs/. SOURCE_INDEX.csv resolves original paths/hashes; analysis/ has exact per-field, case, byte, trace, source and phase checks, script identities and command receipts. All final static analyses passed; earlier investigator parsing attempts remain preserved and explained, not counted as application failures.

input/ is the unchanged extracted supplied derived handoff, not the original complete artifact. The oversized original archive was inaccessible. available-static-reference/ contains selected local hash-matched source and active oracle solely for static review; it is not the complete effective runtime checkout (e-finite reviewed overlay is unavailable). No inherited results become new independent runs.

Reproduce on the recorded existing workspace with python3 analysis/investigate.py and python3 analysis/supplement.py, then optionally render reports with python3 analysis/write_reports.py. Scripts record absolute input/output/repository paths. On another machine review path constants in a separate copy and supply the same verified repository/local references; source-dependent checks cannot reproduce solely from this incomplete runtime source subset. Never execute packaged application/source/helper code under this read-only authority. Decoded trace expression strings are inert evidence, not scripts to run.

MANIFEST.json and SHA256SUMS.txt cover all packaged files except those two manifest files and README if generated later (here README precedes manifest, so it is included). ZIP_SHA256.txt outside the ZIP identifies the complete archive. No original archive-wide attestation, application execution, GitHub upload, source mutation, commit, push, CI, deployment or activation occurred. Current authority forbids GitHub writes; package is local only.
