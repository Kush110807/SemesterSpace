# CODEX MANDATE — SA-001 F152 BOUNDED READ-ONLY FORENSIC AUDIT

Role: Independent technical evidence investigator, NOT final security acceptance authority.

Goal: Produce a source-grounded 152-case gap matrix and exact minimum missing proof for SA-001, with the fastest defensible route to independent D review. No claim of closure. Preserve original identity run 41387922793 attempt 1 commit 1e4413f6791fd76d5676494ff007f35712813d60.

IMPORTANT: Do not assume the current Git checkout matches the historical commit. If checkout/approved source is inaccessible, report the blocked code-level questions. If the 488MB original ZIP is not attached, independently hash-check the derived subset only; mark original archive-wide attestation UNVERIFIED. Do not fetch from GitHub or elsewhere if access would require credentials or any mutation; report access constraints.

1. Independently validate the source member hashes in SOURCE_MEMBER_MANIFEST.json against all embedded raw member bytes. Capture checking-script identity and command outputs. Identify any omission due to this being a subset.
2. Parse the original archived `oracle-comparator-outputs/reconciliation.json` and `browser-native-connected-outputs/report.json`. Derive all 152 classifications and IDs; do not copy HQ counts without independently recalculating. For the 18 missing getter counts, search the included preserved raw controller/browser reports and traces for actual invocation counts. No getter field and no events are *not* proof of zero unless complete instrumentation is shown. For F-SA-28-reload-reuse and F-SA-29-manual-revision, check original byte evidence vs pre/post snapshots; do not infer CHANGED/UNCHANGED from status or write count.
3. Independently reconcile 131 storage partial cases against each case's variant-dependent controller, authority, memory, ACK, reload, source and byte assertions. Verify pure storage output independently where available. If controller integration is absent, report PENDING_REVIEW/NOT_OBSERVED rather than PASS. Full-case accepted tally may remain zero.
4. Inspect exact B2 OMR suite raw transcript and source identity for F-SA-33-legacy-suite; assess F-SA-34-pre-B2 old-client fencing and F-SA-35-multi-tab serialization against frozen obligations. Do not promote external/excluded cases into full acceptance.
5. Validate 6 Job28 phases and status `ASSET_BYTES_MATCH_BUILD_NOT_SA_ACCEPTANCE`; distinguish loaded bytes, actually observed Worker roots, PDF/OCR worker subtype, WASM identity vs instantiation, and same-run build provenance. Don't claim unobserved module evaluation.
6. Historical forged-stage bytes may be absent; label original historical replay unverified and specify recovery/exceptions allowed only under original frozen contract, never fabricate historical bytes.
7. Produce an exact prioritized plan for separately-authorized new observations if mandatory evidence is genuinely unavailable. No changes or execution without fresh approval.
8. Write the six deliverables listed in START_HERE.md, with exact source paths and hashes and a concise owner-facing PASS/FAIL/UNVERIFIED gate table.

Hard restrictions: read-only; no application tests, no GitHub write or CI run, no new PR/commit, no code/harness edits, no deployment or activation. Static Python analysis of provided evidence is allowed. If an action may cause a side effect, stop and report instead.
