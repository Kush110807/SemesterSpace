# SemesterSpace Diamond | Codex forensic audit handoff

Date: 2026-11-05
Authority: HQ-SA001-CODEX-READONLY-2026-11-05-r1
Run: 41387922793, attempt 1
Commit: 1e4413f6791fd76d5676494ff007f35712813d60
SA-001: OPEN P1

## IMPORTANT
This is a **derived source-preserving evidence subset**, NOT the original 488,716,152-byte GitHub artifact. Every copied original archive member is unchanged and has its source path and raw SHA-256 recorded in `SOURCE_MEMBER_MANIFEST.json`. This packet cannot independently prove the full original artifact's integrity, absence of omitted evidence, or security acceptance. For complete independent archive verification Codex must also receive the unchanged original ZIP and recompute its hash.

Original ZIP SHA-256 (previously owner-verified): a49b957235ecb48660d16bb91665a8db3a10373b295b740526e545ce99f22a6e

## First actions
1. Read `CODEX_TASK_PROMPT.md`, this file, `SOURCE_MEMBER_MANIFEST.json`, and the provided D integrated-contract review.
2. Verify every included source-member SHA-256 against `SOURCE_MEMBER_MANIFEST.json` BEFORE any analysis; report unexpected differences as FAILED.
3. Perform a **read-only** F152/Job28 analysis and prepare output reports only; do not edit the GitHub repository or change existing files.
4. If no full original artifact is accessible, make the scope explicitly 'DERIVED SUBSET RECONCILIATION' and leave full archive attestation UNVERIFIED.
5. Keep 0/152 full-case acceptance unless sufficient evidence supports separately justified case-level promotions and independent review (do not self-certify closure).
6. Preserve frozen scope restrictions. No code changes, commits, pushes, PRs, CI workflow runs, test execution of the app, deployment or activation. Run static read-only checksum/JSON parsers only.

## Folder contents
- `SOURCE_MEMBER_MANIFEST.json`: actual raw original member sizes and hashes, plus original archive hash.
- `RECOVERED_APPLICATION_EVIDENCE/...`: unchanged evidence source members copied from the original archive, including 132 storage files, browser reports, Job 28 results, B2 OMR output and selected phase captures.
- `HQ_REFERENCE/`: HQ-derived ledgers and D historical contract review for context; these are not independent verification.
- `CODEX_TASK_PROMPT.md`: full bounded assignment.

## Required outputs
Write new separate reports under `outputs/`, no existing source changes:
- `SA001_152_CASE_ACCEPTANCE_MATRIX.csv`
- `SA001_MISSING_EVIDENCE_RESOLUTION.csv`
- `SA001_JOB28_PHASE_VALIDATION.md`
- `SA001_EXTERNAL_EXCLUDED_CONTRACT_RULINGS.md`
- `SA001_FORENSIC_VERIFICATION_REPORT.md`
- `SA001_TARGETED_NEW_EVIDENCE_PLAN.md` (only if truly necessary)

Each claim requires source path, relevant JSON pointer, original member SHA-256 and disposition (VERIFIED / NOT_OBSERVED / OUT_OF_SCOPE / FAILED / PENDING_REVIEW). Distinguish static source evidence from executed behaviour. Do not recommend broad waivers. Maintain UX03/UX04 as separate release gates.
