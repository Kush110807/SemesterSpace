#!/usr/bin/env python3
"""SemesterSpace SA-001: read-only, standard-library archive verification.

Usage on Windows:
  py -3 sa001_readonly_independent_archive_check.py "SA001-application-41387922793-1-original.zip"

No GitHub access, application execution, repository modification, or dependencies.
This checks preserved evidence integrity and accounting, not full F152 or SA-001 acceptance.
"""
import hashlib
import json
import re
import sys
import zipfile
from collections import Counter
from pathlib import Path

EXPECTED_ARCHIVE_SHA256 = "a49b957235ecb48660d16bb91665a8db3a10373b295b740526e545ce99f22a6e"
EXPECTED_BYTES = 488_716_152
EXPECTED_RUN = "SA001-20261102T042156Z-b5381bc409a7"
EXPECTED_PHASES = {"browser": {"native-before", "native-after", "retained-ui", "fixture-pdf-ocr"},
                   "e-finite": {"forgery-before", "forgery-after"}}
EXPECTED_CLASSIFICATIONS = {"PARTIAL_STORAGE_OBSERVABLE_MATCH": 131,
                            "PARTIAL_MISSING_OBSERVABLE": 18,
                            "EXTERNAL_SUITE_DEPENDENCY": 1,
                            "EXCLUDED_NOT_SINGLE_CALL": 2}


def require(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def digest_stream(stream):
    hasher = hashlib.sha256()
    while True:
        data = stream.read(1024 * 1024)
        if not data:
            break
        hasher.update(data)
    return hasher.hexdigest()


def digest_member(archive, member):
    with archive.open(member) as stream:
        return digest_stream(stream)


def json_member(archive, member):
    return json.loads(archive.read(member).decode("utf-8"))


def manifest_audit(archive, available_names, manifest_name, path_prefix="", nested=False):
    obj = json_member(archive, manifest_name)
    listed = obj["hashes"] if nested else obj
    require(isinstance(listed, dict), f"Invalid manifest schema: {manifest_name}")
    prefix_files = {name[len(path_prefix):] for name in available_names if name.startswith(path_prefix)}
    prefix_files.discard(manifest_name[len(path_prefix):])
    require(set(listed) == prefix_files,
            f"Manifest coverage mismatch in {manifest_name}: missing={sorted(prefix_files-set(listed))[:5]}, "
            f"nonexistent={sorted(set(listed)-prefix_files)[:5]}")
    for relative_name, expected_hash in listed.items():
        full = path_prefix + relative_name
        require(digest_member(archive, full) == expected_hash,
                f"SHA-256 mismatch: {full}")
    return len(listed)


def main(path):
    require(path.is_file(), f"Archive file does not exist: {path}")
    size = path.stat().st_size
    require(size == EXPECTED_BYTES, f"ZIP size changed: {size}")
    with path.open("rb") as source:
        original_digest = digest_stream(source)
    require(original_digest == EXPECTED_ARCHIVE_SHA256, f"ZIP SHA-256 differs: {original_digest}")

    with zipfile.ZipFile(path, "r") as archive:
        info_list = archive.infolist()
        names = [record.filename for record in info_list if not record.is_dir()]
        require(len(names) == 838, f"Unexpected entry count: {len(names)}")
        require(len(names) == len(set(names)), "Duplicate ZIP member names detected")
        require(not any(n.startswith("/") or ".." in n.split("/") for n in names),
                "Unsafe archive path found")
        available = set(names)

        root_count = manifest_audit(archive, available, "FINAL_SHA256.json")
        require(root_count == 837, f"Unexpected root manifest size: {root_count}")

        recovered = f"RECOVERED_APPLICATION_EVIDENCE/{EXPECTED_RUN}/"
        duplicate = f"container/application-evidence/{EXPECTED_RUN}/"
        nested_counts = {}
        for prefix in (recovered, duplicate):
            manifest = prefix + "FINAL_ARTIFACT_HASHES.json"
            require(manifest in available, f"Missing nested manifest: {manifest}")
            nested_counts[prefix] = manifest_audit(archive, available, manifest, prefix, nested=True)
            require(nested_counts[prefix] == 333, f"Unexpected nested count: {prefix}")

        run = json_member(archive, recovered + "RUN_STATE.json")
        jobs = run["results"]
        require(len(jobs) == 28 and len(set(j["tag"] for j in jobs)) == 28,
                "28 unique job records not present")
        require(all(j["status"] == "EXITED" and j["exitCode"] == 0 for j in jobs),
                "Some jobs did not exit successfully")

        stdout_path = recovered + "full-tests.stdout"
        stdout_raw = archive.read(stdout_path)
        stdout = stdout_raw.decode("utf-8", errors="replace")
        tests_meta = json_member(archive, recovered + "full-tests.meta.json")
        require(tests_meta["tag"] == "full-tests" and tests_meta["argv"] == ["npm", "test"],
                "Incorrect originating test job")
        require(tests_meta["status"] == "EXITED" and tests_meta["exitCode"] == 0,
                "Test job did not exit successfully")
        require(hashlib.sha256(stdout_raw).hexdigest() == tests_meta["stdoutSha256"],
                "Test output differs from execution receipt")
        outcomes = re.findall(r"^ok ([0-9]+) - ", stdout, flags=re.M)
        require([int(n) for n in outcomes] == list(range(1, 639)),
                "TAP does not contain exactly 638 sequential successful cases")
        require(not re.search(r"^not ok\b", stdout, flags=re.M), "TAP contains a failed case")
        accounting = {}
        for key in ("tests", "pass", "fail", "skipped", "cancelled", "todo"):
            values = re.findall(r"^# " + key + r" ([0-9]+)\s*$", stdout, flags=re.M)
            require(len(values) == 1, f"Ambiguous TAP {key} total: {values}")
            accounting[key] = int(values[0])
        require(accounting == {"tests":638,"pass":638,"fail":0,"skipped":0,"cancelled":0,"todo":0},
                f"Unexpected TAP accounting: {accounting}")

        f = json_member(archive, recovered + "oracle-comparator-outputs/reconciliation.json")
        require(f["decision"] == "PRODUCER_REPORT_PARTIAL_EVIDENCE_NO_ACCEPTANCE",
                "F152 decision unexpectedly changed")
        require(f["counts"]["classifications"] == EXPECTED_CLASSIFICATIONS, "F152 class counts differ")
        require(f["counts"]["fullCaseAccepted"] == 0, "F152 accepted-case count changed")
        cases = f["cases"]
        require(len(cases) == 152 and len({c["id"] for c in cases}) == 152,
                "F152 case identity count/uniqueness mismatch")
        require(dict(Counter(c["classification"] for c in cases)) == EXPECTED_CLASSIFICATIONS,
                "F152 individual classifications contradict summary")

        binding = json_member(archive, recovered + "loaded-asset-verification-outputs/binding-result.json")
        require(binding["runUuid"] == EXPECTED_RUN, "Wrong Job28 run UUID")
        require(binding["status"] == "LOADED_BYTE_BINDING_COMPLETE_FOR_TWO_SCOPED_JOBS_ONLY",
                "Job28 status changed")
        require(set(binding["jobs"]) == set(EXPECTED_PHASES), "Job28 jobs differ")
        for job_name, phases in EXPECTED_PHASES.items():
            require(set(binding["jobs"][job_name]["phases"]) == phases,
                    f"Wrong captured phases: {job_name}")

        host = json_member(archive, "APPLICATION_HOST_RESULT.json")
        cleanup = json_member(archive, "APPLICATION_CLEANUP.json")
        require(cleanup["ok"] is True, "Cleanup failed")
        require(host["deploymentAuthorized"] is False and host["SA001"] == "OPEN P1",
                "Unexpected release-authority fields")

    result = {
        "verifier": "SA001 standalone read-only archive audit (standard library)",
        "archive_file": path.name,
        "archive_bytes": size,
        "archive_sha256": original_digest,
        "root_manifest_matches": root_count,
        "nested_manifest_matches_each": 333,
        "nested_manifests_checked": 2,
        "archived_jobs_exit_zero": len(jobs),
        "tap": accounting,
        "f152_classifications": EXPECTED_CLASSIFICATIONS,
        "f152_full_case_acceptances": 0,
        "job28_phases": {key: sorted(value) for key, value in EXPECTED_PHASES.items()},
        "cleanup_ok": True,
        "sa001": "OPEN P1",
        "audit": "PASS: archived-byte integrity and selected source-record accounting ONLY",
        "explicit_limits": ["Not full F152 acceptance", "Not independent human UX verification",
                            "Not original forged-stage historical replay",
                            "Not WASM instantiation/module evaluation", "Not deployment authorisation"]
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit('Usage: py -3 sa001_readonly_independent_archive_check.py "<original ZIP path>"')
    try:
        main(Path(sys.argv[1]))
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        print(f"AUDIT FAILED: {error}", file=sys.stderr)
        raise SystemExit(1)
