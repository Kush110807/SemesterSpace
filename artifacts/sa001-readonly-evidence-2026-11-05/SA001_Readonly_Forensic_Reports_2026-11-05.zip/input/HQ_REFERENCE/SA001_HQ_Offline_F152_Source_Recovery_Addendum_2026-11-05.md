# SemesterSpace Diamond — HQ offline source recovery addendum

**Date:** 5 November 2026  
**Authority:** Read-only HQ evidence extraction; *not independent D attestation or security acceptance*.  
**Run:** `41387922793`, attempt 1; commit `1e4413f6791fd76d5676494ff007f35712813d60`.  
**SA-001 disposition:** `OPEN P1`.

## Original evidence identity

- Original ZIP: `SA001-application-41387922793-1-original.zip` — 488,716,152 bytes; owner-verified SHA-256 `a49b957235ecb48660d16bb91665a8db3a10373b295b740526e545ce99f22a6e`.
- Same-run folder: `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/`
- F152 comparator raw member SHA-256: `be9cc57136556404d3b47d51c1d57dc3afcfa314b0885db121489b563f37a75c`.
- Browser-native-connected raw member SHA-256: `1fcf981c8d612af1d1d0bb634e0e2106bda0e576b67ca0672a45aeafbf61161f`.
- Job 28 binding raw member SHA-256: `62a9d90909df5f41c5f5833e33a07cff763f696765757953e2b1144dbc6493a4`.

## New findings from original raw browser report

- **18/18** missing-observable cases are present as distinct rows in the same-run browser report, at the `browser_case_index` and JSON pointer listed in the attached CSV.
- **0/18** browser rows record `candidateGetterInvocations` as an actual field. **Expected zero does not constitute observed zero.** The raw browser report text also contains zero occurrences of the exact field name.
- **16/18** browser rows include actual before/after storage strings. Each of these 16 observed string comparisons **agrees with its own oracle's expected `CHANGED` or `UNCHANGED` classification**. The CSV supplies both SHA-256 hashes and the case index. **This is browser-reported pre/post string evidence, not independent confirmation of durable disk bytes, storage ACK sequencing, getter counts, or full oracle acceptance.**
- The other **2/18** rows — `F-SA-28-reload-reuse` at `/cases/4` and `F-SA-29-manual-revision` at `/cases/26` — contain rejection/status and `reads=0, writes=0`, but **no before/after storage strings and no getter counter**. This does not prove byte identity. They remain `PENDING_REVIEW` for other surviving same-run sources, not definitively `NOT_OBSERVED` across all evidence.
- Each of the 18 still has additional native-reopen authority and capability expectations. Three rows have ACK-related integration concerns in comparator text. No F152 case is promoted to PASS by this extraction.

## 131 pure-storage partial cases

All 131 `PARTIAL_STORAGE_OBSERVABLE_MATCH` case IDs map to an actual `oracle-storage-outputs/<case_id>.json` archive member. The complete 152-case CSV lists each file's **actual read-byte SHA-256** and the comparator's pending integration labels. Existence and hashes do not establish controller-memory, stage, capability, ACK or reopen behaviour. The archived comparator lists **131** cases requiring `acceptedMemoryDisposition` integration evidence, with `reloadAuthority` and `stageCapabilitiesAfterReload` additionally listed as integration-needed expectations for the **149** partial storage/browser cases combined.

## Frozen B2 OMR external-suite lead (F-SA-33)

The exact same-run archive contains:

- `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/b2-omr.meta.json` (SHA-256 `56a2dfebeb92039fbb56a3da02d8d56ee264da9034645db964d5df15c93425aa`).
- `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/b2-omr.stdout` (SHA-256 `11727e92d539b7fa94d41fbec0eb54a73c0a377dabefde8d2013eeeb81adc224`; matches `meta.stdoutSha256`).
- `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/b2-omr.stderr` (0 bytes).

The meta record reports `EXITED`, exit code `0`, command:

`node --test tests/diamond-001/storage.test.mjs tests/diamond-001/omitted-release-acceptance.test.mjs tests/diamond-001/omitted-release-precedence.test.mjs`

The TAP footer reports **191 tests, 191 passed, 0 failed, 0 skipped**. This is a **concrete preserved external-suite lead** for `F-SA-33-legacy-suite`. It is **not** proof that this suite version/test content satisfies every frozen `F-SA-33` contractual assertion; contract/source identity and actual coverage must still be reviewed independently. No single-call oracle PASS is implied.

## Special cases and scope decisions

- `F-SA-33-legacy-suite`: `EXTERNAL_SUITE_DEPENDENCY`; concrete 191-pass suite record exists; formal matching/coverage review pending.
- `F-SA-34-pre-B2`: `EXCLUDED_NOT_SINGLE_CALL`; old-client fencing contract decision pending.
- `F-SA-35-multi-tab`: `EXCLUDED_NOT_SINGLE_CALL`; two-writer serialisation contract decision pending.

## Unresolved and prohibited inferences

1. Browser result `PASS` does not prove the 18 actual getter counts, 2 missing retained-byte outcomes, or native-reopen capabilities.
2. The 16 before/after observations provide **case-local browser-reported string comparison** only; they do not certify persistence durability, ACK/reload behaviour or independent security acceptance.
3. A same-run external suite PASS does not prove contract equivalence or convert the external dependency into F152 full acceptance.
4. Job 28's six-phase byte binding is unchanged and limited by `NOT_OBSERVED` Worker/WASM behaviours.
5. Historical forged-stage raw bytes remain missing; UX03/UX04 remain separate deferred pre-release gates.
6. This HQ extraction is **not independent archive attestation** and does not authorise CI, code corrections, harness modifications or deployment.

## Targeted next assignment

An archive-capable independent verifier should confirm the above original member bytes/hashes and audit the case-level comparisons. D should review contractual obligations for the 131 integration expectations and three special cases. If missing mandatory observations cannot be recovered offline, request a *separate bounded evidence-observation authorisation* rather than issuing blanket waivers or rewriting historical results. The owner should not approve exceptions without the frozen contract and explicit residual-risk review.
