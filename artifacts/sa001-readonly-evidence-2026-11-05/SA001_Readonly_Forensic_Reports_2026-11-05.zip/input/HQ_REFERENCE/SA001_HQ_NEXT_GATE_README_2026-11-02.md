# SemesterSpace Diamond — HQ Next-Gate Decision

**Decision:** HQ-SA001-POST-D-ADDENDUM/2026-11-02-r1  
**Basis:** D-SA001-RUN41387922793-OFFLINE-EVIDENCE-ADDENDUM/2026-11-02-r1  
**SA-001 disposition:** **OPEN P1**. No execution, source changes, deployment or activation authorised.

## What is accepted
- Existing GitHub run `41387922793`, attempt 1: successful under the committed 28-job fail-closed host contract.
- HQ archive integrity and accounting: reproduced on HQ's runtime, but not independently signed by Chat D.
- `638/638` TAP passes and zero skips/fails, 837/837 root manifest digests, 333/333 *for each of two nested evidence copies*, all 28 job-record exit-zero statuses are observed from the preserved ZIP.

## Why the review cannot be closed by another HQ summary
D's runtime could not read ZIP archives on two attempts. D has not independently recalculated byte hashes and must not sign them as if it had. Sending another ZIP is not a remedy. Use an independently operated archive-capable environment and review its full procedure and result.

## Available read-only independent-reproduction procedure
1. Obtain the exact preserved original ZIP named `SA001-application-41387922793-1-original.zip` (488,716,152 bytes) from the user's ChatGPT Library.
2. Download `sa001_readonly_independent_archive_check.py` and put it beside the original ZIP.
3. Open a PowerShell terminal in that folder (VS Code terminal is fine). Run:

```powershell
py -3 .\sa001_readonly_independent_archive_check.py ".\SA001-application-41387922793-1-original.zip" | Tee-Object -FilePath ".\SA001_independent_verification_output.txt"
if ($LASTEXITCODE -ne 0) { throw "Offline archive verification failed" }
```

4. A verification reviewer **other than HQ** must independently inspect the Python script and the original ZIP input, execute the procedure (or an independently written equivalent), and record the unedited output and reviewer identity. The script uses only Python's standard library, accesses no network, writes no files of its own, and does not execute any application code.
5. Submit the code, original archive identity and reviewer execution transcript to Chat D. If D cannot personally execute, it should explicitly state that the independent verifier did so, rather than claim D reran the hash calculation.

The script checked successfully in HQ's environment with SHA-256 `cb7b59e4883998998c2982ea0854a3880ee6fb495de5bdcf380853a90781324e` (script digest). The accompanying JSON is **HQ reference output only**, not independent attestation.

## Hard boundaries of the verification
- ZIP SHA-256 is the recorded GitHub upload value `a49b957235ecb48660d16bb91665a8db3a10373b295b740526e545ce99f22a6e`.
- Original `FINAL_SHA256.json` covers 837 other ZIP files; both nested `FINAL_ARTIFACT_HASHES.json` copies each cover exactly 333 files in their own prefixes.
- `full-tests.stdout` must match its `full-tests.meta.json` stdout SHA-256 and contain 638 sequential TAP passes; `full-tests.meta.json` must report `npm test`, exit zero.
- Job 27: 131 partial storage, 18 partial missing-observable, one external-suite, two excluded; **full case accepted count remains zero**.
- Job 28: two scoped jobs, six phase names, same-run run UUID, scoped byte-binding status only. Script does **not** independently inspect every phase's Worker or WASM behavioural applicability. That separate detailed inspection remains a D sign-off requirement.
- Archived success does **not** establish historical forged-stage replay or human UX03/UX04 acceptance.

## Remaining security/owner decisions
1. **F152:** Resolve 18 candidate-getter missing observations (two cases also lack persisted-byte disposition); reconcile full case-level authority/memory/expected-vs-actual behaviour and independently adjudicate the external/excluded cases. No blank waiver of the security acceptance contract. A future evidence collection may eventually be necessary **for unobserved behaviour**, not to repeat CI success.
2. **Historical original forged-stage:** Seek original raw-byte capture; if unavailable, obtain narrow owner-approved evidence exception with explicitly excluded claims. A new negative test cannot recreate an original historical observation.
3. **UX03/UX04:** Retain as **independently unresolved release gates**, not SA-001 passes. Assessment may proceed separately when appropriately authorised.
4. **SA-001:** Do not mark accepted or production-ready until an independently evidenced decision and explicit owner authorisation.

## Final HQ instruction
Avoid serial re-sending of ZIP summaries to D. First arrange a reviewer who can actually perform the read-only byte verification, then seek D's final bounded evidence acceptance. Meanwhile prioritise the actual F152 evidence gap and separate historical/UX dispositions.
