# SemesterSpace Diamond — SA-001 targeted F152 and Job 28 source dossier

**Date prepared:** 5 November 2026. **Status:** SA-001 OPEN P1; read-only HQ source extraction, NOT independent security sign-off.

**Purpose:** Supply exact source-grounded case IDs, expected fields, evidence gaps and phase scope to support D’s targeted adjudication. No new execution or changed case statuses.

## Source identity and provenance
- Preserved original archive: `SA001-application-41387922793-1-original.zip`; locally owner-verified SHA-256 (recorded in earlier signed run): `a49b957235ecb48660d16bb91665a8db3a10373b295b740526e545ce99f22a6e`.
- Run `41387922793`, attempt 1; commit `1e4413f6791fd76d5676494ff007f35712813d60`; same-run UUID `SA001-20261102T042156Z-b5381bc409a7`.
- F152 archive member: `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/oracle-comparator-outputs/reconciliation.json`. SHA-256 of extracted raw member bytes: `be9cc57136556404d3b47d51c1d57dc3afcfa314b0885db121489b563f37a75c`.
- Job 28 archive member: `RECOVERED_APPLICATION_EVIDENCE/SA001-20261102T042156Z-b5381bc409a7/loaded-asset-verification-outputs/binding-result.json`. SHA-256 of extracted raw member bytes: `62a9d90909df5f41c5f5833e33a07cff763f696765757953e2b1144dbc6493a4`.
- Extraction here confirms the dossier corresponds to those source members, not that an independent D reviewer has personally re-hashed the 488 MB archive.

## Confirmed F152 accounting from preserved comparator reconciliation
- Unique cases: **152**; 131 partial storage comparisons, 18 partial missing observables, one external-suite dependency, two excluded non-single-call cases.
- **Full-case acceptance: zero.** The archived comparator itself states `PRODUCER_REPORT_PARTIAL_EVIDENCE_NO_ACCEPTANCE`.
- Field-level comparator check states: `{'MATCH': 1539, 'ABI_OPTIONAL_ABSENT': 26, 'MISSING': 20}`. `MATCH` of individual fields is NOT full oracle acceptance.
- Other unproven expectations include integration/controller memory ordering, ACK transitions and native-reopen capability, even for the 131 storage-partial cases.

## The exact 18 cases missing candidate getter observations

| ID | Expected outcome | Expected getter | Missing archived comparison fields |
|---|---|---:|---|
| `F011-X-15-required` | `SA_UPGRADE_CONSENT_REQUIRED` | `0` | `candidateGetterInvocations` |
| `F011-X-15-declined` | `SA_UPGRADE_CONSENT_DECLINED` | `0` | `candidateGetterInvocations` |
| `F011-X-15-stage` | `SA_UPGRADE_CONSENT_STALE` | `0` | `candidateGetterInvocations` |
| `F011-X-15-base` | `SA_UPGRADE_CONSENT_STALE` | `0` | `candidateGetterInvocations` |
| `F011-X-16a` | `SA_ACCEPTED` | `0` | `candidateGetterInvocations` |
| `F-SA-26-commit-throw` | `SA_COMMIT_UNCERTAIN` | `0` | `candidateGetterInvocations` |
| `F-SA-27a` | `SA_COMMIT_UNCERTAIN` | `0` | `candidateGetterInvocations` |
| `F-SA-23-decline` | `SA_UPGRADE_CONSENT_DECLINED` | `0` | `candidateGetterInvocations` |
| `F-SA-24-subset` | `SA_UPGRADE_CONSENT_STALE` | `0` | `candidateGetterInvocations` |
| `F-SA-24-base-bytes` | `SA_UPGRADE_CONSENT_STALE` | `0` | `candidateGetterInvocations` |
| `F-SA-24-epoch` | `SA_UPGRADE_CONSENT_STALE` | `0` | `candidateGetterInvocations` |
| `F-SA-24-stage` | `SA_UPGRADE_CONSENT_STALE` | `0` | `candidateGetterInvocations` |
| `F-SA-24-profile` | `SA_UPGRADE_CONSENT_STALE` | `0` | `candidateGetterInvocations` |
| `F-SA-25-genuine-shape` | `SA_ACCEPTED` | `0` | `candidateGetterInvocations` |
| `F-SA-28-reload-reuse` | `SA_AUTH_STALE` | `0` | `candidateGetterInvocations`, `persistedByteDisposition` |
| `F-SA-29-manual-revision` | `SA_AUTH_INVALID` | `0` | `candidateGetterInvocations`, `persistedByteDisposition` |
| `F-SA-40-profile3-upgrade-pending` | `SA_ACCEPTED` | `0` | `candidateGetterInvocations` |
| `F011-X-16a-stale-base-negative` | `SA_UPGRADE_CONSENT_STALE` | `0` | `candidateGetterInvocations` |

**Important:** The comparator marks these fields `MISSING` in its own case-level comparison. That is not proof no other raw observation exists anywhere in the archive. D must search original same-run reports, inspect source identity and determine whether any directly comparable actual values survive.

## Missing persisted-byte dispositions: two named cases
- `F-SA-28-reload-reuse`: expected `SA_AUTH_STALE` / `NO_LIVE_STAGE`, get=0, set=0, persisted bytes **`UNCHANGED`**; comparator has no actual `candidateGetterInvocations` or `persistedByteDisposition`. A zero write count or rejected result alone cannot establish retained byte identity.
- `F-SA-29-manual-revision`: expected `SA_AUTH_INVALID` / `NO_LIVE_STAGE`, get=0, set=0, persisted bytes **`UNCHANGED`**; comparator has no actual `candidateGetterInvocations` or `persistedByteDisposition`. A zero write count or rejected result alone cannot establish retained byte identity.

## Special cases requiring bounded scope decisions
- `F-SA-33-legacy-suite` — **EXTERNAL_SUITE_DEPENDENCY**. Recorded reason: `EXTERNAL_B2_OMR_SUITE_REQUIRED`; no case-level acceptance asserted.
- `F-SA-34-pre-B2` — **EXCLUDED_NOT_SINGLE_CALL**. Recorded reason: `OLD_CLIENT_NOT_FENCED`; no case-level acceptance asserted.
- `F-SA-35-multi-tab` — **EXCLUDED_NOT_SINGLE_CALL**. Recorded reason: `NO_WRITER_SERIALIZATION`; no case-level acceptance asserted.

Recommended HQ position: no automatic acceptance of the external suite, and no automatic waiver of the two exclusions. D should identify contract basis, surviving external-suite proof, and scope impact; Product Owner must explicitly accept/reject a bounded disposition.

## Job 28 phase inventory as recorded in source

| Job/phase | Status | Captured responses | Observed Workers | WASM instantiation |
|---|---|---:|---:|---|
| `browser/native-before` | `ASSET_BYTES_MATCH_BUILD_NOT_SA_ACCEPTANCE` | 25 | 3 | `NOT_OBSERVED_NOT_CLAIMED` |
| `browser/native-after` | `ASSET_BYTES_MATCH_BUILD_NOT_SA_ACCEPTANCE` | 24 | 2 | `NOT_OBSERVED_NOT_CLAIMED` |
| `browser/retained-ui` | `ASSET_BYTES_MATCH_BUILD_NOT_SA_ACCEPTANCE` | 28 | 0 | `NOT_OBSERVED_NOT_CLAIMED` |
| `browser/fixture-pdf-ocr` | `ASSET_BYTES_MATCH_BUILD_NOT_SA_ACCEPTANCE` | 51 | 26 | `NOT_OBSERVED_NOT_CLAIMED` |
| `e-finite/forgery-before` | `ASSET_BYTES_MATCH_BUILD_NOT_SA_ACCEPTANCE` | 24 | 2 | `NOT_OBSERVED_NOT_CLAIMED` |
| `e-finite/forgery-after` | `ASSET_BYTES_MATCH_BUILD_NOT_SA_ACCEPTANCE` | 30 | 8 | `NOT_OBSERVED_NOT_CLAIMED` |

- Binding status: `LOADED_BYTE_BINDING_COMPLETE_FOR_TWO_SCOPED_JOBS_ONLY`. Binding hash: `4f8463c56557eb542cc2efae8929db8a2d3d475f55727e15effa6acbe65c006d`.
- Original forgery status in E-finite record: `BLOCKED_MISSING_ORIGINAL_BYTES`. Historical original raw-byte replay remains unresolved.
- A loaded Worker script is not general proof of arbitrary module evaluation, and decoded embedded WASM bytes are not evidence of WASM instantiation.

## Proposed evidence-resolution order (read-only, no CI)
1. Have a separate archive-capable independent reviewer run/review the original artifact checks; D adjudicates that attestation, not merely HQ’s transcript.
2. For each of the 18 named IDs, search same-run browser/controller reports and receipts for the missing getter observation; record actual, sequence, path/hash and a case-specific comparison, or `NOT_OBSERVED`.
3. For `F-SA-28-reload-reuse` and `F-SA-29-manual-revision`, search preserved before/after raw bytes, hashes and write/receipt records to determine persisted-byte disposition; do not infer from API status alone.
4. Separately evaluate `F-SA-33-legacy-suite`, `F-SA-34-pre-B2` and `F-SA-35-multi-tab` against the frozen acceptance contract. No blanket exception.
5. Preserve missing original historical forged-stage raw bytes as unresolved until authentic recovery or a policy-permitted narrow exception; retain UX03/UX04 as independent unrun release gates.
6. D returns an itemised evidence ledger with each claim `VERIFIED / NOT_OBSERVED / OUT_OF_SCOPE / FAILED` and a formal owner-decision request only for truly irrecoverable evidence.

**No security acceptance or release is implied by this dossier.**
