// Required-delay connected reproduction. Real A callback runs; only its result delivery is held.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {openProfile,shot,fail,state,evidence} from './browser-common.mjs';
import {prepareReview} from './review-helper.mjs';
const seed=JSON.parse(await readFile(evidence+'/qa-seed.json'));
const {context,page}=await openProfile('fv01-recovery-repro','2026-10-26T14:30:00Z',seed);
try{
 await page.getByRole('button',{name:'Calendar updates',exact:true}).click();await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-revision.pdf');await page.getByRole('button',{name:'Read selected calendar',exact:true}).click();await page.getByText(/Reader result: PARTIAL/).waitFor({timeout:180000});await prepareReview(page);
 const originalBytes=await page.evaluate(()=>localStorage.getItem('semesterspace.v1'));
 await page.evaluate(()=>{const callbacks=window.__QA_APP__.callbacks;window.__qaOriginalStage=callbacks.onProposeCalendarRevision;callbacks.onProposeCalendarRevision=async req=>{window.__qaRealStageResult=window.__qaOriginalStage(req);await new Promise(resolve=>window.__qaResolveStage=resolve);window.__qaDelivered=true;return window.__qaRealStageResult;};});
 await page.getByLabel('I have read this comparison and understand that staged items are not yet applied',{exact:true}).check();await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).click();await page.waitForFunction(()=>typeof window.__qaResolveStage==='function');
 await page.getByLabel('Which prior documents and rows did you review?',{exact:true}).fill('SYNTHETIC QA: edited prior-source note while the genuine A response was delayed.');await page.evaluate(()=>window.__qaResolveStage());await page.waitForFunction(()=>window.__qaDelivered===true);
 await page.evaluate(()=>{window.__QA_APP__.callbacks.onProposeCalendarRevision=window.__qaOriginalStage;});
 await page.getByRole('button',{name:'Calendar updates',exact:true}).click();const oldApplyBlocked=await page.getByRole('button',{name:'Apply selected calendar changes',exact:true}).isDisabled();
 await page.locator('[data-revision-intake] details').evaluateAll(n=>n.forEach(d=>d.open=true));await page.getByLabel('I explicitly reviewed all interpretations, source evidence and exclusions before comparing',{exact:true}).check();await page.getByRole('button',{name:'Prepare comparison (no schedule change)',exact:true}).click();
 const comparisonText=await page.locator('.revision-compare').innerText();assert.match(comparisonText,/0 unresolved/);
 await page.getByLabel('I have read this comparison and understand that staged items are not yet applied',{exact:true}).check();
 const disabled=await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).isDisabled();await page.locator('.revision-compare').scrollIntoViewIfNeeded();await shot(page,'14-fv01-new-comparison-stuck');
 const record={id:'FV-01',owner:'C: src/ui/revision-review.js',actualAStagingResult:await page.evaluate(()=>window.__qaRealStageResult),oldApplyBlocked,newComparisonUnresolved:0,newStageDisabled:disabled,modelRevision:(await state(page)).model.revision,noStoredChange:originalBytes===await page.evaluate(()=>localStorage.getItem('semesterspace.v1')),comparisonText};
 // Demonstrate a UI-only workaround; it does not repair the defect.
 await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-revision.pdf');await page.getByRole('button',{name:'Read selected calendar',exact:true}).click();await page.getByText(/Reader result: PARTIAL/).waitFor({timeout:180000});await prepareReview(page);record.stageEnabledAfterReread=!await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).isDisabled();
 await writeFile(evidence+'/fv01-recovery-report.json',JSON.stringify(record,null,2));console.log(JSON.stringify(record,null,2));
 assert.equal(disabled,false,'FV-01: new valid comparison cannot be restaged after a stale delayed staging response');
}catch(e){await writeFile(evidence+'/fv01-assertion.txt',String(e.stack??e));throw e;}finally{await context.close();}
