# SemesterSpace final release verification — HOLD

25 October 2026 IST. **Recommendation: HOLD pending A/C disposition of FV-01.** Installed build/test gates passed and the real connected workflow was exercised, but a new delayed-staging recovery defect remains. No application code, merge, push, deployment or Devfolio submission was performed. Additional spend ₹0.

## Authoritative candidate and preservation

Only the user-attached `SS_RC14_Final_Source_For_D.zip` was tested, SHA-256 **`5d4070ddbccdfaa0a714ff5bebf8f4ae12f8ea0759964db9f9611877214bafc0`**. ZIP CRC passed, current `PACKAGE_INTEGRITY_RC0014_C_FINAL.sha256` verified **196/196 entries**, and all **197 original files**, including the checksum manifest, remain byte-for-byte unchanged after testing. Earlier historical manifests and worker branches were not substituted. Git ancestry declared by supplied manifests is not independently authenticated by an archive without .git.

Extracted candidate: `/workspace/ss-rc14-final-verification/SemesterSpace`; app: its `semester-space` directory. Evidence, scripts and browser profiles are outside that candidate. Installation generated only pinned node_modules, local vendor assets and dist. See source-baseline.json and source-identity-verification.json. No applicable AGENTS.md was present.

## Phase 1 — actual installed checks

Environment: Node **24.19.0**, npm **11.9.0**, Python **3.12.14**, Playwright **1.58.2**, Chromium **154.0.8037.57**, Debian GNU/Linux 13, Linux x86_64. Required Node20+/Python3.10+ satisfied. Tests ran from the attached app directory.

| Exact command | Exit | Actual outcome / log |
| --- | --- | --- |
| `npm --cache /tmp/ss-npm-cache ci --no-audit --no-fund` | 0 | Clean node_modules install: 21 pinned packages; 39 local assets. `install.log` |
| `npm run check` | 0 | 70 modules after asset preparation. `syntax.log` |
| `npm test` | 0 | 274 tests passed, no failures/skips/TODOs. `full-tests.log` |
| `node --test tests/engine/*.test.mjs` | 0 | 26 passed. `engine.log` |
| `python3 tests/checker.py` | 0 | 342 public-engine decisions match independent Fraction arithmetic. `arithmetic.log` |
| `npm run build` | 0 | Production static dist built. `build.log` |

No dependency-load failure, installation failure or executed application assertion failure occurred in these commands. These observations reproduce the installed gate here; they do not rewrite D’s earlier missing-dependency observations or confer independent D approval.

Production dist was served on `http://127.0.0.1:5280` using the supplied `tools/serve.mjs` makeServer with the dist directory. The browser ran that application’s real main.js, C UI, importer, A controller/storage, B ledger and engine. No inline mock-UI fixtures or earlier feature-source code was used.

## Phase 2 — connected browser acceptance

| Requested area | Actual result |
| --- | --- |
| 1. Actual upload and PDF/OCR | PASS: real four-page Pool B timetable and eight-page MAIT scanned calendar selected through file inputs. Calendar has zero native text items on all eight pages; actual browser extraction took 32,969ms and produced the reviewed setup. Separate reference-file metadata inspection is labelled supplementary in input-documents.json. |
| 2. Explicit source/coverage review | PASS: premature save and generic page viewing blocked. Reviewed all original pages, calendar coverage and source dispositions; explicit source-specific correction exercised. Synthetic setup saved through A with 9 separate registers/39 sessions. These are QA choices, not a confirmed personal timetable. |
| 3. Legacy metadata review | PASS: explicit missing-crosswalk consent and reason before comparison. A preserved exact seeded legacy filename `QA-prior-calendar.pdf` and its synthetic 64-hex hash in durable sourceHistory. No prior links were invented. This is identity-retention testing, not reconstruction or verification of an unavailable old physical document. |
| 4. Compare/stage/select/apply | PASS with the documented reread workaround for FV-01: actual generated PDF read through the real PDF reader; 3 reviewed effects staged, 2 selected and applied, unselected holiday absent, 2 durable source links, one model revision increment. |
| 5. Delayed staging after edits/replacement | Old-apply safety PASS in both cases. **Recovery FAIL FV-01:** after editing and receiving a stale result, a fresh valid comparison cannot be staged until reread/replacement. Dedicated reproduction exits 1. |
| 6. Daily closure/correction/official baseline | PASS: unknown marks did not save. Explicit zero-meeting days closed; one missed occurrence gave 90/101; correction appended history and derived 91/101; explicit synthetic official 79/100 baseline retained records and recorded OFFICIAL_COUNT_DISCREPANCY. Controller stamped times. |
| 7. Retained commitment/recalculation | PASS: previously stored break retained. New compulsory exam changed actual engine result to PLAN_BLOCKED and displayed invalid commitment on 2 November; no commitment was deleted. |
| 8. Storage-write failure | PASS for an official snapshot and for calendar application. Injected native Storage.setItem quota failure: model, journal, source metadata and stored bytes unchanged. Calendar failed one write and retained its staged proposal for retry; no phantom holiday. |
| 9. Native persistence | PASS: closed Chromium process and reopened the same persistent profile with **no reseeding**. Exact accepted model/release, source history, records, snapshots, links and invalid commitment read back. This is a real browser process reopen, not only page.reload or a Map facade. |
| 10. Ambiguous/insufficient revisions | PASS: comparison displayed AMBIGUOUS_MATCH or REMOVAL_EVIDENCE/INEFFECTIVE_EVENT; UI Apply disabled. Ephemeral staging is permitted for review. Direct attempts through the actual A apply callback returned REJECTED without changing native stored bytes. |

Initial and connected drivers, native/negative checks and calendar-write-failure driver exit 0. The connected driver records FV-01 and uses an explicit reread workaround to complete other cases; its zero exit does not erase the recovery failure. The separate fv01-recovery-repro.mjs exits 1 and preserves the failing assertion. See verification-results.json and the individual reports/logs.

### Evidence method and test boundaries

All data decisions are explicitly synthetic QA. Initial onboarding used actual supplied source files but synthetic grouping/activity/count/policy/horizon confirmations. The revision and attendance scenario used an isolated native localStorage seed named Synthetic Release QA, plus generated PDF notices whose complete bytes are included. Q / Q3 / Q23 declarations do not resolve actual Physics/activity/count/policy/horizon questions.

A DevTools breakpoint exposes the actual main.js controller for read-only state assertions; application source is never patched or replaced. The only fault hooks are real-callback result latency and native Storage.setItem exceptions, each delegated to the original handler outside the controlled fault. Direct negative controller calls are labelled supplemental backend guards; successful user flows use the real UI. Browser clocks are controlled (24 October 20:00 IST for initial import; 26 October 20:00/20:59 IST for daily/revision/reopen). These timestamps are test conditions, not personal attestations.

Desktop 1440px and mobile **390×844 viewport emulation** screenshots are genuine Chromium application renderings. This is not physical-device testing. Mobile checks found client/scroll width 390/390 on the initial and recalculated calendar views. No external browser requests or application pageerror events occurred in the successful scenarios. Nonfatal diagnostics: missing favicon.ico (404, confirmed by console URL) and OCR-worker resolution/diacritic/clipping messages during partial extraction; no universal accuracy claim follows from successful decoding.

Preliminary harness attempts failed on a too-strict accessible-name match, collapsed details after redraw, and an incorrect assumption that unresolved proposals must be rejected at *staging*. Those were corrected only in external scripts; logs remain included. The contract permits ephemeral staging and rejects unresolved *application*. These harness errors are not reported as application defects. FV-01 is separately reproduced with stage consent checked and zero unresolved items.

## Confirmed finding and ownership

**FV-01 — C-owned staging recovery remains busy after a stale response.** Medium / workflow P1 under the required injected delay. The previous stale-apply guard passes: no older proposal was applied and no stored bytes changed. Actual A handler currently returns synchronously; the test deliberately delays its result delivery to exercise the required asynchronous boundary. Reopening/replacing/reading the document is a working UI workaround, not a repair.

`CHAT_A_FV01_HANDOFF.md` contains the bounded reproduction, source correspondence and expected behavior. Screenshots 09 and 14 show the blocked new comparison; fv01-recovery-report.json records actual REVIEW_REQUIRED, old-apply blocked, 0 unresolved items, new Stage disabled, no stored change and successful reread workaround. No fix was implemented. A should obtain a bounded C correction/disposition and arrange independent recheck against a newly identified candidate.

## Outstanding limitations / gate recommendation

**HOLD** pending FV-01 disposition and the independent final release decision. Existing D acceptances remain scoped to their accepted repairs; this report is not an expanded D sign-off. The installed/browser evidence closes the previously unexecuted gates in this environment, but does not authorize deployment or submission.

Physical devices, screen readers, Firefox/Safari, simultaneous-tab concurrency, unseen-format coverage, a fresh full five-calendar OCR accuracy audit, institutional applicability and actual personal inputs were not verified. The known getItem→setItem optimistic revision check is not serializable cross-tab compare-and-swap; no multi-tab safety claim. Dense grids/cohort/legend/footnote/Hindi interpretation and MAIT orientation/sessionals remain partial. Manual review cannot prove detection of every omitted event. Arithmetic checks establish the tested feasibility cases, not universal correctness or greedy optimality.

SS-INT-002 fallback, production hosting and Devfolio submission were untouched. No paid services or publication occurred.
