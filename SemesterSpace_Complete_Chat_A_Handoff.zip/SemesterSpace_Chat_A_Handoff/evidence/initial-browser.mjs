import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {openProfile,shot,fail,state,root,evidence} from './browser-common.mjs';
const {context,page,errors,consoleErrors,external}=await openProfile('initial-documents','2026-10-24T14:30:00Z');
const dir=evidence,report={scenario:'Actual supplied timetable and scanned calendar; all choices synthetic QA',clock:'2026-10-24 20:00 Asia/Kolkata'};
try{
  await page.getByRole('heading',{name:'Start with your documents',exact:true}).waitFor();
  const file=n=>root+'/reference-inputs/'+n;
  await page.getByLabel('Timetable file',{exact:true}).setInputFiles(file('1stSemPoolB.pdf'));await page.getByLabel('Academic calendar file',{exact:true}).setInputFiles(file('Academic_Calendar_Odd_Semester_2026-2027.pdf'));
  const start=Date.now();await page.getByRole('button',{name:'Extract editable draft',exact:true}).click();await page.getByRole('heading',{name:'1. Review source pages and extracted candidates',exact:true}).waitFor({timeout:180000});report.extractionMs=Date.now()-start;
  assert.equal(await page.locator('[data-import-row]').count(),29);assert.match(await page.locator('[data-import-output]').innerText(),/18 lecture periods; 4 merged lab blocks/);
  await page.getByRole('button',{name:'Validate reviewed draft and save initial setup',exact:true}).click();assert.match(await page.locator('[data-import-errors]').innerText(),/unresolved issues/);assert.equal(await page.evaluate(()=>localStorage.length),0);report.unresolvedBlocked=true;
  await page.screenshot({path:dir+'/draft-desktop.png',fullPage:false});
  await page.setViewportSize({width:390,height:844});report.draftMobileWidths=await page.evaluate(()=>({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth}));assert.ok(report.draftMobileWidths.scroll<=390);await page.screenshot({path:dir+'/draft-mobile.png',fullPage:false});await page.setViewportSize({width:1280,height:900});
  // Mark each source page covered by this synthetic QA review, using the real preview controls.
  const picker=page.locator('[data-page-picker]');for(const value of await picker.locator('option').evaluateAll(nodes=>nodes.map(n=>n.value))){await picker.selectOption(value);await page.getByLabel('I viewed this source page (this does not confirm calendar coverage)',{exact:true}).check();}
  await page.locator('[data-import-output] details').evaluateAll(nodes=>nodes.forEach(n=>n.open=true));
  const subjects=page.getByLabel('I reviewed this subject and its alias proposal',{exact:true});for(let i=0;i<await subjects.count();i++)await subjects.nth(i).check();
  for(const row of await page.locator('[data-import-row]').all()){
   await row.evaluate(e=>{e.open=true;});const title=await row.locator(':scope > summary').innerText();
   const note=row.getByLabel('Resolution / correction reason',{exact:true});
   if(/ACTIVITY/.test(title)){await row.getByLabel('Attendance treatment',{exact:true}).selectOption(title.includes('Library')&&title.includes('Monday')?'COMPULSORY_ZERO_UNITS':'OPTIONAL');await note.fill('Synthetic QA only: explicit activity treatment, not personal policy.');}
   else await row.getByLabel('Attendance units per occurrence (not duration)',{exact:true}).fill('1');
   const group=row.getByLabel('Source group label (confirm its mapping)',{exact:true});
   if(await group.count()){
    if(title.includes('Physics')){await row.getByLabel('Applies to me',{exact:true}).selectOption('DOES_NOT_APPLY');await note.fill('Synthetic QA only: exclude this block for test setup. Real Q3 physics remains unresolved.');}
    else{await group.selectOption(title.toLowerCase().includes('programming')?'Q23':'Q3');await row.getByLabel('Applies to me',{exact:true}).selectOption('APPLIES');await note.fill('Synthetic QA: source group explicitly selected and reviewed.');}
   }
   await row.getByLabel('I reviewed this occurrence, including applicability and any group mapping',{exact:true}).check();
  }
  let correctedHolidayId=null;
  for(const row of await page.locator('[data-calendar-row]').all()){
   await row.evaluate(e=>{e.open=true;});const category=await row.getByLabel('Source category',{exact:true}).inputValue();
   if(category==='HOLIDAY'&&(await row.getByLabel('Start date',{exact:true}).inputValue())&&(await row.getByLabel('Start date',{exact:true}).inputValue())===(await row.getByLabel('End date',{exact:true}).inputValue())){
    await row.getByLabel('Applies to my cohort',{exact:true}).selectOption('APPLIES');await row.getByLabel('Planner treatment',{exact:true}).selectOption('HOLIDAY');
   }else{
    await row.getByLabel('Applies to my cohort',{exact:true}).selectOption('DOES_NOT_APPLY');await row.getByLabel('Planner treatment',{exact:true}).selectOption('DOES_NOT_APPLY');
   }
   await row.getByLabel('Resolution / correction reason',{exact:true}).fill('Synthetic QA only: scoped test confirmations. These are not the student’s actual applicability decisions.');await row.getByLabel('Review decision',{exact:true}).selectOption('CORRECTED');
   await row.locator('details').evaluateAll(nodes=>nodes.forEach(n=>n.open=true));
   const represented=await row.getByLabel('Planner treatment',{exact:true}).inputValue()==='HOLIDAY';
   await row.getByLabel('Source candidate resolution',{exact:true}).selectOption(represented?'REPRESENTED':'NO_APPLICABLE_EFFECT');
   if(represented)await row.getByLabel('Planner entries representing this source candidate',{exact:true}).selectOption(await row.getAttribute('data-calendar-row'));
   await row.getByLabel('Source-based resolution explanation',{exact:true}).fill(represented?'Synthetic reviewer explicitly represents this holiday.':'Synthetic review only: no student obligation applies to the synthetic programme. This is not a personal confirmation.');
   await row.getByLabel('I explicitly confirm this source candidate resolution',{exact:true}).check();
   if(represented&&(await row.getByLabel('Start date',{exact:true}).inputValue())==='2026-11-08'){correctedHolidayId=await row.getAttribute('data-calendar-row');await row.getByLabel('Start date',{exact:true}).fill('2026-11-09');await row.getByLabel('End date',{exact:true}).fill('2026-11-09');}
  }
  await page.locator('[data-import-output] details').evaluateAll(nodes=>nodes.forEach(n=>n.open=true));
  const confirm=page.getByText('5. Subjects I must attend, actual counts and final confirmation',{exact:true}).locator('..');
  for(const [label,value] of [['Institution','MAIT'],['Academic year','2026-27'],['Semester number','1'],['Programme','Synthetic QA UG'],['Confirmed schedule start','2026-10-24'],['Confirmed last teaching day','2026-11-09'],['Counts complete through','2026-10-23'],['First candidate break date','2026-10-24'],['Last candidate break date','2026-11-09']])await confirm.getByLabel(label,{exact:true}).fill(value);
  await confirm.getByLabel('I checked academic identity, source applicability and teaching horizon',{exact:true}).check();await confirm.getByLabel('All actual counts refer to this same completed day',{exact:true}).check();
  for(const label of ['I verified this source institution','I verified its term / academic year','I verified first-year / programme / cohort applicability, exceptions and notices'])for(const node of await confirm.getByLabel(label,{exact:true}).all())await node.check();
  // Refresh active count roster after treatments and applicability edits (without losing draft inputs).
  for(const box of await confirm.locator('details').all())await box.evaluate(e=>{e.open=true;});
  for(const [label,value] of [['Requirement R (%)','75'],['Buffer B (percentage points)','3'],['Actually attended units','90'],['Actually held units','100']])for(const node of await confirm.getByLabel(label,{exact:true}).all())await node.fill(value);
  await confirm.getByLabel('Search reviewed subjects',{exact:true}).fill('Communication');const selection=confirm.getByLabel('Subjects I must attend',{exact:true});await selection.selectOption({label:'Communication Skills'});
  await page.getByRole('button',{name:'Validate reviewed draft and save initial setup',exact:true}).click();
  assert.match(await page.locator('[data-import-errors]').innerText(),/CALENDAR_MANUAL_COMPLETION/);assert.equal(await page.evaluate(()=>localStorage.length),0);report.pageViewingCannotCompleteCoverage=true;
  assert.ok(correctedHolidayId,'Actual calendar holiday candidate available for synthetic correction test');assert.match(await page.locator('[data-import-errors]').innerText(),/CALENDAR_RESOLUTION_CORRESPONDENCE/);
  const correctedHoliday=page.locator(`[data-calendar-row="${correctedHolidayId}"]`);await correctedHoliday.evaluate(n=>n.open=true);await correctedHoliday.locator('details').evaluateAll(nodes=>nodes.forEach(n=>n.open=true));
  await correctedHoliday.getByLabel('Source-specific date or pattern correction explanation',{exact:true}).fill('Synthetic browser QA only: explicit correction from 8 to 9 November, not a change to the student’s real holiday.');
  await correctedHoliday.getByRole('button',{name:'Confirm source-specific reconciliation for selected planner entries',exact:true}).click();assert.equal(await correctedHoliday.getByLabel('I explicitly confirm this source candidate resolution',{exact:true}).isChecked(),false);await correctedHoliday.getByLabel('I explicitly confirm this source candidate resolution',{exact:true}).check();report.sourceSpecificReconciliationUi=true;

  const effects=new Map();for(const row of await page.locator('[data-calendar-row]').all())effects.set(await row.getAttribute('data-calendar-row'),{treatment:await row.getByLabel('Planner treatment',{exact:true}).inputValue(),date:await row.getByLabel('Start date',{exact:true}).inputValue()});
  for(const panel of await page.locator('[data-coverage-page]').all()){
   await panel.evaluate(n=>n.open=true);
   for(const area of await panel.locator('[data-coverage-area]').all()){
    await area.evaluate(n=>n.open=true);const key=await area.getAttribute('data-coverage-area'),rows=area.getByLabel('Entered planner rows for this coverage area',{exact:true});
    const ids=await rows.locator('option').evaluateAll(nodes=>nodes.map(n=>n.value));const selected=ids.filter(id=>key==='NON_TEACHING'&&effects.get(id)?.treatment==='HOLIDAY'&&effects.get(id).date>='2026-10-24'&&effects.get(id).date<='2026-11-09');
    await area.getByLabel('Manual coverage decision',{exact:true}).selectOption(selected.length?'ENTERED':'NONE_APPLICABLE');if(selected.length)await rows.selectOption(selected);
    await area.getByLabel('Manual completion explanation',{exact:true}).fill('Explicit synthetic manual comparison with this source page, cohort and horizon. All nonholiday obligations are excluded only in this synthetic scenario.');
   }
   await panel.getByRole('button',{name:'Confirm this page’s manual coverage for current entries and scope',exact:true}).click();
  }
  await page.getByRole('button',{name:'Validate reviewed draft and save initial setup',exact:true}).click();
  await page.getByRole('button',{name:'Calendar & breaks',exact:true}).click();
  await page.getByRole('heading',{name:'Projected attendance by separate register',exact:true}).waitFor({timeout:15000}).catch(async()=>{throw Error('Setup failed: '+await page.locator('[data-import-errors]').innerText());});

 report.connectedSetup=true;const s=await state(page);report.registers=s.model.registers.length;report.sessions=s.model.sessions.length;report.modelRevision=s.model.revision;report.persistence=s.persistence.status;
 assert.equal(s.persistence.status,'SAVED');assert.ok(s.model.context.programme.includes('Synthetic'));
 await shot(page,'01-initial-calendar-desktop');await shot(page,'02-initial-calendar-mobile',true);
 report.mobileWidth=await page.evaluate(()=>({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth}));
 report.pageErrors=errors;report.consoleErrors=consoleErrors;report.externalRequests=external;
 assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
 await writeFile(evidence+'/initial-browser-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}catch(e){await fail(page,'initial',e);throw e;}finally{await context.close();}
