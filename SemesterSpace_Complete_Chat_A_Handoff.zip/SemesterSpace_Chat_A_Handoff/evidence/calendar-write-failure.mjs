import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {openProfile,shot,fail,state,evidence} from './browser-common.mjs';
import {prepareReview} from './review-helper.mjs';
const {context,page,errors,external}=await openProfile('connected-release-r3','2026-10-26T15:29:00Z');
try{
 await page.getByRole('button',{name:'Calendar updates',exact:true}).click();await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-replacement.pdf');await page.getByRole('button',{name:'Read selected calendar',exact:true}).click();await page.getByText(/Reader result: PARTIAL/).waitFor({timeout:180000});await prepareReview(page);
 await page.getByLabel('I have read this comparison and understand that staged items are not yet applied',{exact:true}).check();await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).click();await page.waitForFunction(()=>window.__QA_APP__.getState().stagedCalendarRevision!==null);
 await page.locator('[data-release-revision] > .revision-change').getByLabel('Include this change in the application',{exact:true}).check();await page.getByLabel('I have reviewed source coverage, my cohort and every relevant calendar page, including omissions',{exact:true}).check();await page.getByLabel('Apply the checked changes only; retain past attendance and existing commitments for re-evaluation',{exact:true}).check();
 const before=await state(page),bytes=await page.evaluate(()=>localStorage.getItem('semesterspace.v1'));
 await page.evaluate(()=>{window.__qaFailures=0;window.__qaNativeSetItem=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='semesterspace.v1'){window.__qaFailures++;throw new DOMException('Synthetic calendar-acceptance quota failure','QuotaExceededError');}return window.__qaNativeSetItem.call(this,k,v);};});
 await page.getByRole('button',{name:'Apply selected calendar changes',exact:true}).click();await page.waitForFunction(()=>window.__QA_APP__.getState().persistence.status==='FAILED');
 const after=await state(page);assert.deepEqual(after.model,before.model);assert.deepEqual(after.release,before.release);assert.equal(await page.evaluate(()=>localStorage.getItem('semesterspace.v1')),bytes);assert.deepEqual(after.stagedCalendarRevision,before.stagedCalendarRevision);assert.ok(!after.model.schedule.holidays.some(h=>h.date==='2026-11-05'));assert.equal(await page.evaluate(()=>window.__qaFailures),1);
 await page.getByText('Calendar was not updated',{exact:true}).waitFor();await shot(page,'15-calendar-write-failure-desktop');await shot(page,'16-calendar-write-failure-mobile',true);
 const report={attemptedWrites:1,modelUnchanged:true,journalAndSourceMetadataUnchanged:true,storedBytesUnchanged:true,stagedProposalRetained:true,noPhantomHoliday:true,revision:after.model.revision,pageErrors:errors,externalRequests:external};
 await page.evaluate(()=>{Storage.prototype.setItem=window.__qaNativeSetItem;});assert.deepEqual(errors,[]);assert.deepEqual(external,[]);await writeFile(evidence+'/calendar-write-failure-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}catch(e){await fail(page,'calendar-write',e);throw e;}finally{await context.close();}
