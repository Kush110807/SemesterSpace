# To Chat A — FV-01 final-browser recovery finding

**Recommendation: HOLD pending A/C disposition.** Owner: C (`src/ui/revision-review.js`); A integrates and D rechecks. Severity: medium / release-workflow P1 under the required delayed-response condition. This is a new recovery/liveness case; the previously accepted stale-apply safety guard still passes. No accepted data was corrupted or partially written.

Exact candidate: `SS_RC14_Final_Source_For_D.zip`, SHA-256 `5d4070ddbccdfaa0a714ff5bebf8f4ae12f8ea0759964db9f9611877214bafc0`. All 197 original payload files remain unchanged. No production fix is included.

## Minimal connected reproduction

Use `fv01-recovery-repro.mjs` and included synthetic QA seed/PDF, served from the installed candidate’s production `dist`. The harness exposes the actual controller through a DevTools breakpoint in main.js; extraction, UI, engine and controller are the real candidate modules.

1. Open Calendar updates, upload `synthetic-revision.pdf`, genuinely read it, explicitly review its page/scope/legacy metadata/effects/coverage, and prepare a comparison with zero unresolved items.
2. Hold only the delivery of the real `onProposeCalendarRevision` result with a Promise. The real A handler runs and returns REVIEW_REQUIRED; this is latency injection, not a mocked proposal or controller. The production handler is currently synchronous; no spontaneous production latency is claimed.
3. Click Stage, edit the prior-source review note while that result is delayed, then deliver the result.
4. Confirm that applying the old proposal is disabled (PASS).
5. Renew the edited review, prepare a fresh comparison with **0 unresolved items**, and check its stage consent.
6. **Actual:** Stage remains disabled indefinitely even after the prior response completed. Model revision and native stored bytes are unchanged. Rereading/replacing the document clears the stuck state and permits staging again.
7. **Expected:** a completed stale request must not authorize the old proposal, but must allow a fully reviewed current comparison to be staged.

The separate reproduction exits **1** on this expected-versus-actual assertion. `fv01-recovery-report.json`, `fv01-repro.log` and `14-fv01-new-comparison-stuck.png` retain the observations. The broader connected flow completed through an explicit reread workaround; that is not a pass for this recovery case.

## Source correspondence / repair boundary

At `src/ui/revision-review.js:48`, dirty() advances the generation and clears review/comparison consent but leaves `s.controller` unchanged. The staging handler sets it to `'stage'`; at lines 216–220 a stale completion returns and its finally block cleans up only when generation is unchanged. Line 222 disables staging while Boolean(s.controller). Thus the stale request no longer owns a useful proposal but leaves the busy guard set. Source replacement/reread resets it, explaining the observed workaround.

C/A should provide a bounded, independently reviewed cleanup that releases a completed obsolete request’s busy ownership without allowing it to clear a newer active request or authorize stale application. Do not remove generation/source/model checks. Re-run both delay cases, this recovery reproduction and the normal stage/select/apply/native-reopen path against a newly identified candidate. This report does not implement that change.
