import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {openProfile,shot,fail,state,evidence} from './browser-common.mjs';
import {prepareReview} from './review-helper.mjs';
const expected=JSON.parse(await readFile(evidence+'/expected-native-envelope.json'));
// This starts a new Chromium process on the closed profile, with NO storage seed/init script.
const {context,page,errors,consoleErrors,external}=await openProfile('connected-release-r3','2026-10-26T15:29:00Z');
const report={scenario:'New Chromium process, same native profile, no reseeding; real UI negative revisions',clock:'2026-10-26 20:59 Asia/Kolkata'};
try{
 const s=await state(page);assert.equal(s.persistence.status,'SAVED');assert.deepEqual(s.model,expected.model);assert.deepEqual(s.release,expected.release);assert.equal(s.stagedCalendarRevision,null);assert.equal(await page.evaluate(()=>window.__QA_APP__.getResults().evaluation.status),'PLAN_BLOCKED');
 report.nativeReopen={passed:true,revision:s.model.revision,snapshots:s.model.snapshots.length,journalRecords:s.release.attendance.records.length,sourceHistory:s.release.calendar.sourceRevision.sourceHistory,retainedCommitments:s.model.commitments.map(c=>c.id)};
 await page.getByRole('button',{name:'Calendar & breaks',exact:true}).click();await shot(page,'10-native-reopen-desktop');await shot(page,'11-native-reopen-mobile',true);await page.setViewportSize({width:1440,height:1000});
 const before=await page.evaluate(()=>localStorage.getItem('semesterspace.v1'));
 report.negative=[];
 for(const mode of ['ambiguous','insufficient']){
  await page.getByRole('button',{name:'Calendar updates',exact:true}).click();await page.getByLabel('Choose revised academic calendar PDF or image',{exact:true}).setInputFiles(evidence+'/synthetic-negative.pdf');await page.getByRole('button',{name:'Read selected calendar',exact:true}).click();await page.getByText(/Reader result: PARTIAL/).waitFor({timeout:180000});
  await prepareReview(page,{mode});const text=await page.locator('.revision-compare').innerText();assert.match(text,mode==='ambiguous'?/AMBIGUOUS_MATCH/:/REMOVAL_EVIDENCE|INEFFECTIVE_EVENT/);
  await page.evaluate(()=>{window.__qaStageResult=null;const callbacks=window.__QA_APP__.callbacks;window.__qaStageOriginal=callbacks.onProposeCalendarRevision;callbacks.onProposeCalendarRevision=req=>{const r=window.__qaStageOriginal(req);window.__qaStageResult=r;return r;};});
  await page.getByLabel('I have read this comparison and understand that staged items are not yet applied',{exact:true}).check();await page.getByRole('button',{name:'Stage reviewed proposal for selective application',exact:true}).click();await page.waitForFunction(()=>window.__qaStageResult!==null);
  const result=await page.evaluate(()=>window.__qaStageResult);assert.equal(result.ok,true); // Staging is explicitly ephemeral review, not acceptance.
  const uiApplyDisabled=await page.getByRole('button',{name:'Apply selected calendar changes',exact:true}).isDisabled();assert.ok(uiApplyDisabled);
  const directApply=await page.evaluate(()=>{const app=window.__QA_APP__,s=app.getState(),p=s.stagedCalendarRevision;return app.callbacks.onApplyCalendarRevision({expectedModelRevision:s.model.revision,proposalId:p.proposalId,acceptedChangeIds:p.changes.map(c=>c.changeId),confirmedSourceCoverage:true,historicalResolutions:[],confirmation:true});});
  assert.equal(directApply.ok,false);assert.equal(await page.evaluate(()=>localStorage.getItem('semesterspace.v1')),before);
  report.negative.push({mode,stagingResult:result,uiApplyDisabled,directActualControllerApply:directApply,comparison:text});await shot(page,mode==='ambiguous'?'12-ambiguous-rejected':'13-insufficient-evidence-rejected');
  await page.evaluate(()=>{window.__QA_APP__.callbacks.onProposeCalendarRevision=window.__qaStageOriginal;delete window.__qaStageOriginal;});
 }
 report.pageErrors=errors;report.consoleErrors=consoleErrors;report.externalRequests=external;assert.deepEqual(errors,[]);assert.deepEqual(external,[]);await writeFile(evidence+'/native-negative-report.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}catch(e){await fail(page,'native-negative',e);throw e;}finally{await context.close();}
