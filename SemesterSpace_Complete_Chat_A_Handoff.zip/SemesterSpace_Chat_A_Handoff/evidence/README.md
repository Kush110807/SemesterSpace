# Final verification evidence (no production changes)

Read FINAL_RELEASE_VERIFICATION.md, verification-results.json and CHAT_A_FV01_HANDOFF.md. The authoritative candidate archive SHA-256 is 5d4070ddbccdfaa0a714ff5bebf8f4ae12f8ea0759964db9f9611877214bafc0. All 197 original files remain unchanged. This evidence is not a source replacement or deployment package.

Screenshots 01–16 are actual production-dist browser captures. Logs and JSON reports preserve both passing cases and the FV-01 failure. Chromium profiles/node_modules/vendor/dist/source archives are excluded from the evidence ZIP; exported fixtures and saved envelopes contain synthetic QA data only.

## Reproduction

Use a fresh extraction of the exact candidate and install/build its pinned app. From its semester-space directory:

```sh
npm ci --no-audit --no-fund
npm run build
node --input-type=module -e "import('./tools/serve.mjs').then(({makeServer})=>makeServer(process.cwd()+'/dist').listen(5280,'127.0.0.1'))"
```

Use a fresh evidence working directory for each run, because connected-browser.mjs intentionally creates persistent profiles and expects a new synthetic seed. Copy qa-seed.json and synthetic-*.pdf from this packet to that working directory. Keep scripts together in the packet directory. Set environment variables (Linux example):

```sh
export SS_CANDIDATE_ROOT=/path/to/extracted/SemesterSpace
export SS_EVIDENCE_DIR=/path/to/fresh-qa-working-directory
export SS_ORIGIN=http://127.0.0.1:5280
export SS_CHROMIUM=/usr/bin/chromium
node initial-browser.mjs
node connected-browser.mjs
node native-and-negative.mjs
node calendar-write-failure.mjs
node fv01-recovery-repro.mjs
```

The first four browser commands exit 0 on this candidate; connected-browser.mjs records FV-01 and uses a reread workaround. The last command exits 1 while FV-01 remains. It uses the actual A callback with controlled delivery latency, not a mocked controller. Normal main entrypoint modules remain unchanged. DevTools exposes the actual controller for assertions and the test-only latency/Storage failure injections. Native reopen uses the closed persistent profile without reseeding. No scripts should be run on a personal browser profile or real student data.

EVIDENCE_INTEGRITY.sha256 covers all packet files except itself; the external ZIP SHA-256 covers the complete ZIP. Earlier failed harness attempts are retained and explained in the report. No application logic was modified and no code was pushed, merged, deployed or submitted.
