export async function prepareReview(page,{mode='positive'}={}){
 const check=async label=>page.getByLabel(label,{exact:true}).check();
 await page.locator('[data-revision-intake] details').evaluateAll(nodes=>nodes.forEach(n=>n.open=true));
 await page.getByLabel('Academic term',{exact:true}).selectOption('ODD');await page.getByLabel('Degree group',{exact:true}).selectOption('UG');
 await page.getByLabel('Practical subgroup',{exact:true}).fill('Q3');await page.getByLabel('Programming group',{exact:true}).fill('Q23');
 await check('I checked this notice against my actual course, cohort, and confirmed teaching dates');
 if(await page.getByLabel('I manually checked the original calendar and acknowledge that old source links cannot be reconstructed',{exact:true}).count()){
  await check('I manually checked the original calendar and acknowledge that old source links cannot be reconstructed');
  await page.getByLabel('Which prior documents and rows did you review?',{exact:true}).fill('SYNTHETIC QA: explicitly reviewed the prior source; no old links invented.');
 }
 await page.getByLabel('I compared original page 1 with extracted entries, captions and footnotes',{exact:true}).check();
 for(const card of await page.locator('[data-revision-effect]').all()){
  const json=card.getByLabel('Proposed calendar entry (editable JSON)',{exact:false});const after=JSON.parse(await json.inputValue());
  if('start' in after){after.start='10:00';after.end='11:00';if(mode==='insufficient'){
   const event=await page.evaluate(()=>window.__QA_APP__.getState().model.events[0]);Object.assign(after,event,{cancelled:true});await card.getByLabel('Existing target (only if verified)',{exact:true}).selectOption(event.id);
  }await json.fill(JSON.stringify(after,null,2));}
  if(mode==='insufficient'){await card.getByLabel('I matched this exact existing occurrence/source link',{exact:true}).check();await card.getByLabel('Reason for addition or matched identity',{exact:true}).fill('Deliberate synthetic negative QA: matching an existing event cannot authorize cancellation without affirmative evidence.');}
  await card.getByLabel('I verified this entry is applicable to my section/cohort',{exact:true}).check();await card.getByLabel('I checked the meaning and effective date against the source',{exact:true}).check();await card.getByLabel('Include this interpreted effect in the comparison',{exact:true}).check();
 }
 for(const x of await page.getByLabel('Exclude this source candidate after reviewing applicability',{exact:true}).all())await x.check();
 for(const x of await page.getByLabel('Evidence-based exclusion reason',{exact:true}).all())await x.fill('SYNTHETIC negative QA only: keep existing occurrences; this row does not justify changing them.');
 for(const x of await page.getByLabel('Keep the previously recorded calendar effect if absent from this extraction',{exact:true}).all())await x.check();
 for(const x of await page.getByLabel('Why the existing effect should be retained',{exact:true}).all())await x.fill('No affirmative withdrawal; retain the existing restriction and provenance.');
 await page.getByLabel('What did you manually verify on EVERY page (including legend, cohort, exams, notes, cancellations, rescheduling, end dates)?',{exact:true}).fill('SYNTHETIC QA only: compared every printed row, date and source page; no institutional or personal confirmations. No missing row was treated as deletion.');
 await check('I checked the source and manually resolved any relevant omissions (PARTIAL still means extraction was partial)');await check('I explicitly reviewed all interpretations, source evidence and exclusions before comparing');
 await page.getByRole('button',{name:'Prepare comparison (no schedule change)',exact:true}).click();await page.getByRole('heading',{name:'Comparison — not yet staged',exact:true}).waitFor();
}
