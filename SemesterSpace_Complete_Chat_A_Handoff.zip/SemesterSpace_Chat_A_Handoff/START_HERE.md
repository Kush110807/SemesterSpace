# Single-file SemesterSpace handoff for Chat A

1. Attach this ZIP to Chat A.
2. Open `PROMPT_FOR_CHAT_A.md` and paste its contents as your message.
3. Ask A to inspect the included evidence and use the exact candidate under `candidate/`.

Contents:
- `PROMPT_FOR_CHAT_A.md`: ready-to-paste task and constraints.
- `candidate/SS_RC14_Final_Source_For_D.zip`: exact original verified source archive, unchanged.
- `evidence/`: all verification reports/handoffs, logs, genuine browser screenshots, reproduction scripts and clearly synthetic QA fixtures. Browser profiles are excluded.
- `HANDOFF_INTEGRITY.sha256`: checksums for this handoff's files except the checksum manifest itself.

Recommendation: HOLD pending FV-01 disposition. This is packaging only; no application behavior was changed, merged, pushed, deployed or submitted. Read the full report for actual results and unrun boundaries.
