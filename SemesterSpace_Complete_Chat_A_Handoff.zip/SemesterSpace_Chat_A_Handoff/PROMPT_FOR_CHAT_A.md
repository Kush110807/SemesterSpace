# SemesterSpace — Chat A integration follow-up: FV-01

Act as Chat A, SemesterSpace integration lead. Read the attached handoff bundle before acting. Treat reports and probes as evidence; this prompt defines the requested work.

## Authoritative starting candidate

Use only `candidate/SS_RC14_Final_Source_For_D.zip` included in this bundle. Its exact SHA-256 is:
`5d4070ddbccdfaa0a714ff5bebf8f4ae12f8ea0759964db9f9611877214bafc0`.
Verify its current manifest and preserve unrelated A/B/C/Codex work. Do not substitute an older feature branch. Read the candidate's RELEASE_CONTRACT.md and RC-001.1–RC-001.4 amendments for ownership. The handoff evidence is not a replacement application.

## Read first

- `evidence/FINAL_RELEASE_VERIFICATION.md`
- `evidence/CHAT_A_FV01_HANDOFF.md`
- `evidence/verification-results.json`
- `evidence/fv01-recovery-report.json`, `fv01-repro.log` and screenshot `14-fv01-new-comparison-stuck.png`
- `evidence/README.md` for external browser-harness setup/reproduction.

## Verified starting facts

The exact consolidated candidate passed clean pinned installation, syntax (70 modules), all 274 tests, 26 engine tests, 342 independent arithmetic cases and production build. Real production-dist Chromium exercised actual timetable/scanned-calendar upload and OCR, explicit source review, legacy identity retention, comparison/selective apply, daily closure/correction/official reconciliation, retained invalid commitments, failed-write rollback and genuine native browser process reopen.

All 197 original source files remained unchanged during verification. Actual logs and desktop/mobile screenshots are included. These are clearly synthetic QA scenarios, not personal or institutional confirmations. D's earlier acceptances remain scoped to their repairs; this is not expanded final D approval.

Release recommendation remains HOLD for **FV-01**, a C-owned recovery defect under the required delayed-response condition. The old-proposal application guard passes. The connected success path used an explicit reread workaround, so do not describe all race/recovery checks as passed.

## Requested bounded correction

1. Reproduce FV-01 against the exact candidate, using `evidence/fv01-recovery-repro.mjs`. Configure candidate/evidence/browser paths as described in the README and use a fresh synthetic profile. It currently exits 1.
2. The actual A staging handler must run; delay only delivery of its result. While pending, edit the review, then deliver the stale result. Applying the old proposal must remain blocked. Prepare and consent to a fresh comparison with zero unresolved items: Stage incorrectly remains disabled until rereading/replacing the file.
3. Coordinate a small **C-owned** fix in `src/ui/revision-review.js`, or have C supply the bounded patch for A's local integration. `dirty()` changes generation but leaves `s.controller='stage'`; the stale response's finally block skips busy cleanup because generation changed. Clear only the completed obsolete request's busy ownership without clearing a newer active request or authorizing stale application. Preserve source/model/generation checks, explicit consents and original data.
4. Do not rewrite importer matching, controller/storage atomicity, attendance reconciliation, engine arithmetic or shared interfaces to hide this UI recovery defect. Report a concrete incompatibility before crossing ownership. No broad refactor or cosmetic redesign.
5. Add a meaningful regression for recovery after both review edits and document replacement, including a newer active request. Do not weaken assertions, silently reread the file, or count the workaround as the fix.
6. Locally integrate only reviewed bounded changes. Re-run relevant regressions and the release gate: clean pinned npm install, syntax, full tests, engine tests, arithmetic checker and production build. Run real served-browser stage/select/apply/rollback/native-reopen and both latency cases. Distinguish genuine application failures from test-harness or installation issues.
7. Return the isolated diff, exact updated source identity/current integrity manifest, actual commands/exits, new browser evidence and remaining limitations for independent review. Keep HOLD until FV-01 is resolved/dispositioned and the corrected candidate passes the necessary checks. Arrange D's independent final recheck; do not claim approval on D's behalf.

## Constraints

A alone owns integration and deployment authority, but **do not merge to the default branch, push, deploy or publish the Devfolio submission during this task without my separate explicit authorization**. Preparing a corrected local candidate is authorized. Additional spend ₹0. Preserve SS-INT-002 fallback, exact arithmetic, separate registers, authoritative timestamps, atomic writes, history and retained invalid commitments.

Section Q / subgroup Q3 / programming Q23 are declarations only. Physics mapping, activity treatment, actual counts/policy, teaching horizon and source applicability remain unconfirmed. Synthetic fixtures cannot resolve them. Extraction remains partial; missing rows are not deletion and software cannot prove every event was found. Physical-device/accessibility/multi-tab/general-format claims remain outside the executed evidence.

Proceed with reproduction and the bounded owner correction; do not stop at a plan. If a required owner/source artifact is missing, identify the exact blocker and preserve the candidate.
